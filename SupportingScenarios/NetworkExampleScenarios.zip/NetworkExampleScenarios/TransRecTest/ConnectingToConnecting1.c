stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Chain

    Name		 ConnectingToConnecting1
    BEGIN Definition

        Object		 Constellation/SatTrans
        Object		 Constellation/SatRec
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 Yes
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 86400
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 15 Jun 2020 19:00:00.000000000
                Stop		 16 Jun 2020 19:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        SaveIntervalFile		 C:\Users\ACLAYB~1\AppData\Local\Temp\STK16536\strand.int
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        BEGIN StrandObjIndexes
            StrandObj		 Satellite/LEO11/Transmitter/Transmitter3
            StrandObj		 Satellite/LEO12/Transmitter/Transmitter4
            StrandObj		 Satellite/LEO13/Transmitter/Transmitter5
            StrandObj		 Satellite/LEO14/Transmitter/Transmitter6
            StrandObj		 Satellite/LEO15/Transmitter/Transmitter7
            StrandObj		 Satellite/LEO16/Transmitter/Transmitter8
            StrandObj		 Satellite/LEO21/Transmitter/Transmitter9
            StrandObj		 Satellite/LEO22/Transmitter/Transmitter12
            StrandObj		 Satellite/LEO23/Transmitter/Transmitter13
            StrandObj		 Satellite/LEO24/Transmitter/Transmitter14
            StrandObj		 Satellite/LEO25/Transmitter/Transmitter15
            StrandObj		 Satellite/LEO26/Transmitter/Transmitter16
            StrandObj		 Satellite/LEO31/Transmitter/Transmitter17
            StrandObj		 Satellite/LEO32/Transmitter/Transmitter18
            StrandObj		 Satellite/LEO33/Transmitter/Transmitter19
            StrandObj		 Satellite/LEO34/Transmitter/Transmitter20
            StrandObj		 Satellite/LEO35/Transmitter/Transmitter21
            StrandObj		 Satellite/LEO36/Transmitter/Transmitter22
            StrandObj		 Satellite/LEO41/Transmitter/Transmitter23
            StrandObj		 Satellite/LEO42/Transmitter/Transmitter24
            StrandObj		 Satellite/LEO43/Transmitter/Transmitter25
            StrandObj		 Satellite/LEO44/Transmitter/Transmitter26
            StrandObj		 Satellite/LEO45/Transmitter/Transmitter27
            StrandObj		 Satellite/LEO46/Transmitter/Transmitter28
            StrandObj		 Satellite/LEO51/Transmitter/Transmitter29
            StrandObj		 Satellite/LEO52/Transmitter/Transmitter30
            StrandObj		 Satellite/LEO53/Transmitter/Transmitter31
            StrandObj		 Satellite/LEO54/Transmitter/Transmitter32
            StrandObj		 Satellite/LEO55/Transmitter/Transmitter33
            StrandObj		 Satellite/LEO56/Transmitter/Transmitter34
            StrandObj		 Satellite/LEO61/Transmitter/Transmitter35
            StrandObj		 Satellite/LEO62/Transmitter/Transmitter36
            StrandObj		 Satellite/LEO63/Transmitter/Transmitter37
            StrandObj		 Satellite/LEO64/Transmitter/Transmitter38
            StrandObj		 Satellite/LEO65/Transmitter/Transmitter39
            StrandObj		 Satellite/LEO66/Transmitter/Transmitter40
            StrandObj		 Satellite/LEO11/Receiver/Receiver3
            StrandObj		 Satellite/LEO12/Receiver/Receiver4
            StrandObj		 Satellite/LEO13/Receiver/Receiver5
            StrandObj		 Satellite/LEO14/Receiver/Receiver6
            StrandObj		 Satellite/LEO15/Receiver/Receiver9
            StrandObj		 Satellite/LEO16/Receiver/Receiver10
            StrandObj		 Satellite/LEO21/Receiver/Receiver11
            StrandObj		 Satellite/LEO22/Receiver/Receiver12
            StrandObj		 Satellite/LEO23/Receiver/Receiver13
            StrandObj		 Satellite/LEO24/Receiver/Receiver14
            StrandObj		 Satellite/LEO25/Receiver/Receiver15
            StrandObj		 Satellite/LEO26/Receiver/Receiver16
            StrandObj		 Satellite/LEO31/Receiver/Receiver17
            StrandObj		 Satellite/LEO32/Receiver/Receiver18
            StrandObj		 Satellite/LEO33/Receiver/Receiver19
            StrandObj		 Satellite/LEO34/Receiver/Receiver20
            StrandObj		 Satellite/LEO35/Receiver/Receiver21
            StrandObj		 Satellite/LEO36/Receiver/Receiver22
            StrandObj		 Satellite/LEO41/Receiver/Receiver23
            StrandObj		 Satellite/LEO42/Receiver/Receiver24
            StrandObj		 Satellite/LEO43/Receiver/Receiver25
            StrandObj		 Satellite/LEO44/Receiver/Receiver26
            StrandObj		 Satellite/LEO45/Receiver/Receiver27
            StrandObj		 Satellite/LEO46/Receiver/Receiver28
            StrandObj		 Satellite/LEO51/Receiver/Receiver29
            StrandObj		 Satellite/LEO52/Receiver/Receiver30
            StrandObj		 Satellite/LEO53/Receiver/Receiver31
            StrandObj		 Satellite/LEO54/Receiver/Receiver32
            StrandObj		 Satellite/LEO55/Receiver/Receiver33
            StrandObj		 Satellite/LEO56/Receiver/Receiver34
            StrandObj		 Satellite/LEO61/Receiver/Receiver35
            StrandObj		 Satellite/LEO62/Receiver/Receiver36
            StrandObj		 Satellite/LEO63/Receiver/Receiver37
            StrandObj		 Satellite/LEO64/Receiver/Receiver38
            StrandObj		 Satellite/LEO65/Receiver/Receiver39
            StrandObj		 Satellite/LEO66/Receiver/Receiver40
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 37
            Strand		 0 38
            Strand		 0 39
            Strand		 0 40
            Strand		 0 41
            Strand		 0 42
            Strand		 0 43
            Strand		 0 44
            Strand		 0 45
            Strand		 0 46
            Strand		 0 47
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 0 48
            Strand		 0 49
            Strand		 0 50
            Strand		 0 51
            Strand		 0 52
            Start		  1.6094145343198797e+03
            Stop		  2.7998371357533806e+03
            Start		  4.4439461440979376e+03
            Stop		  5.6343717598449075e+03
            Start		  7.2784728638520746e+03
            Stop		  8.4689023552405761e+03
            Start		  1.0113003537412209e+04
            Stop		  1.1303433066648764e+04
            Start		  1.2947534244166221e+04
            Stop		  1.4137963774736374e+04
            Start		  1.5782064949431437e+04
            Stop		  1.6972494484032068e+04
            Start		  1.8616595654375869e+04
            Stop		  1.9807025194313097e+04
            Start		  2.1451126359150694e+04
            Stop		  2.2641555905553199e+04
            Start		  2.4285657063967436e+04
            Stop		  2.5476086617671874e+04
            Start		  2.7120187769033193e+04
            Stop		  2.8310617330550696e+04
            Start		  2.9954718474544279e+04
            Stop		  3.1145148044037840e+04
            Start		  3.2789249180677478e+04
            Stop		  3.3979678757954738e+04
            Start		  3.5623779887582306e+04
            Stop		  3.6814209472103947e+04
            Start		  3.8458310595374380e+04
            Stop		  3.9648740186277748e+04
            Start		  4.1292841304130401e+04
            Stop		  4.2483270900267358e+04
            Start		  4.4127372013884778e+04
            Stop		  4.5317801613872034e+04
            Start		  4.6961902724628118e+04
            Stop		  4.8152332326907883e+04
            Start		  4.9796433436307627e+04
            Stop		  5.0986863039216005e+04
            Start		  5.2630964148829444e+04
            Stop		  5.3821393750669347e+04
            Start		  5.5465494862062726e+04
            Stop		  5.6655924461178431e+04
            Start		  5.8300025575845488e+04
            Stop		  5.9490455170695095e+04
            Start		  6.1134556289991553e+04
            Stop		  6.2324985879214742e+04
            Start		  6.3969087004298905e+04
            Stop		  6.5159516586776590e+04
            Start		  6.6803617718558467e+04
            Stop		  6.7994047293461743e+04
            Start		  6.9638148432563205e+04
            Stop		  7.0828577999389789e+04
            Start		  7.2472679146117385e+04
            Stop		  7.3663108704713595e+04
            Start		  7.5307209859045019e+04
            Stop		  7.6497639409612297e+04
            Start		  7.8141740571197734e+04
            Stop		  7.9332170114283901e+04
            Start		  8.0976271282461079e+04
            Stop		  8.2166700818936151e+04
            Start		  8.3810801992759734e+04
            Stop		  8.5001231523777649e+04
            Strand		 0 53
            Strand		 0 54
            Strand		 0 55
            Strand		 0 56
            Start		  0.0000000000000000e+00
            Stop		  6.6965530014730246e+02
            Start		  2.6372798841694562e+03
            Stop		  3.5041865919649958e+03
            Start		  5.4718115502011005e+03
            Stop		  6.3387166104123362e+03
            Start		  8.3063414733090976e+03
            Stop		  9.1732476195540730e+03
            Start		  1.1140872968719254e+04
            Stop		  1.2007777900235273e+04
            Start		  1.3975401633699887e+04
            Stop		  1.4842308849288278e+04
            Start		  1.6809934388832578e+04
            Stop		  1.7676839261185589e+04
            Start		  1.9644464929748065e+04
            Stop		  2.0511370201299054e+04
            Start		  2.2478995810397286e+04
            Stop		  2.3345900658277249e+04
            Start		  2.5313526086006786e+04
            Stop		  2.6180431596520022e+04
            Start		  2.8148057232982232e+04
            Stop		  2.9014962068001292e+04
            Start		  3.0982587421412947e+04
            Stop		  3.1849493005391043e+04
            Start		  3.3817118655958307e+04
            Stop		  3.4684023481341334e+04
            Start		  3.6651648815450892e+04
            Stop		  3.7518554418251450e+04
            Start		  3.9486180078621357e+04
            Stop		  4.0353084895583073e+04
            Start		  4.2320710228164236e+04
            Stop		  4.3187615832366762e+04
            Start		  4.5155241500319193e+04
            Stop		  4.6022146310310927e+04
            Start		  4.7989771646029862e+04
            Stop		  4.8856677247327068e+04
            Start		  5.0824302920566312e+04
            Stop		  5.1691207725855129e+04
            Start		  5.3658833064404840e+04
            Stop		  5.4525738663418910e+04
            Start		  5.6493364339128690e+04
            Stop		  5.7360269142680903e+04
            Start		  5.9327894481785894e+04
            Stop		  6.0194800081011541e+04
            Start		  6.2162425756064542e+04
            Stop		  6.3029330561122697e+04
            Start		  6.4996955897909182e+04
            Stop		  6.5863861500306113e+04
            Start		  6.7831487171714252e+04
            Stop		  6.8698391981264940e+04
            Start		  7.0666017313081873e+04
            Stop		  7.1532922921238947e+04
            Start		  7.3500548586641293e+04
            Stop		  7.4367453402907020e+04
            Start		  7.6335078727892673e+04
            Stop		  7.7201984343472272e+04
            Start		  7.9169610001534413e+04
            Stop		  8.0036514825591410e+04
            Start		  8.2004140143031313e+04
            Stop		  8.2871045766445997e+04
            Start		  8.4838671417087797e+04
            Stop		  8.5705576248680998e+04
            Strand		 0 57
            Start		  0.0000000000000000e+00
            Stop		  1.9722289947313610e+02
            Start		  2.1648677615005054e+03
            Stop		  3.0317538561614560e+03
            Start		  4.9994001928985581e+03
            Stop		  5.8662842294143720e+03
            Start		  7.8339309355981159e+03
            Stop		  8.7008151686656583e+03
            Start		  1.0668461612640160e+04
            Stop		  1.1535345612633368e+04
            Start		  1.3502991941217953e+04
            Stop		  1.4369876550350375e+04
            Start		  1.6337523030664985e+04
            Stop		  1.7204407018637081e+04
            Start		  1.9172053222877596e+04
            Stop		  2.0038937956911835e+04
            Start		  2.2006584447162913e+04
            Stop		  2.2873468433859951e+04
            Start		  2.4841114594072711e+04
            Stop		  2.5707999372946011e+04
            Start		  2.7675645862578240e+04
            Stop		  2.8542529853280816e+04
            Start		  3.0510175994413163e+04
            Stop		  3.1377060793086421e+04
            Start		  3.3344707277539725e+04
            Stop		  3.4211591274891412e+04
            Start		  3.6179237404533684e+04
            Stop		  3.7046122215174859e+04
            Start		  3.9013768692753954e+04
            Stop		  3.9880652697583864e+04
            Start		  4.1848298818516887e+04
            Stop		  4.2715183638016861e+04
            Start		  4.4682830108883398e+04
            Stop		  4.5549714120490520e+04
            Start		  4.7517360234772234e+04
            Stop		  4.8384245060718051e+04
            Start		  5.0351891526431718e+04
            Stop		  5.1218775542848467e+04
            Start		  5.3186421652965953e+04
            Stop		  5.4053306482550950e+04
            Start		  5.6020952945656303e+04
            Stop		  5.6887836964036986e+04
            Start		  5.8855483072973788e+04
            Stop		  5.9722367902985883e+04
            Start		  6.1690014366523654e+04
            Stop		  6.2556898383653781e+04
            Start		  6.4524544494537004e+04
            Stop		  6.5391429321751304e+04
            Start		  6.7359075788715243e+04
            Stop		  6.8225959801574470e+04
            Start		  7.0193605917186796e+04
            Stop		  7.1060490738870547e+04
            Start		  7.3028137211682813e+04
            Stop		  7.3895021217970643e+04
            Start		  7.5862667340285581e+04
            Stop		  7.6729552154654317e+04
            Start		  7.8697198634743647e+04
            Stop		  7.9564082633279046e+04
            Start		  8.1531728763124644e+04
            Stop		  8.2398613569645473e+04
            Start		  8.4366260057199193e+04
            Stop		  8.5233144048125119e+04
            Strand		 0 58
            Strand		 0 59
            Strand		 0 60
            Strand		 0 61
            Start		  3.4676244852060549e+01
            Stop		  1.2251025081161881e+03
            Start		  2.8692021993494600e+03
            Stop		  4.0596330609879819e+03
            Start		  5.7037328223378117e+03
            Stop		  6.8941637797666990e+03
            Start		  8.5382635304940104e+03
            Stop		  9.7286944937733188e+03
            Start		  1.1372794238512777e+04
            Stop		  1.2563225207971327e+04
            Start		  1.4207324947569767e+04
            Stop		  1.5397755921886808e+04
            Start		  1.7041855657622633e+04
            Stop		  1.8232286635338744e+04
            Start		  1.9876386368646614e+04
            Stop		  2.1066817348151806e+04
            Start		  2.2710917080570885e+04
            Stop		  2.3901348060180087e+04
            Start		  2.5545447793285304e+04
            Stop		  2.6735878771311814e+04
            Start		  2.8379978506645068e+04
            Stop		  2.9570409481474613e+04
            Start		  3.1214509220477019e+04
            Stop		  3.2404940190638587e+04
            Start		  3.4049039934587221e+04
            Stop		  3.5239470898817781e+04
            Start		  3.6883570648769535e+04
            Stop		  3.8074001606069374e+04
            Start		  3.9718101362814588e+04
            Stop		  4.0908532312491356e+04
            Start		  4.2552632076519025e+04
            Stop		  4.3743063018218105e+04
            Start		  4.5387162789694397e+04
            Stop		  4.6577593723414553e+04
            Start		  4.8221693502175476e+04
            Stop		  4.9412124428268879e+04
            Start		  5.1056224213827445e+04
            Stop		  5.2246655132984306e+04
            Start		  5.3890754924551889e+04
            Stop		  5.5081185837770157e+04
            Start		  5.6725285634291067e+04
            Stop		  5.7915716542832670e+04
            Start		  5.9559816343030398e+04
            Stop		  6.0750247248365929e+04
            Start		  6.2394347050799239e+04
            Stop		  6.3584777954543402e+04
            Start		  6.5228877757669441e+04
            Stop		  6.6419308661510222e+04
            Start		  6.8063408463752305e+04
            Stop		  6.9253839369376947e+04
            Start		  7.0897939169193618e+04
            Stop		  7.2088370078214648e+04
            Start		  7.3732469874167306e+04
            Stop		  7.4922900788051658e+04
            Start		  7.6567000578867795e+04
            Stop		  7.7757431498872626e+04
            Start		  7.9401531283501434e+04
            Stop		  8.0591962210618920e+04
            Start		  8.2236061988277375e+04
            Stop		  8.3426492923191385e+04
            Start		  8.5070592693398678e+04
            Stop		  8.6261023970334165e+04
            Strand		 0 62
            Strand		 0 63
            Strand		 0 64
            Strand		 0 65
            Strand		 0 66
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 0 67
            Strand		 0 68
            Strand		 0 69
            Strand		 0 70
            Strand		 0 71
            Strand		 1 36
            Strand		 1 38
            Strand		 1 39
            Strand		 1 40
            Strand		 1 41
            Strand		 1 42
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 1 43
            Strand		 1 44
            Strand		 1 45
            Strand		 1 46
            Strand		 1 47
            Strand		 1 48
            Strand		 1 49
            Strand		 1 50
            Strand		 1 51
            Strand		 1 52
            Strand		 1 53
            Start		  6.6456786119240587e+02
            Stop		  1.8549973758664783e+03
            Start		  3.4990985543558804e+03
            Stop		  4.6895280840516389e+03
            Start		  6.3336292626605209e+03
            Stop		  7.5240587901668723e+03
            Start		  9.1681599694815322e+03
            Stop		  1.0358589497232726e+04
            Start		  1.2002690675570806e+04
            Stop		  1.3193120205206242e+04
            Start		  1.4837221381047182e+04
            Stop		  1.6027650914158537e+04
            Start		  1.7671752086090488e+04
            Stop		  1.8862181624109999e+04
            Start		  2.0506282790898116e+04
            Stop		  2.1696712335037442e+04
            Start		  2.3340813495677616e+04
            Stop		  2.4531243046874592e+04
            Start		  2.6175344200637825e+04
            Stop		  2.7365773759515385e+04
            Start		  2.9009874905979697e+04
            Stop		  3.0200304472818432e+04
            Start		  3.1844405611887429e+04
            Stop		  3.3034835186613265e+04
            Start		  3.4678936318520406e+04
            Stop		  3.5869365900707766e+04
            Start		  3.7513467026006198e+04
            Stop		  3.8703896614896708e+04
            Start		  4.0347997734434939e+04
            Stop		  4.1538427328970611e+04
            Start		  4.3182528443855408e+04
            Stop		  4.4372958042725026e+04
            Start		  4.6017059154272829e+04
            Stop		  4.7207488755969549e+04
            Start		  4.8851589865648777e+04
            Stop		  5.0042019468536047e+04
            Start		  5.1686120577902628e+04
            Stop		  5.2876550180286235e+04
            Start		  5.4520651290915368e+04
            Stop		  5.5711080891117512e+04
            Start		  5.7355182004534596e+04
            Stop		  5.8545611600967655e+04
            Start		  6.0189712718581388e+04
            Stop		  6.1380142309817449e+04
            Start		  6.3024243432858078e+04
            Stop		  6.4214673017691573e+04
            Start		  6.5858774147156830e+04
            Stop		  6.7049203724657447e+04
            Start		  6.8693304861269018e+04
            Stop		  6.9883734430822427e+04
            Start		  7.1527835574994067e+04
            Stop		  7.2718265136328861e+04
            Start		  7.4362366288148580e+04
            Stop		  7.5552795841348023e+04
            Start		  7.7196897000574099e+04
            Stop		  7.8387326546072552e+04
            Start		  8.0031427712144272e+04
            Stop		  8.1221857250707908e+04
            Start		  8.2865958422770316e+04
            Stop		  8.4056387955463477e+04
            Start		  8.5700489132404851e+04
            Stop		  8.6400000000000000e+04
            Strand		 1 54
            Strand		 1 55
            Strand		 1 56
            Strand		 1 57
            Start		  1.6924371143649169e+03
            Stop		  2.5593430960925675e+03
            Start		  4.5269679805755541e+03
            Stop		  5.3938729255025073e+03
            Start		  7.3614967792395182e+03
            Stop		  8.2284038794234439e+03
            Start		  1.0196029398928336e+04
            Stop		  1.1062934277381881e+04
            Start		  1.3030560026027575e+04
            Stop		  1.3897465218969828e+04
            Start		  1.5865090818729248e+04
            Stop		  1.6731995671959550e+04
            Start		  1.8699621122196935e+04
            Stop		  1.9566526611253641e+04
            Start		  2.1534152240058782e+04
            Stop		  2.2401057082019088e+04
            Start		  2.4368682437544721e+04
            Stop		  2.5235588020262850e+04
            Start		  2.7203213662508249e+04
            Stop		  2.8070118496383719e+04
            Start		  3.0037743825157111e+04
            Stop		  3.0904649433853283e+04
            Start		  3.2872275085465859e+04
            Stop		  3.3739179911378407e+04
            Start		  3.5706805236481960e+04
            Stop		  3.6573710848337010e+04
            Start		  3.8541336508228742e+04
            Stop		  3.9408241326187992e+04
            Start		  4.1375866655046520e+04
            Stop		  4.2242772262965351e+04
            Start		  4.4210397930126739e+04
            Stop		  4.5077302741038373e+04
            Start		  4.7044928075033815e+04
            Stop		  4.7911833677991381e+04
            Start		  4.9879459350639394e+04
            Stop		  5.0746364156485222e+04
            Start		  5.2713989494312889e+04
            Stop		  5.3580895093939129e+04
            Start		  5.5548520769486560e+04
            Stop		  5.6415425573092332e+04
            Start		  5.8383050912175560e+04
            Stop		  5.9249956511285207e+04
            Start		  6.1217582186676984e+04
            Stop		  6.2084486991259211e+04
            Start		  6.4052112328589210e+04
            Stop		  6.4919017930300783e+04
            Start		  6.6886643602506912e+04
            Stop		  6.7753548411126947e+04
            Start		  6.9721173743914740e+04
            Stop		  7.0588079350979606e+04
            Start		  7.2555705017508575e+04
            Stop		  7.3422609832545437e+04
            Start		  7.5390235158748706e+04
            Stop		  7.6257140773030944e+04
            Start		  7.8224766432357705e+04
            Stop		  7.9091671255097026e+04
            Start		  8.1059296573788364e+04
            Stop		  8.1926202195927224e+04
            Start		  8.3893827847756329e+04
            Stop		  8.4760732678167886e+04
            Strand		 1 58
            Start		  1.2200259122785103e+03
            Stop		  2.0869098641939686e+03
            Start		  4.0545556124598943e+03
            Stop		  4.9214408018951954e+03
            Start		  6.8890873330477325e+03
            Stop		  7.7559713056611890e+03
            Start		  9.7236173178091594e+03
            Stop		  1.0590502242734074e+04
            Start		  1.2558148752183297e+04
            Stop		  1.3425032730417048e+04
            Start		  1.5392678831115711e+04
            Stop		  1.6259563668101908e+04
            Start		  1.8227210169654896e+04
            Stop		  1.9094094151064852e+04
            Start		  2.1061740279324105e+04
            Stop		  2.1928625089584737e+04
            Start		  2.3896271585728380e+04
            Stop		  2.4763155571574382e+04
            Start		  2.6730801705297010e+04
            Stop		  2.7597686510914893e+04
            Start		  2.9565333000915231e+04
            Stop		  3.0432216993056303e+04
            Start		  3.2399863123731382e+04
            Stop		  3.3266747933052291e+04
            Start		  3.5234394415881747e+04
            Stop		  3.6101278415521650e+04
            Start		  3.8068924539994237e+04
            Stop		  3.8935809355893660e+04
            Start		  4.0903455831332984e+04
            Stop		  4.1770339838505155e+04
            Start		  4.3737985956306824e+04
            Stop		  4.4604870778908502e+04
            Start		  4.6572517247890115e+04
            Stop		  4.7439401261350693e+04
            Start		  4.9407047373716508e+04
            Stop		  5.0273932201435207e+04
            Start		  5.2241578665982495e+04
            Stop		  5.3108462683392638e+04
            Start		  5.5076108792694991e+04
            Stop		  5.5942993622863469e+04
            Start		  5.7910640085773062e+04
            Stop		  5.8777524104093754e+04
            Start		  6.0745170213314268e+04
            Stop		  6.1612055042762549e+04
            Start		  6.3579701507130150e+04
            Stop		  6.4446585523145804e+04
            Start		  6.6414231635319506e+04
            Stop		  6.7281116460963356e+04
            Start		  6.9248762929650227e+04
            Stop		  7.0115646940525578e+04
            Start		  7.2083293058201554e+04
            Stop		  7.2950177877590395e+04
            Start		  7.4917824352728087e+04
            Stop		  7.5784708356499526e+04
            Start		  7.7752354481294577e+04
            Stop		  7.8619239293040737e+04
            Start		  8.0586885775661984e+04
            Stop		  8.1453769771577950e+04
            Start		  8.3421415903895017e+04
            Stop		  8.4288300707915449e+04
            Start		  8.6255945036712234e+04
            Stop		  8.6400000000000000e+04
            Strand		 1 59
            Strand		 1 60
            Strand		 1 61
            Strand		 1 62
            Start		  0.0000000000000000e+00
            Stop		  2.8025479236399690e+02
            Start		  1.9243623393038069e+03
            Stop		  3.1147895949674148e+03
            Start		  4.7588892837847397e+03
            Stop		  5.9493202043726787e+03
            Start		  7.5934199604822170e+03
            Stop		  8.7838509225603866e+03
            Start		  1.0427950669093545e+04
            Stop		  1.1618381636585451e+04
            Start		  1.3262481377771612e+04
            Stop		  1.4452912350624285e+04
            Start		  1.6097012087494944e+04
            Stop		  1.7287443064250951e+04
            Start		  1.8931542798200895e+04
            Stop		  2.0121973777294741e+04
            Start		  2.1766073509835471e+04
            Stop		  2.2956504489598865e+04
            Start		  2.4600604222300997e+04
            Stop		  2.5791035201039515e+04
            Start		  2.7435134935463637e+04
            Stop		  2.8625565911530757e+04
            Start		  3.0269665649158873e+04
            Stop		  3.1460096621028300e+04
            Start		  3.3104196363198818e+04
            Stop		  3.4294627329531482e+04
            Start		  3.5938727077380398e+04
            Stop		  3.7129158037083333e+04
            Start		  3.8773257791494281e+04
            Stop		  3.9963688743768602e+04
            Start		  4.1607788505334102e+04
            Stop		  4.2798219449710152e+04
            Start		  4.4442319218705488e+04
            Stop		  4.5632750155063448e+04
            Start		  4.7276849931434612e+04
            Stop		  4.8467280860009814e+04
            Start		  5.0111380643375807e+04
            Stop		  5.1301811564748357e+04
            Start		  5.2945911354417920e+04
            Stop		  5.4136342269487497e+04
            Start		  5.5780442064489296e+04
            Stop		  5.6970872974435450e+04
            Start		  5.8614972773560810e+04
            Stop		  5.9805403679791336e+04
            Start		  6.1449503481647225e+04
            Stop		  6.2639934385736400e+04
            Start		  6.4284034188806472e+04
            Stop		  6.5474465092426006e+04
            Start		  6.7118564895137155e+04
            Stop		  6.8308995799982862e+04
            Start		  6.9953095600774250e+04
            Stop		  7.1143526508491545e+04
            Start		  7.2787626305883052e+04
            Stop		  7.3978057217994996e+04
            Start		  7.5622157010652096e+04
            Stop		  7.6812587928492387e+04
            Start		  7.8456687715284701e+04
            Stop		  7.9647118639939348e+04
            Start		  8.1291218419990168e+04
            Stop		  8.2481649352249806e+04
            Start		  8.4125749124974565e+04
            Stop		  8.5316180065299806e+04
            Strand		 1 63
            Strand		 1 64
            Strand		 1 65
            Strand		 1 66
            Strand		 1 67
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 1 68
            Strand		 1 69
            Strand		 1 70
            Strand		 1 71
            Strand		 2 36
            Strand		 2 37
            Strand		 2 39
            Strand		 2 40
            Strand		 2 41
            Strand		 2 42
            Strand		 2 43
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 2 44
            Strand		 2 45
            Strand		 2 46
            Strand		 2 47
            Strand		 2 48
            Start		  0.0000000000000000e+00
            Stop		  9.1015393277150042e+02
            Start		  2.5542550489236196e+03
            Stop		  3.7446845112121496e+03
            Start		  5.3887856925896494e+03
            Stop		  6.5792152215510278e+03
            Start		  8.2233164006708503e+03
            Stop		  9.4137459281047013e+03
            Start		  1.1057847106948469e+04
            Stop		  1.2248276635775743e+04
            Start		  1.3892377812612545e+04
            Stop		  1.5082807344396846e+04
            Start		  1.6726908517778960e+04
            Stop		  1.7917338054015647e+04
            Start		  1.9561439222642395e+04
            Stop		  2.0751868764623086e+04
            Start		  2.2395969927407932e+04
            Stop		  2.3586399476166898e+04
            Start		  2.5230500632285006e+04
            Stop		  2.6420930188553877e+04
            Start		  2.8065031337478194e+04
            Stop		  2.9255460901653823e+04
            Start		  3.0899562043178201e+04
            Stop		  3.2089991615305164e+04
            Start		  3.3734092749553551e+04
            Stop		  3.4924522329322113e+04
            Start		  3.6568623456743117e+04
            Stop		  3.7759053043502841e+04
            Start		  3.9403154164850013e+04
            Stop		  4.0593583757638226e+04
            Start		  4.2237684873937164e+04
            Stop		  4.3428114471521178e+04
            Start		  4.5072215584024387e+04
            Stop		  4.6262645184955603e+04
            Start		  4.7906746295087760e+04
            Stop		  4.9097175897765097e+04
            Start		  5.0741277007060380e+04
            Stop		  5.1931706609800662e+04
            Start		  5.3575807719835560e+04
            Stop		  5.4766237320947221e+04
            Start		  5.6410338433271369e+04
            Stop		  5.7600768031128689e+04
            Start		  5.9244869147196856e+04
            Stop		  6.0435298740311344e+04
            Start		  6.2079399861419683e+04
            Stop		  6.3269829448505254e+04
            Start		  6.4913930575734405e+04
            Stop		  6.6104360155763861e+04
            Start		  6.7748461289931642e+04
            Stop		  6.8938890862181608e+04
            Start		  7.0582992003807129e+04
            Stop		  7.1773421567889804e+04
            Start		  7.3417522717170796e+04
            Stop		  7.4607952273050876e+04
            Start		  7.6252053429855077e+04
            Stop		  7.7442482977851221e+04
            Start		  7.9086584141722225e+04
            Stop		  8.0277013682493067e+04
            Start		  8.1921114852670333e+04
            Stop		  8.3111544387185437e+04
            Start		  8.4755645562637932e+04
            Stop		  8.5946075092135172e+04
            Strand		 2 49
            Strand		 2 50
            Strand		 2 51
            Strand		 2 52
            Strand		 2 53
            Strand		 2 54
            Strand		 2 55
            Strand		 2 56
            Strand		 2 57
            Strand		 2 58
            Start		  7.4759219830210077e+02
            Stop		  1.6144986041015907e+03
            Start		  3.5821244082849180e+03
            Stop		  4.4490298801742392e+03
            Start		  6.4166551196774717e+03
            Stop		  7.2835601958344550e+03
            Start		  9.2511852399373820e+03
            Stop		  1.0118091217542442e+04
            Start		  1.2085716538602936e+04
            Stop		  1.2952621478923893e+04
            Start		  1.4920245268052422e+04
            Stop		  1.5787152429732760e+04
            Start		  1.7754777958992716e+04
            Stop		  1.8621682834384097e+04
            Start		  2.0589308541716146e+04
            Stop		  2.1456213774593703e+04
            Start		  2.3423839380769758e+04
            Stop		  2.4290744229046777e+04
            Start		  2.6258369670126205e+04
            Stop		  2.7125275167190091e+04
            Start		  2.9092900803468980e+04
            Stop		  2.9959805637764784e+04
            Start		  3.1927430996422805e+04
            Stop		  3.2794336575063433e+04
            Start		  3.4761962226442505e+04
            Stop		  3.5628867050680274e+04
            Start		  3.7596492387379236e+04
            Stop		  3.8463397987546894e+04
            Start		  4.0431023648986979e+04
            Stop		  4.1297928464776829e+04
            Start		  4.3265553798925437e+04
            Stop		  4.4132459401575572e+04
            Start		  4.6100085070470857e+04
            Stop		  4.6966989879535329e+04
            Start		  4.8934615216213031e+04
            Stop		  4.9801520816623088e+04
            Start		  5.1769146490445804e+04
            Stop		  5.2636051295237630e+04
            Start		  5.4603676634195253e+04
            Stop		  5.5470582232917317e+04
            Start		  5.7438207908725031e+04
            Stop		  5.8305112712307229e+04
            Start		  6.0272738051270353e+04
            Stop		  6.1139643650778016e+04
            Start		  6.3107269325415888e+04
            Stop		  6.3974174131031548e+04
            Start		  6.5941799467172488e+04
            Stop		  6.6808705070355019e+04
            Start		  6.8776330740901278e+04
            Stop		  6.9643235551444392e+04
            Start		  7.1610860882229012e+04
            Stop		  7.2477766491534087e+04
            Start		  7.4445392155773152e+04
            Stop		  7.5312296973297693e+04
            Start		  7.7279922297042649e+04
            Stop		  7.8146827913934190e+04
            Start		  8.0114453570729718e+04
            Stop		  8.0981358396097115e+04
            Start		  8.2948983712300673e+04
            Stop		  8.3815889336966182e+04
            Start		  8.5783514986454233e+04
            Stop		  8.6400000000000000e+04
            Strand		 2 59
            Start		  2.7518194948329415e+02
            Stop		  1.1420669118438416e+03
            Start		  3.1097130525650446e+03
            Stop		  3.9765971511502958e+03
            Start		  5.9442418378292041e+03
            Stop		  6.8111281007181169e+03
            Start		  8.7787744729035530e+03
            Stop		  9.6456584964179783e+03
            Start		  1.1613305082816658e+04
            Stop		  1.2480189435159658e+04
            Start		  1.4447835891503168e+04
            Stop		  1.5314719887110297e+04
            Start		  1.7282366176262403e+04
            Stop		  1.8149250825253501e+04
            Start		  2.0116897308475571e+04
            Stop		  2.0983781296594316e+04
            Start		  2.2951427486001630e+04
            Stop		  2.3818312235424946e+04
            Start		  2.5785958724190143e+04
            Stop		  2.6652842713746293e+04
            Start		  2.8620488866148520e+04
            Stop		  2.9487373653335333e+04
            Start		  3.1455020139226133e+04
            Stop		  3.2321904134381333e+04
            Start		  3.4289550269491730e+04
            Stop		  3.5156435074539375e+04
            Start		  3.7124081554277924e+04
            Stop		  3.7990965556686118e+04
            Start		  3.9958611680977308e+04
            Stop		  4.0825496497108805e+04
            Start		  4.2793142970036388e+04
            Stop		  4.3660026979568313e+04
            Start		  4.5627673096044331e+04
            Stop		  4.6494557919902880e+04
            Start		  4.8462204387069614e+04
            Stop		  4.9329088402172478e+04
            Start		  5.1296734513440511e+04
            Stop		  5.2163619342080892e+04
            Start		  5.4131265805724426e+04
            Stop		  5.4998149823803120e+04
            Start		  5.6965795932808156e+04
            Stop		  5.7832680763021148e+04
            Start		  5.9800327226066212e+04
            Stop		  6.0667211243970625e+04
            Start		  6.2634857353876730e+04
            Stop		  6.3501742182353773e+04
            Start		  6.5469388647867585e+04
            Stop		  6.6336272662451564e+04
            Start		  6.8303918776222534e+04
            Stop		  6.9170803600000203e+04
            Start		  7.1138450070648003e+04
            Stop		  7.2005334079319131e+04
            Start		  7.3972980199247279e+04
            Stop		  7.4839865016178461e+04
            Start		  7.6807511493757149e+04
            Stop		  7.7674395494927900e+04
            Start		  7.9642041622250530e+04
            Stop		  8.0508926431362663e+04
            Start		  8.2476572916487945e+04
            Stop		  8.3343456909851142e+04
            Start		  8.5311103044541160e+04
            Stop		  8.6177987846199656e+04
            Strand		 2 60
            Strand		 2 61
            Strand		 2 62
            Strand		 2 63
            Start		  9.7951533446065832e+02
            Stop		  2.1699459402422581e+03
            Start		  3.8140456896408105e+03
            Stop		  5.0044766359223677e+03
            Start		  6.6485763920627278e+03
            Stop		  7.8390073509903805e+03
            Start		  9.4831070997040842e+03
            Stop		  1.0673538065195424e+04
            Start		  1.2317637808088744e+04
            Stop		  1.3508068779316100e+04
            Start		  1.5152168517476841e+04
            Stop		  1.6342599493098171e+04
            Start		  1.7986699227858688e+04
            Stop		  1.9177130206355243e+04
            Start		  2.0821229939192683e+04
            Stop		  2.2011660918921381e+04
            Start		  2.3655760651394397e+04
            Stop		  2.4846191630661371e+04
            Start		  2.6490291364341567e+04
            Stop		  2.7680722341476121e+04
            Start		  2.9324822077879158e+04
            Stop		  3.0515253051307143e+04
            Start		  3.2159352791826201e+04
            Stop		  3.3349783760139137e+04
            Start		  3.4993883505983686e+04
            Stop		  3.6184314468000666e+04
            Start		  3.7828414220143401e+04
            Stop		  3.9018845174962960e+04
            Start		  4.0662944934096951e+04
            Stop		  4.1853375881136613e+04
            Start		  4.3497475647644998e+04
            Stop		  4.4687906586666977e+04
            Start		  4.6332006360605934e+04
            Stop		  4.7522437291727547e+04
            Start		  4.9166537072823936e+04
            Stop		  5.0356967996512503e+04
            Start		  5.2001067784175742e+04
            Stop		  5.3191498701228120e+04
            Start		  5.4835598494576079e+04
            Stop		  5.6026029406083690e+04
            Start		  5.7670129203981414e+04
            Stop		  5.8860560111282422e+04
            Start		  6.0504659912391828e+04
            Stop		  6.1695090817012373e+04
            Start		  6.3339190619851113e+04
            Stop		  6.4529621523438451e+04
            Start		  6.6173721326444676e+04
            Stop		  6.7364152230694817e+04
            Start		  6.9008252032295975e+04
            Stop		  7.0198682938879356e+04
            Start		  7.1842782737560934e+04
            Stop		  7.3033213648049132e+04
            Start		  7.4677313442421175e+04
            Stop		  7.5867744358218057e+04
            Start		  7.7511844147076117e+04
            Stop		  7.8702275069356052e+04
            Start		  8.0346374851734028e+04
            Stop		  8.1536805781390620e+04
            Start		  8.3180905556603160e+04
            Stop		  8.4371336494210002e+04
            Start		  8.6015436261882234e+04
            Stop		  8.6400000000000000e+04
            Strand		 2 64
            Strand		 2 65
            Strand		 2 66
            Strand		 2 67
            Strand		 2 68
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 2 69
            Strand		 2 70
            Strand		 2 71
            Strand		 3 36
            Strand		 3 37
            Strand		 3 38
            Strand		 3 40
            Strand		 3 41
            Strand		 3 42
            Strand		 3 43
            Strand		 3 44
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 3 45
            Strand		 3 46
            Strand		 3 47
            Strand		 3 48
            Strand		 3 49
            Start		  1.6094145343198784e+03
            Stop		  2.7998371357533779e+03
            Start		  4.4439461440979348e+03
            Stop		  5.6343717598449030e+03
            Start		  7.2784728638520701e+03
            Stop		  8.4689023552405579e+03
            Start		  1.0113003537412205e+04
            Stop		  1.1303433066648753e+04
            Start		  1.2947534244166211e+04
            Stop		  1.4137963774736363e+04
            Start		  1.5782064949431431e+04
            Stop		  1.6972494484032060e+04
            Start		  1.8616595654375858e+04
            Stop		  1.9807025194313079e+04
            Start		  2.1451126359150683e+04
            Stop		  2.2641555905553178e+04
            Start		  2.4285657063967417e+04
            Stop		  2.5476086617671848e+04
            Start		  2.7120187769033160e+04
            Stop		  2.8310617330550667e+04
            Start		  2.9954718474544261e+04
            Stop		  3.1145148044037815e+04
            Start		  3.2789249180677471e+04
            Stop		  3.3979678757954716e+04
            Start		  3.5623779887582285e+04
            Stop		  3.6814209472103918e+04
            Start		  3.8458310595374358e+04
            Stop		  3.9648740186277719e+04
            Start		  4.1292841304130372e+04
            Stop		  4.2483270900267329e+04
            Start		  4.4127372013884742e+04
            Stop		  4.5317801613871983e+04
            Start		  4.6961902724628075e+04
            Stop		  4.8152332326907861e+04
            Start		  4.9796433436307605e+04
            Stop		  5.0986863039215954e+04
            Start		  5.2630964148829407e+04
            Stop		  5.3821393750669318e+04
            Start		  5.5465494862062689e+04
            Stop		  5.6655924461178380e+04
            Start		  5.8300025575845437e+04
            Stop		  5.9490455170695015e+04
            Start		  6.1134556289991517e+04
            Stop		  6.2324985879214706e+04
            Start		  6.3969087004298861e+04
            Stop		  6.5159516586776517e+04
            Start		  6.6803617718558424e+04
            Stop		  6.7994047293461685e+04
            Start		  6.9638148432563146e+04
            Stop		  7.0828577999389745e+04
            Start		  7.2472679146117342e+04
            Stop		  7.3663108704713522e+04
            Start		  7.5307209859044975e+04
            Stop		  7.6497639409612253e+04
            Start		  7.8141740571197704e+04
            Stop		  7.9332170114283828e+04
            Start		  8.0976271282460992e+04
            Stop		  8.2166700818936079e+04
            Start		  8.3810801992759662e+04
            Stop		  8.5001231523777547e+04
            Strand		 3 50
            Strand		 3 51
            Strand		 3 52
            Strand		 3 53
            Strand		 3 54
            Start		  0.0000000000000000e+00
            Stop		  1.9722289947312899e+02
            Start		  2.1648677615005045e+03
            Stop		  3.0317538561614529e+03
            Start		  4.9994001928985599e+03
            Stop		  5.8662842294143711e+03
            Start		  7.8339309355981050e+03
            Stop		  8.7008151686656493e+03
            Start		  1.0668461612640162e+04
            Stop		  1.1535345612633357e+04
            Start		  1.3502991941217950e+04
            Stop		  1.4369876550350364e+04
            Start		  1.6337523030664983e+04
            Stop		  1.7204407018637070e+04
            Start		  1.9172053222877588e+04
            Stop		  2.0038937956911825e+04
            Start		  2.2006584447162906e+04
            Stop		  2.2873468433859929e+04
            Start		  2.4841114594072704e+04
            Stop		  2.5707999372945989e+04
            Start		  2.7675645862578229e+04
            Stop		  2.8542529853280790e+04
            Start		  3.0510175994413155e+04
            Stop		  3.1377060793086395e+04
            Start		  3.3344707277539717e+04
            Stop		  3.4211591274891383e+04
            Start		  3.6179237404533676e+04
            Stop		  3.7046122215174822e+04
            Start		  3.9013768692753940e+04
            Stop		  3.9880652697583828e+04
            Start		  4.1848298818516887e+04
            Stop		  4.2715183638016824e+04
            Start		  4.4682830108883383e+04
            Stop		  4.5549714120490484e+04
            Start		  4.7517360234772219e+04
            Stop		  4.8384245060718007e+04
            Start		  5.0351891526431711e+04
            Stop		  5.1218775542848423e+04
            Start		  5.3186421652965939e+04
            Stop		  5.4053306482550914e+04
            Start		  5.6020952945656296e+04
            Stop		  5.6887836964036927e+04
            Start		  5.8855483072973759e+04
            Stop		  5.9722367902985839e+04
            Start		  6.1690014366523654e+04
            Stop		  6.2556898383653715e+04
            Start		  6.4524544494536989e+04
            Stop		  6.5391429321751246e+04
            Start		  6.7359075788715229e+04
            Stop		  6.8225959801574398e+04
            Start		  7.0193605917186767e+04
            Stop		  7.1060490738870474e+04
            Start		  7.3028137211682799e+04
            Stop		  7.3895021217970600e+04
            Start		  7.5862667340285552e+04
            Stop		  7.6729552154654244e+04
            Start		  7.8697198634743618e+04
            Stop		  7.9564082633278973e+04
            Start		  8.1531728763124614e+04
            Stop		  8.2398613569645415e+04
            Start		  8.4366260057199179e+04
            Stop		  8.5233144048125061e+04
            Strand		 3 55
            Strand		 3 56
            Strand		 3 57
            Strand		 3 58
            Strand		 3 59
            Start		  0.0000000000000000e+00
            Stop		  6.6965530014730120e+02
            Start		  2.6372798841694625e+03
            Stop		  3.5041865919649949e+03
            Start		  5.4718115502011015e+03
            Stop		  6.3387166104123353e+03
            Start		  8.3063414733090940e+03
            Stop		  9.1732476195540621e+03
            Start		  1.1140872968719263e+04
            Stop		  1.2007777900235271e+04
            Start		  1.3975401633699876e+04
            Stop		  1.4842308849288280e+04
            Start		  1.6809934388832575e+04
            Stop		  1.7676839261185585e+04
            Start		  1.9644464929748057e+04
            Stop		  2.0511370201299047e+04
            Start		  2.2478995810397297e+04
            Stop		  2.3345900658277238e+04
            Start		  2.5313526086006783e+04
            Stop		  2.6180431596520019e+04
            Start		  2.8148057232982235e+04
            Stop		  2.9014962068001289e+04
            Start		  3.0982587421412947e+04
            Stop		  3.1849493005391036e+04
            Start		  3.3817118655958293e+04
            Stop		  3.4684023481341334e+04
            Start		  3.6651648815450884e+04
            Stop		  3.7518554418251450e+04
            Start		  3.9486180078621350e+04
            Stop		  4.0353084895583073e+04
            Start		  4.2320710228164236e+04
            Stop		  4.3187615832366770e+04
            Start		  4.5155241500319185e+04
            Stop		  4.6022146310310920e+04
            Start		  4.7989771646029854e+04
            Stop		  4.8856677247327068e+04
            Start		  5.0824302920566297e+04
            Stop		  5.1691207725855122e+04
            Start		  5.3658833064404826e+04
            Stop		  5.4525738663418902e+04
            Start		  5.6493364339128661e+04
            Stop		  5.7360269142680889e+04
            Start		  5.9327894481785879e+04
            Stop		  6.0194800081011534e+04
            Start		  6.2162425756064513e+04
            Stop		  6.3029330561122697e+04
            Start		  6.4996955897909167e+04
            Stop		  6.5863861500306099e+04
            Start		  6.7831487171714209e+04
            Stop		  6.8698391981264940e+04
            Start		  7.0666017313081873e+04
            Stop		  7.1532922921238962e+04
            Start		  7.3500548586641293e+04
            Stop		  7.4367453402907006e+04
            Start		  7.6335078727892629e+04
            Stop		  7.7201984343472257e+04
            Start		  7.9169610001534384e+04
            Stop		  8.0036514825591395e+04
            Start		  8.2004140143031284e+04
            Stop		  8.2871045766445997e+04
            Start		  8.4838671417087768e+04
            Stop		  8.5705576248680984e+04
            Strand		 3 60
            Strand		 3 61
            Strand		 3 62
            Strand		 3 63
            Strand		 3 64
            Start		  3.4676244852063718e+01
            Stop		  1.2251025081161861e+03
            Start		  2.8692021993494550e+03
            Stop		  4.0596330609879860e+03
            Start		  5.7037328223378081e+03
            Stop		  6.8941637797666981e+03
            Start		  8.5382635304940140e+03
            Stop		  9.7286944937733169e+03
            Start		  1.1372794238512775e+04
            Stop		  1.2563225207971320e+04
            Start		  1.4207324947569761e+04
            Stop		  1.5397755921886810e+04
            Start		  1.7041855657622626e+04
            Stop		  1.8232286635338740e+04
            Start		  1.9876386368646617e+04
            Stop		  2.1066817348151799e+04
            Start		  2.2710917080570878e+04
            Stop		  2.3901348060180069e+04
            Start		  2.5545447793285297e+04
            Stop		  2.6735878771311811e+04
            Start		  2.8379978506645057e+04
            Stop		  2.9570409481474599e+04
            Start		  3.1214509220477008e+04
            Stop		  3.2404940190638583e+04
            Start		  3.4049039934587214e+04
            Stop		  3.5239470898817752e+04
            Start		  3.6883570648769528e+04
            Stop		  3.8074001606069352e+04
            Start		  3.9718101362814567e+04
            Stop		  4.0908532312491341e+04
            Start		  4.2552632076519003e+04
            Stop		  4.3743063018218105e+04
            Start		  4.5387162789694383e+04
            Stop		  4.6577593723414531e+04
            Start		  4.8221693502175447e+04
            Stop		  4.9412124428268857e+04
            Start		  5.1056224213827438e+04
            Stop		  5.2246655132984299e+04
            Start		  5.3890754924551875e+04
            Stop		  5.5081185837770136e+04
            Start		  5.6725285634291038e+04
            Stop		  5.7915716542832663e+04
            Start		  5.9559816343030383e+04
            Stop		  6.0750247248365922e+04
            Start		  6.2394347050799239e+04
            Stop		  6.3584777954543388e+04
            Start		  6.5228877757669427e+04
            Stop		  6.6419308661510222e+04
            Start		  6.8063408463752290e+04
            Stop		  6.9253839369376947e+04
            Start		  7.0897939169193603e+04
            Stop		  7.2088370078214619e+04
            Start		  7.3732469874167320e+04
            Stop		  7.4922900788051644e+04
            Start		  7.6567000578867795e+04
            Stop		  7.7757431498872611e+04
            Start		  7.9401531283501376e+04
            Stop		  8.0591962210618905e+04
            Start		  8.2236061988277375e+04
            Stop		  8.3426492923191341e+04
            Start		  8.5070592693398678e+04
            Stop		  8.6261023970334150e+04
            Strand		 3 65
            Strand		 3 66
            Strand		 3 67
            Strand		 3 68
            Strand		 3 69
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 3 70
            Strand		 3 71
            Strand		 4 36
            Strand		 4 37
            Strand		 4 38
            Strand		 4 39
            Strand		 4 41
            Strand		 4 42
            Strand		 4 43
            Strand		 4 44
            Strand		 4 45
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 4 46
            Strand		 4 47
            Strand		 4 48
            Strand		 4 49
            Strand		 4 50
            Start		  6.6456786119240769e+02
            Stop		  1.8549973758664760e+03
            Start		  3.4990985543558859e+03
            Stop		  4.6895280840516398e+03
            Start		  6.3336292626605136e+03
            Stop		  7.5240587901668714e+03
            Start		  9.1681599694815322e+03
            Stop		  1.0358589497232730e+04
            Start		  1.2002690675570811e+04
            Stop		  1.3193120205206242e+04
            Start		  1.4837221381047186e+04
            Stop		  1.6027650914158536e+04
            Start		  1.7671752086090495e+04
            Stop		  1.8862181624109999e+04
            Start		  2.0506282790898123e+04
            Stop		  2.1696712335037442e+04
            Start		  2.3340813495677616e+04
            Stop		  2.4531243046874595e+04
            Start		  2.6175344200637832e+04
            Stop		  2.7365773759515381e+04
            Start		  2.9009874905979701e+04
            Stop		  3.0200304472818432e+04
            Start		  3.1844405611887436e+04
            Stop		  3.3034835186613273e+04
            Start		  3.4678936318520406e+04
            Stop		  3.5869365900707773e+04
            Start		  3.7513467026006198e+04
            Stop		  3.8703896614896723e+04
            Start		  4.0347997734434939e+04
            Stop		  4.1538427328970611e+04
            Start		  4.3182528443855423e+04
            Stop		  4.4372958042725033e+04
            Start		  4.6017059154272843e+04
            Stop		  4.7207488755969556e+04
            Start		  4.8851589865648784e+04
            Stop		  5.0042019468536077e+04
            Start		  5.1686120577902628e+04
            Stop		  5.2876550180286242e+04
            Start		  5.4520651290915353e+04
            Stop		  5.5711080891117519e+04
            Start		  5.7355182004534588e+04
            Stop		  5.8545611600967663e+04
            Start		  6.0189712718581410e+04
            Stop		  6.1380142309817449e+04
            Start		  6.3024243432858086e+04
            Stop		  6.4214673017691559e+04
            Start		  6.5858774147156859e+04
            Stop		  6.7049203724657462e+04
            Start		  6.8693304861268989e+04
            Stop		  6.9883734430822427e+04
            Start		  7.1527835574994067e+04
            Stop		  7.2718265136328861e+04
            Start		  7.4362366288148580e+04
            Stop		  7.5552795841348037e+04
            Start		  7.7196897000574114e+04
            Stop		  7.8387326546072567e+04
            Start		  8.0031427712144301e+04
            Stop		  8.1221857250707893e+04
            Start		  8.2865958422770302e+04
            Stop		  8.4056387955463491e+04
            Start		  8.5700489132404866e+04
            Stop		  8.6400000000000000e+04
            Strand		 4 51
            Strand		 4 52
            Strand		 4 53
            Strand		 4 54
            Start		  1.6924371143649137e+03
            Stop		  2.5593430960925657e+03
            Start		  4.5269679805755613e+03
            Stop		  5.3938729255024991e+03
            Start		  7.3614967792395173e+03
            Stop		  8.2284038794234475e+03
            Start		  1.0196029398928333e+04
            Stop		  1.1062934277381875e+04
            Start		  1.3030560026027571e+04
            Stop		  1.3897465218969826e+04
            Start		  1.5865090818729241e+04
            Stop		  1.6731995671959550e+04
            Start		  1.8699621122196921e+04
            Stop		  1.9566526611253641e+04
            Start		  2.1534152240058764e+04
            Stop		  2.2401057082019084e+04
            Start		  2.4368682437544699e+04
            Stop		  2.5235588020262854e+04
            Start		  2.7203213662508224e+04
            Stop		  2.8070118496383715e+04
            Start		  3.0037743825157086e+04
            Stop		  3.0904649433853287e+04
            Start		  3.2872275085465830e+04
            Stop		  3.3739179911378422e+04
            Start		  3.5706805236481945e+04
            Stop		  3.6573710848337010e+04
            Start		  3.8541336508228705e+04
            Stop		  3.9408241326187992e+04
            Start		  4.1375866655046491e+04
            Stop		  4.2242772262965365e+04
            Start		  4.4210397930126703e+04
            Stop		  4.5077302741038380e+04
            Start		  4.7044928075033778e+04
            Stop		  4.7911833677991381e+04
            Start		  4.9879459350639358e+04
            Stop		  5.0746364156485230e+04
            Start		  5.2713989494312846e+04
            Stop		  5.3580895093939129e+04
            Start		  5.5548520769486509e+04
            Stop		  5.6415425573092332e+04
            Start		  5.8383050912175517e+04
            Stop		  5.9249956511285221e+04
            Start		  6.1217582186676947e+04
            Stop		  6.2084486991259233e+04
            Start		  6.4052112328589166e+04
            Stop		  6.4919017930300790e+04
            Start		  6.6886643602506869e+04
            Stop		  6.7753548411126947e+04
            Start		  6.9721173743914682e+04
            Stop		  7.0588079350979635e+04
            Start		  7.2555705017508517e+04
            Stop		  7.3422609832545451e+04
            Start		  7.5390235158748648e+04
            Stop		  7.6257140773030944e+04
            Start		  7.8224766432357661e+04
            Stop		  7.9091671255097055e+04
            Start		  8.1059296573788291e+04
            Stop		  8.1926202195927253e+04
            Start		  8.3893827847756242e+04
            Stop		  8.4760732678167915e+04
            Strand		 4 55
            Start		  1.2200259122785117e+03
            Stop		  2.0869098641939677e+03
            Start		  4.0545556124598961e+03
            Stop		  4.9214408018951872e+03
            Start		  6.8890873330477334e+03
            Stop		  7.7559713056611863e+03
            Start		  9.7236173178091631e+03
            Stop		  1.0590502242734075e+04
            Start		  1.2558148752183302e+04
            Stop		  1.3425032730417042e+04
            Start		  1.5392678831115703e+04
            Stop		  1.6259563668101902e+04
            Start		  1.8227210169654903e+04
            Stop		  1.9094094151064844e+04
            Start		  2.1061740279324113e+04
            Stop		  2.1928625089584741e+04
            Start		  2.3896271585728395e+04
            Stop		  2.4763155571574382e+04
            Start		  2.6730801705297021e+04
            Stop		  2.7597686510914908e+04
            Start		  2.9565333000915245e+04
            Stop		  3.0432216993056307e+04
            Start		  3.2399863123731397e+04
            Stop		  3.3266747933052284e+04
            Start		  3.5234394415881769e+04
            Stop		  3.6101278415521650e+04
            Start		  3.8068924539994252e+04
            Stop		  3.8935809355893667e+04
            Start		  4.0903455831332998e+04
            Stop		  4.1770339838505155e+04
            Start		  4.3737985956306838e+04
            Stop		  4.4604870778908502e+04
            Start		  4.6572517247890130e+04
            Stop		  4.7439401261350700e+04
            Start		  4.9407047373716523e+04
            Stop		  5.0273932201435207e+04
            Start		  5.2241578665982503e+04
            Stop		  5.3108462683392645e+04
            Start		  5.5076108792694999e+04
            Stop		  5.5942993622863483e+04
            Start		  5.7910640085773099e+04
            Stop		  5.8777524104093769e+04
            Start		  6.0745170213314283e+04
            Stop		  6.1612055042762542e+04
            Start		  6.3579701507130179e+04
            Stop		  6.4446585523145826e+04
            Start		  6.6414231635319535e+04
            Stop		  6.7281116460963385e+04
            Start		  6.9248762929650242e+04
            Stop		  7.0115646940525563e+04
            Start		  7.2083293058201583e+04
            Stop		  7.2950177877590395e+04
            Start		  7.4917824352728087e+04
            Stop		  7.5784708356499541e+04
            Start		  7.7752354481294635e+04
            Stop		  7.8619239293040766e+04
            Start		  8.0586885775661998e+04
            Stop		  8.1453769771577980e+04
            Start		  8.3421415903895060e+04
            Stop		  8.4288300707915463e+04
            Start		  8.6255945036712248e+04
            Stop		  8.6400000000000000e+04
            Strand		 4 56
            Strand		 4 57
            Strand		 4 58
            Strand		 4 59
            Strand		 4 60
            Strand		 4 61
            Strand		 4 62
            Strand		 4 63
            Strand		 4 64
            Strand		 4 65
            Start		  0.0000000000000000e+00
            Stop		  2.8025479236399366e+02
            Start		  1.9243623393038067e+03
            Stop		  3.1147895949674221e+03
            Start		  4.7588892837847425e+03
            Stop		  5.9493202043726751e+03
            Start		  7.5934199604822115e+03
            Stop		  8.7838509225603921e+03
            Start		  1.0427950669093558e+04
            Stop		  1.1618381636585456e+04
            Start		  1.3262481377771628e+04
            Stop		  1.4452912350624303e+04
            Start		  1.6097012087494941e+04
            Stop		  1.7287443064250958e+04
            Start		  1.8931542798200913e+04
            Stop		  2.0121973777294763e+04
            Start		  2.1766073509835478e+04
            Stop		  2.2956504489598869e+04
            Start		  2.4600604222301004e+04
            Stop		  2.5791035201039533e+04
            Start		  2.7435134935463648e+04
            Stop		  2.8625565911530764e+04
            Start		  3.0269665649158895e+04
            Stop		  3.1460096621028304e+04
            Start		  3.3104196363198826e+04
            Stop		  3.4294627329531490e+04
            Start		  3.5938727077380398e+04
            Stop		  3.7129158037083333e+04
            Start		  3.8773257791494296e+04
            Stop		  3.9963688743768624e+04
            Start		  4.1607788505334116e+04
            Stop		  4.2798219449710166e+04
            Start		  4.4442319218705517e+04
            Stop		  4.5632750155063470e+04
            Start		  4.7276849931434641e+04
            Stop		  4.8467280860009814e+04
            Start		  5.0111380643375829e+04
            Stop		  5.1301811564748408e+04
            Start		  5.2945911354417956e+04
            Stop		  5.4136342269487519e+04
            Start		  5.5780442064489325e+04
            Stop		  5.6970872974435493e+04
            Start		  5.8614972773560832e+04
            Stop		  5.9805403679791358e+04
            Start		  6.1449503481647247e+04
            Stop		  6.2639934385736444e+04
            Start		  6.4284034188806487e+04
            Stop		  6.5474465092426020e+04
            Start		  6.7118564895137213e+04
            Stop		  6.8308995799982877e+04
            Start		  6.9953095600774293e+04
            Stop		  7.1143526508491588e+04
            Start		  7.2787626305883095e+04
            Stop		  7.3978057217995040e+04
            Start		  7.5622157010652110e+04
            Stop		  7.6812587928492474e+04
            Start		  7.8456687715284745e+04
            Stop		  7.9647118639939392e+04
            Start		  8.1291218419990197e+04
            Stop		  8.2481649352249849e+04
            Start		  8.4125749124974609e+04
            Stop		  8.5316180065299821e+04
            Strand		 4 66
            Strand		 4 67
            Strand		 4 68
            Strand		 4 69
            Strand		 4 70
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 4 71
            Strand		 5 36
            Strand		 5 37
            Strand		 5 38
            Strand		 5 39
            Strand		 5 40
            Strand		 5 42
            Strand		 5 43
            Strand		 5 44
            Strand		 5 45
            Strand		 5 46
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 5 47
            Strand		 5 48
            Strand		 5 49
            Strand		 5 50
            Strand		 5 51
            Start		  0.0000000000000000e+00
            Stop		  9.1015393277150122e+02
            Start		  2.5542550489236137e+03
            Stop		  3.7446845112121541e+03
            Start		  5.3887856925896440e+03
            Stop		  6.5792152215510168e+03
            Start		  8.2233164006708594e+03
            Stop		  9.4137459281047031e+03
            Start		  1.1057847106948464e+04
            Stop		  1.2248276635775746e+04
            Start		  1.3892377812612556e+04
            Stop		  1.5082807344396857e+04
            Start		  1.6726908517778971e+04
            Stop		  1.7917338054015654e+04
            Start		  1.9561439222642406e+04
            Stop		  2.0751868764623105e+04
            Start		  2.2395969927407950e+04
            Stop		  2.3586399476166909e+04
            Start		  2.5230500632285020e+04
            Stop		  2.6420930188553895e+04
            Start		  2.8065031337478198e+04
            Stop		  2.9255460901653842e+04
            Start		  3.0899562043178212e+04
            Stop		  3.2089991615305189e+04
            Start		  3.3734092749553573e+04
            Stop		  3.4924522329322150e+04
            Start		  3.6568623456743131e+04
            Stop		  3.7759053043502863e+04
            Start		  3.9403154164850035e+04
            Stop		  4.0593583757638247e+04
            Start		  4.2237684873937178e+04
            Stop		  4.3428114471521199e+04
            Start		  4.5072215584024416e+04
            Stop		  4.6262645184955618e+04
            Start		  4.7906746295087774e+04
            Stop		  4.9097175897765112e+04
            Start		  5.0741277007060424e+04
            Stop		  5.1931706609800676e+04
            Start		  5.3575807719835604e+04
            Stop		  5.4766237320947250e+04
            Start		  5.6410338433271383e+04
            Stop		  5.7600768031128719e+04
            Start		  5.9244869147196878e+04
            Stop		  6.0435298740311388e+04
            Start		  6.2079399861419719e+04
            Stop		  6.3269829448505312e+04
            Start		  6.4913930575734426e+04
            Stop		  6.6104360155763905e+04
            Start		  6.7748461289931671e+04
            Stop		  6.8938890862181637e+04
            Start		  7.0582992003807187e+04
            Stop		  7.1773421567889847e+04
            Start		  7.3417522717170898e+04
            Stop		  7.4607952273050920e+04
            Start		  7.6252053429855150e+04
            Stop		  7.7442482977851294e+04
            Start		  7.9086584141722255e+04
            Stop		  8.0277013682493096e+04
            Start		  8.1921114852670362e+04
            Stop		  8.3111544387185480e+04
            Start		  8.4755645562637990e+04
            Stop		  8.5946075092135230e+04
            Strand		 5 52
            Strand		 5 53
            Strand		 5 54
            Strand		 5 55
            Start		  7.4759219830210009e+02
            Stop		  1.6144986041015916e+03
            Start		  3.5821244082849194e+03
            Stop		  4.4490298801742329e+03
            Start		  6.4166551196774763e+03
            Stop		  7.2835601958344587e+03
            Start		  9.2511852399373875e+03
            Stop		  1.0118091217542442e+04
            Start		  1.2085716538602937e+04
            Stop		  1.2952621478923891e+04
            Start		  1.4920245268052418e+04
            Stop		  1.5787152429732774e+04
            Start		  1.7754777958992723e+04
            Stop		  1.8621682834384104e+04
            Start		  2.0589308541716138e+04
            Stop		  2.1456213774593718e+04
            Start		  2.3423839380769758e+04
            Stop		  2.4290744229046792e+04
            Start		  2.6258369670126209e+04
            Stop		  2.7125275167190113e+04
            Start		  2.9092900803468972e+04
            Stop		  2.9959805637764792e+04
            Start		  3.1927430996422816e+04
            Stop		  3.2794336575063440e+04
            Start		  3.4761962226442505e+04
            Stop		  3.5628867050680296e+04
            Start		  3.7596492387379229e+04
            Stop		  3.8463397987546909e+04
            Start		  4.0431023648986979e+04
            Stop		  4.1297928464776858e+04
            Start		  4.3265553798925430e+04
            Stop		  4.4132459401575587e+04
            Start		  4.6100085070470865e+04
            Stop		  4.6966989879535344e+04
            Start		  4.8934615216213031e+04
            Stop		  4.9801520816623110e+04
            Start		  5.1769146490445804e+04
            Stop		  5.2636051295237652e+04
            Start		  5.4603676634195261e+04
            Stop		  5.5470582232917339e+04
            Start		  5.7438207908725039e+04
            Stop		  5.8305112712307258e+04
            Start		  6.0272738051270360e+04
            Stop		  6.1139643650778031e+04
            Start		  6.3107269325415902e+04
            Stop		  6.3974174131031570e+04
            Start		  6.5941799467172503e+04
            Stop		  6.6808705070355049e+04
            Start		  6.8776330740901278e+04
            Stop		  6.9643235551444421e+04
            Start		  7.1610860882229012e+04
            Stop		  7.2477766491534130e+04
            Start		  7.4445392155773166e+04
            Stop		  7.5312296973297707e+04
            Start		  7.7279922297042649e+04
            Stop		  7.8146827913934248e+04
            Start		  8.0114453570729762e+04
            Stop		  8.0981358396097159e+04
            Start		  8.2948983712300673e+04
            Stop		  8.3815889336966240e+04
            Start		  8.5783514986454262e+04
            Stop		  8.6400000000000000e+04
            Strand		 5 56
            Start		  2.7518194948329108e+02
            Stop		  1.1420669118438329e+03
            Start		  3.1097130525650541e+03
            Stop		  3.9765971511502967e+03
            Start		  5.9442418378291986e+03
            Stop		  6.8111281007181205e+03
            Start		  8.7787744729035621e+03
            Stop		  9.6456584964179910e+03
            Start		  1.1613305082816662e+04
            Stop		  1.2480189435159662e+04
            Start		  1.4447835891503177e+04
            Stop		  1.5314719887110301e+04
            Start		  1.7282366176262407e+04
            Stop		  1.8149250825253508e+04
            Start		  2.0116897308475574e+04
            Stop		  2.0983781296594327e+04
            Start		  2.2951427486001641e+04
            Stop		  2.3818312235424964e+04
            Start		  2.5785958724190154e+04
            Stop		  2.6652842713746308e+04
            Start		  2.8620488866148542e+04
            Stop		  2.9487373653335344e+04
            Start		  3.1455020139226148e+04
            Stop		  3.2321904134381348e+04
            Start		  3.4289550269491738e+04
            Stop		  3.5156435074539389e+04
            Start		  3.7124081554277946e+04
            Stop		  3.7990965556686133e+04
            Start		  3.9958611680977323e+04
            Stop		  4.0825496497108827e+04
            Start		  4.2793142970036410e+04
            Stop		  4.3660026979568334e+04
            Start		  4.5627673096044338e+04
            Stop		  4.6494557919902894e+04
            Start		  4.8462204387069636e+04
            Stop		  4.9329088402172514e+04
            Start		  5.1296734513440533e+04
            Stop		  5.2163619342080921e+04
            Start		  5.4131265805724455e+04
            Stop		  5.4998149823803156e+04
            Start		  5.6965795932808192e+04
            Stop		  5.7832680763021170e+04
            Start		  5.9800327226066234e+04
            Stop		  6.0667211243970662e+04
            Start		  6.2634857353876767e+04
            Stop		  6.3501742182353810e+04
            Start		  6.5469388647867607e+04
            Stop		  6.6336272662451593e+04
            Start		  6.8303918776222577e+04
            Stop		  6.9170803600000247e+04
            Start		  7.1138450070648018e+04
            Stop		  7.2005334079319160e+04
            Start		  7.3972980199247308e+04
            Stop		  7.4839865016178504e+04
            Start		  7.6807511493757193e+04
            Stop		  7.7674395494927929e+04
            Start		  7.9642041622250574e+04
            Stop		  8.0508926431362721e+04
            Start		  8.2476572916487989e+04
            Stop		  8.3343456909851186e+04
            Start		  8.5311103044541189e+04
            Stop		  8.6177987846199714e+04
            Strand		 5 57
            Strand		 5 58
            Strand		 5 59
            Strand		 5 60
            Start		  9.7951533446066117e+02
            Stop		  2.1699459402422685e+03
            Start		  3.8140456896408050e+03
            Stop		  5.0044766359223677e+03
            Start		  6.6485763920627305e+03
            Stop		  7.8390073509903805e+03
            Start		  9.4831070997040752e+03
            Stop		  1.0673538065195422e+04
            Start		  1.2317637808088746e+04
            Stop		  1.3508068779316105e+04
            Start		  1.5152168517476844e+04
            Stop		  1.6342599493098160e+04
            Start		  1.7986699227858688e+04
            Stop		  1.9177130206355250e+04
            Start		  2.0821229939192675e+04
            Stop		  2.2011660918921381e+04
            Start		  2.3655760651394390e+04
            Stop		  2.4846191630661378e+04
            Start		  2.6490291364341574e+04
            Stop		  2.7680722341476128e+04
            Start		  2.9324822077879155e+04
            Stop		  3.0515253051307147e+04
            Start		  3.2159352791826193e+04
            Stop		  3.3349783760139122e+04
            Start		  3.4993883505983693e+04
            Stop		  3.6184314468000666e+04
            Start		  3.7828414220143401e+04
            Stop		  3.9018845174962938e+04
            Start		  4.0662944934096951e+04
            Stop		  4.1853375881136628e+04
            Start		  4.3497475647644991e+04
            Stop		  4.4687906586666977e+04
            Start		  4.6332006360605919e+04
            Stop		  4.7522437291727554e+04
            Start		  4.9166537072823943e+04
            Stop		  5.0356967996512496e+04
            Start		  5.2001067784175728e+04
            Stop		  5.3191498701228105e+04
            Start		  5.4835598494576072e+04
            Stop		  5.6026029406083690e+04
            Start		  5.7670129203981407e+04
            Stop		  5.8860560111282408e+04
            Start		  6.0504659912391828e+04
            Stop		  6.1695090817012388e+04
            Start		  6.3339190619851113e+04
            Stop		  6.4529621523438436e+04
            Start		  6.6173721326444705e+04
            Stop		  6.7364152230694832e+04
            Start		  6.9008252032295975e+04
            Stop		  7.0198682938879370e+04
            Start		  7.1842782737560905e+04
            Stop		  7.3033213648049161e+04
            Start		  7.4677313442421146e+04
            Stop		  7.5867744358218057e+04
            Start		  7.7511844147076103e+04
            Stop		  7.8702275069356037e+04
            Start		  8.0346374851734043e+04
            Stop		  8.1536805781390634e+04
            Start		  8.3180905556603160e+04
            Stop		  8.4371336494210016e+04
            Start		  8.6015436261882234e+04
            Stop		  8.6400000000000000e+04
            Strand		 5 61
            Strand		 5 62
            Strand		 5 63
            Strand		 5 64
            Strand		 5 65
            Strand		 5 66
            Strand		 5 67
            Strand		 5 68
            Strand		 5 69
            Strand		 5 70
            Strand		 5 71
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 36
            Strand		 6 37
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 38
            Strand		 6 39
            Strand		 6 40
            Strand		 6 41
            Strand		 6 43
            Strand		 6 44
            Strand		 6 45
            Strand		 6 46
            Strand		 6 47
            Strand		 6 48
            Strand		 6 49
            Strand		 6 50
            Strand		 6 51
            Strand		 6 52
            Strand		 6 53
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 54
            Strand		 6 55
            Strand		 6 56
            Strand		 6 57
            Strand		 6 58
            Start		  1.4519398699029084e+03
            Stop		  2.6423672213239820e+03
            Start		  4.2864682872322128e+03
            Stop		  5.4768977422459593e+03
            Start		  7.1209989032112344e+03
            Stop		  8.3114284515057261e+03
            Start		  9.9555296155602700e+03
            Stop		  1.1145959155996674e+04
            Start		  1.2790060325915674e+04
            Stop		  1.3980489860896716e+04
            Start		  1.5624591035328467e+04
            Stop		  1.6815020566153391e+04
            Start		  1.8459121743748256e+04
            Stop		  1.9649551271965305e+04
            Start		  2.1293652451227306e+04
            Stop		  2.2484081978492952e+04
            Start		  2.4128183157856463e+04
            Stop		  2.5318612685865901e+04
            Start		  2.6962713863763885e+04
            Stop		  2.8153143394176790e+04
            Start		  2.9797244569109454e+04
            Stop		  3.0987674103477002e+04
            Start		  3.2631775274077689e+04
            Stop		  3.3822204813774515e+04
            Start		  3.5466305978869765e+04
            Stop		  3.6656735525033517e+04
            Start		  3.8300836683694593e+04
            Stop		  3.9491266237176009e+04
            Start		  4.1135367388759674e+04
            Stop		  4.2325796950085110e+04
            Start		  4.3969898094262004e+04
            Stop		  4.5160327663610420e+04
            Start		  4.6804428800379399e+04
            Stop		  4.7994858377574383e+04
            Start		  4.9638959507262720e+04
            Stop		  5.0829389091780184e+04
            Start		  5.2473490215029226e+04
            Stop		  5.3663919806020444e+04
            Start		  5.5308020923757453e+04
            Stop		  5.6498450520086189e+04
            Start		  5.8142551633483759e+04
            Stop		  5.9332981233776183e+04
            Start		  6.0977082344200702e+04
            Stop		  6.2167511946905594e+04
            Start		  6.3811613055857408e+04
            Stop		  6.5002042659314240e+04
            Start		  6.6646143768361755e+04
            Stop		  6.7836573370873593e+04
            Start		  6.9480674481584545e+04
            Stop		  7.0671104081492318e+04
            Start		  7.2315205195364935e+04
            Stop		  7.3505634791120407e+04
            Start		  7.5149735909517796e+04
            Stop		  7.6340165499751325e+04
            Start		  7.7984266623841657e+04
            Stop		  7.9174696207422312e+04
            Start		  8.0818797338127522e+04
            Stop		  8.2009226914212690e+04
            Start		  8.3653328052168159e+04
            Stop		  8.4843757620240402e+04
            Strand		 6 59
            Strand		 6 60
            Strand		 6 61
            Strand		 6 62
            Start		  0.0000000000000000e+00
            Stop		  5.1218200003446327e+02
            Start		  2.4798069220354014e+03
            Stop		  3.3467119912597241e+03
            Start		  5.3143372595828350e+03
            Stop		  6.1812430280376711e+03
            Start		  8.1488683371369434e+03
            Stop		  9.0157732693092184e+03
            Start		  1.0983397136211588e+04
            Stop		  1.1850304223616660e+04
            Start		  1.3817929752761471e+04
            Stop		  1.4684834622015915e+04
            Start		  1.6652460379538043e+04
            Stop		  1.7519365564524174e+04
            Start		  1.9486991169550096e+04
            Stop		  2.0353896018599389e+04
            Start		  2.2321521471875429e+04
            Stop		  2.3188426959228898e+04
            Start		  2.5156052587913891e+04
            Stop		  2.6022957431434272e+04
            Start		  2.7990582784226841e+04
            Stop		  2.8857488371197538e+04
            Start		  3.0825114007965167e+04
            Stop		  3.1692018848824289e+04
            Start		  3.3659644169808540e+04
            Stop		  3.4526549787729098e+04
            Start		  3.6494175429514733e+04
            Stop		  3.7361080266548342e+04
            Start		  3.9328705580298396e+04
            Stop		  4.0195611204603505e+04
            Start		  4.2163236852110334e+04
            Stop		  4.3030141683303191e+04
            Start		  4.4997766999332431e+04
            Stop		  4.5864672620642697e+04
            Start		  4.7832298275117042e+04
            Stop		  4.8699203098965074e+04
            Start		  5.0666828421004349e+04
            Stop		  5.1533734035842725e+04
            Start		  5.3501359697828120e+04
            Stop		  5.4368264513937444e+04
            Start		  5.6335889842892197e+04
            Stop		  5.7202795450686070e+04
            Start		  5.9170421119587976e+04
            Stop		  6.0037325928855367e+04
            Start		  6.2004951263839524e+04
            Stop		  6.2871856865829839e+04
            Start		  6.4839482539905977e+04
            Stop		  6.5706387344400340e+04
            Start		  6.7674012683283916e+04
            Stop		  6.8540918281916194e+04
            Start		  7.0508543958541792e+04
            Stop		  7.1375448761157182e+04
            Start		  7.3343074101066217e+04
            Stop		  7.4209979699435949e+04
            Start		  7.6177605375546991e+04
            Stop		  7.7044510179504417e+04
            Start		  7.9012135517362913e+04
            Stop		  7.9879041118635010e+04
            Start		  8.1846666791256110e+04
            Stop		  8.2713571599545598e+04
            Start		  8.4681196932623759e+04
            Stop		  8.5548102539469110e+04
            Strand		 6 63
            Start		  0.0000000000000000e+00
            Stop		  3.9749042880311507e+01
            Start		  2.0073944261648501e+03
            Stop		  2.8742800289318106e+03
            Start		  4.8419262567447831e+03
            Stop		  5.7088103394741483e+03
            Start		  7.6764548059067874e+03
            Stop		  8.5433412823011913e+03
            Start		  1.0510987679622087e+04
            Stop		  1.1377871703735878e+04
            Start		  1.3345518137141205e+04
            Stop		  1.4212402640862578e+04
            Start		  1.6180049101574146e+04
            Stop		  1.7046933100474325e+04
            Start		  1.9014579337611005e+04
            Stop		  1.9881464037133195e+04
            Start		  2.1849110522112867e+04
            Stop		  2.2715994509789260e+04
            Start		  2.4683640684646180e+04
            Stop		  2.5550525446880860e+04
            Start		  2.7518171940978096e+04
            Stop		  2.8385055924379158e+04
            Start		  3.0352702078673145e+04
            Stop		  3.1219586862205786e+04
            Start		  3.3187233358194499e+04
            Stop		  3.4054117341909143e+04
            Start		  3.6021763487237717e+04
            Stop		  3.6888648280583424e+04
            Start		  3.8856294774071212e+04
            Stop		  3.9723178761592884e+04
            Start		  4.1690824900017171e+04
            Stop		  4.2557709701072170e+04
            Start		  4.4525356189149497e+04
            Stop		  4.5392240182963498e+04
            Start		  4.7359886314082039e+04
            Stop		  4.8226771123063998e+04
            Start		  5.0194417604109214e+04
            Stop		  5.1061301605491819e+04
            Start		  5.3028947728963140e+04
            Stop		  5.3895832545921643e+04
            Start		  5.5863479019650847e+04
            Stop		  5.6730363028524116e+04
            Start		  5.8698009144936645e+04
            Stop		  5.9564893968934084e+04
            Start		  6.1532540436373987e+04
            Stop		  6.2399424451344370e+04
            Start		  6.4367070562382316e+04
            Stop		  6.5233955391388758e+04
            Start		  6.7201601854673150e+04
            Stop		  6.8068485873281854e+04
            Start		  7.0036131981521394e+04
            Stop		  7.0903016812678383e+04
            Start		  7.2870663274669307e+04
            Stop		  7.3737547293821845e+04
            Start		  7.5705193402313205e+04
            Stop		  7.6572078232400745e+04
            Start		  7.8539724696188932e+04
            Stop		  7.9406608712693167e+04
            Start		  8.1374254824440883e+04
            Stop		  8.2241139650426776e+04
            Start		  8.4208786118794174e+04
            Stop		  8.5075670129914914e+04
            Strand		 6 64
            Strand		 6 65
            Strand		 6 66
            Strand		 6 67
            Start		  0.0000000000000000e+00
            Stop		  1.0676284738078709e+03
            Start		  2.7117282269360899e+03
            Stop		  3.9021591198786218e+03
            Start		  5.5462589153390545e+03
            Stop		  6.7366898332960891e+03
            Start		  8.3807896206399982e+03
            Stop		  9.5712205447391116e+03
            Start		  1.1215320325430781e+04
            Stop		  1.2405751257170308e+04
            Start		  1.4049851030578389e+04
            Stop		  1.5240281970300533e+04
            Start		  1.6884381736238411e+04
            Stop		  1.8074812683975062e+04
            Start		  1.9718912442580197e+04
            Stop		  2.0909343398006615e+04
            Start		  2.2553443149741015e+04
            Stop		  2.3743874112192898e+04
            Start		  2.5387973857822151e+04
            Stop		  2.6578404826324702e+04
            Start		  2.8222504566884654e+04
            Stop		  2.9412935540195238e+04
            Start		  3.1057035276946426e+04
            Stop		  3.2247466253609113e+04
            Start		  3.3891565987981514e+04
            Stop		  3.5081996966390980e+04
            Start		  3.6726096699921247e+04
            Stop		  3.7916527678393242e+04
            Start		  3.9560627412657188e+04
            Stop		  4.0751058389502476e+04
            Start		  4.2395158126045957e+04
            Stop		  4.3585589099644421e+04
            Start		  4.5229688839915507e+04
            Stop		  4.6420119808787305e+04
            Start		  4.8064219554072697e+04
            Stop		  4.9254650516943140e+04
            Start		  5.0898750268311669e+04
            Stop		  5.2089181224167274e+04
            Start		  5.3733280982423079e+04
            Stop		  5.4923711930555924e+04
            Start		  5.6567811696203084e+04
            Stop		  5.7758242636241957e+04
            Start		  5.9402342409462421e+04
            Stop		  6.0592773341389046e+04
            Start		  6.2236873122034653e+04
            Stop		  6.3427304046184479e+04
            Start		  6.5071403833783472e+04
            Stop		  6.6261834750830967e+04
            Start		  6.7905934544608754e+04
            Stop		  6.9096365455537802e+04
            Start		  7.0740465254450872e+04
            Stop		  7.1930896160511431e+04
            Start		  7.3574995963293361e+04
            Stop		  7.4765426865946720e+04
            Start		  7.6409526671163519e+04
            Stop		  7.7599957572018116e+04
            Start		  7.9244057378131401e+04
            Stop		  8.0434488278872173e+04
            Start		  8.2078588084306626e+04
            Stop		  8.3269018986621086e+04
            Start		  8.4913118789833563e+04
            Stop		  8.6103549695337715e+04
            Strand		 6 68
            Strand		 6 69
            Strand		 6 70
            Strand		 6 71
            Strand		 7 36
            Strand		 7 37
            Strand		 7 38
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 7 39
            Strand		 7 40
            Strand		 7 41
            Strand		 7 42
            Strand		 7 44
            Strand		 7 45
            Strand		 7 46
            Strand		 7 47
            Strand		 7 48
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 7 49
            Strand		 7 50
            Strand		 7 51
            Strand		 7 52
            Strand		 7 53
            Strand		 7 54
            Strand		 7 55
            Strand		 7 56
            Strand		 7 57
            Strand		 7 58
            Strand		 7 59
            Start		  5.0709733841287090e+02
            Stop		  1.6975235347269249e+03
            Start		  3.3416246372135092e+03
            Stop		  4.5320541756004213e+03
            Start		  6.1761553329151802e+03
            Stop		  7.3665848831810699e+03
            Start		  9.0106860451898228e+03
            Stop		  1.0201115587752276e+04
            Start		  1.1845216755890882e+04
            Stop		  1.3035646292569098e+04
            Start		  1.4679747465636250e+04
            Stop		  1.5870176997681447e+04
            Start		  1.7514278174382835e+04
            Stop		  1.8704707703289168e+04
            Start		  2.0348808882167352e+04
            Stop		  2.1539238409562167e+04
            Start		  2.3183339589067316e+04
            Stop		  2.4373769116641142e+04
            Start		  2.6017870295198987e+04
            Stop		  2.7208299824631569e+04
            Start		  2.8852401000712405e+04
            Stop		  3.0042830533598943e+04
            Start		  3.1686931705784693e+04
            Stop		  3.2877361243565851e+04
            Start		  3.4521462410612483e+04
            Stop		  3.5711891954510997e+04
            Start		  3.7355993115403078e+04
            Stop		  3.8546422666370141e+04
            Start		  4.0190523820365481e+04
            Stop		  4.1380953379038903e+04
            Start		  4.3025054525701191e+04
            Stop		  4.4215484092377352e+04
            Start		  4.5859585231595331e+04
            Stop		  4.7050014806216190e+04
            Start		  4.8694115938208517e+04
            Stop		  4.9884545520364074e+04
            Start		  5.1528646645669905e+04
            Stop		  5.2719076234616165e+04
            Start		  5.4363177354071398e+04
            Stop		  5.5553606948763008e+04
            Start		  5.7197708063463666e+04
            Stop		  5.8388137662599780e+04
            Start		  6.0032238773853918e+04
            Stop		  6.1222668375935224e+04
            Start		  6.2866769485205645e+04
            Stop		  6.4057199088600115e+04
            Start		  6.5701300197440054e+04
            Stop		  6.6891729800454632e+04
            Start		  6.8535830910439792e+04
            Stop		  6.9726260511394576e+04
            Start		  7.1370361624053869e+04
            Stop		  7.2560791221355787e+04
            Start		  7.4204892338104328e+04
            Stop		  7.5395321930317077e+04
            Start		  7.7039423052394210e+04
            Stop		  7.8229852638301280e+04
            Start		  7.9873953766716062e+04
            Stop		  8.1064383345373877e+04
            Start		  8.2708484480860978e+04
            Stop		  8.3898914051640531e+04
            Start		  8.5543015194627995e+04
            Stop		  8.6400000000000000e+04
            Strand		 7 60
            Strand		 7 61
            Strand		 7 62
            Strand		 7 63
            Start		  1.5349633527991675e+03
            Stop		  2.4018684006929161e+03
            Start		  4.3694934039180334e+03
            Stop		  5.2363994181042717e+03
            Start		  7.2040247679709182e+03
            Stop		  8.0709296866802733e+03
            Start		  1.0038553472984288e+04
            Stop		  1.0905460638009985e+04
            Start		  1.2873086183437166e+04
            Stop		  1.3739991046747233e+04
            Start		  1.5707616749231007e+04
            Stop		  1.6574521988912020e+04
            Start		  1.8542147599987387e+04
            Stop		  1.9409052446525107e+04
            Start		  2.1376677882219101e+04
            Stop		  2.2243583387191724e+04
            Start		  2.4211209018069927e+04
            Stop		  2.5078113860658163e+04
            Start		  2.7045739207662613e+04
            Stop		  2.7912644800539059e+04
            Start		  2.9880270437844309e+04
            Stop		  3.0747175278684364e+04
            Start		  3.2714800597393216e+04
            Stop		  3.3581706217730221e+04
            Start		  3.5549331859168968e+04
            Stop		  3.6416236696817825e+04
            Start		  3.8383862009154342e+04
            Stop		  3.9250767635007767e+04
            Start		  4.1218393281630553e+04
            Stop		  4.2085298113871715e+04
            Start		  4.4052923428590468e+04
            Stop		  4.4919829051315399e+04
            Start		  4.6887454704617354e+04
            Stop		  4.7754359529733207e+04
            Start		  4.9721984850461027e+04
            Stop		  5.0588890466666089e+04
            Start		  5.2556516127426134e+04
            Stop		  5.3423420944791920e+04
            Start		  5.5391046272552616e+04
            Stop		  5.6257951881537178e+04
            Start		  5.8225577549384281e+04
            Stop		  5.9092482359674825e+04
            Start		  6.1060107693753787e+04
            Stop		  6.1927013296587917e+04
            Start		  6.3894638969966822e+04
            Stop		  6.4761543775071790e+04
            Start		  6.6729169113484633e+04
            Stop		  6.7596074712478934e+04
            Start		  6.9563700388887475e+04
            Stop		  7.0430605191594150e+04
            Start		  7.2398230531545094e+04
            Stop		  7.3265136129735693e+04
            Start		  7.5232761806148410e+04
            Stop		  7.6099666609661333e+04
            Start		  7.8067291948066253e+04
            Stop		  7.8934197548650031e+04
            Start		  8.0901823222039704e+04
            Stop		  8.1768728029425634e+04
            Start		  8.3736353363459901e+04
            Stop		  8.4603258969227245e+04
            Strand		 7 64
            Start		  1.0625512618475523e+03
            Stop		  1.9294386315278009e+03
            Start		  3.8970826851218822e+03
            Stop		  4.7639705189467568e+03
            Start		  6.7316126515782698e+03
            Stop		  7.5984971029434137e+03
            Start		  9.5661432180057927e+03
            Stop		  1.0433027696525491e+04
            Start		  1.2400671045505380e+04
            Stop		  1.3267558737164269e+04
            Start		  1.5235204000627917e+04
            Stop		  1.6102089344728032e+04
            Start		  1.8069733962536255e+04
            Stop		  1.8936620304447129e+04
            Start		  2.0904266952182083e+04
            Stop		  2.1771150884502425e+04
            Start		  2.3738796502639198e+04
            Stop		  2.4605681823752104e+04
            Start		  2.6573328371301905e+04
            Stop		  2.7440212336918095e+04
            Start		  2.9407858305327354e+04
            Stop		  3.0274743274828375e+04
            Start		  3.2242389788768374e+04
            Stop		  3.3109273766227445e+04
            Start		  3.5076919850391096e+04
            Stop		  3.5943804704775794e+04
            Start		  3.7911451204832556e+04
            Stop		  3.8778335189562080e+04
            Start		  4.0745981308494658e+04
            Stop		  4.1612866128915870e+04
            Start		  4.3580512619997884e+04
            Stop		  4.4447396611993412e+04
            Start		  4.6415042737541480e+04
            Stop		  4.7281927552007437e+04
            Start		  4.9249574034927340e+04
            Stop		  5.0116458034803196e+04
            Start		  5.2084104157279609e+04
            Stop		  5.2950988975201202e+04
            Start		  5.4918635450326066e+04
            Stop		  5.5785519457943505e+04
            Start		  5.7753165574697436e+04
            Stop		  5.8620050398381529e+04
            Start		  6.0587696866818223e+04
            Stop		  6.1454580880895526e+04
            Start		  6.3422226992423246e+04
            Stop		  6.4289111821022794e+04
            Start		  6.6256758284838375e+04
            Stop		  6.7123642303036962e+04
            Start		  6.9091288411456131e+04
            Stop		  6.9958173242556761e+04
            Start		  7.1925819704555906e+04
            Stop		  7.2792703723841245e+04
            Start		  7.4760349832047155e+04
            Stop		  7.5627234662562390e+04
            Start		  7.7594881125845612e+04
            Stop		  7.8461765142999153e+04
            Start		  8.0429411254004590e+04
            Stop		  8.1296296080869201e+04
            Start		  8.3263942548309526e+04
            Stop		  8.4130826560482485e+04
            Start		  8.6098472676842794e+04
            Stop		  8.6400000000000000e+04
            Strand		 7 65
            Strand		 7 66
            Strand		 7 67
            Strand		 7 68
            Start		  0.0000000000000000e+00
            Stop		  1.2278465097688994e+02
            Start		  1.7668846185568837e+03
            Stop		  2.9573155667684214e+03
            Start		  4.6014153509041544e+03
            Stop		  5.7918462621317858e+03
            Start		  7.4359460522201362e+03
            Stop		  8.6263769741550168e+03
            Start		  1.0270476757140073e+04
            Stop		  1.1460907686274413e+04
            Start		  1.3105007462147769e+04
            Stop		  1.4295438399188070e+04
            Start		  1.5939538167617062e+04
            Stop		  1.7129969112700903e+04
            Start		  1.8774068873714663e+04
            Stop		  1.9964499826635354e+04
            Start		  2.1608599580589358e+04
            Stop		  2.2799030540793152e+04
            Start		  2.4443130288354874e+04
            Stop		  2.5633561254966407e+04
            Start		  2.7277660997086106e+04
            Stop		  2.8468091968946483e+04
            Start		  3.0112191706815509e+04
            Stop		  3.1302622682533205e+04
            Start		  3.2946722417531724e+04
            Stop		  3.4137153395543675e+04
            Start		  3.5781253129180070e+04
            Stop		  3.6971684107820220e+04
            Start		  3.8615783841664947e+04
            Stop		  3.9806214819237386e+04
            Start		  4.1450314554853940e+04
            Stop		  4.2640745529707427e+04
            Start		  4.4284845268583827e+04
            Stop		  4.5475276239184175e+04
            Start		  4.7119375982667545e+04
            Stop		  4.8309806947664983e+04
            Start		  4.9953906696902544e+04
            Stop		  5.1144337655190931e+04
            Start		  5.2788437411079569e+04
            Stop		  5.3978868361845045e+04
            Start		  5.5622968124991981e+04
            Stop		  5.6813399067748462e+04
            Start		  5.8457498838444648e+04
            Stop		  5.9647929773055381e+04
            Start		  6.1292029551262662e+04
            Stop		  6.2482460477946101e+04
            Start		  6.4126560263298998e+04
            Stop		  6.5316991182619153e+04
            Start		  6.6961090974440827e+04
            Stop		  6.8151521887282594e+04
            Start		  6.9795621684614685e+04
            Stop		  7.0986052592144872e+04
            Start		  7.2630152393789482e+04
            Stop		  7.3820583297405712e+04
            Start		  7.5464683101978022e+04
            Stop		  7.6655114003247247e+04
            Start		  7.8299213809236360e+04
            Stop		  7.9489644709826156e+04
            Start		  8.1133744515661354e+04
            Stop		  8.2324175417266655e+04
            Start		  8.3968275221386415e+04
            Stop		  8.5158706125655212e+04
            Strand		 7 69
            Strand		 7 70
            Strand		 7 71
            Strand		 8 36
            Strand		 8 37
            Strand		 8 38
            Strand		 8 39
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 8 40
            Strand		 8 41
            Strand		 8 42
            Strand		 8 43
            Strand		 8 45
            Strand		 8 46
            Strand		 8 47
            Strand		 8 48
            Strand		 8 49
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 8 50
            Strand		 8 51
            Strand		 8 52
            Strand		 8 53
            Strand		 8 54
            Start		  0.0000000000000000e+00
            Stop		  7.5267990263043146e+02
            Start		  2.3967810495435688e+03
            Stop		  3.5872106099890966e+03
            Start		  5.2313117627646980e+03
            Stop		  6.4217413147903289e+03
            Start		  8.0658424747031258e+03
            Stop		  9.2562720195215170e+03
            Start		  1.0900373185756498e+04
            Stop		  1.2090802724275121e+04
            Start		  1.3734903895832836e+04
            Stop		  1.4925333429264683e+04
            Start		  1.6569434604910133e+04
            Stop		  1.7759864134687185e+04
            Start		  1.9403965313008808e+04
            Stop		  2.0594394840721237e+04
            Start		  2.2238496020192521e+04
            Stop		  2.3428925547517971e+04
            Start		  2.5073026726565175e+04
            Stop		  2.6263456255195244e+04
            Start		  2.7907557432266178e+04
            Stop		  2.9097986963832311e+04
            Start		  3.0742088137464452e+04
            Stop		  3.1932517673466253e+04
            Start		  3.3576618842351068e+04
            Stop		  3.4767048384090383e+04
            Start		  3.6411149547130735e+04
            Stop		  3.7601579095654546e+04
            Start		  3.9245680252012920e+04
            Stop		  4.0436109808067347e+04
            Start		  4.2080210957202631e+04
            Stop		  4.3270640521200075e+04
            Start		  4.4914741662891407e+04
            Stop		  4.6105171234892427e+04
            Start		  4.7749272369248873e+04
            Stop		  4.8939701948959584e+04
            Start		  5.0583803076415381e+04
            Stop		  5.1774232663200200e+04
            Start		  5.3418333784495779e+04
            Stop		  5.4608763377405296e+04
            Start		  5.6252864493554807e+04
            Stop		  5.7443294091367505e+04
            Start		  5.9087395203614324e+04
            Stop		  6.0277824804890122e+04
            Start		  6.1921925914652267e+04
            Stop		  6.3112355517795651e+04
            Start		  6.4756456626603693e+04
            Stop		  6.5946886229933778e+04
            Start		  6.7590987339363564e+04
            Stop		  6.8781416941187723e+04
            Start		  7.0425518052791478e+04
            Stop		  7.1615947651479655e+04
            Start		  7.3260048766717577e+04
            Stop		  7.4450478360773937e+04
            Start		  7.6094579480950386e+04
            Stop		  7.7285009069078616e+04
            Start		  7.8929110195284899e+04
            Stop		  8.0119539776445250e+04
            Start		  8.1763640909511683e+04
            Stop		  8.2954070482966548e+04
            Start		  8.4598171623426184e+04
            Stop		  8.5788601188772227e+04
            Strand		 8 55
            Strand		 8 56
            Strand		 8 57
            Strand		 8 58
            Strand		 8 59
            Strand		 8 60
            Strand		 8 61
            Strand		 8 62
            Strand		 8 63
            Strand		 8 64
            Start		  5.9011978098280417e+02
            Stop		  1.4570248489689229e+03
            Start		  3.4246504910797821e+03
            Stop		  4.2915555825354959e+03
            Start		  6.2591811724938370e+03
            Stop		  7.1260866441440412e+03
            Start		  9.0937119063180453e+03
            Stop		  9.9606168539054634e+03
            Start		  1.1928240819241295e+04
            Stop		  1.2795147812211135e+04
            Start		  1.4762773322119001e+04
            Stop		  1.5629678198194162e+04
            Start		  1.7597304022606022e+04
            Stop		  1.8464209141171701e+04
            Start		  2.0431834739157333e+04
            Stop		  2.1298739590984005e+04
            Start		  2.3266365065723494e+04
            Stop		  2.4133270531585564e+04
            Start		  2.6100896157805440e+04
            Stop		  2.6967801002285247e+04
            Start		  2.8935426362199756e+04
            Stop		  2.9802331941928689e+04
            Start		  3.1769957578128233e+04
            Stop		  3.2636862418955418e+04
            Start		  3.4604487742710284e+04
            Stop		  3.5471393357719084e+04
            Start		  3.7439018999889944e+04
            Stop		  3.8305923836245507e+04
            Start		  4.0273549151612089e+04
            Stop		  4.1140454774169593e+04
            Start		  4.3108080422601677e+04
            Stop		  4.3974985252701874e+04
            Start		  4.5942610570125194e+04
            Stop		  4.6809516189944334e+04
            Start		  4.8777141845608363e+04
            Stop		  4.9644046668176888e+04
            Start		  5.1611671991545962e+04
            Stop		  5.2478577605008664e+04
            Start		  5.4446203268203288e+04
            Stop		  5.5313108083081279e+04
            Start		  5.7280733413202681e+04
            Stop		  5.8147639019843235e+04
            Start		  6.0115264689750991e+04
            Stop		  6.0982169498053554e+04
            Start		  6.2949794833882028e+04
            Stop		  6.3816700435098297e+04
            Start		  6.5784326109797708e+04
            Stop		  6.6651230913763036e+04
            Start		  6.8618856253036036e+04
            Stop		  6.9485761851393894e+04
            Start		  7.1453387528150139e+04
            Stop		  7.2320292330765107e+04
            Start		  7.4287917670545372e+04
            Stop		  7.5154823269183573e+04
            Start		  7.7122448944909047e+04
            Stop		  7.7989353749395275e+04
            Start		  7.9956979086630323e+04
            Stop		  8.0823884688666105e+04
            Start		  8.2791510360451692e+04
            Stop		  8.3658415169708009e+04
            Start		  8.5626040501776253e+04
            Stop		  8.6400000000000000e+04
            Strand		 8 65
            Start		  1.1770840402934809e+02
            Stop		  9.8459262598333737e+02
            Start		  2.9522381510963878e+03
            Stop		  3.8191236207474931e+03
            Start		  5.7867698272425087e+03
            Stop		  6.6536539156578710e+03
            Start		  8.6212984265139494e+03
            Stop		  9.4881848596650489e+03
            Start		  1.1455831250020094e+04
            Stop		  1.2322715275500559e+04
            Start		  1.4290361740051980e+04
            Stop		  1.5157246212782946e+04
            Start		  1.7124892671770158e+04
            Stop		  1.7991776670567975e+04
            Start		  1.9959422918384742e+04
            Stop		  2.0826307607309598e+04
            Start		  2.2793954092042222e+04
            Stop		  2.3660838079438683e+04
            Start		  2.5628484257963850e+04
            Stop		  2.6495369016643937e+04
            Start		  2.8463015510623452e+04
            Stop		  2.9329899494065885e+04
            Start		  3.1297545649352476e+04
            Stop		  3.2164430432031233e+04
            Start		  3.4132076927588110e+04
            Stop		  3.4998960911810231e+04
            Start		  3.6966607056917615e+04
            Stop		  3.7833491850625935e+04
            Start		  3.9801138343289138e+04
            Stop		  4.0668022331746703e+04
            Start		  4.2635668469313809e+04
            Stop		  4.3502553271345787e+04
            Start		  4.5470199758298375e+04
            Stop		  4.6337083753330611e+04
            Start		  4.8304729883283297e+04
            Stop		  4.9171614693508564e+04
            Start		  5.1139261173307692e+04
            Stop		  5.2006145175984566e+04
            Start		  5.3973791298243050e+04
            Stop		  5.4840676116436036e+04
            Start		  5.6808322589009018e+04
            Stop		  5.7675206599029290e+04
            Start		  5.9642852714412438e+04
            Stop		  6.0509737539401322e+04
            Start		  6.2477384005974207e+04
            Stop		  6.3344268021745353e+04
            Start		  6.5311914132123005e+04
            Stop		  6.6178798961698878e+04
            Start		  6.8146445424555772e+04
            Stop		  6.9013329443479743e+04
            Start		  7.0980975551545242e+04
            Stop		  7.1847860382748229e+04
            Start		  7.3815506844825679e+04
            Stop		  7.4682390863752837e+04
            Start		  7.6650036972587826e+04
            Stop		  7.7516921802188794e+04
            Start		  7.9484568266562885e+04
            Stop		  8.0351452282339858e+04
            Start		  8.2319098394889879e+04
            Stop		  8.3185983219940346e+04
            Start		  8.5153629689291804e+04
            Stop		  8.6020513699309129e+04
            Strand		 8 66
            Strand		 8 67
            Strand		 8 68
            Strand		 8 69
            Start		  8.2204520067875774e+02
            Stop		  2.0124720930026563e+03
            Start		  3.6565718124384630e+03
            Stop		  4.8470026886509841e+03
            Start		  6.4911024832863350e+03
            Stop		  7.6815334037943603e+03
            Start		  9.3256331889055509e+03
            Stop		  1.0516064115456167e+04
            Start		  1.2160163893766236e+04
            Stop		  1.3350594828142968e+04
            Start		  1.4994694599065871e+04
            Stop		  1.6185125541473732e+04
            Start		  1.7829225304935750e+04
            Stop		  1.9019656255288995e+04
            Start		  2.0663756011537025e+04
            Stop		  2.1854186969395134e+04
            Start		  2.3498286718995256e+04
            Stop		  2.4688717683586568e+04
            Start		  2.6332817427398833e+04
            Stop		  2.7523248397653897e+04
            Start		  2.9167348136794593e+04
            Stop		  3.0357779111393087e+04
            Start		  3.2001878847185853e+04
            Stop		  3.3192309824614553e+04
            Start		  3.4836409558532170e+04
            Stop		  3.6026840537151395e+04
            Start		  3.7670940270751184e+04
            Stop		  3.8861371248866737e+04
            Start		  4.0505470983722218e+04
            Stop		  4.1695901959659735e+04
            Start		  4.3340001697291591e+04
            Stop		  4.4530432669470043e+04
            Start		  4.6174532411279280e+04
            Stop		  4.7364963378280401e+04
            Start		  4.9009063125486959e+04
            Stop		  5.0199494086117455e+04
            Start		  5.1843593839706598e+04
            Stop		  5.3034024793050470e+04
            Start		  5.4678124553729642e+04
            Stop		  5.5868555499188515e+04
            Start		  5.7512655267356160e+04
            Stop		  5.8703086204675375e+04
            Start		  6.0347185980403578e+04
            Stop		  6.1537616909683493e+04
            Start		  6.3181716692714828e+04
            Stop		  6.4372147614406276e+04
            Start		  6.6016247404165042e+04
            Stop		  6.7206678319049563e+04
            Start		  6.8850778114667119e+04
            Stop		  7.0041209023822783e+04
            Start		  7.1685308824175692e+04
            Stop		  7.2875739728929446e+04
            Start		  7.4519839532688828e+04
            Stop		  7.5710270434558624e+04
            Start		  7.7354370240248434e+04
            Stop		  7.8544801140876196e+04
            Start		  8.0188900946938127e+04
            Stop		  8.1379331848017944e+04
            Start		  8.3023431652879633e+04
            Stop		  8.4213862556083375e+04
            Start		  8.5857962358227669e+04
            Stop		  8.6400000000000000e+04
            Strand		 8 70
            Strand		 8 71
            Strand		 9 36
            Strand		 9 37
            Strand		 9 38
            Strand		 9 39
            Strand		 9 40
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 9 41
            Strand		 9 42
            Strand		 9 43
            Strand		 9 44
            Strand		 9 46
            Strand		 9 47
            Strand		 9 48
            Strand		 9 49
            Strand		 9 50
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 9 51
            Strand		 9 52
            Strand		 9 53
            Strand		 9 54
            Strand		 9 55
            Start		  1.4519398699029086e+03
            Stop		  2.6423672213239861e+03
            Start		  4.2864682872322073e+03
            Stop		  5.4768977422459620e+03
            Start		  7.1209989032112317e+03
            Stop		  8.3114284515057298e+03
            Start		  9.9555296155602664e+03
            Stop		  1.1145959155996678e+04
            Start		  1.2790060325915676e+04
            Stop		  1.3980489860896723e+04
            Start		  1.5624591035328462e+04
            Stop		  1.6815020566153376e+04
            Start		  1.8459121743748259e+04
            Stop		  1.9649551271965305e+04
            Start		  2.1293652451227306e+04
            Stop		  2.2484081978492944e+04
            Start		  2.4128183157856463e+04
            Stop		  2.5318612685865912e+04
            Start		  2.6962713863763896e+04
            Stop		  2.8153143394176797e+04
            Start		  2.9797244569109436e+04
            Stop		  3.0987674103476998e+04
            Start		  3.2631775274077696e+04
            Stop		  3.3822204813774508e+04
            Start		  3.5466305978869765e+04
            Stop		  3.6656735525033509e+04
            Start		  3.8300836683694586e+04
            Stop		  3.9491266237176002e+04
            Start		  4.1135367388759674e+04
            Stop		  4.2325796950085110e+04
            Start		  4.3969898094262004e+04
            Stop		  4.5160327663610427e+04
            Start		  4.6804428800379392e+04
            Stop		  4.7994858377574383e+04
            Start		  4.9638959507262713e+04
            Stop		  5.0829389091780184e+04
            Start		  5.2473490215029226e+04
            Stop		  5.3663919806020444e+04
            Start		  5.5308020923757460e+04
            Stop		  5.6498450520086204e+04
            Start		  5.8142551633483759e+04
            Stop		  5.9332981233776190e+04
            Start		  6.0977082344200695e+04
            Stop		  6.2167511946905594e+04
            Start		  6.3811613055857393e+04
            Stop		  6.5002042659314240e+04
            Start		  6.6646143768361770e+04
            Stop		  6.7836573370873579e+04
            Start		  6.9480674481584530e+04
            Stop		  7.0671104081492289e+04
            Start		  7.2315205195364935e+04
            Stop		  7.3505634791120421e+04
            Start		  7.5149735909517811e+04
            Stop		  7.6340165499751311e+04
            Start		  7.7984266623841657e+04
            Stop		  7.9174696207422327e+04
            Start		  8.0818797338127508e+04
            Stop		  8.2009226914212690e+04
            Start		  8.3653328052168174e+04
            Stop		  8.4843757620240387e+04
            Strand		 9 56
            Strand		 9 57
            Strand		 9 58
            Strand		 9 59
            Strand		 9 60
            Start		  0.0000000000000000e+00
            Stop		  3.9749042880307982e+01
            Start		  2.0073944261648489e+03
            Stop		  2.8742800289318088e+03
            Start		  4.8419262567447777e+03
            Stop		  5.7088103394741420e+03
            Start		  7.6764548059067874e+03
            Stop		  8.5433412823011950e+03
            Start		  1.0510987679622087e+04
            Stop		  1.1377871703735875e+04
            Start		  1.3345518137141204e+04
            Stop		  1.4212402640862572e+04
            Start		  1.6180049101574150e+04
            Stop		  1.7046933100474318e+04
            Start		  1.9014579337611001e+04
            Stop		  1.9881464037133188e+04
            Start		  2.1849110522112875e+04
            Stop		  2.2715994509789256e+04
            Start		  2.4683640684646172e+04
            Stop		  2.5550525446880842e+04
            Start		  2.7518171940978096e+04
            Stop		  2.8385055924379136e+04
            Start		  3.0352702078673148e+04
            Stop		  3.1219586862205775e+04
            Start		  3.3187233358194499e+04
            Stop		  3.4054117341909128e+04
            Start		  3.6021763487237724e+04
            Stop		  3.6888648280583409e+04
            Start		  3.8856294774071219e+04
            Stop		  3.9723178761592862e+04
            Start		  4.1690824900017164e+04
            Stop		  4.2557709701072134e+04
            Start		  4.4525356189149505e+04
            Stop		  4.5392240182963469e+04
            Start		  4.7359886314082032e+04
            Stop		  4.8226771123063969e+04
            Start		  5.0194417604109214e+04
            Stop		  5.1061301605491797e+04
            Start		  5.3028947728963125e+04
            Stop		  5.3895832545921628e+04
            Start		  5.5863479019650847e+04
            Stop		  5.6730363028524087e+04
            Start		  5.8698009144936630e+04
            Stop		  5.9564893968934055e+04
            Start		  6.1532540436373980e+04
            Stop		  6.2399424451344348e+04
            Start		  6.4367070562382309e+04
            Stop		  6.5233955391388736e+04
            Start		  6.7201601854673121e+04
            Stop		  6.8068485873281825e+04
            Start		  7.0036131981521365e+04
            Stop		  7.0903016812678354e+04
            Start		  7.2870663274669292e+04
            Stop		  7.3737547293821786e+04
            Start		  7.5705193402313162e+04
            Stop		  7.6572078232400730e+04
            Start		  7.8539724696188947e+04
            Stop		  7.9406608712693167e+04
            Start		  8.1374254824440854e+04
            Stop		  8.2241139650426747e+04
            Start		  8.4208786118794174e+04
            Stop		  8.5075670129914855e+04
            Strand		 9 61
            Strand		 9 62
            Strand		 9 63
            Strand		 9 64
            Strand		 9 65
            Start		  0.0000000000000000e+00
            Stop		  5.1218200003446168e+02
            Start		  2.4798069220354118e+03
            Stop		  3.3467119912597282e+03
            Start		  5.3143372595828441e+03
            Stop		  6.1812430280376848e+03
            Start		  8.1488683371369389e+03
            Stop		  9.0157732693092294e+03
            Start		  1.0983397136211597e+04
            Stop		  1.1850304223616655e+04
            Start		  1.3817929752761474e+04
            Stop		  1.4684834622015913e+04
            Start		  1.6652460379538043e+04
            Stop		  1.7519365564524174e+04
            Start		  1.9486991169550103e+04
            Stop		  2.0353896018599396e+04
            Start		  2.2321521471875443e+04
            Stop		  2.3188426959228898e+04
            Start		  2.5156052587913899e+04
            Stop		  2.6022957431434286e+04
            Start		  2.7990582784226859e+04
            Stop		  2.8857488371197545e+04
            Start		  3.0825114007965178e+04
            Stop		  3.1692018848824293e+04
            Start		  3.3659644169808562e+04
            Stop		  3.4526549787729105e+04
            Start		  3.6494175429514740e+04
            Stop		  3.7361080266548350e+04
            Start		  3.9328705580298418e+04
            Stop		  4.0195611204603505e+04
            Start		  4.2163236852110356e+04
            Stop		  4.3030141683303198e+04
            Start		  4.4997766999332460e+04
            Stop		  4.5864672620642690e+04
            Start		  4.7832298275117071e+04
            Stop		  4.8699203098965088e+04
            Start		  5.0666828421004378e+04
            Stop		  5.1533734035842725e+04
            Start		  5.3501359697828157e+04
            Stop		  5.4368264513937458e+04
            Start		  5.6335889842892218e+04
            Stop		  5.7202795450686084e+04
            Start		  5.9170421119587991e+04
            Stop		  6.0037325928855382e+04
            Start		  6.2004951263839554e+04
            Stop		  6.2871856865829854e+04
            Start		  6.4839482539905992e+04
            Stop		  6.5706387344400355e+04
            Start		  6.7674012683283931e+04
            Stop		  6.8540918281916194e+04
            Start		  7.0508543958541821e+04
            Stop		  7.1375448761157197e+04
            Start		  7.3343074101066275e+04
            Stop		  7.4209979699435949e+04
            Start		  7.6177605375547049e+04
            Stop		  7.7044510179504432e+04
            Start		  7.9012135517362956e+04
            Stop		  7.9879041118635025e+04
            Start		  8.1846666791256139e+04
            Stop		  8.2713571599545627e+04
            Start		  8.4681196932623789e+04
            Stop		  8.5548102539469139e+04
            Strand		 9 66
            Strand		 9 67
            Strand		 9 68
            Strand		 9 69
            Strand		 9 70
            Start		  0.0000000000000000e+00
            Stop		  1.0676284738078682e+03
            Start		  2.7117282269360962e+03
            Stop		  3.9021591198786200e+03
            Start		  5.5462589153390591e+03
            Stop		  6.7366898332960882e+03
            Start		  8.3807896206399928e+03
            Stop		  9.5712205447391116e+03
            Start		  1.1215320325430779e+04
            Stop		  1.2405751257170312e+04
            Start		  1.4049851030578393e+04
            Stop		  1.5240281970300528e+04
            Start		  1.6884381736238414e+04
            Stop		  1.8074812683975055e+04
            Start		  1.9718912442580189e+04
            Stop		  2.0909343398006618e+04
            Start		  2.2553443149741004e+04
            Stop		  2.3743874112192883e+04
            Start		  2.5387973857822155e+04
            Stop		  2.6578404826324706e+04
            Start		  2.8222504566884643e+04
            Stop		  2.9412935540195227e+04
            Start		  3.1057035276946419e+04
            Stop		  3.2247466253609098e+04
            Start		  3.3891565987981514e+04
            Stop		  3.5081996966390980e+04
            Start		  3.6726096699921232e+04
            Stop		  3.7916527678393235e+04
            Start		  3.9560627412657173e+04
            Stop		  4.0751058389502454e+04
            Start		  4.2395158126045957e+04
            Stop		  4.3585589099644400e+04
            Start		  4.5229688839915492e+04
            Stop		  4.6420119808787284e+04
            Start		  4.8064219554072668e+04
            Stop		  4.9254650516943126e+04
            Start		  5.0898750268311669e+04
            Stop		  5.2089181224167260e+04
            Start		  5.3733280982423064e+04
            Stop		  5.4923711930555917e+04
            Start		  5.6567811696203054e+04
            Stop		  5.7758242636241943e+04
            Start		  5.9402342409462377e+04
            Stop		  6.0592773341389009e+04
            Start		  6.2236873122034609e+04
            Stop		  6.3427304046184458e+04
            Start		  6.5071403833783443e+04
            Stop		  6.6261834750830996e+04
            Start		  6.7905934544608768e+04
            Stop		  6.9096365455537773e+04
            Start		  7.0740465254450886e+04
            Stop		  7.1930896160511416e+04
            Start		  7.3574995963293346e+04
            Stop		  7.4765426865946676e+04
            Start		  7.6409526671163490e+04
            Stop		  7.7599957572018087e+04
            Start		  7.9244057378131387e+04
            Stop		  8.0434488278872130e+04
            Start		  8.2078588084306626e+04
            Stop		  8.3269018986621071e+04
            Start		  8.4913118789833534e+04
            Stop		  8.6103549695337642e+04
            Strand		 9 71
            Strand		 10 36
            Strand		 10 37
            Strand		 10 38
            Strand		 10 39
            Strand		 10 40
            Strand		 10 41
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 10 42
            Strand		 10 43
            Strand		 10 44
            Strand		 10 45
            Strand		 10 47
            Strand		 10 48
            Strand		 10 49
            Strand		 10 50
            Strand		 10 51
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 10 52
            Strand		 10 53
            Strand		 10 54
            Strand		 10 55
            Strand		 10 56
            Start		  5.0709733841287971e+02
            Stop		  1.6975235347269247e+03
            Start		  3.3416246372135083e+03
            Stop		  4.5320541756004222e+03
            Start		  6.1761553329151875e+03
            Stop		  7.3665848831810781e+03
            Start		  9.0106860451898247e+03
            Stop		  1.0201115587752281e+04
            Start		  1.1845216755890875e+04
            Stop		  1.3035646292569101e+04
            Start		  1.4679747465636243e+04
            Stop		  1.5870176997681450e+04
            Start		  1.7514278174382838e+04
            Stop		  1.8704707703289172e+04
            Start		  2.0348808882167366e+04
            Stop		  2.1539238409562182e+04
            Start		  2.3183339589067324e+04
            Stop		  2.4373769116641146e+04
            Start		  2.6017870295198994e+04
            Stop		  2.7208299824631573e+04
            Start		  2.8852401000712402e+04
            Stop		  3.0042830533598950e+04
            Start		  3.1686931705784711e+04
            Stop		  3.2877361243565865e+04
            Start		  3.4521462410612490e+04
            Stop		  3.5711891954511018e+04
            Start		  3.7355993115403100e+04
            Stop		  3.8546422666370148e+04
            Start		  4.0190523820365495e+04
            Stop		  4.1380953379038918e+04
            Start		  4.3025054525701205e+04
            Stop		  4.4215484092377366e+04
            Start		  4.5859585231595323e+04
            Stop		  4.7050014806216190e+04
            Start		  4.8694115938208524e+04
            Stop		  4.9884545520364103e+04
            Start		  5.1528646645669927e+04
            Stop		  5.2719076234616201e+04
            Start		  5.4363177354071406e+04
            Stop		  5.5553606948763059e+04
            Start		  5.7197708063463673e+04
            Stop		  5.8388137662599795e+04
            Start		  6.0032238773853926e+04
            Stop		  6.1222668375935231e+04
            Start		  6.2866769485205637e+04
            Stop		  6.4057199088600144e+04
            Start		  6.5701300197440098e+04
            Stop		  6.6891729800454646e+04
            Start		  6.8535830910439821e+04
            Stop		  6.9726260511394590e+04
            Start		  7.1370361624053883e+04
            Stop		  7.2560791221355787e+04
            Start		  7.4204892338104371e+04
            Stop		  7.5395321930317121e+04
            Start		  7.7039423052394224e+04
            Stop		  7.8229852638301280e+04
            Start		  7.9873953766716048e+04
            Stop		  8.1064383345373906e+04
            Start		  8.2708484480860992e+04
            Stop		  8.3898914051640561e+04
            Start		  8.5543015194628053e+04
            Stop		  8.6400000000000000e+04
            Strand		 10 57
            Strand		 10 58
            Strand		 10 59
            Strand		 10 60
            Start		  1.5349633527991657e+03
            Stop		  2.4018684006929252e+03
            Start		  4.3694934039180307e+03
            Stop		  5.2363994181042744e+03
            Start		  7.2040247679709155e+03
            Stop		  8.0709296866802742e+03
            Start		  1.0038553472984277e+04
            Stop		  1.0905460638009987e+04
            Start		  1.2873086183437157e+04
            Stop		  1.3739991046747244e+04
            Start		  1.5707616749231007e+04
            Stop		  1.6574521988912013e+04
            Start		  1.8542147599987380e+04
            Stop		  1.9409052446525115e+04
            Start		  2.1376677882219097e+04
            Stop		  2.2243583387191728e+04
            Start		  2.4211209018069905e+04
            Stop		  2.5078113860658166e+04
            Start		  2.7045739207662609e+04
            Stop		  2.7912644800539070e+04
            Start		  2.9880270437844305e+04
            Stop		  3.0747175278684375e+04
            Start		  3.2714800597393212e+04
            Stop		  3.3581706217730229e+04
            Start		  3.5549331859168953e+04
            Stop		  3.6416236696817818e+04
            Start		  3.8383862009154320e+04
            Stop		  3.9250767635007767e+04
            Start		  4.1218393281630531e+04
            Stop		  4.2085298113871730e+04
            Start		  4.4052923428590460e+04
            Stop		  4.4919829051315392e+04
            Start		  4.6887454704617347e+04
            Stop		  4.7754359529733214e+04
            Start		  4.9721984850461005e+04
            Stop		  5.0588890466666089e+04
            Start		  5.2556516127426105e+04
            Stop		  5.3423420944791920e+04
            Start		  5.5391046272552601e+04
            Stop		  5.6257951881537185e+04
            Start		  5.8225577549384252e+04
            Stop		  5.9092482359674810e+04
            Start		  6.1060107693753765e+04
            Stop		  6.1927013296587924e+04
            Start		  6.3894638969966814e+04
            Stop		  6.4761543775071797e+04
            Start		  6.6729169113484590e+04
            Stop		  6.7596074712478920e+04
            Start		  6.9563700388887446e+04
            Stop		  7.0430605191594150e+04
            Start		  7.2398230531545094e+04
            Stop		  7.3265136129735693e+04
            Start		  7.5232761806148366e+04
            Stop		  7.6099666609661319e+04
            Start		  7.8067291948066224e+04
            Stop		  7.8934197548650031e+04
            Start		  8.0901823222039689e+04
            Stop		  8.1768728029425634e+04
            Start		  8.3736353363459872e+04
            Stop		  8.4603258969227230e+04
            Strand		 10 61
            Start		  1.0625512618475520e+03
            Stop		  1.9294386315277898e+03
            Start		  3.8970826851218812e+03
            Stop		  4.7639705189467641e+03
            Start		  6.7316126515782717e+03
            Stop		  7.5984971029434209e+03
            Start		  9.5661432180057891e+03
            Stop		  1.0433027696525505e+04
            Start		  1.2400671045505382e+04
            Stop		  1.3267558737164272e+04
            Start		  1.5235204000627926e+04
            Stop		  1.6102089344728029e+04
            Start		  1.8069733962536251e+04
            Stop		  1.8936620304447140e+04
            Start		  2.0904266952182083e+04
            Stop		  2.1771150884502436e+04
            Start		  2.3738796502639201e+04
            Stop		  2.4605681823752129e+04
            Start		  2.6573328371301908e+04
            Stop		  2.7440212336918110e+04
            Start		  2.9407858305327361e+04
            Stop		  3.0274743274828405e+04
            Start		  3.2242389788768385e+04
            Stop		  3.3109273766227474e+04
            Start		  3.5076919850391118e+04
            Stop		  3.5943804704775815e+04
            Start		  3.7911451204832556e+04
            Stop		  3.8778335189562109e+04
            Start		  4.0745981308494665e+04
            Stop		  4.1612866128915892e+04
            Start		  4.3580512619997906e+04
            Stop		  4.4447396611993434e+04
            Start		  4.6415042737541495e+04
            Stop		  4.7281927552007466e+04
            Start		  4.9249574034927355e+04
            Stop		  5.0116458034803225e+04
            Start		  5.2084104157279631e+04
            Stop		  5.2950988975201239e+04
            Start		  5.4918635450326081e+04
            Stop		  5.5785519457943527e+04
            Start		  5.7753165574697450e+04
            Stop		  5.8620050398381558e+04
            Start		  6.0587696866818238e+04
            Stop		  6.1454580880895548e+04
            Start		  6.3422226992423268e+04
            Stop		  6.4289111821022816e+04
            Start		  6.6256758284838390e+04
            Stop		  6.7123642303036992e+04
            Start		  6.9091288411456175e+04
            Stop		  6.9958173242556804e+04
            Start		  7.1925819704555921e+04
            Stop		  7.2792703723841259e+04
            Start		  7.4760349832047170e+04
            Stop		  7.5627234662562434e+04
            Start		  7.7594881125845626e+04
            Stop		  7.8461765142999167e+04
            Start		  8.0429411254004619e+04
            Stop		  8.1296296080869215e+04
            Start		  8.3263942548309540e+04
            Stop		  8.4130826560482528e+04
            Start		  8.6098472676842808e+04
            Stop		  8.6400000000000000e+04
            Strand		 10 62
            Strand		 10 63
            Strand		 10 64
            Strand		 10 65
            Strand		 10 66
            Strand		 10 67
            Strand		 10 68
            Strand		 10 69
            Strand		 10 70
            Strand		 10 71
            Start		  0.0000000000000000e+00
            Stop		  1.2278465097689669e+02
            Start		  1.7668846185568855e+03
            Stop		  2.9573155667684296e+03
            Start		  4.6014153509041544e+03
            Stop		  5.7918462621317840e+03
            Start		  7.4359460522201352e+03
            Stop		  8.6263769741550332e+03
            Start		  1.0270476757140084e+04
            Stop		  1.1460907686274419e+04
            Start		  1.3105007462147782e+04
            Stop		  1.4295438399188088e+04
            Start		  1.5939538167617065e+04
            Stop		  1.7129969112700914e+04
            Start		  1.8774068873714674e+04
            Stop		  1.9964499826635358e+04
            Start		  2.1608599580589362e+04
            Stop		  2.2799030540793159e+04
            Start		  2.4443130288354881e+04
            Stop		  2.5633561254966418e+04
            Start		  2.7277660997086110e+04
            Stop		  2.8468091968946501e+04
            Start		  3.0112191706815520e+04
            Stop		  3.1302622682533223e+04
            Start		  3.2946722417531739e+04
            Stop		  3.4137153395543697e+04
            Start		  3.5781253129180091e+04
            Stop		  3.6971684107820234e+04
            Start		  3.8615783841664939e+04
            Stop		  3.9806214819237408e+04
            Start		  4.1450314554853954e+04
            Stop		  4.2640745529707470e+04
            Start		  4.4284845268583842e+04
            Stop		  4.5475276239184197e+04
            Start		  4.7119375982667574e+04
            Stop		  4.8309806947665013e+04
            Start		  4.9953906696902552e+04
            Stop		  5.1144337655190975e+04
            Start		  5.2788437411079591e+04
            Stop		  5.3978868361845060e+04
            Start		  5.5622968124991981e+04
            Stop		  5.6813399067748484e+04
            Start		  5.8457498838444670e+04
            Stop		  5.9647929773055424e+04
            Start		  6.1292029551262698e+04
            Stop		  6.2482460477946130e+04
            Start		  6.4126560263299005e+04
            Stop		  6.5316991182619182e+04
            Start		  6.6961090974440856e+04
            Stop		  6.8151521887282608e+04
            Start		  6.9795621684614700e+04
            Stop		  7.0986052592144872e+04
            Start		  7.2630152393789496e+04
            Stop		  7.3820583297405727e+04
            Start		  7.5464683101978037e+04
            Stop		  7.6655114003247276e+04
            Start		  7.8299213809236389e+04
            Stop		  7.9489644709826185e+04
            Start		  8.1133744515661368e+04
            Stop		  8.2324175417266699e+04
            Start		  8.3968275221386473e+04
            Stop		  8.5158706125655212e+04
            Strand		 11 36
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 11 37
            Strand		 11 38
            Strand		 11 39
            Strand		 11 40
            Strand		 11 41
            Strand		 11 42
            Strand		 11 43
            Strand		 11 44
            Strand		 11 45
            Strand		 11 46
            Strand		 11 48
            Strand		 11 49
            Strand		 11 50
            Strand		 11 51
            Strand		 11 52
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 11 53
            Strand		 11 54
            Strand		 11 55
            Strand		 11 56
            Strand		 11 57
            Start		  0.0000000000000000e+00
            Stop		  7.5267990263043600e+02
            Start		  2.3967810495435751e+03
            Stop		  3.5872106099891053e+03
            Start		  5.2313117627647052e+03
            Stop		  6.4217413147903317e+03
            Start		  8.0658424747031358e+03
            Stop		  9.2562720195215261e+03
            Start		  1.0900373185756504e+04
            Stop		  1.2090802724275132e+04
            Start		  1.3734903895832853e+04
            Stop		  1.4925333429264703e+04
            Start		  1.6569434604910151e+04
            Stop		  1.7759864134687203e+04
            Start		  1.9403965313008826e+04
            Stop		  2.0594394840721259e+04
            Start		  2.2238496020192531e+04
            Stop		  2.3428925547517989e+04
            Start		  2.5073026726565193e+04
            Stop		  2.6263456255195280e+04
            Start		  2.7907557432266200e+04
            Stop		  2.9097986963832340e+04
            Start		  3.0742088137464485e+04
            Stop		  3.1932517673466278e+04
            Start		  3.3576618842351098e+04
            Stop		  3.4767048384090413e+04
            Start		  3.6411149547130757e+04
            Stop		  3.7601579095654597e+04
            Start		  3.9245680252012942e+04
            Stop		  4.0436109808067384e+04
            Start		  4.2080210957202675e+04
            Stop		  4.3270640521200097e+04
            Start		  4.4914741662891429e+04
            Stop		  4.6105171234892478e+04
            Start		  4.7749272369248923e+04
            Stop		  4.8939701948959635e+04
            Start		  5.0583803076415439e+04
            Stop		  5.1774232663200244e+04
            Start		  5.3418333784495830e+04
            Stop		  5.4608763377405354e+04
            Start		  5.6252864493554865e+04
            Stop		  5.7443294091367577e+04
            Start		  5.9087395203614353e+04
            Stop		  6.0277824804890173e+04
            Start		  6.1921925914652333e+04
            Stop		  6.3112355517795724e+04
            Start		  6.4756456626603736e+04
            Stop		  6.5946886229933836e+04
            Start		  6.7590987339363623e+04
            Stop		  6.8781416941187781e+04
            Start		  7.0425518052791522e+04
            Stop		  7.1615947651479772e+04
            Start		  7.3260048766717635e+04
            Stop		  7.4450478360774025e+04
            Start		  7.6094579480950430e+04
            Stop		  7.7285009069078675e+04
            Start		  7.8929110195284957e+04
            Stop		  8.0119539776445323e+04
            Start		  8.1763640909511771e+04
            Stop		  8.2954070482966621e+04
            Start		  8.4598171623426242e+04
            Stop		  8.5788601188772285e+04
            Strand		 11 58
            Strand		 11 59
            Strand		 11 60
            Strand		 11 61
            Start		  5.9011978098280019e+02
            Stop		  1.4570248489689211e+03
            Start		  3.4246504910797871e+03
            Stop		  4.2915555825355023e+03
            Start		  6.2591811724938398e+03
            Stop		  7.1260866441440457e+03
            Start		  9.0937119063180544e+03
            Stop		  9.9606168539054725e+03
            Start		  1.1928240819241299e+04
            Stop		  1.2795147812211148e+04
            Start		  1.4762773322119003e+04
            Stop		  1.5629678198194169e+04
            Start		  1.7597304022606033e+04
            Stop		  1.8464209141171723e+04
            Start		  2.0431834739157341e+04
            Stop		  2.1298739590984020e+04
            Start		  2.3266365065723505e+04
            Stop		  2.4133270531585586e+04
            Start		  2.6100896157805466e+04
            Stop		  2.6967801002285269e+04
            Start		  2.8935426362199782e+04
            Stop		  2.9802331941928722e+04
            Start		  3.1769957578128247e+04
            Stop		  3.2636862418955443e+04
            Start		  3.4604487742710306e+04
            Stop		  3.5471393357719113e+04
            Start		  3.7439018999889973e+04
            Stop		  3.8305923836245529e+04
            Start		  4.0273549151612111e+04
            Stop		  4.1140454774169622e+04
            Start		  4.3108080422601706e+04
            Stop		  4.3974985252701903e+04
            Start		  4.5942610570125238e+04
            Stop		  4.6809516189944377e+04
            Start		  4.8777141845608399e+04
            Stop		  4.9644046668176925e+04
            Start		  5.1611671991545983e+04
            Stop		  5.2478577605008701e+04
            Start		  5.4446203268203331e+04
            Stop		  5.5313108083081308e+04
            Start		  5.7280733413202710e+04
            Stop		  5.8147639019843278e+04
            Start		  6.0115264689751028e+04
            Stop		  6.0982169498053590e+04
            Start		  6.2949794833882064e+04
            Stop		  6.3816700435098333e+04
            Start		  6.5784326109797723e+04
            Stop		  6.6651230913763095e+04
            Start		  6.8618856253036065e+04
            Stop		  6.9485761851393938e+04
            Start		  7.1453387528150182e+04
            Stop		  7.2320292330765165e+04
            Start		  7.4287917670545430e+04
            Stop		  7.5154823269183617e+04
            Start		  7.7122448944909091e+04
            Stop		  7.7989353749395348e+04
            Start		  7.9956979086630367e+04
            Stop		  8.0823884688666163e+04
            Start		  8.2791510360451735e+04
            Stop		  8.3658415169708052e+04
            Start		  8.5626040501776297e+04
            Stop		  8.6400000000000000e+04
            Strand		 11 62
            Start		  1.1770840402934888e+02
            Stop		  9.8459262598334044e+02
            Start		  2.9522381510963942e+03
            Stop		  3.8191236207474863e+03
            Start		  5.7867698272425150e+03
            Stop		  6.6536539156578729e+03
            Start		  8.6212984265139548e+03
            Stop		  9.4881848596650434e+03
            Start		  1.1455831250020095e+04
            Stop		  1.2322715275500546e+04
            Start		  1.4290361740051989e+04
            Stop		  1.5157246212782933e+04
            Start		  1.7124892671770172e+04
            Stop		  1.7991776670567975e+04
            Start		  1.9959422918384753e+04
            Stop		  2.0826307607309580e+04
            Start		  2.2793954092042237e+04
            Stop		  2.3660838079438672e+04
            Start		  2.5628484257963864e+04
            Stop		  2.6495369016643926e+04
            Start		  2.8463015510623471e+04
            Stop		  2.9329899494065881e+04
            Start		  3.1297545649352509e+04
            Stop		  3.2164430432031229e+04
            Start		  3.4132076927588139e+04
            Stop		  3.4998960911810223e+04
            Start		  3.6966607056917645e+04
            Stop		  3.7833491850625927e+04
            Start		  3.9801138343289160e+04
            Stop		  4.0668022331746695e+04
            Start		  4.2635668469313830e+04
            Stop		  4.3502553271345772e+04
            Start		  4.5470199758298404e+04
            Stop		  4.6337083753330611e+04
            Start		  4.8304729883283326e+04
            Stop		  4.9171614693508542e+04
            Start		  5.1139261173307714e+04
            Stop		  5.2006145175984559e+04
            Start		  5.3973791298243079e+04
            Stop		  5.4840676116436021e+04
            Start		  5.6808322589009054e+04
            Stop		  5.7675206599029261e+04
            Start		  5.9642852714412460e+04
            Stop		  6.0509737539401307e+04
            Start		  6.2477384005974236e+04
            Stop		  6.3344268021745360e+04
            Start		  6.5311914132123013e+04
            Stop		  6.6178798961698834e+04
            Start		  6.8146445424555801e+04
            Stop		  6.9013329443479714e+04
            Start		  7.0980975551545271e+04
            Stop		  7.1847860382748186e+04
            Start		  7.3815506844825723e+04
            Stop		  7.4682390863752837e+04
            Start		  7.6650036972587870e+04
            Stop		  7.7516921802188750e+04
            Start		  7.9484568266562943e+04
            Stop		  8.0351452282339844e+04
            Start		  8.2319098394889894e+04
            Stop		  8.3185983219940317e+04
            Start		  8.5153629689291847e+04
            Stop		  8.6020513699309115e+04
            Strand		 11 63
            Strand		 11 64
            Strand		 11 65
            Strand		 11 66
            Start		  8.2204520067875887e+02
            Stop		  2.0124720930026535e+03
            Start		  3.6565718124384657e+03
            Stop		  4.8470026886509841e+03
            Start		  6.4911024832863386e+03
            Stop		  7.6815334037943612e+03
            Start		  9.3256331889055473e+03
            Stop		  1.0516064115456171e+04
            Start		  1.2160163893766239e+04
            Stop		  1.3350594828142985e+04
            Start		  1.4994694599065871e+04
            Stop		  1.6185125541473741e+04
            Start		  1.7829225304935753e+04
            Stop		  1.9019656255289006e+04
            Start		  2.0663756011537029e+04
            Stop		  2.1854186969395156e+04
            Start		  2.3498286718995267e+04
            Stop		  2.4688717683586579e+04
            Start		  2.6332817427398848e+04
            Stop		  2.7523248397653897e+04
            Start		  2.9167348136794608e+04
            Stop		  3.0357779111393102e+04
            Start		  3.2001878847185864e+04
            Stop		  3.3192309824614575e+04
            Start		  3.4836409558532170e+04
            Stop		  3.6026840537151416e+04
            Start		  3.7670940270751205e+04
            Stop		  3.8861371248866759e+04
            Start		  4.0505470983722240e+04
            Stop		  4.1695901959659750e+04
            Start		  4.3340001697291598e+04
            Stop		  4.4530432669470072e+04
            Start		  4.6174532411279295e+04
            Stop		  4.7364963378280423e+04
            Start		  4.9009063125486966e+04
            Stop		  5.0199494086117455e+04
            Start		  5.1843593839706613e+04
            Stop		  5.3034024793050499e+04
            Start		  5.4678124553729664e+04
            Stop		  5.5868555499188522e+04
            Start		  5.7512655267356160e+04
            Stop		  5.8703086204675383e+04
            Start		  6.0347185980403614e+04
            Stop		  6.1537616909683522e+04
            Start		  6.3181716692714857e+04
            Stop		  6.4372147614406291e+04
            Start		  6.6016247404165028e+04
            Stop		  6.7206678319049592e+04
            Start		  6.8850778114667162e+04
            Stop		  7.0041209023822812e+04
            Start		  7.1685308824175692e+04
            Stop		  7.2875739728929490e+04
            Start		  7.4519839532688886e+04
            Stop		  7.5710270434558639e+04
            Start		  7.7354370240248478e+04
            Stop		  7.8544801140876240e+04
            Start		  8.0188900946938113e+04
            Stop		  8.1379331848017973e+04
            Start		  8.3023431652879663e+04
            Stop		  8.4213862556083448e+04
            Start		  8.5857962358227713e+04
            Stop		  8.6400000000000000e+04
            Strand		 11 67
            Strand		 11 68
            Strand		 11 69
            Strand		 11 70
            Strand		 11 71
            Strand		 12 36
            Strand		 12 37
            Strand		 12 38
            Start		  0.0000000000000000e+00
            Stop		  9.1015461974623520e+02
            Start		  2.5542543634766084e+03
            Stop		  3.7446851984480991e+03
            Start		  5.3887850055549288e+03
            Stop		  6.5792159088425542e+03
            Start		  8.2233157136340797e+03
            Stop		  9.4137466153911773e+03
            Start		  1.1057846419911366e+04
            Stop		  1.2248277323062637e+04
            Start		  1.3892377125575573e+04
            Stop		  1.5082808031683748e+04
            Start		  1.6726907830742068e+04
            Stop		  1.7917338741302545e+04
            Start		  1.9561438535605583e+04
            Stop		  2.0751869451909977e+04
            Start		  2.2395969240371207e+04
            Stop		  2.3586400163453753e+04
            Start		  2.5230499945248364e+04
            Stop		  2.6420930875840695e+04
            Start		  2.8065030650441622e+04
            Stop		  2.9255461588940569e+04
            Start		  3.0899561356141705e+04
            Stop		  3.2089992302591840e+04
            Start		  3.3734092062517106e+04
            Stop		  3.4924523016608720e+04
            Start		  3.6568622769706693e+04
            Stop		  3.7759053730789361e+04
            Start		  3.9403153477813619e+04
            Stop		  4.0593584444924665e+04
            Start		  4.2237684186900755e+04
            Stop		  4.3428115158807515e+04
            Start		  4.5072214896987978e+04
            Stop		  4.6262645872241861e+04
            Start		  4.7906745608051307e+04
            Stop		  4.9097176585051289e+04
            Start		  5.0741276320023877e+04
            Stop		  5.1931707297086788e+04
            Start		  5.3575807032798984e+04
            Stop		  5.4766238008233311e+04
            Start		  5.6410337746234691e+04
            Stop		  5.7600768718414758e+04
            Start		  5.9244868460160098e+04
            Stop		  6.0435299427597420e+04
            Start		  6.2079399174382852e+04
            Stop		  6.3269830135791359e+04
            Start		  6.4913929888697487e+04
            Stop		  6.6104360843049973e+04
            Start		  6.7748460602894629e+04
            Stop		  6.8938891549467779e+04
            Start		  7.0582991316770058e+04
            Stop		  7.1773422255176032e+04
            Start		  7.3417522030133667e+04
            Stop		  7.4607952960337192e+04
            Start		  7.6252052742817890e+04
            Stop		  7.7442483665137610e+04
            Start		  7.9086583454684966e+04
            Stop		  8.0277014369779543e+04
            Start		  8.1921114165633073e+04
            Stop		  8.3111545074472000e+04
            Start		  8.4755644875600687e+04
            Stop		  8.5946075779421852e+04
            Strand		 12 39
            Strand		 12 40
            Strand		 12 41
            Strand		 12 42
            Strand		 12 43
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 12 44
            Strand		 12 45
            Strand		 12 46
            Strand		 12 47
            Strand		 12 49
            Strand		 12 50
            Strand		 12 51
            Strand		 12 52
            Strand		 12 53
            Strand		 12 54
            Strand		 12 55
            Strand		 12 56
            Strand		 12 57
            Strand		 12 58
            Strand		 12 59
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 12 60
            Strand		 12 61
            Strand		 12 62
            Strand		 12 63
            Strand		 12 64
            Start		  1.2944643982655489e+03
            Stop		  2.4848932701163803e+03
            Start		  4.1289943154163193e+03
            Stop		  5.3194238303176535e+03
            Start		  6.9635249550908748e+03
            Stop		  8.1539545427140429e+03
            Start		  9.7980556703176971e+03
            Stop		  1.0988485249426063e+04
            Start		  1.2632586384271533e+04
            Stop		  1.3823015955606606e+04
            Start		  1.5467117097858260e+04
            Stop		  1.6657546661145952e+04
            Start		  1.8301647810841114e+04
            Stop		  1.9492077366232927e+04
            Start		  2.1136178523069422e+04
            Stop		  2.2326608071062579e+04
            Start		  2.3970709234423299e+04
            Stop		  2.5161138775841842e+04
            Start		  2.6805239944821064e+04
            Stop		  2.7995669480779863e+04
            Start		  2.9639770654223004e+04
            Stop		  3.0830200186078844e+04
            Start		  3.2474301362633199e+04
            Stop		  3.3664730891925152e+04
            Start		  3.5308832070099197e+04
            Stop		  3.6499261598481207e+04
            Start		  3.8143362776710077e+04
            Stop		  3.9333792305878225e+04
            Start		  4.0977893482592393e+04
            Stop		  4.2168323014210539e+04
            Start		  4.3812424187904762e+04
            Stop		  4.5002853723531487e+04
            Start		  4.6646954892830792e+04
            Stop		  4.7837384433850966e+04
            Start		  4.9481485597571082e+04
            Stop		  5.0671915145135150e+04
            Start		  5.2316016302334356e+04
            Stop		  5.3506445857307815e+04
            Start		  5.5150547007328394e+04
            Stop		  5.6340976570253813e+04
            Start		  5.7985077712750826e+04
            Stop		  5.9175507283824030e+04
            Start		  6.0819608418780474e+04
            Stop		  6.2010037997842010e+04
            Start		  6.3654139125569614e+04
            Stop		  6.4844568712111708e+04
            Start		  6.6488669833237029e+04
            Stop		  6.7679099426425935e+04
            Start		  6.9323200541863116e+04
            Stop		  7.0513630140575726e+04
            Start		  7.2157731251486126e+04
            Stop		  7.3348160854359245e+04
            Start		  7.4992261962100602e+04
            Stop		  7.6182691567590868e+04
            Start		  7.7826792673657590e+04
            Stop		  7.9017222280109127e+04
            Start		  8.0661323386066724e+04
            Stop		  8.1851752991783957e+04
            Start		  8.3495854099200340e+04
            Stop		  8.4686283702522400e+04
            Start		  8.6330384812898948e+04
            Stop		  8.6400000000000000e+04
            Strand		 12 65
            Strand		 12 66
            Strand		 12 67
            Strand		 12 68
            Start		  0.0000000000000000e+00
            Stop		  3.5470750194125839e+02
            Start		  2.3223330022870632e+03
            Stop		  3.1892378612508896e+03
            Start		  5.1568638475062580e+03
            Stop		  6.0237688033193781e+03
            Start		  7.9913944187621191e+03
            Stop		  8.8582992434405278e+03
            Start		  1.0825924791301311e+04
            Stop		  1.1692830183384991e+04
            Start		  1.3660455834144226e+04
            Stop		  1.4527360651259572e+04
            Start		  1.6494986051631320e+04
            Stop		  1.7361891591536722e+04
            Start		  1.9329517249079847e+04
            Stop		  2.0196422068959546e+04
            Start		  2.2164047415603723e+04
            Stop		  2.3030953009648820e+04
            Start		  2.4998578664280885e+04
            Stop		  2.5865483490342966e+04
            Start		  2.7833108814343625e+04
            Stop		  2.8700014431161875e+04
            Start		  3.0667640080408895e+04
            Stop		  3.1534544912797395e+04
            Start		  3.3502170225565336e+04
            Stop		  3.4369075853399954e+04
            Start		  3.6336701497963324e+04
            Stop		  3.7203606334977696e+04
            Start		  3.9171231642101411e+04
            Stop		  4.0038137275048044e+04
            Start		  4.2005762917195512e+04
            Stop		  4.2872667756073104e+04
            Start		  4.4840293061564473e+04
            Stop		  4.5707198695385909e+04
            Start		  4.7674824338065373e+04
            Stop		  4.8541729175622742e+04
            Start		  5.0509354482943374e+04
            Stop		  5.1376260114083641e+04
            Start		  5.3343885760248442e+04
            Stop		  5.4210790593487574e+04
            Start		  5.6178415905517344e+04
            Stop		  5.7045321531149872e+04
            Start		  5.9012947183192286e+04
            Stop		  5.9879852009838636e+04
            Start		  6.1847477328564215e+04
            Stop		  6.2714382946894162e+04
            Start		  6.4682008606212446e+04
            Stop		  6.5548913425115505e+04
            Start		  6.7516538751347922e+04
            Stop		  6.8383444361861330e+04
            Start		  7.0351070028611299e+04
            Stop		  7.1217974839946037e+04
            Start		  7.3185600173200757e+04
            Stop		  7.4052505776732898e+04
            Start		  7.6020131449799359e+04
            Stop		  7.6887036255035913e+04
            Start		  7.8854661593624172e+04
            Stop		  7.9721567192207222e+04
            Start		  8.1689192869397288e+04
            Stop		  8.2556097671045747e+04
            Start		  8.4523723012370479e+04
            Stop		  8.5390628608878033e+04
            Strand		 12 69
            Start		  1.8499169280044048e+03
            Stop		  2.7168059162310951e+03
            Start		  4.6844522956565634e+03
            Stop		  5.5513373253636992e+03
            Start		  7.5189830299007454e+03
            Stop		  8.3858671676525864e+03
            Start		  1.0353511899298472e+04
            Stop		  1.1220398121224038e+04
            Start		  1.3188044452678738e+04
            Stop		  1.4054928508417723e+04
            Start		  1.6022575118410750e+04
            Stop		  1.6889459447395482e+04
            Start		  1.8857105875694928e+04
            Stop		  1.9723989895517141e+04
            Start		  2.1691636180877820e+04
            Stop		  2.2558520832315400e+04
            Start		  2.4526167298482822e+04
            Stop		  2.5393051300696025e+04
            Start		  2.7360697484932865e+04
            Stop		  2.8227582237121824e+04
            Start		  3.0195228720386916e+04
            Stop		  3.1062112712333161e+04
            Start		  3.3029758867152661e+04
            Stop		  3.3896643648916826e+04
            Start		  3.5864290140895282e+04
            Stop		  3.6731174126739512e+04
            Start		  3.8698820273948702e+04
            Stop		  3.9565705063826565e+04
            Start		  4.1533351559735114e+04
            Stop		  4.2400235543035880e+04
            Start		  4.4367881687681234e+04
            Stop		  4.5234766480865081e+04
            Start		  4.7202412976922285e+04
            Stop		  4.8069296961136381e+04
            Start		  5.0036943102732577e+04
            Stop		  5.0903827899814889e+04
            Start		  5.2871474392759250e+04
            Stop		  5.3738358381016405e+04
            Start		  5.5706004517621150e+04
            Stop		  5.6572889320503476e+04
            Start		  5.8540535807782675e+04
            Stop		  5.9407419802466713e+04
            Start		  6.1375065932336045e+04
            Stop		  6.2241950742581175e+04
            Start		  6.4209597222670505e+04
            Stop		  6.5076481225046737e+04
            Start		  6.7044127347373214e+04
            Stop		  6.7911012165498527e+04
            Start		  6.9878658638123961e+04
            Stop		  7.0745542648133574e+04
            Start		  7.2713188763330239e+04
            Stop		  7.3580073588574145e+04
            Start		  7.5547720054746038e+04
            Stop		  7.6414604071020949e+04
            Start		  7.8382250180696952e+04
            Stop		  7.9249135011103892e+04
            Start		  8.1216781472936666e+04
            Stop		  8.2083665493039065e+04
            Start		  8.4051311599735564e+04
            Stop		  8.4918196432480181e+04
            Strand		 12 70
            Strand		 12 71
            Strand		 13 36
            Strand		 13 37
            Strand		 13 38
            Strand		 13 39
            Start		  1.6094138482376879e+03
            Stop		  2.7998378249240986e+03
            Start		  4.4439454616406256e+03
            Stop		  5.6343724469556983e+03
            Start		  7.2784721763763637e+03
            Stop		  8.4689030424815573e+03
            Start		  1.0113002850377761e+04
            Stop		  1.1303433753939973e+04
            Start		  1.2947533557129518e+04
            Stop		  1.4137964462022932e+04
            Start		  1.5782064262394464e+04
            Stop		  1.6972495171318984e+04
            Start		  1.8616594967339024e+04
            Stop		  1.9807025881599980e+04
            Start		  2.1451125672113925e+04
            Stop		  2.2641556592840061e+04
            Start		  2.4285656376930747e+04
            Stop		  2.5476087304958684e+04
            Start		  2.7120187081996584e+04
            Stop		  2.8310618017837445e+04
            Start		  2.9954717787507740e+04
            Stop		  3.1145148731324516e+04
            Start		  3.2789248493641011e+04
            Stop		  3.3979679445241338e+04
            Start		  3.5623779200545861e+04
            Stop		  3.6814210159390452e+04
            Start		  3.8458309908337964e+04
            Stop		  3.9648740873564158e+04
            Start		  4.1292840617093978e+04
            Stop		  4.2483271587553674e+04
            Start		  4.4127371326848341e+04
            Stop		  4.5317802301158263e+04
            Start		  4.6961902037591630e+04
            Stop		  4.8152333014194039e+04
            Start		  4.9796432749271109e+04
            Stop		  5.0986863726502117e+04
            Start		  5.2630963461792860e+04
            Stop		  5.3821394437955430e+04
            Start		  5.5465494175026048e+04
            Stop		  5.6655925148464470e+04
            Start		  5.8300024888808730e+04
            Stop		  5.9490455857981113e+04
            Start		  6.1134555602954730e+04
            Stop		  6.2324986566500782e+04
            Start		  6.3969086317261957e+04
            Stop		  6.5159517274062659e+04
            Start		  6.6803617031521426e+04
            Stop		  6.7994047980747826e+04
            Start		  6.9638147745526076e+04
            Stop		  7.0828578686675944e+04
            Start		  7.2472678459080198e+04
            Stop		  7.3663109391999766e+04
            Start		  7.5307209172007773e+04
            Stop		  7.6497640096898613e+04
            Start		  7.8141739884160444e+04
            Stop		  7.9332170801570275e+04
            Start		  8.0976270595423775e+04
            Stop		  8.2166701506222598e+04
            Start		  8.3810801305722416e+04
            Stop		  8.5001232211064213e+04
            Strand		 13 40
            Strand		 13 41
            Strand		 13 42
            Strand		 13 43
            Strand		 13 44
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 13 45
            Strand		 13 46
            Strand		 13 47
            Strand		 13 48
            Strand		 13 50
            Strand		 13 51
            Strand		 13 52
            Strand		 13 53
            Strand		 13 54
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 13 55
            Strand		 13 56
            Strand		 13 57
            Strand		 13 58
            Strand		 13 59
            Strand		 13 60
            Strand		 13 61
            Strand		 13 62
            Strand		 13 63
            Strand		 13 64
            Strand		 13 65
            Start		  3.4961992812338809e+02
            Stop		  1.5400497631767148e+03
            Start		  3.1841507853121007e+03
            Stop		  4.3745802613528494e+03
            Start		  6.0186813837813052e+03
            Stop		  7.2091109735115706e+03
            Start		  8.8532120989167051e+03
            Stop		  1.0043641680538283e+04
            Start		  1.1687742812973996e+04
            Stop		  1.2878172386961449e+04
            Start		  1.4522273526721940e+04
            Stop		  1.5712703092692152e+04
            Start		  1.7356804239923691e+04
            Stop		  1.8547233797909172e+04
            Start		  2.0191334952418634e+04
            Stop		  2.1381764502801980e+04
            Start		  2.3025865664075056e+04
            Stop		  2.4216295207574738e+04
            Start		  2.5860396374798056e+04
            Stop		  2.7050825912436838e+04
            Start		  2.8694927084533669e+04
            Stop		  2.9885356617593814e+04
            Start		  3.1529457793271293e+04
            Stop		  3.2719887323238316e+04
            Start		  3.4363988501044128e+04
            Stop		  3.5554418029541550e+04
            Start		  3.7198519207927704e+04
            Stop		  3.8388948736645805e+04
            Start		  4.0033049914036710e+04
            Stop		  4.1223479444658355e+04
            Start		  4.2867580619519751e+04
            Stop		  4.4058010153646486e+04
            Start		  4.5702111324552927e+04
            Stop		  4.6892540863634742e+04
            Start		  4.8536642029332143e+04
            Stop		  4.9727071574603782e+04
            Start		  5.1371172734064443e+04
            Stop		  5.2561602286491245e+04
            Start		  5.4205703438958903e+04
            Stop		  5.5396132999194480e+04
            Start		  5.7040234144217575e+04
            Stop		  5.8230663712575035e+04
            Start		  5.9874764850026448e+04
            Stop		  6.1065194426464754e+04
            Start		  6.2709295556547462e+04
            Stop		  6.3899725140673196e+04
            Start		  6.5543826263911178e+04
            Stop		  6.6734255854995863e+04
            Start		  6.8378356972211332e+04
            Stop		  6.9568786569223434e+04
            Start		  7.1212887681500448e+04
            Stop		  7.2403317283150711e+04
            Start		  7.4047418391787767e+04
            Stop		  7.5237847996585551e+04
            Start		  7.6881949103038627e+04
            Stop		  7.8072378709357741e+04
            Start		  7.9716479815176179e+04
            Stop		  8.0906909421325996e+04
            Start		  8.2551010528084618e+04
            Stop		  8.3741440132384407e+04
            Start		  8.5385541241614279e+04
            Stop		  8.6400000000000000e+04
            Strand		 13 66
            Strand		 13 67
            Strand		 13 68
            Strand		 13 69
            Start		  1.3774864174214556e+03
            Stop		  2.2443942362020571e+03
            Start		  4.2120162644810916e+03
            Stop		  5.0789248359744324e+03
            Start		  7.0465491671829777e+03
            Stop		  7.9134557837271677e+03
            Start		  9.8810815573540403e+03
            Stop		  1.0747986330550935e+04
            Start		  1.2715611323876012e+04
            Stop		  1.3582517271075099e+04
            Start		  1.5550142972483964e+04
            Stop		  1.6417047774459494e+04
            Start		  1.8384672989210372e+04
            Stop		  1.9251578714890857e+04
            Start		  2.1219204387420228e+04
            Stop		  2.2086109204123841e+04
            Start		  2.4053734487617308e+04
            Stop		  2.4920640144872938e+04
            Start		  2.6888265802859696e+04
            Stop		  2.7755170629453580e+04
            Start		  2.9722795931148936e+04
            Stop		  3.0589701570229918e+04
            Start		  3.2557327219417559e+04
            Stop		  3.3424232053050604e+04
            Start		  3.5391857357571913e+04
            Stop		  3.6258762993504279e+04
            Start		  3.8226388637516968e+04
            Stop		  3.9093293475310245e+04
            Start		  4.1060918779537838e+04
            Stop		  4.1927824415146199e+04
            Start		  4.3895450057314083e+04
            Stop		  4.4762354896047793e+04
            Start		  4.6729980201146449e+04
            Stop		  4.7596885835079564e+04
            Start		  4.9564511478670545e+04
            Stop		  5.0431416315075927e+04
            Start		  5.2399041623471385e+04
            Stop		  5.3265947253257305e+04
            Start		  5.5233572901177373e+04
            Stop		  5.6100477732416010e+04
            Start		  5.8068103046440352e+04
            Stop		  5.8935008669848619e+04
            Start		  6.0902634324225917e+04
            Stop		  6.1769539148353295e+04
            Start		  6.3737164469531352e+04
            Stop		  6.4604070085268722e+04
            Start		  6.6571695747113554e+04
            Stop		  6.7438600563406784e+04
            Start		  6.9406225892089598e+04
            Stop		  7.0273131500126357e+04
            Start		  7.2240757169165765e+04
            Stop		  7.3107661978245495e+04
            Start		  7.5075287313515961e+04
            Stop		  7.5942192915124469e+04
            Start		  7.7909818589853166e+04
            Stop		  7.8776723393574517e+04
            Start		  8.0744348733395673e+04
            Stop		  8.1611254330940268e+04
            Start		  8.3578880008883556e+04
            Stop		  8.4445784810013080e+04
            Strand		 13 70
            Start		  9.0507764888621421e+02
            Stop		  1.7719660817850965e+03
            Start		  3.7396084787550549e+03
            Stop		  4.6064925413987803e+03
            Start		  6.5741389612458288e+03
            Stop		  7.4410231507488215e+03
            Start		  9.4086668619458651e+03
            Stop		  1.0275554158729103e+04
            Start		  1.2243197841193649e+04
            Stop		  1.3110084761414684e+04
            Start		  1.5077729674574455e+04
            Stop		  1.5944615712285335e+04
            Start		  1.7912262305240005e+04
            Stop		  1.8779146270510606e+04
            Start		  2.0746791983132905e+04
            Stop		  2.1613677208494584e+04
            Start		  2.3581323728079940e+04
            Stop		  2.4448207713407486e+04
            Start		  2.6415853706483034e+04
            Stop		  2.7282738649934814e+04
            Start		  2.9250385150160833e+04
            Stop		  3.0117269137189895e+04
            Start		  3.2084915228161080e+04
            Stop		  3.2951800073722152e+04
            Start		  3.4919446570924323e+04
            Stop		  3.5786330555454108e+04
            Start		  3.7753976681334847e+04
            Stop		  3.8620861492435208e+04
            Start		  4.0588507990047947e+04
            Stop		  4.1455391972841557e+04
            Start		  4.3423038110596091e+04
            Stop		  4.4289922910534660e+04
            Start		  4.6257569407496485e+04
            Stop		  4.7124453391099974e+04
            Start		  4.9092099530922664e+04
            Stop		  4.9958984329635328e+04
            Start		  5.1926630823526415e+04
            Stop		  5.2793514810843670e+04
            Start		  5.4761160947623874e+04
            Stop		  5.5628045750204903e+04
            Start		  5.7595692238640768e+04
            Stop		  5.8462576232107102e+04
            Start		  6.0430222362922854e+04
            Stop		  6.1297107172134689e+04
            Start		  6.3264753653501553e+04
            Stop		  6.4131637654554826e+04
            Start		  6.6099283778056939e+04
            Stop		  6.6966168594973715e+04
            Start		  6.8933815068814743e+04
            Stop		  6.9800699077610901e+04
            Start		  7.1768345193885572e+04
            Stop		  7.2635230018078233e+04
            Start		  7.4602876485207715e+04
            Stop		  7.5469760500582357e+04
            Start		  7.7437406611012993e+04
            Stop		  7.8304291440747023e+04
            Start		  8.0271937903120182e+04
            Stop		  8.1138821922787305e+04
            Start		  8.3106468029773489e+04
            Stop		  8.3973352862350876e+04
            Start		  8.5940999322727905e+04
            Stop		  8.6400000000000000e+04
            Strand		 13 71
            Strand		 14 36
            Strand		 14 37
            Strand		 14 38
            Strand		 14 39
            Strand		 14 40
            Start		  6.6456717359312086e+02
            Stop		  1.8549980631694639e+03
            Start		  3.4990978673302079e+03
            Stop		  4.6895287713387870e+03
            Start		  6.3336285756230400e+03
            Stop		  7.5240594774535757e+03
            Start		  9.1681592824444324e+03
            Stop		  1.0358590184519580e+04
            Start		  1.2002689988533775e+04
            Stop		  1.3193120892493116e+04
            Start		  1.4837220694010224e+04
            Stop		  1.6027651601445436e+04
            Start		  1.7671751399053628e+04
            Stop		  1.8862182311396893e+04
            Start		  2.0506282103861337e+04
            Stop		  2.1696713022324318e+04
            Start		  2.3340812808640923e+04
            Stop		  2.4531243734161439e+04
            Start		  2.6175343513601216e+04
            Stop		  2.7365774446802181e+04
            Start		  2.9009874218943161e+04
            Stop		  3.0200305160105156e+04
            Start		  3.1844404924850958e+04
            Stop		  3.3034835873899909e+04
            Start		  3.4678935631483975e+04
            Stop		  3.5869366587994358e+04
            Start		  3.7513466338969796e+04
            Stop		  3.8703897302183206e+04
            Start		  4.0347997047398545e+04
            Stop		  4.1538428016256999e+04
            Start		  4.3182527756819007e+04
            Stop		  4.4372958730011334e+04
            Start		  4.6017058467236428e+04
            Stop		  4.7207489443255770e+04
            Start		  4.8851589178612288e+04
            Stop		  5.0042020155822225e+04
            Start		  5.1686119890866103e+04
            Stop		  5.2876550867572361e+04
            Start		  5.4520650603878756e+04
            Stop		  5.5711081578403595e+04
            Start		  5.7355181317497925e+04
            Stop		  5.8545612288253724e+04
            Start		  6.0189712031544637e+04
            Stop		  6.1380142997103510e+04
            Start		  6.3024242745821219e+04
            Stop		  6.4214673704977664e+04
            Start		  6.5858773460119890e+04
            Stop		  6.7049204411943589e+04
            Start		  6.8693304174231991e+04
            Stop		  6.9883735118108598e+04
            Start		  7.1527834887956982e+04
            Stop		  7.2718265823615118e+04
            Start		  7.4362365601111393e+04
            Stop		  7.5552796528634368e+04
            Start		  7.7196896313536912e+04
            Stop		  7.8387327233358970e+04
            Start		  8.0031427025107056e+04
            Stop		  8.1221857937994428e+04
            Start		  8.2865957735733056e+04
            Stop		  8.4056388642750055e+04
            Start		  8.5700488445367606e+04
            Stop		  8.6400000000000000e+04
            Strand		 14 41
            Strand		 14 42
            Strand		 14 43
            Strand		 14 44
            Strand		 14 45
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 14 46
            Strand		 14 47
            Strand		 14 48
            Strand		 14 49
            Strand		 14 51
            Strand		 14 52
            Strand		 14 53
            Strand		 14 54
            Strand		 14 55
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 14 56
            Strand		 14 57
            Strand		 14 58
            Strand		 14 59
            Strand		 14 60
            Start		  0.0000000000000000e+00
            Stop		  5.9520621462729957e+02
            Start		  2.2393072313722109e+03
            Stop		  3.4297366924235625e+03
            Start		  5.0738378125096579e+03
            Stop		  6.2642674041991158e+03
            Start		  7.9083685274968357e+03
            Stop		  9.0987981115596012e+03
            Start		  1.0742899241636727e+04
            Stop		  1.1933328818240296e+04
            Start		  1.3577429955524984e+04
            Stop		  1.4767859524181025e+04
            Start		  1.6411960668927451e+04
            Stop		  1.7602390229549288e+04
            Start		  1.9246491381674379e+04
            Stop		  2.0436920934528011e+04
            Start		  2.2081022093622742e+04
            Stop		  2.3271451639317576e+04
            Start		  2.4915552804664974e+04
            Stop		  2.6105982344126667e+04
            Start		  2.7750083514733076e+04
            Stop		  2.8940513049163150e+04
            Start		  3.0584614223801826e+04
            Stop		  3.1775043754624898e+04
            Start		  3.3419144931889889e+04
            Stop		  3.4609574460691154e+04
            Start		  3.6253675639059002e+04
            Stop		  3.7444105167514652e+04
            Start		  3.9088206345411258e+04
            Stop		  4.0278635875214924e+04
            Start		  4.1922737051084587e+04
            Stop		  4.3113166583872953e+04
            Start		  4.4757267756246751e+04
            Stop		  4.5947697293527817e+04
            Start		  4.7591798461087987e+04
            Stop		  4.8782228004174794e+04
            Start		  5.0426329165812604e+04
            Stop		  5.1616758715765609e+04
            Start		  5.3260859870630025e+04
            Stop		  5.4451289428210643e+04
            Start		  5.6095390575745660e+04
            Stop		  5.7285820141382763e+04
            Start		  5.8929921281351781e+04
            Stop		  6.0120350855122990e+04
            Start		  6.1764451987619221e+04
            Stop		  6.2954881569247416e+04
            Start		  6.4598982694689694e+04
            Stop		  6.5789412283555197e+04
            Start		  6.7433513402669778e+04
            Stop		  6.8623942997837701e+04
            Start		  7.0268044111626063e+04
            Stop		  7.1458473711887200e+04
            Start		  7.3102574821582355e+04
            Stop		  7.4293004425506355e+04
            Start		  7.5937105532518501e+04
            Stop		  7.7127535138516731e+04
            Start		  7.8771636244371577e+04
            Stop		  7.9962065850766565e+04
            Start		  8.1606166957038091e+04
            Stop		  8.2796596562137638e+04
            Start		  8.4440697670379130e+04
            Stop		  8.5631127272550206e+04
            Strand		 14 61
            Strand		 14 62
            Strand		 14 63
            Strand		 14 64
            Strand		 14 65
            Strand		 14 66
            Strand		 14 67
            Strand		 14 68
            Strand		 14 69
            Strand		 14 70
            Start		  4.3264586289599026e+02
            Stop		  1.2995510000528864e+03
            Start		  3.2671750915420785e+03
            Stop		  4.1340822040576268e+03
            Start		  6.1017072799058824e+03
            Stop		  6.9686122744713430e+03
            Start		  8.9362368110075968e+03
            Stop		  9.8031432595645729e+03
            Start		  1.1770768695703575e+04
            Stop		  1.2637673579087834e+04
            Start		  1.4605297231325172e+04
            Stop		  1.5472204525127605e+04
            Start		  1.7439830110752890e+04
            Stop		  1.8306734952143128e+04
            Start		  2.0274360566028121e+04
            Stop		  2.1141265893488613e+04
            Start		  2.3108891525801053e+04
            Stop		  2.3975796357444593e+04
            Start		  2.5943421770871602e+04
            Stop		  2.6810327298374410e+04
            Start		  2.8777952941559055e+04
            Stop		  2.9644857774545646e+04
            Start		  3.1612483117905158e+04
            Stop		  3.2479388715281399e+04
            Start		  3.4447014358597997e+04
            Stop		  3.5313919195197042e+04
            Start		  3.7281544512843706e+04
            Stop		  3.8148450135481275e+04
            Start		  4.0116075777261125e+04
            Stop		  4.0982980616147506e+04
            Start		  4.2950605924793446e+04
            Stop		  4.3817511555732141e+04
            Start		  4.5785137197607983e+04
            Stop		  4.6652042036053688e+04
            Start		  4.8619667343408095e+04
            Stop		  4.9486572974800554e+04
            Start		  5.1454198619405135e+04
            Stop		  5.2321103454413096e+04
            Start		  5.4288728764931388e+04
            Stop		  5.5155634392326843e+04
            Start		  5.7123260042167247e+04
            Stop		  5.7990164871211098e+04
            Start		  5.9957790187661310e+04
            Stop		  6.0824695808440207e+04
            Start		  6.2792321465241388e+04
            Stop		  6.3659226286776648e+04
            Start		  6.5626851610532496e+04
            Stop		  6.6493757223588225e+04
            Start		  6.8461382887920583e+04
            Stop		  6.9328287701676629e+04
            Start		  7.1295913032734927e+04
            Stop		  7.2162818638410012e+04
            Start		  7.4130444309566534e+04
            Stop		  7.4997349116601137e+04
            Start		  7.6964974453667281e+04
            Stop		  7.7831880053609144e+04
            Start		  7.9799505729720462e+04
            Stop		  8.0666410532238442e+04
            Start		  8.2634035872979541e+04
            Stop		  8.3500941469825964e+04
            Start		  8.5468567148182745e+04
            Stop		  8.6335471478171661e+04
            Strand		 14 71
            Start		  0.0000000000000000e+00
            Stop		  8.2711810304996607e+02
            Start		  2.7947632770930268e+03
            Stop		  3.6616534084157388e+03
            Start		  5.6292915195802952e+03
            Stop		  6.4961797628629593e+03
            Start		  8.4638227095719794e+03
            Stop		  9.3307103759074289e+03
            Start		  1.1298354558374251e+04
            Stop		  1.2165241354256605e+04
            Start		  1.4132883480457993e+04
            Stop		  1.4999771947046987e+04
            Start		  1.6967417239266255e+04
            Stop		  1.7834302890028775e+04
            Start		  1.9801949446228784e+04
            Stop		  2.0668833422568074e+04
            Start		  2.2636479269230418e+04
            Stop		  2.3503364359678548e+04
            Start		  2.5471010868889345e+04
            Stop		  2.6337894856014380e+04
            Start		  2.8305540895577593e+04
            Stop		  2.9172425792468301e+04
            Start		  3.1140072290583135e+04
            Stop		  3.2006956276967041e+04
            Start		  3.3974602384401624e+04
            Stop		  3.4841487213611428e+04
            Start		  3.6809133710822338e+04
            Stop		  3.7676017694582268e+04
            Start		  3.9643663826266064e+04
            Stop		  4.0510548631777725e+04
            Start		  4.2478195129376727e+04
            Stop		  4.3345079112125692e+04
            Start		  4.5312725251414297e+04
            Stop		  4.6179610050092131e+04
            Start		  4.8147256546310360e+04
            Stop		  4.9014140530840981e+04
            Start		  5.0981786670110778e+04
            Stop		  5.1848671469660832e+04
            Start		  5.3816317961969224e+04
            Stop		  5.4683201951107090e+04
            Start		  5.6650848086149730e+04
            Stop		  5.7517732890714666e+04
            Start		  5.9485379376920791e+04
            Stop		  6.0352263372816386e+04
            Start		  6.2319909501274313e+04
            Stop		  6.3186794313009465e+04
            Start		  6.5154440791855348e+04
            Stop		  6.6021324795539127e+04
            Start		  6.7988970916555380e+04
            Stop		  6.8855855736013938e+04
            Start		  7.0823502207466023e+04
            Stop		  7.1690386218646003e+04
            Start		  7.3658032332761723e+04
            Stop		  7.4524917159050077e+04
            Start		  7.6492563624328497e+04
            Stop		  7.7359447641433508e+04
            Start		  7.9327093750410524e+04
            Stop		  8.0193978581426723e+04
            Start		  8.2161625042800937e+04
            Stop		  8.3028509063251186e+04
            Start		  8.4996155169738297e+04
            Stop		  8.5863040002564943e+04
            Strand		 15 36
            Strand		 15 37
            Strand		 15 38
            Strand		 15 39
            Strand		 15 40
            Strand		 15 41
            Start		  0.0000000000000000e+00
            Stop		  9.1015461974623452e+02
            Start		  2.5542543634766021e+03
            Stop		  3.7446851984481095e+03
            Start		  5.3887850055549334e+03
            Stop		  6.5792159088425569e+03
            Start		  8.2233157136340833e+03
            Stop		  9.4137466153911846e+03
            Start		  1.1057846419911373e+04
            Stop		  1.2248277323062643e+04
            Start		  1.3892377125575575e+04
            Stop		  1.5082808031683760e+04
            Start		  1.6726907830742071e+04
            Stop		  1.7917338741302559e+04
            Start		  1.9561438535605590e+04
            Stop		  2.0751869451909988e+04
            Start		  2.2395969240371225e+04
            Stop		  2.3586400163453764e+04
            Start		  2.5230499945248375e+04
            Stop		  2.6420930875840702e+04
            Start		  2.8065030650441640e+04
            Stop		  2.9255461588940583e+04
            Start		  3.0899561356141716e+04
            Stop		  3.2089992302591858e+04
            Start		  3.3734092062517127e+04
            Stop		  3.4924523016608735e+04
            Start		  3.6568622769706715e+04
            Stop		  3.7759053730789368e+04
            Start		  3.9403153477813627e+04
            Stop		  4.0593584444924680e+04
            Start		  4.2237684186900769e+04
            Stop		  4.3428115158807537e+04
            Start		  4.5072214896988000e+04
            Stop		  4.6262645872241883e+04
            Start		  4.7906745608051322e+04
            Stop		  4.9097176585051304e+04
            Start		  5.0741276320023899e+04
            Stop		  5.1931707297086810e+04
            Start		  5.3575807032799021e+04
            Stop		  5.4766238008233340e+04
            Start		  5.6410337746234727e+04
            Stop		  5.7600768718414787e+04
            Start		  5.9244868460160142e+04
            Stop		  6.0435299427597442e+04
            Start		  6.2079399174382874e+04
            Stop		  6.3269830135791395e+04
            Start		  6.4913929888697530e+04
            Stop		  6.6104360843050003e+04
            Start		  6.7748460602894687e+04
            Stop		  6.8938891549467808e+04
            Start		  7.0582991316770087e+04
            Stop		  7.1773422255176076e+04
            Start		  7.3417522030133696e+04
            Stop		  7.4607952960337221e+04
            Start		  7.6252052742817948e+04
            Stop		  7.7442483665137697e+04
            Start		  7.9086583454685009e+04
            Stop		  8.0277014369779572e+04
            Start		  8.1921114165633102e+04
            Stop		  8.3111545074472058e+04
            Start		  8.4755644875600716e+04
            Stop		  8.5946075779421895e+04
            Strand		 15 42
            Strand		 15 43
            Strand		 15 44
            Strand		 15 45
            Strand		 15 46
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 15 47
            Strand		 15 48
            Strand		 15 49
            Strand		 15 50
            Strand		 15 52
            Strand		 15 53
            Strand		 15 54
            Strand		 15 55
            Strand		 15 56
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 15 57
            Strand		 15 58
            Strand		 15 59
            Strand		 15 60
            Strand		 15 61
            Start		  1.2944643982655537e+03
            Stop		  2.4848932701163917e+03
            Start		  4.1289943154163202e+03
            Stop		  5.3194238303176571e+03
            Start		  6.9635249550908766e+03
            Stop		  8.1539545427140483e+03
            Start		  9.7980556703177081e+03
            Stop		  1.0988485249426072e+04
            Start		  1.2632586384271526e+04
            Stop		  1.3823015955606616e+04
            Start		  1.5467117097858272e+04
            Stop		  1.6657546661145967e+04
            Start		  1.8301647810841114e+04
            Stop		  1.9492077366232930e+04
            Start		  2.1136178523069437e+04
            Stop		  2.2326608071062605e+04
            Start		  2.3970709234423310e+04
            Stop		  2.5161138775841857e+04
            Start		  2.6805239944821064e+04
            Stop		  2.7995669480779867e+04
            Start		  2.9639770654223030e+04
            Stop		  3.0830200186078851e+04
            Start		  3.2474301362633214e+04
            Stop		  3.3664730891925195e+04
            Start		  3.5308832070099226e+04
            Stop		  3.6499261598481229e+04
            Start		  3.8143362776710092e+04
            Stop		  3.9333792305878247e+04
            Start		  4.0977893482592415e+04
            Stop		  4.2168323014210553e+04
            Start		  4.3812424187904791e+04
            Stop		  4.5002853723531502e+04
            Start		  4.6646954892830821e+04
            Stop		  4.7837384433851003e+04
            Start		  4.9481485597571096e+04
            Stop		  5.0671915145135172e+04
            Start		  5.2316016302334356e+04
            Stop		  5.3506445857307845e+04
            Start		  5.5150547007328401e+04
            Stop		  5.6340976570253835e+04
            Start		  5.7985077712750841e+04
            Stop		  5.9175507283824052e+04
            Start		  6.0819608418780517e+04
            Stop		  6.2010037997842053e+04
            Start		  6.3654139125569600e+04
            Stop		  6.4844568712111737e+04
            Start		  6.6488669833237043e+04
            Stop		  6.7679099426425964e+04
            Start		  6.9323200541863145e+04
            Stop		  7.0513630140575755e+04
            Start		  7.2157731251486155e+04
            Stop		  7.3348160854359317e+04
            Start		  7.4992261962100645e+04
            Stop		  7.6182691567590911e+04
            Start		  7.7826792673657619e+04
            Stop		  7.9017222280109156e+04
            Start		  8.0661323386066753e+04
            Stop		  8.1851752991784015e+04
            Start		  8.3495854099200369e+04
            Stop		  8.4686283702522414e+04
            Start		  8.6330384812898992e+04
            Stop		  8.6400000000000000e+04
            Strand		 15 62
            Strand		 15 63
            Strand		 15 64
            Strand		 15 65
            Strand		 15 66
            Start		  1.8499169280044061e+03
            Stop		  2.7168059162310974e+03
            Start		  4.6844522956565597e+03
            Stop		  5.5513373253637019e+03
            Start		  7.5189830299007490e+03
            Stop		  8.3858671676525864e+03
            Start		  1.0353511899298472e+04
            Stop		  1.1220398121224038e+04
            Start		  1.3188044452678740e+04
            Stop		  1.4054928508417721e+04
            Start		  1.6022575118410761e+04
            Stop		  1.6889459447395482e+04
            Start		  1.8857105875694931e+04
            Stop		  1.9723989895517152e+04
            Start		  2.1691636180877824e+04
            Stop		  2.2558520832315397e+04
            Start		  2.4526167298482829e+04
            Stop		  2.5393051300696032e+04
            Start		  2.7360697484932884e+04
            Stop		  2.8227582237121827e+04
            Start		  3.0195228720386920e+04
            Stop		  3.1062112712333161e+04
            Start		  3.3029758867152683e+04
            Stop		  3.3896643648916826e+04
            Start		  3.5864290140895282e+04
            Stop		  3.6731174126739519e+04
            Start		  3.8698820273948717e+04
            Stop		  3.9565705063826565e+04
            Start		  4.1533351559735107e+04
            Stop		  4.2400235543035888e+04
            Start		  4.4367881687681256e+04
            Stop		  4.5234766480865081e+04
            Start		  4.7202412976922293e+04
            Stop		  4.8069296961136381e+04
            Start		  5.0036943102732585e+04
            Stop		  5.0903827899814904e+04
            Start		  5.2871474392759250e+04
            Stop		  5.3738358381016405e+04
            Start		  5.5706004517621157e+04
            Stop		  5.6572889320503484e+04
            Start		  5.8540535807782711e+04
            Stop		  5.9407419802466728e+04
            Start		  6.1375065932336074e+04
            Stop		  6.2241950742581183e+04
            Start		  6.4209597222670534e+04
            Stop		  6.5076481225046766e+04
            Start		  6.7044127347373258e+04
            Stop		  6.7911012165498556e+04
            Start		  6.9878658638123976e+04
            Stop		  7.0745542648133574e+04
            Start		  7.2713188763330283e+04
            Stop		  7.3580073588574160e+04
            Start		  7.5547720054746052e+04
            Stop		  7.6414604071020964e+04
            Start		  7.8382250180697010e+04
            Stop		  7.9249135011103892e+04
            Start		  8.1216781472936709e+04
            Stop		  8.2083665493039050e+04
            Start		  8.4051311599735593e+04
            Stop		  8.4918196432480181e+04
            Strand		 15 67
            Strand		 15 68
            Strand		 15 69
            Strand		 15 70
            Strand		 15 71
            Start		  0.0000000000000000e+00
            Stop		  3.5470750194125975e+02
            Start		  2.3223330022870732e+03
            Stop		  3.1892378612508942e+03
            Start		  5.1568638475062589e+03
            Stop		  6.0237688033193699e+03
            Start		  7.9913944187621164e+03
            Stop		  8.8582992434405369e+03
            Start		  1.0825924791301319e+04
            Stop		  1.1692830183385004e+04
            Start		  1.3660455834144233e+04
            Stop		  1.4527360651259580e+04
            Start		  1.6494986051631338e+04
            Stop		  1.7361891591536725e+04
            Start		  1.9329517249079847e+04
            Stop		  2.0196422068959557e+04
            Start		  2.2164047415603742e+04
            Stop		  2.3030953009648827e+04
            Start		  2.4998578664280907e+04
            Stop		  2.5865483490342984e+04
            Start		  2.7833108814343632e+04
            Stop		  2.8700014431161882e+04
            Start		  3.0667640080408921e+04
            Stop		  3.1534544912797413e+04
            Start		  3.3502170225565351e+04
            Stop		  3.4369075853399969e+04
            Start		  3.6336701497963346e+04
            Stop		  3.7203606334977718e+04
            Start		  3.9171231642101433e+04
            Stop		  4.0038137275048066e+04
            Start		  4.2005762917195534e+04
            Stop		  4.2872667756073126e+04
            Start		  4.4840293061564487e+04
            Stop		  4.5707198695385916e+04
            Start		  4.7674824338065402e+04
            Stop		  4.8541729175622771e+04
            Start		  5.0509354482943410e+04
            Stop		  5.1376260114083656e+04
            Start		  5.3343885760248464e+04
            Stop		  5.4210790593487589e+04
            Start		  5.6178415905517388e+04
            Stop		  5.7045321531149893e+04
            Start		  5.9012947183192315e+04
            Stop		  5.9879852009838658e+04
            Start		  6.1847477328564259e+04
            Stop		  6.2714382946894191e+04
            Start		  6.4682008606212476e+04
            Stop		  6.5548913425115548e+04
            Start		  6.7516538751347951e+04
            Stop		  6.8383444361861388e+04
            Start		  7.0351070028611357e+04
            Stop		  7.1217974839946066e+04
            Start		  7.3185600173200786e+04
            Stop		  7.4052505776732913e+04
            Start		  7.6020131449799388e+04
            Stop		  7.6887036255035942e+04
            Start		  7.8854661593624216e+04
            Stop		  7.9721567192207251e+04
            Start		  8.1689192869397317e+04
            Stop		  8.2556097671045791e+04
            Start		  8.4523723012370509e+04
            Stop		  8.5390628608878105e+04
            Strand		 16 36
            Start		  1.6094138482376818e+03
            Stop		  2.7998378249241059e+03
            Start		  4.4439454616406292e+03
            Stop		  5.6343724469557083e+03
            Start		  7.2784721763763528e+03
            Stop		  8.4689030424815628e+03
            Start		  1.0113002850377763e+04
            Stop		  1.1303433753939982e+04
            Start		  1.2947533557129527e+04
            Stop		  1.4137964462022939e+04
            Start		  1.5782064262394466e+04
            Stop		  1.6972495171318998e+04
            Start		  1.8616594967339035e+04
            Stop		  1.9807025881599999e+04
            Start		  2.1451125672113947e+04
            Stop		  2.2641556592840068e+04
            Start		  2.4285656376930772e+04
            Stop		  2.5476087304958703e+04
            Start		  2.7120187081996610e+04
            Stop		  2.8310618017837471e+04
            Start		  2.9954717787507769e+04
            Stop		  3.1145148731324545e+04
            Start		  3.2789248493641018e+04
            Stop		  3.3979679445241381e+04
            Start		  3.5623779200545883e+04
            Stop		  3.6814210159390481e+04
            Start		  3.8458309908337986e+04
            Stop		  3.9648740873564195e+04
            Start		  4.1292840617094007e+04
            Stop		  4.2483271587553725e+04
            Start		  4.4127371326848363e+04
            Stop		  4.5317802301158306e+04
            Start		  4.6961902037591681e+04
            Stop		  4.8152333014194082e+04
            Start		  4.9796432749271145e+04
            Stop		  5.0986863726502146e+04
            Start		  5.2630963461792890e+04
            Stop		  5.3821394437955460e+04
            Start		  5.5465494175026121e+04
            Stop		  5.6655925148464492e+04
            Start		  5.8300024888808759e+04
            Stop		  5.9490455857981142e+04
            Start		  6.1134555602954752e+04
            Stop		  6.2324986566500840e+04
            Start		  6.3969086317262023e+04
            Stop		  6.5159517274062702e+04
            Start		  6.6803617031521484e+04
            Stop		  6.7994047980747884e+04
            Start		  6.9638147745526134e+04
            Stop		  7.0828578686676017e+04
            Start		  7.2472678459080256e+04
            Stop		  7.3663109391999853e+04
            Start		  7.5307209172007846e+04
            Stop		  7.6497640096898671e+04
            Start		  7.8141739884160503e+04
            Stop		  7.9332170801570363e+04
            Start		  8.0976270595423834e+04
            Stop		  8.2166701506222715e+04
            Start		  8.3810801305722489e+04
            Stop		  8.5001232211064256e+04
            Strand		 16 37
            Strand		 16 38
            Strand		 16 39
            Strand		 16 40
            Strand		 16 41
            Strand		 16 42
            Strand		 16 43
            Strand		 16 44
            Strand		 16 45
            Strand		 16 46
            Strand		 16 47
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 16 48
            Strand		 16 49
            Strand		 16 50
            Strand		 16 51
            Strand		 16 53
            Strand		 16 54
            Strand		 16 55
            Strand		 16 56
            Strand		 16 57
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 16 58
            Strand		 16 59
            Strand		 16 60
            Strand		 16 61
            Strand		 16 62
            Start		  3.4961992812338281e+02
            Stop		  1.5400497631767239e+03
            Start		  3.1841507853121057e+03
            Stop		  4.3745802613528567e+03
            Start		  6.0186813837812997e+03
            Stop		  7.2091109735115733e+03
            Start		  8.8532120989167088e+03
            Stop		  1.0043641680538294e+04
            Start		  1.1687742812973996e+04
            Stop		  1.2878172386961458e+04
            Start		  1.4522273526721945e+04
            Stop		  1.5712703092692162e+04
            Start		  1.7356804239923691e+04
            Stop		  1.8547233797909175e+04
            Start		  2.0191334952418649e+04
            Stop		  2.1381764502801994e+04
            Start		  2.3025865664075056e+04
            Stop		  2.4216295207574749e+04
            Start		  2.5860396374798063e+04
            Stop		  2.7050825912436852e+04
            Start		  2.8694927084533683e+04
            Stop		  2.9885356617593832e+04
            Start		  3.1529457793271300e+04
            Stop		  3.2719887323238330e+04
            Start		  3.4363988501044121e+04
            Stop		  3.5554418029541550e+04
            Start		  3.7198519207927719e+04
            Stop		  3.8388948736645849e+04
            Start		  4.0033049914036732e+04
            Stop		  4.1223479444658384e+04
            Start		  4.2867580619519773e+04
            Stop		  4.4058010153646494e+04
            Start		  4.5702111324552949e+04
            Stop		  4.6892540863634771e+04
            Start		  4.8536642029332186e+04
            Stop		  4.9727071574603811e+04
            Start		  5.1371172734064443e+04
            Stop		  5.2561602286491274e+04
            Start		  5.4205703438958946e+04
            Stop		  5.5396132999194509e+04
            Start		  5.7040234144217597e+04
            Stop		  5.8230663712575042e+04
            Start		  5.9874764850026477e+04
            Stop		  6.1065194426464783e+04
            Start		  6.2709295556547462e+04
            Stop		  6.3899725140673210e+04
            Start		  6.5543826263911207e+04
            Stop		  6.6734255854995936e+04
            Start		  6.8378356972211346e+04
            Stop		  6.9568786569223506e+04
            Start		  7.1212887681500506e+04
            Stop		  7.2403317283150696e+04
            Start		  7.4047418391787811e+04
            Stop		  7.5237847996585610e+04
            Start		  7.6881949103038685e+04
            Stop		  7.8072378709357756e+04
            Start		  7.9716479815176222e+04
            Stop		  8.0906909421326054e+04
            Start		  8.2551010528084633e+04
            Stop		  8.3741440132384436e+04
            Start		  8.5385541241614308e+04
            Stop		  8.6400000000000000e+04
            Strand		 16 63
            Strand		 16 64
            Strand		 16 65
            Strand		 16 66
            Start		  1.3774864174214522e+03
            Stop		  2.2443942362020516e+03
            Start		  4.2120162644810925e+03
            Stop		  5.0789248359744342e+03
            Start		  7.0465491671829877e+03
            Stop		  7.9134557837271814e+03
            Start		  9.8810815573540422e+03
            Stop		  1.0747986330550959e+04
            Start		  1.2715611323876017e+04
            Stop		  1.3582517271075118e+04
            Start		  1.5550142972483971e+04
            Stop		  1.6417047774459526e+04
            Start		  1.8384672989210376e+04
            Stop		  1.9251578714890878e+04
            Start		  2.1219204387420225e+04
            Stop		  2.2086109204123877e+04
            Start		  2.4053734487617312e+04
            Stop		  2.4920640144872978e+04
            Start		  2.6888265802859700e+04
            Stop		  2.7755170629453616e+04
            Start		  2.9722795931148943e+04
            Stop		  3.0589701570229940e+04
            Start		  3.2557327219417566e+04
            Stop		  3.3424232053050633e+04
            Start		  3.5391857357571920e+04
            Stop		  3.6258762993504330e+04
            Start		  3.8226388637516968e+04
            Stop		  3.9093293475310304e+04
            Start		  4.1060918779537846e+04
            Stop		  4.1927824415146250e+04
            Start		  4.3895450057314083e+04
            Stop		  4.4762354896047844e+04
            Start		  4.6729980201146449e+04
            Stop		  4.7596885835079614e+04
            Start		  4.9564511478670553e+04
            Stop		  5.0431416315075992e+04
            Start		  5.2399041623471399e+04
            Stop		  5.3265947253257364e+04
            Start		  5.5233572901177373e+04
            Stop		  5.6100477732416104e+04
            Start		  5.8068103046440374e+04
            Stop		  5.8935008669848685e+04
            Start		  6.0902634324225917e+04
            Stop		  6.1769539148353382e+04
            Start		  6.3737164469531388e+04
            Stop		  6.4604070085268795e+04
            Start		  6.6571695747113554e+04
            Stop		  6.7438600563406857e+04
            Start		  6.9406225892089627e+04
            Stop		  7.0273131500126459e+04
            Start		  7.2240757169165779e+04
            Stop		  7.3107661978245582e+04
            Start		  7.5075287313515961e+04
            Stop		  7.5942192915124571e+04
            Start		  7.7909818589853210e+04
            Stop		  7.8776723393574619e+04
            Start		  8.0744348733395687e+04
            Stop		  8.1611254330940370e+04
            Start		  8.3578880008883556e+04
            Stop		  8.4445784810013181e+04
            Strand		 16 67
            Start		  9.0507764888621386e+02
            Stop		  1.7719660817851025e+03
            Start		  3.7396084787550549e+03
            Stop		  4.6064925413987858e+03
            Start		  6.5741389612458415e+03
            Stop		  7.4410231507488279e+03
            Start		  9.4086668619458724e+03
            Stop		  1.0275554158729114e+04
            Start		  1.2243197841193671e+04
            Stop		  1.3110084761414697e+04
            Start		  1.5077729674574470e+04
            Stop		  1.5944615712285351e+04
            Start		  1.7912262305240023e+04
            Stop		  1.8779146270510621e+04
            Start		  2.0746791983132927e+04
            Stop		  2.1613677208494602e+04
            Start		  2.3581323728079969e+04
            Stop		  2.4448207713407501e+04
            Start		  2.6415853706483067e+04
            Stop		  2.7282738649934850e+04
            Start		  2.9250385150160862e+04
            Stop		  3.0117269137189920e+04
            Start		  3.2084915228161124e+04
            Stop		  3.2951800073722174e+04
            Start		  3.4919446570924367e+04
            Stop		  3.5786330555454137e+04
            Start		  3.7753976681334891e+04
            Stop		  3.8620861492435237e+04
            Start		  4.0588507990047990e+04
            Stop		  4.1455391972841586e+04
            Start		  4.3423038110596142e+04
            Stop		  4.4289922910534689e+04
            Start		  4.6257569407496536e+04
            Stop		  4.7124453391100004e+04
            Start		  4.9092099530922722e+04
            Stop		  4.9958984329635365e+04
            Start		  5.1926630823526488e+04
            Stop		  5.2793514810843706e+04
            Start		  5.4761160947623946e+04
            Stop		  5.5628045750204954e+04
            Start		  5.7595692238640848e+04
            Stop		  5.8462576232107167e+04
            Start		  6.0430222362922919e+04
            Stop		  6.1297107172134754e+04
            Start		  6.3264753653501641e+04
            Stop		  6.4131637654554892e+04
            Start		  6.6099283778057026e+04
            Stop		  6.6966168594973773e+04
            Start		  6.8933815068814831e+04
            Stop		  6.9800699077610960e+04
            Start		  7.1768345193885660e+04
            Stop		  7.2635230018078320e+04
            Start		  7.4602876485207831e+04
            Stop		  7.5469760500582415e+04
            Start		  7.7437406611013110e+04
            Stop		  7.8304291440747067e+04
            Start		  8.0271937903120299e+04
            Stop		  8.1138821922787378e+04
            Start		  8.3106468029773590e+04
            Stop		  8.3973352862350948e+04
            Start		  8.5940999322728036e+04
            Stop		  8.6400000000000000e+04
            Strand		 16 68
            Strand		 16 69
            Strand		 16 70
            Strand		 16 71
            Strand		 17 36
            Strand		 17 37
            Start		  6.6456717359312574e+02
            Stop		  1.8549980631694759e+03
            Start		  3.4990978673302038e+03
            Stop		  4.6895287713387788e+03
            Start		  6.3336285756230400e+03
            Stop		  7.5240594774535757e+03
            Start		  9.1681592824444306e+03
            Stop		  1.0358590184519577e+04
            Start		  1.2002689988533779e+04
            Stop		  1.3193120892493118e+04
            Start		  1.4837220694010226e+04
            Stop		  1.6027651601445434e+04
            Start		  1.7671751399053632e+04
            Stop		  1.8862182311396893e+04
            Start		  2.0506282103861337e+04
            Stop		  2.1696713022324322e+04
            Start		  2.3340812808640920e+04
            Stop		  2.4531243734161439e+04
            Start		  2.6175343513601212e+04
            Stop		  2.7365774446802177e+04
            Start		  2.9009874218943165e+04
            Stop		  3.0200305160105159e+04
            Start		  3.1844404924850951e+04
            Stop		  3.3034835873899909e+04
            Start		  3.4678935631483968e+04
            Stop		  3.5869366587994351e+04
            Start		  3.7513466338969796e+04
            Stop		  3.8703897302183192e+04
            Start		  4.0347997047398538e+04
            Stop		  4.1538428016256985e+04
            Start		  4.3182527756819007e+04
            Stop		  4.4372958730011342e+04
            Start		  4.6017058467236406e+04
            Stop		  4.7207489443255763e+04
            Start		  4.8851589178612303e+04
            Stop		  5.0042020155822218e+04
            Start		  5.1686119890866095e+04
            Stop		  5.2876550867572361e+04
            Start		  5.4520650603878763e+04
            Stop		  5.5711081578403609e+04
            Start		  5.7355181317497911e+04
            Stop		  5.8545612288253709e+04
            Start		  6.0189712031544637e+04
            Stop		  6.1380142997103503e+04
            Start		  6.3024242745821197e+04
            Stop		  6.4214673704977657e+04
            Start		  6.5858773460119890e+04
            Stop		  6.7049204411943589e+04
            Start		  6.8693304174231977e+04
            Stop		  6.9883735118108598e+04
            Start		  7.1527834887956938e+04
            Stop		  7.2718265823615104e+04
            Start		  7.4362365601111393e+04
            Stop		  7.5552796528634353e+04
            Start		  7.7196896313536898e+04
            Stop		  7.8387327233358970e+04
            Start		  8.0031427025107027e+04
            Stop		  8.1221857937994399e+04
            Start		  8.2865957735733042e+04
            Stop		  8.4056388642750084e+04
            Start		  8.5700488445367562e+04
            Stop		  8.6400000000000000e+04
            Strand		 17 38
            Strand		 17 39
            Strand		 17 40
            Strand		 17 41
            Strand		 17 42
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 17 43
            Strand		 17 44
            Strand		 17 45
            Strand		 17 46
            Strand		 17 47
            Strand		 17 48
            Strand		 17 49
            Strand		 17 50
            Strand		 17 51
            Strand		 17 52
            Strand		 17 54
            Strand		 17 55
            Strand		 17 56
            Strand		 17 57
            Strand		 17 58
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 17 59
            Strand		 17 60
            Strand		 17 61
            Strand		 17 62
            Strand		 17 63
            Start		  0.0000000000000000e+00
            Stop		  5.9520621462730537e+02
            Start		  2.2393072313722168e+03
            Stop		  3.4297366924235662e+03
            Start		  5.0738378125096560e+03
            Stop		  6.2642674041991168e+03
            Start		  7.9083685274968338e+03
            Stop		  9.0987981115596049e+03
            Start		  1.0742899241636736e+04
            Stop		  1.1933328818240298e+04
            Start		  1.3577429955524993e+04
            Stop		  1.4767859524181036e+04
            Start		  1.6411960668927448e+04
            Stop		  1.7602390229549303e+04
            Start		  1.9246491381674390e+04
            Stop		  2.0436920934528021e+04
            Start		  2.2081022093622756e+04
            Stop		  2.3271451639317595e+04
            Start		  2.4915552804664992e+04
            Stop		  2.6105982344126689e+04
            Start		  2.7750083514733084e+04
            Stop		  2.8940513049163168e+04
            Start		  3.0584614223801829e+04
            Stop		  3.1775043754624920e+04
            Start		  3.3419144931889896e+04
            Stop		  3.4609574460691168e+04
            Start		  3.6253675639059016e+04
            Stop		  3.7444105167514674e+04
            Start		  3.9088206345411265e+04
            Stop		  4.0278635875214954e+04
            Start		  4.1922737051084587e+04
            Stop		  4.3113166583872982e+04
            Start		  4.4757267756246765e+04
            Stop		  4.5947697293527846e+04
            Start		  4.7591798461088008e+04
            Stop		  4.8782228004174802e+04
            Start		  5.0426329165812611e+04
            Stop		  5.1616758715765616e+04
            Start		  5.3260859870630069e+04
            Stop		  5.4451289428210664e+04
            Start		  5.6095390575745681e+04
            Stop		  5.7285820141382785e+04
            Start		  5.8929921281351810e+04
            Stop		  6.0120350855123019e+04
            Start		  6.1764451987619243e+04
            Stop		  6.2954881569247424e+04
            Start		  6.4598982694689737e+04
            Stop		  6.5789412283555270e+04
            Start		  6.7433513402669807e+04
            Stop		  6.8623942997837730e+04
            Start		  7.0268044111626077e+04
            Stop		  7.1458473711887229e+04
            Start		  7.3102574821582384e+04
            Stop		  7.4293004425506413e+04
            Start		  7.5937105532518559e+04
            Stop		  7.7127535138516745e+04
            Start		  7.8771636244371592e+04
            Stop		  7.9962065850766638e+04
            Start		  8.1606166957038135e+04
            Stop		  8.2796596562137667e+04
            Start		  8.4440697670379188e+04
            Stop		  8.5631127272550264e+04
            Strand		 17 64
            Strand		 17 65
            Strand		 17 66
            Strand		 17 67
            Start		  4.3264586289599742e+02
            Stop		  1.2995510000528795e+03
            Start		  3.2671750915420780e+03
            Stop		  4.1340822040576322e+03
            Start		  6.1017072799058869e+03
            Stop		  6.9686122744713466e+03
            Start		  8.9362368110075950e+03
            Stop		  9.8031432595645747e+03
            Start		  1.1770768695703573e+04
            Stop		  1.2637673579087843e+04
            Start		  1.4605297231325176e+04
            Stop		  1.5472204525127616e+04
            Start		  1.7439830110752890e+04
            Stop		  1.8306734952143139e+04
            Start		  2.0274360566028121e+04
            Stop		  2.1141265893488617e+04
            Start		  2.3108891525801071e+04
            Stop		  2.3975796357444608e+04
            Start		  2.5943421770871602e+04
            Stop		  2.6810327298374421e+04
            Start		  2.8777952941559066e+04
            Stop		  2.9644857774545642e+04
            Start		  3.1612483117905162e+04
            Stop		  3.2479388715281395e+04
            Start		  3.4447014358597997e+04
            Stop		  3.5313919195197050e+04
            Start		  3.7281544512843706e+04
            Stop		  3.8148450135481282e+04
            Start		  4.0116075777261132e+04
            Stop		  4.0982980616147514e+04
            Start		  4.2950605924793454e+04
            Stop		  4.3817511555732155e+04
            Start		  4.5785137197607990e+04
            Stop		  4.6652042036053695e+04
            Start		  4.8619667343408124e+04
            Stop		  4.9486572974800569e+04
            Start		  5.1454198619405171e+04
            Stop		  5.2321103454413118e+04
            Start		  5.4288728764931409e+04
            Stop		  5.5155634392326865e+04
            Start		  5.7123260042167283e+04
            Stop		  5.7990164871211135e+04
            Start		  5.9957790187661340e+04
            Stop		  6.0824695808440236e+04
            Start		  6.2792321465241417e+04
            Stop		  6.3659226286776677e+04
            Start		  6.5626851610532554e+04
            Stop		  6.6493757223588254e+04
            Start		  6.8461382887920627e+04
            Stop		  6.9328287701676672e+04
            Start		  7.1295913032734956e+04
            Stop		  7.2162818638410041e+04
            Start		  7.4130444309566577e+04
            Stop		  7.4997349116601195e+04
            Start		  7.6964974453667339e+04
            Stop		  7.7831880053609158e+04
            Start		  7.9799505729720477e+04
            Stop		  8.0666410532238471e+04
            Start		  8.2634035872979584e+04
            Stop		  8.3500941469825993e+04
            Start		  8.5468567148182789e+04
            Stop		  8.6335471478171705e+04
            Strand		 17 68
            Start		  0.0000000000000000e+00
            Stop		  8.2711810304996652e+02
            Start		  2.7947632770930309e+03
            Stop		  3.6616534084157333e+03
            Start		  5.6292915195802971e+03
            Stop		  6.4961797628629583e+03
            Start		  8.4638227095719867e+03
            Stop		  9.3307103759074253e+03
            Start		  1.1298354558374243e+04
            Stop		  1.2165241354256603e+04
            Start		  1.4132883480457996e+04
            Stop		  1.4999771947046978e+04
            Start		  1.6967417239266259e+04
            Stop		  1.7834302890028768e+04
            Start		  1.9801949446228784e+04
            Stop		  2.0668833422568066e+04
            Start		  2.2636479269230422e+04
            Stop		  2.3503364359678540e+04
            Start		  2.5471010868889345e+04
            Stop		  2.6337894856014358e+04
            Start		  2.8305540895577597e+04
            Stop		  2.9172425792468290e+04
            Start		  3.1140072290583135e+04
            Stop		  3.2006956276967026e+04
            Start		  3.3974602384401609e+04
            Stop		  3.4841487213611406e+04
            Start		  3.6809133710822338e+04
            Stop		  3.7676017694582253e+04
            Start		  3.9643663826266064e+04
            Stop		  4.0510548631777703e+04
            Start		  4.2478195129376727e+04
            Stop		  4.3345079112125677e+04
            Start		  4.5312725251414289e+04
            Stop		  4.6179610050092109e+04
            Start		  4.8147256546310360e+04
            Stop		  4.9014140530840959e+04
            Start		  5.0981786670110771e+04
            Stop		  5.1848671469660811e+04
            Start		  5.3816317961969224e+04
            Stop		  5.4683201951107068e+04
            Start		  5.6650848086149730e+04
            Stop		  5.7517732890714637e+04
            Start		  5.9485379376920806e+04
            Stop		  6.0352263372816364e+04
            Start		  6.2319909501274327e+04
            Stop		  6.3186794313009435e+04
            Start		  6.5154440791855355e+04
            Stop		  6.6021324795539098e+04
            Start		  6.7988970916555409e+04
            Stop		  6.8855855736013909e+04
            Start		  7.0823502207466052e+04
            Stop		  7.1690386218645959e+04
            Start		  7.3658032332761752e+04
            Stop		  7.4524917159050063e+04
            Start		  7.6492563624328526e+04
            Stop		  7.7359447641433479e+04
            Start		  7.9327093750410539e+04
            Stop		  8.0193978581426694e+04
            Start		  8.2161625042800937e+04
            Stop		  8.3028509063251142e+04
            Start		  8.4996155169738326e+04
            Stop		  8.5863040002564929e+04
            Strand		 17 69
            Strand		 17 70
            Strand		 17 71
            Strand		 18 36
            Strand		 18 37
            Strand		 18 38
            Strand		 18 39
            Start		  0.0000000000000000e+00
            Stop		  1.9723331034034030e+02
            Start		  2.1648573682759225e+03
            Stop		  3.0317642680479589e+03
            Start		  4.9993897838668245e+03
            Stop		  5.8662946404338236e+03
            Start		  7.8339205441153690e+03
            Stop		  8.7008255802883286e+03
            Start		  1.0668451203607174e+04
            Stop		  1.1535356023707345e+04
            Start		  1.3502981549256359e+04
            Stop		  1.4369886961884913e+04
            Start		  1.6337512621631644e+04
            Stop		  1.7204417429728008e+04
            Start		  1.9172042830729744e+04
            Stop		  2.0038948368415578e+04
            Start		  2.2006574038129591e+04
            Stop		  2.2873478844955815e+04
            Start		  2.4841104201854883e+04
            Stop		  2.5708009784438786e+04
            Start		  2.7675635453545132e+04
            Stop		  2.8542540264377931e+04
            Start		  3.0510165602169647e+04
            Stop		  3.1377071204575175e+04
            Start		  3.3344696868506886e+04
            Stop		  3.4211601685988666e+04
            Start		  3.6179227012280986e+04
            Stop		  3.7046132626661987e+04
            Start		  3.9013758283721392e+04
            Stop		  3.9880663108680921e+04
            Start		  4.1848288426261017e+04
            Stop		  4.2715194049503210e+04
            Start		  4.4682819699851068e+04
            Stop		  4.5549724531587301e+04
            Start		  4.7517349842515308e+04
            Stop		  4.8384255472203971e+04
            Start		  5.0351881117399527e+04
            Stop		  5.1218785953945007e+04
            Start		  5.3186411260708672e+04
            Stop		  5.4053316894036616e+04
            Start		  5.6020942536624134e+04
            Stop		  5.6887847375133373e+04
            Start		  5.8855472680716281e+04
            Stop		  5.9722378314471447e+04
            Start		  6.1690003957491375e+04
            Stop		  6.2556908794750154e+04
            Start		  6.4524534102279278e+04
            Stop		  6.5391439733236897e+04
            Start		  6.7359065379682739e+04
            Stop		  6.8225970212670931e+04
            Start		  7.0193595524928780e+04
            Stop		  7.1060501150356315e+04
            Start		  7.3028126802650004e+04
            Stop		  7.3895031629067351e+04
            Start		  7.5862656948027245e+04
            Stop		  7.6729562566140303e+04
            Start		  7.8697188225710546e+04
            Stop		  7.9564093044376030e+04
            Start		  8.1531718370866016e+04
            Stop		  8.2398623981131779e+04
            Start		  8.4366249648165816e+04
            Stop		  8.5233154459222409e+04
            Strand		 18 40
            Start		  1.6924475241922164e+03
            Stop		  2.5593326793695392e+03
            Start		  4.5269783895976962e+03
            Stop		  5.3938625146836639e+03
            Start		  7.3615071736698383e+03
            Stop		  8.2283934677400084e+03
            Start		  1.0196039807959023e+04
            Stop		  1.1062923866382967e+04
            Start		  1.3030570418126117e+04
            Stop		  1.3897454807416107e+04
            Start		  1.5865101227760895e+04
            Stop		  1.6731985260894333e+04
            Start		  1.8699631514369084e+04
            Stop		  1.9566516199743488e+04
            Start		  2.1534162649090882e+04
            Stop		  2.2401046670932294e+04
            Start		  2.4368692829764139e+04
            Stop		  2.5235577608768272e+04
            Start		  2.7203224071540695e+04
            Stop		  2.8070108085290070e+04
            Start		  3.0037754217399193e+04
            Stop		  3.0904639022364216e+04
            Start		  3.2872285494498632e+04
            Stop		  3.3739169500282493e+04
            Start		  3.5706815628733930e+04
            Stop		  3.6573700436849736e+04
            Start		  3.8541346917261806e+04
            Stop		  3.9408230915091153e+04
            Start		  4.1375877047302638e+04
            Stop		  4.2242761851478514e+04
            Start		  4.4210408339160051e+04
            Stop		  4.5077292329941061e+04
            Start		  4.7044938467291635e+04
            Stop		  4.7911823266504529e+04
            Start		  4.9879469759672851e+04
            Stop		  5.0746353745387605e+04
            Start		  5.2713999886571379e+04
            Stop		  5.3580884682452168e+04
            Start		  5.5548531178520032e+04
            Stop		  5.6415415161994555e+04
            Start		  5.8383061304434217e+04
            Stop		  5.9249946099798210e+04
            Start		  6.1217592595710354e+04
            Stop		  6.2084476580161434e+04
            Start		  6.4052122720847772e+04
            Stop		  6.4919007518813851e+04
            Start		  6.6886654011540071e+04
            Stop		  6.7753538000029250e+04
            Start		  6.9721184136173062e+04
            Stop		  7.0588068939492834e+04
            Start		  7.2555715426541443e+04
            Stop		  7.3422599421447972e+04
            Start		  7.5390245551006738e+04
            Stop		  7.6257130361544376e+04
            Start		  7.8224776841390281e+04
            Stop		  7.9091660843999824e+04
            Start		  8.1059306966046090e+04
            Stop		  8.1926191784441005e+04
            Start		  8.3893838256788571e+04
            Stop		  8.4760722267071018e+04
            Strand		 18 41
            Strand		 18 42
            Strand		 18 43
            Strand		 18 44
            Start		  0.0000000000000000e+00
            Stop		  7.5268058976838540e+02
            Start		  2.3967803624808371e+03
            Stop		  3.5872112972840364e+03
            Start		  5.2313110757290906e+03
            Stop		  6.4217420020761720e+03
            Start		  8.0658417876658232e+03
            Stop		  9.2562727068079694e+03
            Start		  1.0900372498719271e+04
            Stop		  1.2090803411561645e+04
            Start		  1.3734903208795607e+04
            Stop		  1.4925334116551296e+04
            Start		  1.6569433917872913e+04
            Stop		  1.7759864821973872e+04
            Start		  1.9403964625971617e+04
            Stop		  2.0594395528008004e+04
            Start		  2.2238495333155384e+04
            Stop		  2.3428926234804789e+04
            Start		  2.5073026039528104e+04
            Stop		  2.6263456942482109e+04
            Start		  2.7907556745229183e+04
            Stop		  2.9097987651119201e+04
            Start		  3.0742087450427549e+04
            Stop		  3.1932518360753136e+04
            Start		  3.3576618155314238e+04
            Stop		  3.4767049071377260e+04
            Start		  3.6411148860094007e+04
            Stop		  3.7601579782941400e+04
            Start		  3.9245679564976257e+04
            Stop		  4.0436110495354136e+04
            Start		  4.2080210270166070e+04
            Stop		  4.3270641208486799e+04
            Start		  4.4914740975854882e+04
            Stop		  4.6105171922179099e+04
            Start		  4.7749271682212420e+04
            Stop		  4.8939702636246162e+04
            Start		  5.0583802389378958e+04
            Stop		  5.1774233350486669e+04
            Start		  5.3418333097459392e+04
            Stop		  5.4608764064691713e+04
            Start		  5.6252863806518420e+04
            Stop		  5.7443294778653828e+04
            Start		  5.9087394516577922e+04
            Stop		  6.0277825492176336e+04
            Start		  6.1921925227615815e+04
            Stop		  6.3112356205081822e+04
            Start		  6.4756455939567182e+04
            Stop		  6.5946886917219890e+04
            Start		  6.7590986652326988e+04
            Stop		  6.8781417628473791e+04
            Start		  7.0425517365754786e+04
            Stop		  7.1615948338765709e+04
            Start		  7.3260048079680841e+04
            Stop		  7.4450479048059962e+04
            Start		  7.6094578793913533e+04
            Stop		  7.7285009756364656e+04
            Start		  7.8929109508247959e+04
            Stop		  8.0119540463731333e+04
            Start		  8.1763640222474685e+04
            Stop		  8.2954071170252661e+04
            Start		  8.4598170936389084e+04
            Stop		  8.5788601876058456e+04
            Strand		 18 45
            Strand		 18 46
            Strand		 18 47
            Strand		 18 48
            Strand		 18 49
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 18 50
            Strand		 18 51
            Strand		 18 52
            Strand		 18 53
            Strand		 18 55
            Strand		 18 56
            Strand		 18 57
            Strand		 18 58
            Strand		 18 59
            Strand		 18 60
            Strand		 18 61
            Strand		 18 62
            Strand		 18 63
            Strand		 18 64
            Strand		 18 65
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 18 66
            Strand		 18 67
            Strand		 18 68
            Strand		 18 69
            Strand		 18 70
            Start		  1.1369941764484772e+03
            Stop		  2.3274193251726874e+03
            Start		  3.9715203664765431e+03
            Stop		  5.1619498959292023e+03
            Start		  6.8060510066192828e+03
            Stop		  7.9964806130338839e+03
            Start		  9.6405817198578534e+03
            Stop		  1.0831011324561909e+04
            Start		  1.2475112432796701e+04
            Stop		  1.3665542035404605e+04
            Start		  1.5309643146372666e+04
            Stop		  1.6500072745250087e+04
            Start		  1.8144173860347233e+04
            Stop		  1.9334603454097774e+04
            Start		  2.0978704574523468e+04
            Stop		  2.2169134161977585e+04
            Start		  2.3813235288692864e+04
            Stop		  2.5003664868962693e+04
            Start		  2.6647766002647237e+04
            Stop		  2.7838195575165431e+04
            Start		  2.9482296716187862e+04
            Stop		  3.0672726280732473e+04
            Start		  3.2316827429134129e+04
            Stop		  3.3507256985838481e+04
            Start		  3.5151358141331511e+04
            Stop		  3.6341787690678342e+04
            Start		  3.7985888852658340e+04
            Stop		  3.9176318395458649e+04
            Start		  4.0820419563031137e+04
            Stop		  4.2010849100388710e+04
            Start		  4.3654950272408292e+04
            Stop		  4.4845379805671168e+04
            Start		  4.6489480980791872e+04
            Stop		  4.7679910511493341e+04
            Start		  4.9324011688227562e+04
            Stop		  5.0514441218018786e+04
            Start		  5.2158542394802615e+04
            Stop		  5.3348971925380327e+04
            Start		  5.4993073100642046e+04
            Stop		  5.6183502633673997e+04
            Start		  5.7827603805903120e+04
            Stop		  5.9018033342955037e+04
            Start		  6.0662134510768527e+04
            Stop		  6.1852564053235365e+04
            Start		  6.3496665215438232e+04
            Stop		  6.4687094764482994e+04
            Start		  6.6331195920120765e+04
            Stop		  6.7521625476623653e+04
            Start		  6.9165726625024108e+04
            Stop		  7.0356156189543748e+04
            Start		  7.2000257330346576e+04
            Stop		  7.3190686903095688e+04
            Start		  7.4834788036267957e+04
            Stop		  7.6025217617104077e+04
            Start		  7.7669318742941759e+04
            Stop		  7.8859748331373485e+04
            Start		  8.0503849450488400e+04
            Stop		  8.1694279045697214e+04
            Start		  8.3338380158990127e+04
            Stop		  8.4528809759866141e+04
            Start		  8.6172910868486986e+04
            Stop		  8.6400000000000000e+04
            Strand		 18 71
            Strand		 19 36
            Strand		 19 37
            Strand		 19 38
            Strand		 19 39
            Strand		 19 40
            Start		  1.2200155032440323e+03
            Stop		  2.0869202750596733e+03
            Start		  4.0545452165277097e+03
            Stop		  4.9214512130137327e+03
            Start		  6.8890769240138579e+03
            Stop		  7.7559817166840785e+03
            Start		  9.7236069242999074e+03
            Stop		  1.0590512654097149e+04
            Start		  1.2558138343149611e+04
            Stop		  1.3425043141489838e+04
            Start		  1.5392668438433659e+04
            Stop		  1.6259574079547261e+04
            Start		  1.8227199760621374e+04
            Stop		  1.9094104562154240e+04
            Start		  2.1061729886922429e+04
            Stop		  2.1928635501057724e+04
            Start		  2.3896261176695079e+04
            Stop		  2.4763165982669278e+04
            Start		  2.6730791312990252e+04
            Stop		  2.7597696922397045e+04
            Start		  2.9565322591882206e+04
            Stop		  3.0432227404152916e+04
            Start		  3.2399852731456889e+04
            Stop		  3.3266758344537331e+04
            Start		  3.5234384006849024e+04
            Stop		  3.6101288826618635e+04
            Start		  3.8068914147730808e+04
            Stop		  3.8935819767379471e+04
            Start		  4.0903445422300538e+04
            Stop		  4.1770350249602066e+04
            Start		  4.3737975564047265e+04
            Stop		  4.4604881190394364e+04
            Start		  4.6572506838857873e+04
            Stop		  4.7439411672447393e+04
            Start		  4.9407036981458346e+04
            Stop		  5.0273942612920939e+04
            Start		  5.2241568256950348e+04
            Stop		  5.3108473094489163e+04
            Start		  5.5076098400437280e+04
            Stop		  5.5943004034349098e+04
            Start		  5.7910629676740915e+04
            Stop		  5.8777534515190193e+04
            Start		  6.0745159821056608e+04
            Stop		  6.1612065454248157e+04
            Start		  6.3579691098097835e+04
            Stop		  6.4446595934242279e+04
            Start		  6.6414221243061707e+04
            Stop		  6.7281126872449066e+04
            Start		  6.9248752520617665e+04
            Stop		  7.0115657351622183e+04
            Start		  7.2083282665943465e+04
            Stop		  7.2950188289076294e+04
            Start		  7.4917813943695204e+04
            Stop		  7.5784718767596409e+04
            Start		  7.7752344089036196e+04
            Stop		  7.8619249704526941e+04
            Start		  8.0586875366628825e+04
            Stop		  8.1453780182675124e+04
            Start		  8.3421405511636331e+04
            Stop		  8.4288311119401973e+04
            Start		  8.6255934626219096e+04
            Stop		  8.6400000000000000e+04
            Strand		 19 41
            Start		  7.4760260677611575e+02
            Stop		  1.6144881939917234e+03
            Start		  3.5821348173914544e+03
            Stop		  4.4490194583350903e+03
            Start		  6.4166655286952746e+03
            Stop		  7.2835497849294043e+03
            Start		  9.2511956276170167e+03
            Stop		  1.0118080804735006e+04
            Start		  1.2085726947631627e+04
            Stop		  1.2952611067865986e+04
            Start		  1.4920255660926965e+04
            Stop		  1.5787142017802134e+04
            Start		  1.7754788368023681e+04
            Stop		  1.8621672423291751e+04
            Start		  2.0589318932749884e+04
            Stop		  2.1456203362955494e+04
            Start		  2.3423849789801701e+04
            Stop		  2.4290733817949036e+04
            Start		  2.6258380061952885e+04
            Stop		  2.7125264755651806e+04
            Start		  2.9092911212501458e+04
            Stop		  2.9959795226666934e+04
            Start		  3.1927441388529638e+04
            Stop		  3.2794326163559366e+04
            Start		  3.4761972635475380e+04
            Stop		  3.5628856639582722e+04
            Start		  3.7596502779584720e+04
            Stop		  3.8463387576054440e+04
            Start		  4.0431034058020152e+04
            Stop		  4.1297918053679343e+04
            Start		  4.3265564191165649e+04
            Stop		  4.4132448990086923e+04
            Start		  4.6100095479504263e+04
            Stop		  4.6966979468437734e+04
            Start		  4.8934625608465445e+04
            Stop		  4.9801510405135588e+04
            Start		  5.1769156899479334e+04
            Stop		  5.2636040884139911e+04
            Start		  5.4603687026451895e+04
            Stop		  5.5470571821430145e+04
            Start		  5.7438218317758532e+04
            Stop		  5.8305102301209430e+04
            Start		  6.0272748443528384e+04
            Stop		  6.1139633239290975e+04
            Start		  6.3107279734449265e+04
            Stop		  6.3974163719933778e+04
            Start		  6.5941809859430825e+04
            Stop		  6.6808694658868117e+04
            Start		  6.8776341149934407e+04
            Stop		  6.9643225140346796e+04
            Start		  7.1610871274487246e+04
            Stop		  7.2477756080047402e+04
            Start		  7.4445402564805991e+04
            Stop		  7.5312286562200330e+04
            Start		  7.7279932689300607e+04
            Stop		  7.8146817502447782e+04
            Start		  8.0114463979762280e+04
            Stop		  8.0981347985000044e+04
            Start		  8.2948994104558369e+04
            Stop		  8.3815878925480109e+04
            Start		  8.5783525395486518e+04
            Stop		  8.6400000000000000e+04
            Strand		 19 42
            Strand		 19 43
            Strand		 19 44
            Strand		 19 45
            Start		  1.4519391836499512e+03
            Stop		  2.6423679082134731e+03
            Start		  4.2864676017731990e+03
            Stop		  5.4768984294558177e+03
            Start		  7.1209982161715297e+03
            Stop		  8.3114291387983176e+03
            Start		  9.9555289285236777e+03
            Stop		  1.1145959843282733e+04
            Start		  1.2790059638878374e+04
            Stop		  1.3980490548183321e+04
            Start		  1.5624590348291240e+04
            Stop		  1.6815021253440053e+04
            Start		  1.8459121056711057e+04
            Stop		  1.9649551959252047e+04
            Start		  2.1293651764190156e+04
            Stop		  2.2484082665779748e+04
            Start		  2.4128182470819364e+04
            Stop		  2.5318613373152755e+04
            Start		  2.6962713176726873e+04
            Stop		  2.8153144081463666e+04
            Start		  2.9797243882072515e+04
            Stop		  3.0987674790763889e+04
            Start		  3.2631774587040840e+04
            Stop		  3.3822205501061391e+04
            Start		  3.5466305291833000e+04
            Stop		  3.6656736212320378e+04
            Start		  3.8300835996657916e+04
            Stop		  3.9491266924462827e+04
            Start		  4.1135366701723076e+04
            Stop		  4.2325797637371892e+04
            Start		  4.3969897407225464e+04
            Stop		  4.5160328350897136e+04
            Start		  4.6804428113342918e+04
            Stop		  4.7994859064861004e+04
            Start		  4.9638958820226275e+04
            Stop		  5.0829389779066725e+04
            Start		  5.2473489527992817e+04
            Stop		  5.3663920493306869e+04
            Start		  5.5308020236721051e+04
            Stop		  5.6498451207372542e+04
            Start		  5.8142550946447351e+04
            Stop		  5.9332981921062434e+04
            Start		  6.0977081657164243e+04
            Stop		  6.2167512634191786e+04
            Start		  6.3811612368820897e+04
            Stop		  6.5002043346600389e+04
            Start		  6.6646143081325208e+04
            Stop		  6.7836574058159676e+04
            Start		  6.9480673794547882e+04
            Stop		  7.0671104768778343e+04
            Start		  7.2315204508328214e+04
            Stop		  7.3505635478406432e+04
            Start		  7.5149735222481002e+04
            Stop		  7.6340166187037379e+04
            Start		  7.7984265936804746e+04
            Stop		  7.9174696894708395e+04
            Start		  8.0818796651090495e+04
            Stop		  8.2009227601498817e+04
            Start		  8.3653327365131103e+04
            Stop		  8.4843758307526557e+04
            Strand		 19 46
            Strand		 19 47
            Strand		 19 48
            Strand		 19 49
            Strand		 19 50
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 19 51
            Strand		 19 52
            Strand		 19 53
            Strand		 19 54
            Strand		 19 56
            Strand		 19 57
            Strand		 19 58
            Strand		 19 59
            Strand		 19 60
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 19 61
            Strand		 19 62
            Strand		 19 63
            Strand		 19 64
            Strand		 19 65
            Strand		 19 66
            Strand		 19 67
            Strand		 19 68
            Strand		 19 69
            Strand		 19 70
            Strand		 19 71
            Start		  1.9214892104185563e+02
            Stop		  1.3825759018849999e+03
            Start		  3.0266769173528746e+03
            Stop		  4.2171063296824468e+03
            Start		  5.8612074371027329e+03
            Stop		  7.0516370420123567e+03
            Start		  8.6957381489645140e+03
            Stop		  9.8861677540870223e+03
            Start		  1.1530268861729639e+04
            Stop		  1.2720698465234498e+04
            Start		  1.4364799575127383e+04
            Stop		  1.5555229175412591e+04
            Start		  1.7199330288989804e+04
            Stop		  1.8389759884591858e+04
            Start		  2.0033861003121772e+04
            Stop		  2.1224290592788184e+04
            Start		  2.2868391717316787e+04
            Stop		  2.4058821300060899e+04
            Start		  2.5702922431365561e+04
            Stop		  2.6893352006509711e+04
            Start		  2.8537453145065250e+04
            Stop		  2.9727882712270475e+04
            Start		  3.1371983858228239e+04
            Stop		  3.2562413417509339e+04
            Start		  3.4206514570690524e+04
            Stop		  3.5396944122415356e+04
            Start		  3.7041045282318781e+04
            Stop		  3.8231474827192214e+04
            Start		  3.9875575993016326e+04
            Stop		  4.1066005532049319e+04
            Start		  4.2710106702727324e+04
            Stop		  4.3900536237192566e+04
            Start		  4.5544637411439144e+04
            Stop		  4.6735066942815327e+04
            Start		  4.8379168119183101e+04
            Stop		  4.9569597649089941e+04
            Start		  5.1213698826032909e+04
            Stop		  5.2404128356160189e+04
            Start		  5.4048229532101526e+04
            Stop		  5.5238659064134925e+04
            Start		  5.6882760237536204e+04
            Stop		  5.8073189773083359e+04
            Start		  5.9717290942511951e+04
            Stop		  6.0907720483031961e+04
            Start		  6.2551821647223951e+04
            Stop		  6.3742251193963391e+04
            Start		  6.5386352351878857e+04
            Stop		  6.6576781905817159e+04
            Start		  6.8220883056685954e+04
            Stop		  6.9411312618492258e+04
            Start		  7.1055413761847638e+04
            Stop		  7.2245843331851851e+04
            Start		  7.3889944467550871e+04
            Stop		  7.5080374045728968e+04
            Start		  7.6724475173958665e+04
            Stop		  7.7914904759934012e+04
            Start		  7.9559005881203309e+04
            Stop		  8.0749435474262908e+04
            Start		  8.2393536589380077e+04
            Stop		  8.3583966188506442e+04
            Start		  8.5228067298543465e+04
            Stop		  8.6400000000000000e+04
            Strand		 20 36
            Start		  0.0000000000000000e+00
            Stop		  6.6964488956909202e+02
            Start		  2.6372902645214790e+03
            Stop		  3.5041761771513629e+03
            Start		  5.4718219592251653e+03
            Stop		  6.3387061996651100e+03
            Start		  8.3063518639704380e+03
            Stop		  9.1732372071923273e+03
            Start		  1.1140883377748132e+04
            Stop		  1.2007767489270584e+04
            Start		  1.3975412027559361e+04
            Stop		  1.4842298437517966e+04
            Start		  1.6809944797863594e+04
            Stop		  1.7676828850130158e+04
            Start		  1.9644475321369093e+04
            Stop		  2.0511359789715229e+04
            Start		  2.2479006219429219e+04
            Stop		  2.3345890247192605e+04
            Start		  2.5313536478028913e+04
            Stop		  2.6180421184999988e+04
            Start		  2.8148067642014681e+04
            Stop		  2.9014951656907939e+04
            Start		  3.0982597813585042e+04
            Stop		  3.1849482593893121e+04
            Start		  3.3817129064991132e+04
            Stop		  3.4684013070245339e+04
            Start		  3.6651659207678189e+04
            Stop		  3.7518544006761076e+04
            Start		  3.9486190487654494e+04
            Stop		  4.0353074484486133e+04
            Start		  4.2320720620411725e+04
            Stop		  4.3187605420878834e+04
            Start		  4.5155251909352570e+04
            Stop		  4.6022135899213521e+04
            Start		  4.7989782038284706e+04
            Stop		  4.8856666835839824e+04
            Start		  5.0824313329599820e+04
            Stop		  5.1691197314757475e+04
            Start		  5.3658843456662311e+04
            Stop		  5.4525728251931818e+04
            Start		  5.6493374748162190e+04
            Stop		  5.7360258731583097e+04
            Start		  5.9327904874044209e+04
            Stop		  6.0194789669524485e+04
            Start		  6.2162436165097926e+04
            Stop		  6.3029320150024891e+04
            Start		  6.4996966290167635e+04
            Stop		  6.5863851088819152e+04
            Start		  6.7831497580747426e+04
            Stop		  6.8698381570167287e+04
            Start		  7.0666027705340195e+04
            Stop		  7.1532912509752190e+04
            Start		  7.3500558995674190e+04
            Stop		  7.4367442991809570e+04
            Start		  7.6335089120150689e+04
            Stop		  7.7201973931985776e+04
            Start		  7.9169620410566975e+04
            Stop		  8.0036504414494237e+04
            Start		  8.2004150535289038e+04
            Stop		  8.2871035354959822e+04
            Start		  8.4838681826120082e+04
            Stop		  8.5705565837584145e+04
            Strand		 20 37
            Strand		 20 38
            Strand		 20 39
            Strand		 20 40
            Strand		 20 41
            Start		  2.7517155550903982e+02
            Stop		  1.1420773238291126e+03
            Start		  3.1097026435356865e+03
            Stop		  3.9766075619059843e+03
            Start		  5.9442314428935406e+03
            Stop		  6.8111385123219907e+03
            Start		  8.7787640638714402e+03
            Stop		  9.6456689073927591e+03
            Start		  1.1613294690390512e+04
            Stop		  1.2480199846687257e+04
            Start		  1.4447825482470094e+04
            Stop		  1.5314730298168093e+04
            Start		  1.7282355783982042e+04
            Stop		  1.8149261236755970e+04
            Start		  2.0116886899442299e+04
            Stop		  2.0983791707679557e+04
            Start		  2.2951417093746019e+04
            Stop		  2.3818322646917823e+04
            Start		  2.5785948315156991e+04
            Stop		  2.6652853124840116e+04
            Start		  2.8620478473894364e+04
            Stop		  2.9487384064824360e+04
            Start		  3.1455009730193233e+04
            Stop		  3.2321914545477648e+04
            Start		  3.4289539877236071e+04
            Stop		  3.5156445486026751e+04
            Start		  3.7124071145245303e+04
            Stop		  3.7990975967782979e+04
            Start		  3.9958601288720623e+04
            Stop		  4.0825506908595366e+04
            Start		  4.2793132561004037e+04
            Stop		  4.3660037390665144e+04
            Start		  4.5627662703787202e+04
            Stop		  4.6494568331388960e+04
            Start		  4.8462193978037430e+04
            Stop		  4.9329098813269127e+04
            Start		  5.1296724121183215e+04
            Stop		  5.2163629753566682e+04
            Start		  5.4131255396692308e+04
            Stop		  5.4998160234899638e+04
            Start		  5.6965785540550722e+04
            Stop		  5.7832691174506792e+04
            Start		  5.9800316817034014e+04
            Stop		  6.0667221655067093e+04
            Start		  6.2634846961619114e+04
            Stop		  6.3501752593839446e+04
            Start		  6.5469378238835212e+04
            Stop		  6.6336283073548082e+04
            Start		  6.8303908383964677e+04
            Stop		  6.9170814011486000e+04
            Start		  7.1138439661615354e+04
            Stop		  7.2005344490415839e+04
            Start		  7.3972969806989102e+04
            Stop		  7.4839875427664505e+04
            Start		  7.6807501084724208e+04
            Stop		  7.7674405906024884e+04
            Start		  7.9642031229992077e+04
            Stop		  8.0508936842848983e+04
            Start		  8.2476562507454699e+04
            Stop		  8.3343467320948446e+04
            Start		  8.5311092652282401e+04
            Stop		  8.6177998257686297e+04
            Strand		 20 42
            Strand		 20 43
            Strand		 20 44
            Strand		 20 45
            Strand		 20 46
            Start		  5.0709665233662730e+02
            Stop		  1.6975242216118490e+03
            Start		  3.3416239498466180e+03
            Stop		  4.5320548628706892e+03
            Start		  6.1761546458829971e+03
            Stop		  7.3665855704696241e+03
            Start		  9.0106853581526375e+03
            Stop		  1.0201116275038563e+04
            Start		  1.1845216068853626e+04
            Stop		  1.3035646979855668e+04
            Start		  1.4679746778599016e+04
            Stop		  1.5870177684968095e+04
            Start		  1.7514277487345633e+04
            Stop		  1.8704708390575888e+04
            Start		  2.0348808195130197e+04
            Stop		  2.1539239096848960e+04
            Start		  2.3183338902030202e+04
            Stop		  2.4373769803927982e+04
            Start		  2.6017869608161953e+04
            Stop		  2.7208300511918445e+04
            Start		  2.8852400313675436e+04
            Stop		  3.0042831220885848e+04
            Start		  3.1686931018747833e+04
            Stop		  3.2877361930852763e+04
            Start		  3.4521461723575710e+04
            Stop		  3.5711892641797887e+04
            Start		  3.7355992428366379e+04
            Stop		  3.8546423353657010e+04
            Start		  4.0190523133328883e+04
            Stop		  4.1380954066325714e+04
            Start		  4.3025053838664644e+04
            Stop		  4.4215484779664097e+04
            Start		  4.5859584544558835e+04
            Stop		  4.7050015493502819e+04
            Start		  4.8694115251172094e+04
            Stop		  4.9884546207650652e+04
            Start		  5.1528645958633504e+04
            Stop		  5.2719076921902677e+04
            Start		  5.4363176667035004e+04
            Stop		  5.5553607636049426e+04
            Start		  5.7197707376427265e+04
            Stop		  5.8388138349886067e+04
            Start		  6.0032238086817488e+04
            Stop		  6.1222669063221452e+04
            Start		  6.2866768798169149e+04
            Stop		  6.4057199775886278e+04
            Start		  6.5701299510403536e+04
            Stop		  6.6891730487740759e+04
            Start		  6.8535830223403202e+04
            Stop		  6.9726261198680615e+04
            Start		  7.1370360937017191e+04
            Stop		  7.2560791908641811e+04
            Start		  7.4204891651067563e+04
            Stop		  7.5395322617603160e+04
            Start		  7.7039422365357372e+04
            Stop		  7.8229853325587363e+04
            Start		  7.9873953079679108e+04
            Stop		  8.1064384032660018e+04
            Start		  8.2708483793823965e+04
            Stop		  8.3898914738926731e+04
            Start		  8.5543014507590939e+04
            Stop		  8.6400000000000000e+04
            Strand		 20 47
            Strand		 20 48
            Strand		 20 49
            Strand		 20 50
            Strand		 20 51
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 20 52
            Strand		 20 53
            Strand		 20 54
            Strand		 20 55
            Strand		 20 57
            Strand		 20 58
            Strand		 20 59
            Strand		 20 60
            Strand		 20 61
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 20 62
            Strand		 20 63
            Strand		 20 64
            Strand		 20 65
            Strand		 20 66
            Start		  0.0000000000000000e+00
            Stop		  4.3773230047354707e+02
            Start		  2.0818333137609184e+03
            Stop		  3.2722627563067249e+03
            Start		  4.9163638661368586e+03
            Stop		  6.1067934712632141e+03
            Start		  7.7508945782384881e+03
            Stop		  8.9413241834935288e+03
            Start		  1.0585425290729709e+04
            Stop		  1.1775854894957100e+04
            Start		  1.3419956003934063e+04
            Stop		  1.4610385605463722e+04
            Start		  1.6254486717662419e+04
            Stop		  1.7444916314976352e+04
            Start		  1.9089017431727119e+04
            Stop		  2.0279447023495810e+04
            Start		  2.1923548145924407e+04
            Stop		  2.3113977731067254e+04
            Start		  2.4758078860044970e+04
            Stop		  2.5948508437777276e+04
            Start		  2.7592609573882801e+04
            Stop		  2.8783039143750302e+04
            Start		  3.0427140287244245e+04
            Stop		  3.1617569849143096e+04
            Start		  3.3261670999956557e+04
            Stop		  3.4452100554137956e+04
            Start		  3.6096201711875467e+04
            Stop		  3.7286631258934693e+04
            Start		  3.8930732422891553e+04
            Stop		  4.0121161963741812e+04
            Start		  4.1765263132934961e+04
            Stop		  4.2955692668767391e+04
            Start		  4.4599793841978506e+04
            Stop		  4.5790223374209963e+04
            Start		  4.7434324550038953e+04
            Stop		  4.8624754080249768e+04
            Start		  5.0268855257176117e+04
            Stop		  5.1459284787040873e+04
            Start		  5.3103385963490357e+04
            Stop		  5.4293815494704380e+04
            Start		  5.5937916669118116e+04
            Stop		  5.7128346203323163e+04
            Start		  5.8772447374225980e+04
            Stop		  5.9962876912938147e+04
            Start		  6.1606978079003304e+04
            Stop		  6.2797407623546569e+04
            Start		  6.4441508783653946e+04
            Stop		  6.5631938335102168e+04
            Start		  6.7276039488387280e+04
            Stop		  6.8466469047517050e+04
            Start		  7.0110570193409061e+04
            Stop		  7.1300999760665713e+04
            Start		  7.2945100898912307e+04
            Stop		  7.4135530474390442e+04
            Start		  7.5779631605068935e+04
            Stop		  7.6970061188508305e+04
            Start		  7.8614162312022105e+04
            Stop		  7.9804591902819098e+04
            Start		  8.1448693019880011e+04
            Stop		  8.2639122617114292e+04
            Start		  8.4283223728711120e+04
            Stop		  8.5473653331186069e+04
            Strand		 20 67
            Strand		 20 68
            Strand		 20 69
            Strand		 20 70
            Strand		 20 71
            Strand		 21 36
            Start		  0.0000000000000000e+00
            Stop		  1.9723331034034342e+02
            Start		  2.1648573682759225e+03
            Stop		  3.0317642680479535e+03
            Start		  4.9993897838668217e+03
            Stop		  5.8662946404338227e+03
            Start		  7.8339205441153699e+03
            Stop		  8.7008255802883323e+03
            Start		  1.0668451203607174e+04
            Stop		  1.1535356023707353e+04
            Start		  1.3502981549256363e+04
            Stop		  1.4369886961884924e+04
            Start		  1.6337512621631655e+04
            Stop		  1.7204417429728026e+04
            Start		  1.9172042830729748e+04
            Stop		  2.0038948368415597e+04
            Start		  2.2006574038129595e+04
            Stop		  2.2873478844955825e+04
            Start		  2.4841104201854891e+04
            Stop		  2.5708009784438807e+04
            Start		  2.7675635453545132e+04
            Stop		  2.8542540264377945e+04
            Start		  3.0510165602169662e+04
            Stop		  3.1377071204575204e+04
            Start		  3.3344696868506893e+04
            Stop		  3.4211601685988688e+04
            Start		  3.6179227012280986e+04
            Stop		  3.7046132626662016e+04
            Start		  3.9013758283721399e+04
            Stop		  3.9880663108680950e+04
            Start		  4.1848288426261031e+04
            Stop		  4.2715194049503254e+04
            Start		  4.4682819699851090e+04
            Stop		  4.5549724531587344e+04
            Start		  4.7517349842515301e+04
            Stop		  4.8384255472204008e+04
            Start		  5.0351881117399535e+04
            Stop		  5.1218785953945066e+04
            Start		  5.3186411260708679e+04
            Stop		  5.4053316894036660e+04
            Start		  5.6020942536624141e+04
            Stop		  5.6887847375133439e+04
            Start		  5.8855472680716288e+04
            Stop		  5.9722378314471505e+04
            Start		  6.1690003957491390e+04
            Stop		  6.2556908794750212e+04
            Start		  6.4524534102279285e+04
            Stop		  6.5391439733236955e+04
            Start		  6.7359065379682768e+04
            Stop		  6.8225970212670989e+04
            Start		  7.0193595524928809e+04
            Stop		  7.1060501150356387e+04
            Start		  7.3028126802650018e+04
            Stop		  7.3895031629067424e+04
            Start		  7.5862656948027245e+04
            Stop		  7.6729562566140390e+04
            Start		  7.8697188225710561e+04
            Stop		  7.9564093044376117e+04
            Start		  8.1531718370866016e+04
            Stop		  8.2398623981131852e+04
            Start		  8.4366249648165831e+04
            Stop		  8.5233154459222482e+04
            Strand		 21 37
            Start		  1.6924475241922189e+03
            Stop		  2.5593326793695273e+03
            Start		  4.5269783895976971e+03
            Stop		  5.3938625146836666e+03
            Start		  7.3615071736698410e+03
            Stop		  8.2283934677400048e+03
            Start		  1.0196039807959027e+04
            Stop		  1.1062923866382978e+04
            Start		  1.3030570418126126e+04
            Stop		  1.3897454807416112e+04
            Start		  1.5865101227760906e+04
            Stop		  1.6731985260894333e+04
            Start		  1.8699631514369095e+04
            Stop		  1.9566516199743492e+04
            Start		  2.1534162649090900e+04
            Stop		  2.2401046670932297e+04
            Start		  2.4368692829764157e+04
            Stop		  2.5235577608768268e+04
            Start		  2.7203224071540710e+04
            Stop		  2.8070108085290070e+04
            Start		  3.0037754217399215e+04
            Stop		  3.0904639022364208e+04
            Start		  3.2872285494498654e+04
            Stop		  3.3739169500282493e+04
            Start		  3.5706815628733959e+04
            Stop		  3.6573700436849722e+04
            Start		  3.8541346917261835e+04
            Stop		  3.9408230915091153e+04
            Start		  4.1375877047302667e+04
            Stop		  4.2242761851478514e+04
            Start		  4.4210408339160087e+04
            Stop		  4.5077292329941061e+04
            Start		  4.7044938467291679e+04
            Stop		  4.7911823266504522e+04
            Start		  4.9879469759672895e+04
            Stop		  5.0746353745387612e+04
            Start		  5.2713999886571408e+04
            Stop		  5.3580884682452168e+04
            Start		  5.5548531178520076e+04
            Stop		  5.6415415161994562e+04
            Start		  5.8383061304434254e+04
            Stop		  5.9249946099798202e+04
            Start		  6.1217592595710390e+04
            Stop		  6.2084476580161405e+04
            Start		  6.4052122720847823e+04
            Stop		  6.4919007518813822e+04
            Start		  6.6886654011540129e+04
            Stop		  6.7753538000029235e+04
            Start		  6.9721184136173106e+04
            Stop		  7.0588068939492819e+04
            Start		  7.2555715426541501e+04
            Stop		  7.3422599421447958e+04
            Start		  7.5390245551006796e+04
            Stop		  7.6257130361544361e+04
            Start		  7.8224776841390340e+04
            Stop		  7.9091660843999809e+04
            Start		  8.1059306966046148e+04
            Stop		  8.1926191784440976e+04
            Start		  8.3893838256788644e+04
            Stop		  8.4760722267070989e+04
            Strand		 21 38
            Strand		 21 39
            Strand		 21 40
            Strand		 21 41
            Strand		 21 42
            Strand		 21 43
            Strand		 21 44
            Strand		 21 45
            Strand		 21 46
            Strand		 21 47
            Start		  0.0000000000000000e+00
            Stop		  7.5268058976839245e+02
            Start		  2.3967803624808375e+03
            Stop		  3.5872112972840441e+03
            Start		  5.2313110757290924e+03
            Stop		  6.4217420020761874e+03
            Start		  8.0658417876658232e+03
            Stop		  9.2562727068079894e+03
            Start		  1.0900372498719273e+04
            Stop		  1.2090803411561657e+04
            Start		  1.3734903208795613e+04
            Stop		  1.4925334116551310e+04
            Start		  1.6569433917872935e+04
            Stop		  1.7759864821973904e+04
            Start		  1.9403964625971643e+04
            Stop		  2.0594395528008026e+04
            Start		  2.2238495333155410e+04
            Stop		  2.3428926234804818e+04
            Start		  2.5073026039528129e+04
            Stop		  2.6263456942482142e+04
            Start		  2.7907556745229205e+04
            Stop		  2.9097987651119234e+04
            Start		  3.0742087450427567e+04
            Stop		  3.1932518360753180e+04
            Start		  3.3576618155314267e+04
            Stop		  3.4767049071377303e+04
            Start		  3.6411148860094036e+04
            Stop		  3.7601579782941430e+04
            Start		  3.9245679564976301e+04
            Stop		  4.0436110495354187e+04
            Start		  4.2080210270166099e+04
            Stop		  4.3270641208486857e+04
            Start		  4.4914740975854926e+04
            Stop		  4.6105171922179157e+04
            Start		  4.7749271682212464e+04
            Stop		  4.8939702636246213e+04
            Start		  5.0583802389379009e+04
            Stop		  5.1774233350486727e+04
            Start		  5.3418333097459428e+04
            Stop		  5.4608764064691757e+04
            Start		  5.6252863806518464e+04
            Stop		  5.7443294778653893e+04
            Start		  5.9087394516577959e+04
            Stop		  6.0277825492176395e+04
            Start		  6.1921925227615873e+04
            Stop		  6.3112356205081887e+04
            Start		  6.4756455939567255e+04
            Stop		  6.5946886917219934e+04
            Start		  6.7590986652327061e+04
            Stop		  6.8781417628473850e+04
            Start		  7.0425517365754829e+04
            Stop		  7.1615948338765782e+04
            Start		  7.3260048079680870e+04
            Stop		  7.4450479048060020e+04
            Start		  7.6094578793913621e+04
            Stop		  7.7285009756364743e+04
            Start		  7.8929109508248017e+04
            Stop		  8.0119540463731406e+04
            Start		  8.1763640222474743e+04
            Stop		  8.2954071170252762e+04
            Start		  8.4598170936389171e+04
            Stop		  8.5788601876058499e+04
            Strand		 21 48
            Strand		 21 49
            Strand		 21 50
            Strand		 21 51
            Strand		 21 52
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 21 53
            Strand		 21 54
            Strand		 21 55
            Strand		 21 56
            Strand		 21 58
            Strand		 21 59
            Strand		 21 60
            Strand		 21 61
            Strand		 21 62
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 21 63
            Strand		 21 64
            Strand		 21 65
            Strand		 21 66
            Strand		 21 67
            Start		  1.1369941764484718e+03
            Stop		  2.3274193251726888e+03
            Start		  3.9715203664765381e+03
            Stop		  5.1619498959292023e+03
            Start		  6.8060510066192919e+03
            Stop		  7.9964806130338866e+03
            Start		  9.6405817198578643e+03
            Stop		  1.0831011324561921e+04
            Start		  1.2475112432796708e+04
            Stop		  1.3665542035404624e+04
            Start		  1.5309643146372677e+04
            Stop		  1.6500072745250101e+04
            Start		  1.8144173860347251e+04
            Stop		  1.9334603454097796e+04
            Start		  2.0978704574523490e+04
            Stop		  2.2169134161977610e+04
            Start		  2.3813235288692878e+04
            Stop		  2.5003664868962715e+04
            Start		  2.6647766002647259e+04
            Stop		  2.7838195575165446e+04
            Start		  2.9482296716187884e+04
            Stop		  3.0672726280732491e+04
            Start		  3.2316827429134148e+04
            Stop		  3.3507256985838510e+04
            Start		  3.5151358141331533e+04
            Stop		  3.6341787690678357e+04
            Start		  3.7985888852658361e+04
            Stop		  3.9176318395458693e+04
            Start		  4.0820419563031166e+04
            Stop		  4.2010849100388739e+04
            Start		  4.3654950272408314e+04
            Stop		  4.4845379805671211e+04
            Start		  4.6489480980791915e+04
            Stop		  4.7679910511493392e+04
            Start		  4.9324011688227612e+04
            Stop		  5.0514441218018837e+04
            Start		  5.2158542394802666e+04
            Stop		  5.3348971925380371e+04
            Start		  5.4993073100642097e+04
            Stop		  5.6183502633674063e+04
            Start		  5.7827603805903185e+04
            Stop		  5.9018033342955096e+04
            Start		  6.0662134510768585e+04
            Stop		  6.1852564053235401e+04
            Start		  6.3496665215438261e+04
            Stop		  6.4687094764483045e+04
            Start		  6.6331195920120808e+04
            Stop		  6.7521625476623696e+04
            Start		  6.9165726625024196e+04
            Stop		  7.0356156189543806e+04
            Start		  7.2000257330346634e+04
            Stop		  7.3190686903095746e+04
            Start		  7.4834788036268001e+04
            Stop		  7.6025217617104121e+04
            Start		  7.7669318742941832e+04
            Stop		  7.8859748331373572e+04
            Start		  8.0503849450488487e+04
            Stop		  8.1694279045697302e+04
            Start		  8.3338380158990200e+04
            Stop		  8.4528809759866184e+04
            Start		  8.6172910868487059e+04
            Stop		  8.6400000000000000e+04
            Strand		 21 68
            Strand		 21 69
            Strand		 21 70
            Strand		 21 71
            Strand		 22 36
            Strand		 22 37
            Start		  1.2200155032440416e+03
            Stop		  2.0869202750596737e+03
            Start		  4.0545452165277061e+03
            Stop		  4.9214512130137318e+03
            Start		  6.8890769240138561e+03
            Stop		  7.7559817166840785e+03
            Start		  9.7236069242998983e+03
            Stop		  1.0590512654097156e+04
            Start		  1.2558138343149605e+04
            Stop		  1.3425043141489841e+04
            Start		  1.5392668438433653e+04
            Stop		  1.6259574079547257e+04
            Start		  1.8227199760621359e+04
            Stop		  1.9094104562154236e+04
            Start		  2.1061729886922414e+04
            Stop		  2.1928635501057724e+04
            Start		  2.3896261176695065e+04
            Stop		  2.4763165982669281e+04
            Start		  2.6730791312990244e+04
            Stop		  2.7597696922397045e+04
            Start		  2.9565322591882188e+04
            Stop		  3.0432227404152909e+04
            Start		  3.2399852731456878e+04
            Stop		  3.3266758344537338e+04
            Start		  3.5234384006849010e+04
            Stop		  3.6101288826618642e+04
            Start		  3.8068914147730793e+04
            Stop		  3.8935819767379471e+04
            Start		  4.0903445422300523e+04
            Stop		  4.1770350249602066e+04
            Start		  4.3737975564047265e+04
            Stop		  4.4604881190394357e+04
            Start		  4.6572506838857866e+04
            Stop		  4.7439411672447401e+04
            Start		  4.9407036981458332e+04
            Stop		  5.0273942612920939e+04
            Start		  5.2241568256950333e+04
            Stop		  5.3108473094489163e+04
            Start		  5.5076098400437266e+04
            Stop		  5.5943004034349098e+04
            Start		  5.7910629676740893e+04
            Stop		  5.8777534515190178e+04
            Start		  6.0745159821056572e+04
            Stop		  6.1612065454248142e+04
            Start		  6.3579691098097828e+04
            Stop		  6.4446595934242279e+04
            Start		  6.6414221243061649e+04
            Stop		  6.7281126872449051e+04
            Start		  6.9248752520617621e+04
            Stop		  7.0115657351622183e+04
            Start		  7.2083282665943421e+04
            Stop		  7.2950188289076279e+04
            Start		  7.4917813943695204e+04
            Stop		  7.5784718767596394e+04
            Start		  7.7752344089036153e+04
            Stop		  7.8619249704526927e+04
            Start		  8.0586875366628796e+04
            Stop		  8.1453780182675124e+04
            Start		  8.3421405511636287e+04
            Stop		  8.4288311119401958e+04
            Start		  8.6255934626219067e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 38
            Start		  7.4760260677611666e+02
            Stop		  1.6144881939917238e+03
            Start		  3.5821348173914639e+03
            Stop		  4.4490194583350949e+03
            Start		  6.4166655286952746e+03
            Stop		  7.2835497849294034e+03
            Start		  9.2511956276170185e+03
            Stop		  1.0118080804734991e+04
            Start		  1.2085726947631623e+04
            Stop		  1.2952611067865975e+04
            Start		  1.4920255660926960e+04
            Stop		  1.5787142017802133e+04
            Start		  1.7754788368023681e+04
            Stop		  1.8621672423291744e+04
            Start		  2.0589318932749884e+04
            Stop		  2.1456203362955486e+04
            Start		  2.3423849789801698e+04
            Stop		  2.4290733817949033e+04
            Start		  2.6258380061952881e+04
            Stop		  2.7125264755651788e+04
            Start		  2.9092911212501454e+04
            Stop		  2.9959795226666913e+04
            Start		  3.1927441388529638e+04
            Stop		  3.2794326163559344e+04
            Start		  3.4761972635475373e+04
            Stop		  3.5628856639582707e+04
            Start		  3.7596502779584727e+04
            Stop		  3.8463387576054411e+04
            Start		  4.0431034058020152e+04
            Stop		  4.1297918053679343e+04
            Start		  4.3265564191165649e+04
            Stop		  4.4132448990086901e+04
            Start		  4.6100095479504256e+04
            Stop		  4.6966979468437719e+04
            Start		  4.8934625608465445e+04
            Stop		  4.9801510405135567e+04
            Start		  5.1769156899479312e+04
            Stop		  5.2636040884139882e+04
            Start		  5.4603687026451895e+04
            Stop		  5.5470571821430123e+04
            Start		  5.7438218317758518e+04
            Stop		  5.8305102301209394e+04
            Start		  6.0272748443528370e+04
            Stop		  6.1139633239290939e+04
            Start		  6.3107279734449250e+04
            Stop		  6.3974163719933749e+04
            Start		  6.5941809859430839e+04
            Stop		  6.6808694658868073e+04
            Start		  6.8776341149934393e+04
            Stop		  6.9643225140346753e+04
            Start		  7.1610871274487232e+04
            Stop		  7.2477756080047373e+04
            Start		  7.4445402564805976e+04
            Stop		  7.5312286562200257e+04
            Start		  7.7279932689300593e+04
            Stop		  7.8146817502447739e+04
            Start		  8.0114463979762266e+04
            Stop		  8.0981347985000000e+04
            Start		  8.2948994104558355e+04
            Stop		  8.3815878925480050e+04
            Start		  8.5783525395486489e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 39
            Strand		 22 40
            Strand		 22 41
            Strand		 22 42
            Start		  1.4519391836499508e+03
            Stop		  2.6423679082134713e+03
            Start		  4.2864676017731981e+03
            Stop		  5.4768984294558213e+03
            Start		  7.1209982161715207e+03
            Stop		  8.3114291387983194e+03
            Start		  9.9555289285236813e+03
            Stop		  1.1145959843282732e+04
            Start		  1.2790059638878387e+04
            Stop		  1.3980490548183325e+04
            Start		  1.5624590348291236e+04
            Stop		  1.6815021253440056e+04
            Start		  1.8459121056711061e+04
            Stop		  1.9649551959252050e+04
            Start		  2.1293651764190156e+04
            Stop		  2.2484082665779744e+04
            Start		  2.4128182470819374e+04
            Stop		  2.5318613373152766e+04
            Start		  2.6962713176726873e+04
            Stop		  2.8153144081463670e+04
            Start		  2.9797243882072518e+04
            Stop		  3.0987674790763893e+04
            Start		  3.2631774587040833e+04
            Stop		  3.3822205501061399e+04
            Start		  3.5466305291833014e+04
            Stop		  3.6656736212320378e+04
            Start		  3.8300835996657916e+04
            Stop		  3.9491266924462812e+04
            Start		  4.1135366701723069e+04
            Stop		  4.2325797637371885e+04
            Start		  4.3969897407225471e+04
            Stop		  4.5160328350897114e+04
            Start		  4.6804428113342932e+04
            Stop		  4.7994859064861012e+04
            Start		  4.9638958820226275e+04
            Stop		  5.0829389779066725e+04
            Start		  5.2473489527992802e+04
            Stop		  5.3663920493306876e+04
            Start		  5.5308020236721044e+04
            Stop		  5.6498451207372549e+04
            Start		  5.8142550946447329e+04
            Stop		  5.9332981921062441e+04
            Start		  6.0977081657164250e+04
            Stop		  6.2167512634191793e+04
            Start		  6.3811612368820890e+04
            Stop		  6.5002043346600374e+04
            Start		  6.6646143081325194e+04
            Stop		  6.7836574058159676e+04
            Start		  6.9480673794547882e+04
            Stop		  7.0671104768778314e+04
            Start		  7.2315204508328199e+04
            Stop		  7.3505635478406432e+04
            Start		  7.5149735222480987e+04
            Stop		  7.6340166187037350e+04
            Start		  7.7984265936804732e+04
            Stop		  7.9174696894708381e+04
            Start		  8.0818796651090524e+04
            Stop		  8.2009227601498802e+04
            Start		  8.3653327365131088e+04
            Stop		  8.4843758307526616e+04
            Strand		 22 43
            Strand		 22 44
            Strand		 22 45
            Strand		 22 46
            Strand		 22 47
            Strand		 22 48
            Strand		 22 49
            Strand		 22 50
            Strand		 22 51
            Strand		 22 52
            Strand		 22 53
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 22 54
            Strand		 22 55
            Strand		 22 56
            Strand		 22 57
            Strand		 22 59
            Strand		 22 60
            Strand		 22 61
            Strand		 22 62
            Strand		 22 63
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 22 64
            Strand		 22 65
            Strand		 22 66
            Strand		 22 67
            Strand		 22 68
            Start		  1.9214892104186086e+02
            Stop		  1.3825759018849944e+03
            Start		  3.0266769173528742e+03
            Stop		  4.2171063296824423e+03
            Start		  5.8612074371027284e+03
            Stop		  7.0516370420123494e+03
            Start		  8.6957381489645086e+03
            Stop		  9.8861677540870278e+03
            Start		  1.1530268861729630e+04
            Stop		  1.2720698465234496e+04
            Start		  1.4364799575127377e+04
            Stop		  1.5555229175412589e+04
            Start		  1.7199330288989804e+04
            Stop		  1.8389759884591847e+04
            Start		  2.0033861003121776e+04
            Stop		  2.1224290592788169e+04
            Start		  2.2868391717316783e+04
            Stop		  2.4058821300060892e+04
            Start		  2.5702922431365554e+04
            Stop		  2.6893352006509704e+04
            Start		  2.8537453145065232e+04
            Stop		  2.9727882712270475e+04
            Start		  3.1371983858228228e+04
            Stop		  3.2562413417509320e+04
            Start		  3.4206514570690502e+04
            Stop		  3.5396944122415349e+04
            Start		  3.7041045282318766e+04
            Stop		  3.8231474827192207e+04
            Start		  3.9875575993016319e+04
            Stop		  4.1066005532049305e+04
            Start		  4.2710106702727302e+04
            Stop		  4.3900536237192551e+04
            Start		  4.5544637411439136e+04
            Stop		  4.6735066942815298e+04
            Start		  4.8379168119183079e+04
            Stop		  4.9569597649089934e+04
            Start		  5.1213698826032902e+04
            Stop		  5.2404128356160159e+04
            Start		  5.4048229532101519e+04
            Stop		  5.5238659064134896e+04
            Start		  5.6882760237536175e+04
            Stop		  5.8073189773083337e+04
            Start		  5.9717290942511929e+04
            Stop		  6.0907720483031968e+04
            Start		  6.2551821647223929e+04
            Stop		  6.3742251193963377e+04
            Start		  6.5386352351878850e+04
            Stop		  6.6576781905817101e+04
            Start		  6.8220883056685911e+04
            Stop		  6.9411312618492258e+04
            Start		  7.1055413761847594e+04
            Stop		  7.2245843331851851e+04
            Start		  7.3889944467550828e+04
            Stop		  7.5080374045728953e+04
            Start		  7.6724475173958679e+04
            Stop		  7.7914904759933968e+04
            Start		  7.9559005881203295e+04
            Stop		  8.0749435474262908e+04
            Start		  8.2393536589380048e+04
            Stop		  8.3583966188506412e+04
            Start		  8.5228067298543450e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 69
            Strand		 22 70
            Strand		 22 71
            Strand		 23 36
            Strand		 23 37
            Strand		 23 38
            Start		  2.7517155550903743e+02
            Stop		  1.1420773238291099e+03
            Start		  3.1097026435356902e+03
            Stop		  3.9766075619059893e+03
            Start		  5.9442314428935370e+03
            Stop		  6.8111385123219861e+03
            Start		  8.7787640638714347e+03
            Stop		  9.6456689073927555e+03
            Start		  1.1613294690390510e+04
            Stop		  1.2480199846687245e+04
            Start		  1.4447825482470091e+04
            Stop		  1.5314730298168091e+04
            Start		  1.7282355783982035e+04
            Stop		  1.8149261236755960e+04
            Start		  2.0116886899442281e+04
            Stop		  2.0983791707679553e+04
            Start		  2.2951417093746008e+04
            Stop		  2.3818322646917808e+04
            Start		  2.5785948315156973e+04
            Stop		  2.6652853124840112e+04
            Start		  2.8620478473894349e+04
            Stop		  2.9487384064824335e+04
            Start		  3.1455009730193218e+04
            Stop		  3.2321914545477634e+04
            Start		  3.4289539877236064e+04
            Stop		  3.5156445486026736e+04
            Start		  3.7124071145245296e+04
            Stop		  3.7990975967782964e+04
            Start		  3.9958601288720602e+04
            Stop		  4.0825506908595351e+04
            Start		  4.2793132561004015e+04
            Stop		  4.3660037390665129e+04
            Start		  4.5627662703787180e+04
            Stop		  4.6494568331388946e+04
            Start		  4.8462193978037409e+04
            Stop		  4.9329098813269113e+04
            Start		  5.1296724121183186e+04
            Stop		  5.2163629753566667e+04
            Start		  5.4131255396692286e+04
            Stop		  5.4998160234899595e+04
            Start		  5.6965785540550693e+04
            Stop		  5.7832691174506763e+04
            Start		  5.9800316817033992e+04
            Stop		  6.0667221655067056e+04
            Start		  6.2634846961619078e+04
            Stop		  6.3501752593839403e+04
            Start		  6.5469378238835190e+04
            Stop		  6.6336283073548053e+04
            Start		  6.8303908383964619e+04
            Stop		  6.9170814011485956e+04
            Start		  7.1138439661615310e+04
            Stop		  7.2005344490415824e+04
            Start		  7.3972969806989073e+04
            Stop		  7.4839875427664461e+04
            Start		  7.6807501084724165e+04
            Stop		  7.7674405906024855e+04
            Start		  7.9642031229992033e+04
            Stop		  8.0508936842848940e+04
            Start		  8.2476562507454684e+04
            Stop		  8.3343467320948403e+04
            Start		  8.5311092652282372e+04
            Stop		  8.6177998257686268e+04
            Strand		 23 39
            Start		  0.0000000000000000e+00
            Stop		  6.6964488956908963e+02
            Start		  2.6372902645214754e+03
            Stop		  3.5041761771513638e+03
            Start		  5.4718219592251753e+03
            Stop		  6.3387061996651055e+03
            Start		  8.3063518639704325e+03
            Stop		  9.1732372071923364e+03
            Start		  1.1140883377748130e+04
            Stop		  1.2007767489270582e+04
            Start		  1.3975412027559354e+04
            Stop		  1.4842298437517960e+04
            Start		  1.6809944797863587e+04
            Stop		  1.7676828850130161e+04
            Start		  1.9644475321369082e+04
            Stop		  2.0511359789715236e+04
            Start		  2.2479006219429215e+04
            Stop		  2.3345890247192601e+04
            Start		  2.5313536478028909e+04
            Stop		  2.6180421184999981e+04
            Start		  2.8148067642014670e+04
            Stop		  2.9014951656907931e+04
            Start		  3.0982597813585031e+04
            Stop		  3.1849482593893117e+04
            Start		  3.3817129064991117e+04
            Stop		  3.4684013070245332e+04
            Start		  3.6651659207678182e+04
            Stop		  3.7518544006761062e+04
            Start		  3.9486190487654480e+04
            Stop		  4.0353074484486126e+04
            Start		  4.2320720620411725e+04
            Stop		  4.3187605420878826e+04
            Start		  4.5155251909352563e+04
            Stop		  4.6022135899213528e+04
            Start		  4.7989782038284691e+04
            Stop		  4.8856666835839824e+04
            Start		  5.0824313329599805e+04
            Stop		  5.1691197314757468e+04
            Start		  5.3658843456662296e+04
            Stop		  5.4525728251931811e+04
            Start		  5.6493374748162183e+04
            Stop		  5.7360258731583104e+04
            Start		  5.9327904874044194e+04
            Stop		  6.0194789669524471e+04
            Start		  6.2162436165097904e+04
            Stop		  6.3029320150024912e+04
            Start		  6.4996966290167598e+04
            Stop		  6.5863851088819167e+04
            Start		  6.7831497580747397e+04
            Stop		  6.8698381570167287e+04
            Start		  7.0666027705340181e+04
            Stop		  7.1532912509752190e+04
            Start		  7.3500558995674161e+04
            Stop		  7.4367442991809541e+04
            Start		  7.6335089120150675e+04
            Stop		  7.7201973931985747e+04
            Start		  7.9169620410566960e+04
            Stop		  8.0036504414494237e+04
            Start		  8.2004150535289038e+04
            Stop		  8.2871035354959808e+04
            Start		  8.4838681826120053e+04
            Stop		  8.5705565837584130e+04
            Strand		 23 40
            Strand		 23 41
            Strand		 23 42
            Strand		 23 43
            Start		  5.0709665233663253e+02
            Stop		  1.6975242216118506e+03
            Start		  3.3416239498466184e+03
            Stop		  4.5320548628706847e+03
            Start		  6.1761546458830026e+03
            Stop		  7.3665855704696223e+03
            Start		  9.0106853581526357e+03
            Stop		  1.0201116275038565e+04
            Start		  1.1845216068853621e+04
            Stop		  1.3035646979855666e+04
            Start		  1.4679746778599014e+04
            Stop		  1.5870177684968083e+04
            Start		  1.7514277487345622e+04
            Stop		  1.8704708390575877e+04
            Start		  2.0348808195130187e+04
            Stop		  2.1539239096848956e+04
            Start		  2.3183338902030206e+04
            Stop		  2.4373769803927968e+04
            Start		  2.6017869608161953e+04
            Stop		  2.7208300511918427e+04
            Start		  2.8852400313675429e+04
            Stop		  3.0042831220885826e+04
            Start		  3.1686931018747822e+04
            Stop		  3.2877361930852734e+04
            Start		  3.4521461723575696e+04
            Stop		  3.5711892641797880e+04
            Start		  3.7355992428366379e+04
            Stop		  3.8546423353656981e+04
            Start		  4.0190523133328861e+04
            Stop		  4.1380954066325685e+04
            Start		  4.3025053838664644e+04
            Stop		  4.4215484779664068e+04
            Start		  4.5859584544558827e+04
            Stop		  4.7050015493502833e+04
            Start		  4.8694115251172065e+04
            Stop		  4.9884546207650630e+04
            Start		  5.1528645958633497e+04
            Stop		  5.2719076921902633e+04
            Start		  5.4363176667034983e+04
            Stop		  5.5553607636049390e+04
            Start		  5.7197707376427243e+04
            Stop		  5.8388138349886067e+04
            Start		  6.0032238086817488e+04
            Stop		  6.1222669063221445e+04
            Start		  6.2866768798169142e+04
            Stop		  6.4057199775886256e+04
            Start		  6.5701299510403522e+04
            Stop		  6.6891730487740730e+04
            Start		  6.8535830223403202e+04
            Stop		  6.9726261198680615e+04
            Start		  7.1370360937017147e+04
            Stop		  7.2560791908641782e+04
            Start		  7.4204891651067534e+04
            Stop		  7.5395322617603117e+04
            Start		  7.7039422365357357e+04
            Stop		  7.8229853325587304e+04
            Start		  7.9873953079679108e+04
            Stop		  8.1064384032659960e+04
            Start		  8.2708483793823936e+04
            Stop		  8.3898914738926687e+04
            Start		  8.5543014507590866e+04
            Stop		  8.6400000000000000e+04
            Strand		 23 44
            Strand		 23 45
            Strand		 23 46
            Strand		 23 47
            Strand		 23 48
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 23 49
            Strand		 23 50
            Strand		 23 51
            Strand		 23 52
            Strand		 23 53
            Strand		 23 54
            Strand		 23 55
            Strand		 23 56
            Strand		 23 57
            Strand		 23 58
            Strand		 23 60
            Strand		 23 61
            Strand		 23 62
            Strand		 23 63
            Strand		 23 64
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 23 65
            Strand		 23 66
            Strand		 23 67
            Strand		 23 68
            Strand		 23 69
            Start		  0.0000000000000000e+00
            Stop		  4.3773230047354440e+02
            Start		  2.0818333137609143e+03
            Stop		  3.2722627563067199e+03
            Start		  4.9163638661368541e+03
            Stop		  6.1067934712632059e+03
            Start		  7.7508945782384935e+03
            Stop		  8.9413241834935325e+03
            Start		  1.0585425290729703e+04
            Stop		  1.1775854894957098e+04
            Start		  1.3419956003934065e+04
            Stop		  1.4610385605463718e+04
            Start		  1.6254486717662421e+04
            Stop		  1.7444916314976344e+04
            Start		  1.9089017431727119e+04
            Stop		  2.0279447023495824e+04
            Start		  2.1923548145924400e+04
            Stop		  2.3113977731067247e+04
            Start		  2.4758078860044956e+04
            Stop		  2.5948508437777276e+04
            Start		  2.7592609573882793e+04
            Stop		  2.8783039143750295e+04
            Start		  3.0427140287244238e+04
            Stop		  3.1617569849143081e+04
            Start		  3.3261670999956543e+04
            Stop		  3.4452100554137964e+04
            Start		  3.6096201711875459e+04
            Stop		  3.7286631258934693e+04
            Start		  3.8930732422891553e+04
            Stop		  4.0121161963741812e+04
            Start		  4.1765263132934953e+04
            Stop		  4.2955692668767391e+04
            Start		  4.4599793841978513e+04
            Stop		  4.5790223374209956e+04
            Start		  4.7434324550038953e+04
            Stop		  4.8624754080249753e+04
            Start		  5.0268855257176117e+04
            Stop		  5.1459284787040851e+04
            Start		  5.3103385963490349e+04
            Stop		  5.4293815494704380e+04
            Start		  5.5937916669118109e+04
            Stop		  5.7128346203323163e+04
            Start		  5.8772447374225958e+04
            Stop		  5.9962876912938133e+04
            Start		  6.1606978079003282e+04
            Stop		  6.2797407623546562e+04
            Start		  6.4441508783653931e+04
            Stop		  6.5631938335102139e+04
            Start		  6.7276039488387280e+04
            Stop		  6.8466469047517050e+04
            Start		  7.0110570193409047e+04
            Stop		  7.1300999760665698e+04
            Start		  7.2945100898912307e+04
            Stop		  7.4135530474390427e+04
            Start		  7.5779631605068935e+04
            Stop		  7.6970061188508276e+04
            Start		  7.8614162312022061e+04
            Stop		  7.9804591902819084e+04
            Start		  8.1448693019879996e+04
            Stop		  8.2639122617114263e+04
            Start		  8.4283223728711062e+04
            Stop		  8.5473653331186026e+04
            Strand		 23 70
            Strand		 23 71
            Strand		 24 36
            Strand		 24 37
            Strand		 24 38
            Strand		 24 39
            Strand		 24 40
            Strand		 24 41
            Start		  9.7951602050581823e+02
            Stop		  2.1699452532395912e+03
            Start		  3.8140463768032650e+03
            Stop		  5.0044759486313706e+03
            Start		  6.6485770790954393e+03
            Stop		  7.8390066637036243e+03
            Start		  9.4831077867405584e+03
            Stop		  1.0673537377908995e+04
            Start		  1.2317638495125113e+04
            Stop		  1.3508068092029729e+04
            Start		  1.5152169204513217e+04
            Stop		  1.6342598805811887e+04
            Start		  1.7986699914895089e+04
            Stop		  1.9177129519069040e+04
            Start		  2.0821230626229131e+04
            Stop		  2.2011660231635240e+04
            Start		  2.3655761338430897e+04
            Stop		  2.4846190943375284e+04
            Start		  2.6490292051378150e+04
            Stop		  2.7680721654190056e+04
            Start		  2.9324822764915811e+04
            Stop		  3.0515252364021093e+04
            Start		  3.2159353478862926e+04
            Stop		  3.3349783072853083e+04
            Start		  3.4993884193020516e+04
            Stop		  3.6184313780714605e+04
            Start		  3.7828414907180333e+04
            Stop		  3.9018844487676826e+04
            Start		  4.0662945621133957e+04
            Stop		  4.1853375193850457e+04
            Start		  4.3497476334682055e+04
            Stop		  4.4687905899380756e+04
            Start		  4.6332007047643070e+04
            Stop		  4.7522436604441245e+04
            Start		  4.9166537759861094e+04
            Stop		  5.0356967309226129e+04
            Start		  5.2001068471212937e+04
            Stop		  5.3191498013941629e+04
            Start		  5.4835599181613274e+04
            Stop		  5.6026028718797112e+04
            Start		  5.7670129891018601e+04
            Stop		  5.8860559423995743e+04
            Start		  6.0504660599429000e+04
            Stop		  6.1695090129725642e+04
            Start		  6.3339191306888242e+04
            Stop		  6.4529620836151647e+04
            Start		  6.6173722013481747e+04
            Stop		  6.7364151543407963e+04
            Start		  6.9008252719332930e+04
            Stop		  7.0198682251592501e+04
            Start		  7.1842783424597830e+04
            Stop		  7.3033212960762263e+04
            Start		  7.4677314129457984e+04
            Stop		  7.5867743670931144e+04
            Start		  7.7511844834112824e+04
            Stop		  7.8702274382069168e+04
            Start		  8.0346375538770677e+04
            Stop		  8.1536805094103824e+04
            Start		  8.3180906243639693e+04
            Stop		  8.4371335806923249e+04
            Start		  8.6015436948918723e+04
            Stop		  8.6400000000000000e+04
            Strand		 24 42
            Strand		 24 43
            Strand		 24 44
            Strand		 24 45
            Start		  0.0000000000000000e+00
            Stop		  3.9759453584115668e+01
            Start		  2.0073840337230965e+03
            Stop		  2.8742904409929984e+03
            Start		  4.8419158477147121e+03
            Stop		  5.7088207504164884e+03
            Start		  7.6764444114505131e+03
            Stop		  8.5433516939729489e+03
            Start		  1.0510977270589905e+04
            Stop		  1.1377882114782744e+04
            Start		  1.3345507745214385e+04
            Stop		  1.4212413052413802e+04
            Start		  1.6180038692541084e+04
            Stop		  1.7046943511556419e+04
            Start		  1.9014568945483126e+04
            Stop		  1.9881474448642901e+04
            Start		  2.1849100113079428e+04
            Stop		  2.2716004920882384e+04
            Start		  2.4683630292437290e+04
            Stop		  2.5550535858375933e+04
            Start		  2.7518161531944566e+04
            Stop		  2.8385066335475640e+04
            Start		  3.0352691686433012e+04
            Stop		  3.1219597273695672e+04
            Start		  3.3187222949161056e+04
            Stop		  3.4054127753006585e+04
            Start		  3.6021753094985892e+04
            Stop		  3.6888658692071396e+04
            Start		  3.8856284365037965e+04
            Stop		  3.9723189172690501e+04
            Start		  4.1690814507761206e+04
            Stop		  4.2557720112559320e+04
            Start		  4.4525345780116528e+04
            Stop		  4.5392250594060963e+04
            Start		  4.7359875921824758e+04
            Stop		  4.8226781534550668e+04
            Start		  5.0194407195076521e+04
            Stop		  5.1061312016589029e+04
            Start		  5.3028937336705581e+04
            Stop		  5.3895842957407927e+04
            Start		  5.5863468610618445e+04
            Stop		  5.6730373439621020e+04
            Start		  5.8697998752679108e+04
            Stop		  5.9564904380420041e+04
            Start		  6.1532530027341782e+04
            Stop		  6.2399434862441012e+04
            Start		  6.4367060170124831e+04
            Stop		  6.5233965802874467e+04
            Start		  6.7201591445641010e+04
            Stop		  6.8068496284378285e+04
            Start		  7.0036121589263887e+04
            Stop		  7.0903027224163947e+04
            Start		  7.2870652865637123e+04
            Stop		  7.3737557704918174e+04
            Start		  7.5705183010055582e+04
            Stop		  7.6572088643886294e+04
            Start		  7.8539714287156603e+04
            Stop		  7.9406619123789584e+04
            Start		  8.1374244432183055e+04
            Stop		  8.2241150061912384e+04
            Start		  8.4208775709761569e+04
            Stop		  8.5075680541011461e+04
            Strand		 24 46
            Start		  1.5349737618177946e+03
            Stop		  2.4018579899055035e+03
            Start		  4.3695037935178216e+03
            Stop		  5.2363890055728907e+03
            Start		  7.2040351770002117e+03
            Stop		  8.0709192756917910e+03
            Start		  1.0038563866490873e+04
            Stop		  1.0905450226180859e+04
            Start		  1.2873096592468381e+04
            Stop		  1.3739980635681923e+04
            Start		  1.5707627140656759e+04
            Stop		  1.6574511577308098e+04
            Start		  1.8542158009019182e+04
            Stop		  1.9409042035436829e+04
            Start		  2.1376688274174947e+04
            Stop		  2.2243572975664963e+04
            Start		  2.4211219427101889e+04
            Stop		  2.5078103449563732e+04
            Start		  2.7045749599811767e+04
            Stop		  2.7912634389039195e+04
            Start		  2.9880280846876380e+04
            Stop		  3.0747164867588410e+04
            Start		  3.2714810989612128e+04
            Stop		  3.3581695806239703e+04
            Start		  3.5549342268201231e+04
            Stop		  3.6416226285721466e+04
            Start		  3.8383872401398374e+04
            Stop		  3.9250757223520384e+04
            Start		  4.1218403690663064e+04
            Stop		  4.2085287702775138e+04
            Start		  4.4052933820843653e+04
            Stop		  4.4919818639828933e+04
            Start		  4.6887465113650156e+04
            Stop		  4.7754349118636375e+04
            Start		  4.9721995242717639e+04
            Stop		  5.0588880055179747e+04
            Start		  5.2556526536459227e+04
            Stop		  5.3423410533694791e+04
            Start		  5.5391056664810611e+04
            Stop		  5.6257941470050660e+04
            Start		  5.8225587958417622e+04
            Stop		  5.9092471948577389e+04
            Start		  6.1060118086012371e+04
            Stop		  6.1927002885101159e+04
            Start		  6.3894649379000322e+04
            Stop		  6.4761533363974115e+04
            Start		  6.6729179505743421e+04
            Stop		  6.7596064300991973e+04
            Start		  6.9563710797920998e+04
            Stop		  7.0430594780496351e+04
            Start		  7.2398240923803925e+04
            Stop		  7.3265125718248644e+04
            Start		  7.5232772215181802e+04
            Stop		  7.6099656198563491e+04
            Start		  7.8067302340324910e+04
            Stop		  7.8934187137163011e+04
            Start		  8.0901833631072921e+04
            Stop		  8.1768717618327879e+04
            Start		  8.3736363755718339e+04
            Stop		  8.4603248557740386e+04
            Strand		 24 47
            Strand		 24 48
            Strand		 24 49
            Strand		 24 50
            Start		  0.0000000000000000e+00
            Stop		  5.9520690096434191e+02
            Start		  2.2393065456010709e+03
            Stop		  3.4297373795946332e+03
            Start		  5.0738371254583471e+03
            Stop		  6.2642680914927550e+03
            Start		  7.9083678404610891e+03
            Stop		  9.0987987988452096e+03
            Start		  1.0742898554599680e+04
            Stop		  1.1933329505526452e+04
            Start		  1.3577429268487927e+04
            Stop		  1.4767860211467201e+04
            Start		  1.6411959981890326e+04
            Stop		  1.7602390916835539e+04
            Start		  1.9246490694637203e+04
            Stop		  2.0436921621814334e+04
            Start		  2.2081021406585536e+04
            Stop		  2.3271452326603991e+04
            Start		  2.4915552117627747e+04
            Stop		  2.6105983031413176e+04
            Start		  2.7750082827695838e+04
            Stop		  2.8940513736449742e+04
            Start		  3.0584613536764602e+04
            Stop		  3.1775044441911559e+04
            Start		  3.3419144244852716e+04
            Stop		  3.4609575147977899e+04
            Start		  3.6253674952021873e+04
            Stop		  3.7444105854801463e+04
            Start		  3.9088205658374194e+04
            Stop		  4.0278636562501764e+04
            Start		  4.1922736364047596e+04
            Stop		  4.3113167271159829e+04
            Start		  4.4757267069209855e+04
            Stop		  4.5947697980814708e+04
            Start		  4.7591797774051171e+04
            Stop		  4.8782228691461649e+04
            Start		  5.0426328478775860e+04
            Stop		  5.1616759403052427e+04
            Start		  5.3260859183593377e+04
            Stop		  5.4451290115497410e+04
            Start		  5.6095389888709084e+04
            Stop		  5.7285820828669493e+04
            Start		  5.8929920594315285e+04
            Stop		  6.0120351542409633e+04
            Start		  6.1764451300582783e+04
            Stop		  6.2954882256533951e+04
            Start		  6.4598982007653292e+04
            Stop		  6.5789412970841688e+04
            Start		  6.7433512715633391e+04
            Stop		  6.8623943685124061e+04
            Start		  7.0268043424589690e+04
            Stop		  7.1458474399173487e+04
            Start		  7.3102574134545954e+04
            Stop		  7.4293005112792569e+04
            Start		  7.5937104845482099e+04
            Stop		  7.7127535825802857e+04
            Start		  7.8771635557335088e+04
            Stop		  7.9962066538052648e+04
            Start		  8.1606166270001500e+04
            Stop		  8.2796597249423663e+04
            Start		  8.4440696983342481e+04
            Stop		  8.5631127959836231e+04
            Strand		 24 51
            Strand		 24 52
            Strand		 24 53
            Strand		 24 54
            Strand		 24 55
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 24 56
            Strand		 24 57
            Strand		 24 58
            Strand		 24 59
            Strand		 24 61
            Strand		 24 62
            Strand		 24 63
            Strand		 24 64
            Strand		 24 65
            Strand		 24 66
            Strand		 24 67
            Strand		 24 68
            Strand		 24 69
            Strand		 24 70
            Strand		 24 71
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 36
            Start		  3.4676930999684984e+01
            Stop		  1.2251018211926730e+03
            Start		  2.8692028848483974e+03
            Stop		  4.0596323737675584e+03
            Start		  5.7037335093742258e+03
            Stop		  6.8941630924744104e+03
            Start		  8.5382642175298824e+03
            Stop		  9.7286938064872429e+03
            Start		  1.1372794925549202e+04
            Stop		  1.2563224520684898e+04
            Start		  1.4207325634606135e+04
            Stop		  1.5397755234600503e+04
            Start		  1.7041856344659034e+04
            Stop		  1.8232285948052508e+04
            Start		  1.9876387055683048e+04
            Stop		  2.1066816660865625e+04
            Start		  2.2710917767607378e+04
            Stop		  2.3901347372893975e+04
            Start		  2.5545448480321866e+04
            Stop		  2.6735878084025750e+04
            Start		  2.8379979193681706e+04
            Stop		  2.9570408794188566e+04
            Start		  3.1214509907513733e+04
            Stop		  3.2404939503352547e+04
            Start		  3.4049040621624037e+04
            Stop		  3.5239470211531705e+04
            Start		  3.6883571335806424e+04
            Stop		  3.8074000918783284e+04
            Start		  3.9718102049851565e+04
            Stop		  4.0908531625205207e+04
            Start		  4.2552632763556059e+04
            Stop		  4.3743062330931905e+04
            Start		  4.5387163476731526e+04
            Stop		  4.6577593036128274e+04
            Start		  4.8221694189212634e+04
            Stop		  4.9412123740982512e+04
            Start		  5.1056224900864647e+04
            Stop		  5.2246654445697859e+04
            Start		  5.3890755611589113e+04
            Stop		  5.5081185150483623e+04
            Start		  5.6725286321328247e+04
            Stop		  5.7915715855546041e+04
            Start		  5.9559817030067592e+04
            Stop		  6.0750246561079235e+04
            Start		  6.2394347737836382e+04
            Stop		  6.3584777267256635e+04
            Start		  6.5228878444706526e+04
            Stop		  6.6419307974223382e+04
            Start		  6.8063409150789332e+04
            Stop		  6.9253838682090107e+04
            Start		  7.0897939856230543e+04
            Stop		  7.2088369390927735e+04
            Start		  7.3732470561204187e+04
            Stop		  7.4922900100764731e+04
            Start		  7.6567001265904561e+04
            Stop		  7.7757430811585727e+04
            Start		  7.9401531970538083e+04
            Stop		  8.0591961523332080e+04
            Start		  8.2236062675313951e+04
            Stop		  8.3426492235904589e+04
            Start		  8.5070593380435210e+04
            Stop		  8.6261023283927047e+04
            Strand		 25 37
            Strand		 25 38
            Strand		 25 39
            Strand		 25 40
            Strand		 25 41
            Strand		 25 42
            Strand		 25 43
            Strand		 25 44
            Strand		 25 45
            Strand		 25 46
            Start		  1.0625408519380926e+03
            Stop		  1.9294493133042383e+03
            Start		  3.8970722760533299e+03
            Stop		  4.7639809303465790e+03
            Start		  6.7316022457463032e+03
            Stop		  7.5985075128145063e+03
            Start		  9.5661327844108764e+03
            Stop		  1.0433038108540244e+04
            Start		  1.2400660649229570e+04
            Stop		  1.3267569148089318e+04
            Start		  1.5235193536913173e+04
            Stop		  1.6102099757022825e+04
            Start		  1.8069723575087581e+04
            Stop		  1.8936630716262855e+04
            Start		  2.0904256543146574e+04
            Stop		  2.1771161295922229e+04
            Start		  2.3738786112059897e+04
            Stop		  2.4605692235332906e+04
            Start		  2.6573317962267698e+04
            Stop		  2.7440222748113123e+04
            Start		  2.9407847913604524e+04
            Stop		  3.0274753686342432e+04
            Start		  3.2242379379734688e+04
            Stop		  3.3109284177355803e+04
            Start		  3.5076909458299422e+04
            Stop		  3.5943815116270613e+04
            Start		  3.7911440795799186e+04
            Stop		  3.8778345600669556e+04
            Start		  4.0745970916287661e+04
            Stop		  4.1612876540404985e+04
            Start		  4.3580502210964842e+04
            Stop		  4.4447407023094085e+04
            Start		  4.6415032345299027e+04
            Stop		  4.7281937963494696e+04
            Start		  4.9249563625894625e+04
            Stop		  5.0116468445901482e+04
            Start		  5.2084093765026482e+04
            Stop		  5.2950999386687719e+04
            Start		  5.4918625041293628e+04
            Stop		  5.5785529869040831e+04
            Start		  5.7753155182441194e+04
            Stop		  5.8620060809867617e+04
            Start		  6.0587686457786011e+04
            Stop		  6.1454591291992358e+04
            Start		  6.3422216600166168e+04
            Stop		  6.4289122232508591e+04
            Start		  6.6256747875806279e+04
            Stop		  6.7123652714133510e+04
            Start		  6.9091278019198784e+04
            Stop		  6.9958183654042412e+04
            Start		  7.1925809295523766e+04
            Stop		  7.2792714134937676e+04
            Start		  7.4760339439789634e+04
            Stop		  7.5627245074047984e+04
            Start		  7.7594870716813341e+04
            Stop		  7.8461775554095613e+04
            Start		  8.0429400861746864e+04
            Stop		  8.1296306492354852e+04
            Start		  8.3263932139277007e+04
            Stop		  8.4130836971579061e+04
            Start		  8.6098462284584777e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 47
            Start		  5.9013019008558706e+02
            Stop		  1.4570144227742176e+03
            Start		  3.4246609000983613e+03
            Stop		  4.2915451718339564e+03
            Start		  6.2591915605796239e+03
            Stop		  7.1260762312942488e+03
            Start		  9.0937223153463110e+03
            Stop		  9.9606064429647486e+03
            Start		  1.1928251212226176e+04
            Stop		  1.2795137400292073e+04
            Start		  1.4762783731149781e+04
            Stop		  1.5629667787145603e+04
            Start		  1.7597314413860782e+04
            Stop		  1.8464198729537889e+04
            Start		  2.0431845148188968e+04
            Stop		  2.1298729179900900e+04
            Start		  2.3266375457613769e+04
            Stop		  2.4133260120048450e+04
            Start		  2.6100906566837384e+04
            Stop		  2.6967790591192348e+04
            Start		  2.8935436754324503e+04
            Stop		  2.9802321530425204e+04
            Start		  3.1769967987160362e+04
            Stop		  3.2636852007859910e+04
            Start		  3.4604498134920323e+04
            Stop		  3.5471382946227277e+04
            Start		  3.7439029408922303e+04
            Stop		  3.8305913425149251e+04
            Start		  4.0273559543852985e+04
            Stop		  4.1140444362681737e+04
            Start		  4.3108090831634327e+04
            Stop		  4.3974974841605283e+04
            Start		  4.5942620962377347e+04
            Stop		  4.6809505778457664e+04
            Start		  4.8777152254641318e+04
            Stop		  4.9644036257079999e+04
            Start		  5.1611682383802312e+04
            Stop		  5.2478567193522191e+04
            Start		  5.4446213677236527e+04
            Stop		  5.5313097671984084e+04
            Start		  5.7280743805460654e+04
            Stop		  5.8147628608356637e+04
            Start		  6.0115275098784434e+04
            Stop		  6.0982159086956097e+04
            Start		  6.2949805226140663e+04
            Stop		  6.3816690023611511e+04
            Start		  6.5784336518831260e+04
            Stop		  6.6651220502665354e+04
            Start		  6.8618866645294896e+04
            Stop		  6.9485751439906962e+04
            Start		  7.1453397937183705e+04
            Stop		  7.2320281919667308e+04
            Start		  7.4287928062804218e+04
            Stop		  7.5154812857696597e+04
            Start		  7.7122459353942468e+04
            Stop		  7.7989343338297505e+04
            Start		  7.9956989478889009e+04
            Stop		  8.0823874277179217e+04
            Start		  8.2791520769484909e+04
            Stop		  8.3658404758610355e+04
            Start		  8.5626050894034648e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 48
            Strand		 25 49
            Strand		 25 50
            Strand		 25 51
            Start		  1.2944637122123322e+03
            Stop		  2.4848939568760115e+03
            Start		  4.1289936297949089e+03
            Stop		  5.3194245175443184e+03
            Start		  6.9635242680553474e+03
            Stop		  8.1539552300054384e+03
            Start		  9.7980549832811994e+03
            Stop		  1.0988485936711775e+04
            Start		  1.2632585697234463e+04
            Stop		  1.3823016642892802e+04
            Start		  1.5467116410821176e+04
            Stop		  1.6657547348432192e+04
            Start		  1.8301647123803959e+04
            Stop		  1.9492078053519243e+04
            Start		  2.1136177836032242e+04
            Stop		  2.2326608758348986e+04
            Start		  2.3970708547386083e+04
            Stop		  2.5161139463128333e+04
            Start		  2.6805239257783840e+04
            Stop		  2.7995670168066434e+04
            Start		  2.9639769967185792e+04
            Stop		  3.0830200873365498e+04
            Start		  3.2474300675596020e+04
            Stop		  3.3664731579211904e+04
            Start		  3.5308831383062075e+04
            Stop		  3.6499262285768018e+04
            Start		  3.8143362089672999e+04
            Stop		  3.9333792993165072e+04
            Start		  4.0977892795555403e+04
            Stop		  4.2168323701497429e+04
            Start		  4.3812423500867859e+04
            Stop		  4.5002854410818385e+04
            Start		  4.6646954205793954e+04
            Stop		  4.7837385121137857e+04
            Start		  4.9481484910534338e+04
            Stop		  5.0671915832422033e+04
            Start		  5.2316015615297700e+04
            Stop		  5.3506446544594633e+04
            Start		  5.5150546320291825e+04
            Stop		  5.6340977257540559e+04
            Start		  5.7985077025714330e+04
            Stop		  5.9175507971110725e+04
            Start		  6.0819607731744036e+04
            Stop		  6.2010038685128646e+04
            Start		  6.3654138438533198e+04
            Stop		  6.4844569399398228e+04
            Start		  6.6488669146200657e+04
            Stop		  6.7679100113712368e+04
            Start		  6.9323199854826744e+04
            Stop		  7.0513630827862085e+04
            Start		  7.2157730564449754e+04
            Stop		  7.3348161541645532e+04
            Start		  7.4992261275064215e+04
            Stop		  7.6182692254877053e+04
            Start		  7.7826791986621130e+04
            Stop		  7.9017222967395282e+04
            Start		  8.0661322699030206e+04
            Stop		  8.1851753679070069e+04
            Start		  8.3495853412163749e+04
            Stop		  8.4686284389808425e+04
            Start		  8.6330384125862285e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 52
            Strand		 25 53
            Strand		 25 54
            Strand		 25 55
            Strand		 25 56
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 57
            Strand		 25 58
            Strand		 25 59
            Strand		 25 60
            Strand		 25 62
            Strand		 25 63
            Strand		 25 64
            Strand		 25 65
            Strand		 25 66
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 67
            Strand		 25 68
            Strand		 25 69
            Strand		 25 70
            Strand		 25 71
            Strand		 26 36
            Strand		 26 37
            Start		  0.0000000000000000e+00
            Stop		  2.8025410635535832e+02
            Start		  1.9243630253600761e+03
            Stop		  3.1147889079529687e+03
            Start		  4.7588899712714228e+03
            Stop		  5.9493195171269199e+03
            Start		  7.5934206475153296e+03
            Stop		  8.7838502352698270e+03
            Start		  1.0427951356129659e+04
            Stop		  1.1618380949299322e+04
            Start		  1.3262482064808029e+04
            Stop		  1.4452911663337924e+04
            Start		  1.6097012774531326e+04
            Stop		  1.7287442376964696e+04
            Start		  1.8931543485237322e+04
            Stop		  2.0121973090008560e+04
            Start		  2.1766074196871934e+04
            Stop		  2.2956503802312734e+04
            Start		  2.4600604909337526e+04
            Stop		  2.5791034513753439e+04
            Start		  2.7435135622500235e+04
            Stop		  2.8625565224244696e+04
            Start		  3.0269666336195554e+04
            Stop		  3.1460095933742243e+04
            Start		  3.3104197050235598e+04
            Stop		  3.4294626642245428e+04
            Start		  3.5938727764417265e+04
            Stop		  3.7129157349797249e+04
            Start		  3.8773258478531221e+04
            Stop		  3.9963688056482468e+04
            Start		  4.1607789192371129e+04
            Stop		  4.2798218762423967e+04
            Start		  4.4442319905742588e+04
            Stop		  4.5632749467777205e+04
            Start		  4.7276850618471770e+04
            Stop		  4.8467280172723447e+04
            Start		  5.0111381330412994e+04
            Stop		  5.1301810877461947e+04
            Start		  5.2945912041455122e+04
            Stop		  5.4136341582200992e+04
            Start		  5.5780442751526512e+04
            Stop		  5.6970872287148843e+04
            Start		  5.8614973460597990e+04
            Stop		  5.9805402992504656e+04
            Start		  6.1449504168684383e+04
            Stop		  6.2639933698449640e+04
            Start		  6.4284034875843558e+04
            Stop		  6.5474464405139210e+04
            Start		  6.7118565582174197e+04
            Stop		  6.8308995112695993e+04
            Start		  6.9953096287811190e+04
            Stop		  7.1143525821204676e+04
            Start		  7.2787626992919919e+04
            Stop		  7.3978056530708098e+04
            Start		  7.5622157697688861e+04
            Stop		  7.6812587241205503e+04
            Start		  7.8456688402321393e+04
            Stop		  7.9647117952652508e+04
            Start		  8.1291219107026787e+04
            Stop		  8.2481648664962966e+04
            Start		  8.4125749812011083e+04
            Stop		  8.5316179378013025e+04
            Strand		 26 38
            Strand		 26 39
            Strand		 26 40
            Strand		 26 41
            Strand		 26 42
            Start		  0.0000000000000000e+00
            Stop		  5.1217158422224611e+02
            Start		  2.4798173310589686e+03
            Stop		  3.3467015806152449e+03
            Start		  5.3143476500143643e+03
            Stop		  6.1812326155708979e+03
            Start		  8.1488787461656812e+03
            Stop		  9.0157628584063823e+03
            Start		  1.0983407529980022e+04
            Stop		  1.1850293811826750e+04
            Start		  1.3817940161792452e+04
            Stop		  1.4684824210983430e+04
            Start		  1.6652470771208984e+04
            Stop		  1.7519355152933931e+04
            Start		  1.9487001578581807e+04
            Stop		  2.0353885607522287e+04
            Start		  2.2321531863907308e+04
            Stop		  2.3188416547706518e+04
            Start		  2.5156062996945831e+04
            Stop		  2.6022947020343501e+04
            Start		  2.7990593176399772e+04
            Stop		  2.8857477959699027e+04
            Start		  3.0825124416997271e+04
            Stop		  3.1692008437729499e+04
            Start		  3.3659654562034935e+04
            Stop		  3.4526539376238958e+04
            Start		  3.6494185838547040e+04
            Stop		  3.7361069855452348e+04
            Start		  3.9328715972544815e+04
            Stop		  4.0195600793116209e+04
            Start		  4.2163247261142904e+04
            Stop		  4.3030131272206694e+04
            Start		  4.4997777391586409e+04
            Stop		  4.5864662209156224e+04
            Start		  4.7832308684149910e+04
            Stop		  4.8699192687868235e+04
            Start		  5.0666838813261260e+04
            Stop		  5.1533723624356324e+04
            Start		  5.3501370106861294e+04
            Stop		  5.4368254102840292e+04
            Start		  5.6335900235150322e+04
            Stop		  5.7202785039199502e+04
            Start		  5.9170431528621375e+04
            Stop		  6.0037315517757896e+04
            Start		  6.2004961656098181e+04
            Stop		  6.2871846454343045e+04
            Start		  6.4839492948939500e+04
            Stop		  6.5706376933302628e+04
            Start		  6.7674023075542776e+04
            Stop		  6.8540907870429248e+04
            Start		  7.0508554367575329e+04
            Stop		  7.1375438350059369e+04
            Start		  7.3343084493325048e+04
            Stop		  7.4209969287948887e+04
            Start		  7.6177615784580426e+04
            Stop		  7.7044499768406575e+04
            Start		  7.9012145909621584e+04
            Stop		  7.9879030707148035e+04
            Start		  8.1846677200289312e+04
            Stop		  8.2713561188447886e+04
            Start		  8.4681207324882169e+04
            Stop		  8.5548092127982294e+04
            Strand		 26 43
            Strand		 26 44
            Strand		 26 45
            Strand		 26 46
            Strand		 26 47
            Start		  1.1769799500435502e+02
            Stop		  9.8460303674128727e+02
            Start		  2.9522277599013501e+03
            Stop		  3.8191340330107814e+03
            Start		  5.7867594182125958e+03
            Stop		  6.6536643266283791e+03
            Start		  8.6212880324713715e+03
            Stop		  9.4881952714053514e+03
            Start		  1.1455820840987944e+04
            Stop		  1.2322725686558388e+04
            Start		  1.4290351348353575e+04
            Stop		  1.5157256624357358e+04
            Start		  1.7124882262737094e+04
            Stop		  1.7991787081654031e+04
            Start		  1.9959412526334145e+04
            Stop		  2.0826318018827140e+04
            Start		  2.2793943683008794e+04
            Stop		  2.3660848490533208e+04
            Start		  2.5628473865781161e+04
            Stop		  2.6495379428141670e+04
            Start		  2.8463005101589952e+04
            Stop		  2.9329909905162869e+04
            Start		  3.1297535257121242e+04
            Stop		  3.2164440843522021e+04
            Start		  3.4132066518554704e+04
            Stop		  3.4998971322907848e+04
            Start		  3.6966596664668876e+04
            Stop		  3.7833502262114205e+04
            Start		  3.9801127934255950e+04
            Stop		  4.0668032742844342e+04
            Start		  4.2635658077058943e+04
            Stop		  4.3502563682833003e+04
            Start		  4.5470189349265478e+04
            Stop		  4.6337094164428083e+04
            Start		  4.8304719491026452e+04
            Stop		  4.9171625104995219e+04
            Start		  5.1139250764275101e+04
            Stop		  5.2006155587081754e+04
            Start		  5.3973780905985681e+04
            Stop		  5.4840686527922277e+04
            Start		  5.6808312179976681e+04
            Stop		  5.7675217010126144e+04
            Start		  5.9642842322155011e+04
            Stop		  6.0509747950887249e+04
            Start		  6.2477373596942045e+04
            Stop		  6.3344278432841980e+04
            Start		  6.5311903739865571e+04
            Stop		  6.6178809373184558e+04
            Start		  6.8146435015523675e+04
            Stop		  6.9013339854576188e+04
            Start		  7.0980965159287807e+04
            Stop		  7.1847870794233779e+04
            Start		  7.3815496435793524e+04
            Stop		  7.4682401274849224e+04
            Start		  7.6650026580330246e+04
            Stop		  7.7516932213674329e+04
            Start		  7.9484557857530570e+04
            Stop		  8.0351462693436290e+04
            Start		  8.2319088002632037e+04
            Stop		  8.3185993631426027e+04
            Start		  8.5153619280259212e+04
            Stop		  8.6020524110405735e+04
            Strand		 26 48
            Strand		 26 49
            Strand		 26 50
            Strand		 26 51
            Strand		 26 52
            Start		  3.4961924210310229e+02
            Stop		  1.5400504500248767e+03
            Start		  3.1841500999071723e+03
            Stop		  4.3745809485507289e+03
            Start		  6.0186806967379343e+03
            Stop		  7.2091116608041830e+03
            Start		  8.8532114118805930e+03
            Stop		  1.0043642367823950e+04
            Start		  1.1687742125936929e+04
            Stop		  1.2878173074247616e+04
            Start		  1.4522272839684865e+04
            Stop		  1.5712703779978359e+04
            Start		  1.7356803552886544e+04
            Stop		  1.8547234485195462e+04
            Start		  2.0191334265381454e+04
            Stop		  2.1381765190088354e+04
            Start		  2.3025864977037840e+04
            Stop		  2.4216295894861189e+04
            Start		  2.5860395687760833e+04
            Stop		  2.7050826599723383e+04
            Start		  2.8694926397496452e+04
            Stop		  2.9885357304880454e+04
            Start		  3.1529457106234095e+04
            Stop		  3.2719888010525032e+04
            Start		  3.4363987814006970e+04
            Stop		  3.5554418716828317e+04
            Start		  3.7198518520890626e+04
            Stop		  3.8388949423932660e+04
            Start		  4.0033049226999683e+04
            Stop		  4.1223480131945238e+04
            Start		  4.2867579932482811e+04
            Stop		  4.4058010840933370e+04
            Start		  4.5702110637516074e+04
            Stop		  4.6892541550921640e+04
            Start		  4.8536641342295385e+04
            Stop		  4.9727072261890666e+04
            Start		  5.1371172047027772e+04
            Stop		  5.2561602973778077e+04
            Start		  5.4205702751922334e+04
            Stop		  5.5396133686481262e+04
            Start		  5.7040233457181050e+04
            Stop		  5.8230664399861751e+04
            Start		  5.9874764162990003e+04
            Stop		  6.1065195113751397e+04
            Start		  6.2709294869511054e+04
            Stop		  6.3899725827959730e+04
            Start		  6.5543825576874820e+04
            Stop		  6.6734256542282354e+04
            Start		  6.8378356285174959e+04
            Stop		  6.9568787256509851e+04
            Start		  7.1212886994464105e+04
            Stop		  7.2403317970437012e+04
            Start		  7.4047417704751380e+04
            Stop		  7.5237848683871765e+04
            Start		  7.6881948416002211e+04
            Stop		  7.8072379396643912e+04
            Start		  7.9716479128139705e+04
            Stop		  8.0906910108612094e+04
            Start		  8.2551009841048042e+04
            Stop		  8.3741440819670475e+04
            Start		  8.5385540554577659e+04
            Stop		  8.6400000000000000e+04
            Strand		 26 53
            Strand		 26 54
            Strand		 26 55
            Strand		 26 56
            Strand		 26 57
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 26 58
            Strand		 26 59
            Strand		 26 60
            Strand		 26 61
            Strand		 26 63
            Strand		 26 64
            Strand		 26 65
            Strand		 26 66
            Strand		 26 67
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 26 68
            Strand		 26 69
            Strand		 26 70
            Strand		 26 71
            Strand		 27 36
            Strand		 27 37
            Strand		 27 38
            Start		  9.7951602050581721e+02
            Stop		  2.1699452532395944e+03
            Start		  3.8140463768032701e+03
            Stop		  5.0044759486313687e+03
            Start		  6.6485770790954466e+03
            Stop		  7.8390066637036243e+03
            Start		  9.4831077867405620e+03
            Stop		  1.0673537377908995e+04
            Start		  1.2317638495125113e+04
            Stop		  1.3508068092029731e+04
            Start		  1.5152169204513219e+04
            Stop		  1.6342598805811891e+04
            Start		  1.7986699914895096e+04
            Stop		  1.9177129519069036e+04
            Start		  2.0821230626229120e+04
            Stop		  2.2011660231635240e+04
            Start		  2.3655761338430901e+04
            Stop		  2.4846190943375277e+04
            Start		  2.6490292051378146e+04
            Stop		  2.7680721654190056e+04
            Start		  2.9324822764915814e+04
            Stop		  3.0515252364021097e+04
            Start		  3.2159353478862940e+04
            Stop		  3.3349783072853083e+04
            Start		  3.4993884193020524e+04
            Stop		  3.6184313780714612e+04
            Start		  3.7828414907180311e+04
            Stop		  3.9018844487676834e+04
            Start		  4.0662945621133949e+04
            Stop		  4.1853375193850450e+04
            Start		  4.3497476334682062e+04
            Stop		  4.4687905899380741e+04
            Start		  4.6332007047643063e+04
            Stop		  4.7522436604441231e+04
            Start		  4.9166537759861087e+04
            Stop		  5.0356967309226122e+04
            Start		  5.2001068471212930e+04
            Stop		  5.3191498013941644e+04
            Start		  5.4835599181613281e+04
            Stop		  5.6026028718797097e+04
            Start		  5.7670129891018594e+04
            Stop		  5.8860559423995728e+04
            Start		  6.0504660599429000e+04
            Stop		  6.1695090129725664e+04
            Start		  6.3339191306888235e+04
            Stop		  6.4529620836151618e+04
            Start		  6.6173722013481747e+04
            Stop		  6.7364151543407977e+04
            Start		  6.9008252719332959e+04
            Stop		  7.0198682251592487e+04
            Start		  7.1842783424597816e+04
            Stop		  7.3033212960762234e+04
            Start		  7.4677314129457984e+04
            Stop		  7.5867743670931115e+04
            Start		  7.7511844834112824e+04
            Stop		  7.8702274382069183e+04
            Start		  8.0346375538770691e+04
            Stop		  8.1536805094103838e+04
            Start		  8.3180906243639693e+04
            Stop		  8.4371335806923234e+04
            Start		  8.6015436948918723e+04
            Stop		  8.6400000000000000e+04
            Strand		 27 39
            Strand		 27 40
            Strand		 27 41
            Strand		 27 42
            Start		  0.0000000000000000e+00
            Stop		  3.9759453584121239e+01
            Start		  2.0073840337230961e+03
            Stop		  2.8742904409930006e+03
            Start		  4.8419158477147084e+03
            Stop		  5.7088207504164920e+03
            Start		  7.6764444114505122e+03
            Stop		  8.5433516939729579e+03
            Start		  1.0510977270589898e+04
            Stop		  1.1377882114782753e+04
            Start		  1.3345507745214387e+04
            Stop		  1.4212413052413813e+04
            Start		  1.6180038692541086e+04
            Stop		  1.7046943511556427e+04
            Start		  1.9014568945483126e+04
            Stop		  1.9881474448642904e+04
            Start		  2.1849100113079428e+04
            Stop		  2.2716004920882398e+04
            Start		  2.4683630292437290e+04
            Stop		  2.5550535858375937e+04
            Start		  2.7518161531944566e+04
            Stop		  2.8385066335475665e+04
            Start		  3.0352691686433005e+04
            Stop		  3.1219597273695686e+04
            Start		  3.3187222949161056e+04
            Stop		  3.4054127753006615e+04
            Start		  3.6021753094985899e+04
            Stop		  3.6888658692071433e+04
            Start		  3.8856284365037958e+04
            Stop		  3.9723189172690523e+04
            Start		  4.1690814507761213e+04
            Stop		  4.2557720112559342e+04
            Start		  4.4525345780116520e+04
            Stop		  4.5392250594060992e+04
            Start		  4.7359875921824758e+04
            Stop		  4.8226781534550690e+04
            Start		  5.0194407195076521e+04
            Stop		  5.1061312016589058e+04
            Start		  5.3028937336705574e+04
            Stop		  5.3895842957407964e+04
            Start		  5.5863468610618438e+04
            Stop		  5.6730373439621042e+04
            Start		  5.8697998752679116e+04
            Stop		  5.9564904380420063e+04
            Start		  6.1532530027341774e+04
            Stop		  6.2399434862441049e+04
            Start		  6.4367060170124838e+04
            Stop		  6.5233965802874474e+04
            Start		  6.7201591445641010e+04
            Stop		  6.8068496284378329e+04
            Start		  7.0036121589263916e+04
            Stop		  7.0903027224163961e+04
            Start		  7.2870652865637137e+04
            Stop		  7.3737557704918203e+04
            Start		  7.5705183010055582e+04
            Stop		  7.6572088643886324e+04
            Start		  7.8539714287156618e+04
            Stop		  7.9406619123789613e+04
            Start		  8.1374244432183070e+04
            Stop		  8.2241150061912442e+04
            Start		  8.4208775709761569e+04
            Stop		  8.5075680541011476e+04
            Strand		 27 43
            Start		  1.5349737618177967e+03
            Stop		  2.4018579899055030e+03
            Start		  4.3695037935178207e+03
            Stop		  5.2363890055728843e+03
            Start		  7.2040351770002180e+03
            Stop		  8.0709192756917864e+03
            Start		  1.0038563866490880e+04
            Stop		  1.0905450226180865e+04
            Start		  1.2873096592468382e+04
            Stop		  1.3739980635681932e+04
            Start		  1.5707627140656761e+04
            Stop		  1.6574511577308098e+04
            Start		  1.8542158009019189e+04
            Stop		  1.9409042035436825e+04
            Start		  2.1376688274174947e+04
            Stop		  2.2243572975664974e+04
            Start		  2.4211219427101896e+04
            Stop		  2.5078103449563721e+04
            Start		  2.7045749599811770e+04
            Stop		  2.7912634389039195e+04
            Start		  2.9880280846876405e+04
            Stop		  3.0747164867588406e+04
            Start		  3.2714810989612142e+04
            Stop		  3.3581695806239695e+04
            Start		  3.5549342268201231e+04
            Stop		  3.6416226285721459e+04
            Start		  3.8383872401398381e+04
            Stop		  3.9250757223520384e+04
            Start		  4.1218403690663072e+04
            Stop		  4.2085287702775138e+04
            Start		  4.4052933820843660e+04
            Stop		  4.4919818639828933e+04
            Start		  4.6887465113650193e+04
            Stop		  4.7754349118636375e+04
            Start		  4.9721995242717654e+04
            Stop		  5.0588880055179732e+04
            Start		  5.2556526536459241e+04
            Stop		  5.3423410533694791e+04
            Start		  5.5391056664810625e+04
            Stop		  5.6257941470050660e+04
            Start		  5.8225587958417644e+04
            Stop		  5.9092471948577389e+04
            Start		  6.1060118086012393e+04
            Stop		  6.1927002885101159e+04
            Start		  6.3894649379000351e+04
            Stop		  6.4761533363974115e+04
            Start		  6.6729179505743479e+04
            Stop		  6.7596064300991988e+04
            Start		  6.9563710797921041e+04
            Stop		  7.0430594780496351e+04
            Start		  7.2398240923803940e+04
            Stop		  7.3265125718248630e+04
            Start		  7.5232772215181831e+04
            Stop		  7.6099656198563491e+04
            Start		  7.8067302340324983e+04
            Stop		  7.8934187137163011e+04
            Start		  8.0901833631072965e+04
            Stop		  8.1768717618327864e+04
            Start		  8.3736363755718383e+04
            Stop		  8.4603248557740386e+04
            Strand		 27 44
            Strand		 27 45
            Strand		 27 46
            Strand		 27 47
            Strand		 27 48
            Strand		 27 49
            Strand		 27 50
            Strand		 27 51
            Strand		 27 52
            Strand		 27 53
            Start		  0.0000000000000000e+00
            Stop		  5.9520690096434316e+02
            Start		  2.2393065456010745e+03
            Stop		  3.4297373795946310e+03
            Start		  5.0738371254583517e+03
            Stop		  6.2642680914927614e+03
            Start		  7.9083678404610873e+03
            Stop		  9.0987987988452132e+03
            Start		  1.0742898554599680e+04
            Stop		  1.1933329505526450e+04
            Start		  1.3577429268487936e+04
            Stop		  1.4767860211467209e+04
            Start		  1.6411959981890330e+04
            Stop		  1.7602390916835542e+04
            Start		  1.9246490694637214e+04
            Stop		  2.0436921621814356e+04
            Start		  2.2081021406585543e+04
            Stop		  2.3271452326604005e+04
            Start		  2.4915552117627754e+04
            Stop		  2.6105983031413194e+04
            Start		  2.7750082827695853e+04
            Stop		  2.8940513736449750e+04
            Start		  3.0584613536764613e+04
            Stop		  3.1775044441911574e+04
            Start		  3.3419144244852716e+04
            Stop		  3.4609575147977928e+04
            Start		  3.6253674952021887e+04
            Stop		  3.7444105854801484e+04
            Start		  3.9088205658374201e+04
            Stop		  4.0278636562501772e+04
            Start		  4.1922736364047596e+04
            Stop		  4.3113167271159859e+04
            Start		  4.4757267069209862e+04
            Stop		  4.5947697980814730e+04
            Start		  4.7591797774051200e+04
            Stop		  4.8782228691461678e+04
            Start		  5.0426328478775889e+04
            Stop		  5.1616759403052456e+04
            Start		  5.3260859183593391e+04
            Stop		  5.4451290115497439e+04
            Start		  5.6095389888709120e+04
            Stop		  5.7285820828669537e+04
            Start		  5.8929920594315321e+04
            Stop		  6.0120351542409669e+04
            Start		  6.1764451300582783e+04
            Stop		  6.2954882256533965e+04
            Start		  6.4598982007653321e+04
            Stop		  6.5789412970841746e+04
            Start		  6.7433512715633420e+04
            Stop		  6.8623943685124119e+04
            Start		  7.0268043424589705e+04
            Stop		  7.1458474399173545e+04
            Start		  7.3102574134545983e+04
            Stop		  7.4293005112792627e+04
            Start		  7.5937104845482128e+04
            Stop		  7.7127535825802901e+04
            Start		  7.8771635557335088e+04
            Stop		  7.9962066538052663e+04
            Start		  8.1606166270001529e+04
            Stop		  8.2796597249423692e+04
            Start		  8.4440696983342510e+04
            Stop		  8.5631127959836260e+04
            Strand		 27 54
            Strand		 27 55
            Strand		 27 56
            Strand		 27 57
            Strand		 27 58
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 27 59
            Strand		 27 60
            Strand		 27 61
            Strand		 27 62
            Strand		 27 64
            Strand		 27 65
            Strand		 27 66
            Strand		 27 67
            Strand		 27 68
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 27 69
            Strand		 27 70
            Strand		 27 71
            Strand		 28 36
            Strand		 28 37
            Strand		 28 38
            Strand		 28 39
            Start		  3.4676930999688722e+01
            Stop		  1.2251018211926751e+03
            Start		  2.8692028848484101e+03
            Stop		  4.0596323737675566e+03
            Start		  5.7037335093742367e+03
            Stop		  6.8941630924744095e+03
            Start		  8.5382642175298824e+03
            Stop		  9.7286938064872393e+03
            Start		  1.1372794925549211e+04
            Stop		  1.2563224520684897e+04
            Start		  1.4207325634606137e+04
            Stop		  1.5397755234600505e+04
            Start		  1.7041856344659023e+04
            Stop		  1.8232285948052497e+04
            Start		  1.9876387055683048e+04
            Stop		  2.1066816660865628e+04
            Start		  2.2710917767607356e+04
            Stop		  2.3901347372893961e+04
            Start		  2.5545448480321847e+04
            Stop		  2.6735878084025750e+04
            Start		  2.8379979193681702e+04
            Stop		  2.9570408794188552e+04
            Start		  3.1214509907513730e+04
            Stop		  3.2404939503352536e+04
            Start		  3.4049040621624023e+04
            Stop		  3.5239470211531690e+04
            Start		  3.6883571335806424e+04
            Stop		  3.8074000918783255e+04
            Start		  3.9718102049851543e+04
            Stop		  4.0908531625205200e+04
            Start		  4.2552632763556052e+04
            Stop		  4.3743062330931891e+04
            Start		  4.5387163476731483e+04
            Stop		  4.6577593036128252e+04
            Start		  4.8221694189212627e+04
            Stop		  4.9412123740982504e+04
            Start		  5.1056224900864632e+04
            Stop		  5.2246654445697823e+04
            Start		  5.3890755611589091e+04
            Stop		  5.5081185150483609e+04
            Start		  5.6725286321328254e+04
            Stop		  5.7915715855546026e+04
            Start		  5.9559817030067563e+04
            Stop		  6.0750246561079228e+04
            Start		  6.2394347737836360e+04
            Stop		  6.3584777267256606e+04
            Start		  6.5228878444706512e+04
            Stop		  6.6419307974223397e+04
            Start		  6.8063409150789303e+04
            Stop		  6.9253838682090078e+04
            Start		  7.0897939856230543e+04
            Stop		  7.2088369390927706e+04
            Start		  7.3732470561204143e+04
            Stop		  7.4922900100764760e+04
            Start		  7.6567001265904561e+04
            Stop		  7.7757430811585713e+04
            Start		  7.9401531970538039e+04
            Stop		  8.0591961523332066e+04
            Start		  8.2236062675313937e+04
            Stop		  8.3426492235904559e+04
            Start		  8.5070593380435137e+04
            Stop		  8.6261023283927061e+04
            Strand		 28 40
            Strand		 28 41
            Strand		 28 42
            Strand		 28 43
            Start		  1.0625408519380935e+03
            Stop		  1.9294493133042342e+03
            Start		  3.8970722760533290e+03
            Stop		  4.7639809303465763e+03
            Start		  6.7316022457463059e+03
            Stop		  7.5985075128145027e+03
            Start		  9.5661327844108782e+03
            Stop		  1.0433038108540246e+04
            Start		  1.2400660649229567e+04
            Stop		  1.3267569148089306e+04
            Start		  1.5235193536913177e+04
            Stop		  1.6102099757022808e+04
            Start		  1.8069723575087577e+04
            Stop		  1.8936630716262851e+04
            Start		  2.0904256543146566e+04
            Stop		  2.1771161295922215e+04
            Start		  2.3738786112059886e+04
            Stop		  2.4605692235332896e+04
            Start		  2.6573317962267683e+04
            Stop		  2.7440222748113109e+04
            Start		  2.9407847913604510e+04
            Stop		  3.0274753686342410e+04
            Start		  3.2242379379734670e+04
            Stop		  3.3109284177355781e+04
            Start		  3.5076909458299415e+04
            Stop		  3.5943815116270605e+04
            Start		  3.7911440795799186e+04
            Stop		  3.8778345600669527e+04
            Start		  4.0745970916287646e+04
            Stop		  4.1612876540404955e+04
            Start		  4.3580502210964834e+04
            Stop		  4.4447407023094049e+04
            Start		  4.6415032345299005e+04
            Stop		  4.7281937963494674e+04
            Start		  4.9249563625894611e+04
            Stop		  5.0116468445901468e+04
            Start		  5.2084093765026468e+04
            Stop		  5.2950999386687690e+04
            Start		  5.4918625041293621e+04
            Stop		  5.5785529869040802e+04
            Start		  5.7753155182441194e+04
            Stop		  5.8620060809867580e+04
            Start		  6.0587686457785996e+04
            Stop		  6.1454591291992336e+04
            Start		  6.3422216600166161e+04
            Stop		  6.4289122232508591e+04
            Start		  6.6256747875806250e+04
            Stop		  6.7123652714133495e+04
            Start		  6.9091278019198784e+04
            Stop		  6.9958183654042383e+04
            Start		  7.1925809295523766e+04
            Stop		  7.2792714134937632e+04
            Start		  7.4760339439789634e+04
            Stop		  7.5627245074047969e+04
            Start		  7.7594870716813326e+04
            Stop		  7.8461775554095555e+04
            Start		  8.0429400861746835e+04
            Stop		  8.1296306492354852e+04
            Start		  8.3263932139276963e+04
            Stop		  8.4130836971579032e+04
            Start		  8.6098462284584733e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 44
            Start		  5.9013019008558967e+02
            Stop		  1.4570144227742105e+03
            Start		  3.4246609000983594e+03
            Stop		  4.2915451718339409e+03
            Start		  6.2591915605796185e+03
            Stop		  7.1260762312942416e+03
            Start		  9.0937223153463019e+03
            Stop		  9.9606064429647304e+03
            Start		  1.1928251212226176e+04
            Stop		  1.2795137400292057e+04
            Start		  1.4762783731149768e+04
            Stop		  1.5629667787145587e+04
            Start		  1.7597314413860768e+04
            Stop		  1.8464198729537871e+04
            Start		  2.0431845148188964e+04
            Stop		  2.1298729179900885e+04
            Start		  2.3266375457613762e+04
            Stop		  2.4133260120048428e+04
            Start		  2.6100906566837377e+04
            Stop		  2.6967790591192323e+04
            Start		  2.8935436754324492e+04
            Stop		  2.9802321530425183e+04
            Start		  3.1769967987160351e+04
            Stop		  3.2636852007859874e+04
            Start		  3.4604498134920286e+04
            Stop		  3.5471382946227255e+04
            Start		  3.7439029408922273e+04
            Stop		  3.8305913425149221e+04
            Start		  4.0273559543852964e+04
            Stop		  4.1140444362681694e+04
            Start		  4.3108090831634298e+04
            Stop		  4.3974974841605239e+04
            Start		  4.5942620962377325e+04
            Stop		  4.6809505778457620e+04
            Start		  4.8777152254641289e+04
            Stop		  4.9644036257079963e+04
            Start		  5.1611682383802276e+04
            Stop		  5.2478567193522140e+04
            Start		  5.4446213677236497e+04
            Stop		  5.5313097671984040e+04
            Start		  5.7280743805460617e+04
            Stop		  5.8147628608356594e+04
            Start		  6.0115275098784419e+04
            Stop		  6.0982159086956039e+04
            Start		  6.2949805226140641e+04
            Stop		  6.3816690023611445e+04
            Start		  6.5784336518831231e+04
            Stop		  6.6651220502665295e+04
            Start		  6.8618866645294853e+04
            Stop		  6.9485751439906904e+04
            Start		  7.1453397937183676e+04
            Stop		  7.2320281919667250e+04
            Start		  7.4287928062804174e+04
            Stop		  7.5154812857696539e+04
            Start		  7.7122459353942424e+04
            Stop		  7.7989343338297433e+04
            Start		  7.9956989478888951e+04
            Stop		  8.0823874277179144e+04
            Start		  8.2791520769484865e+04
            Stop		  8.3658404758610282e+04
            Start		  8.5626050894034619e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 45
            Strand		 28 46
            Strand		 28 47
            Strand		 28 48
            Start		  1.2944637122123324e+03
            Stop		  2.4848939568760029e+03
            Start		  4.1289936297949098e+03
            Stop		  5.3194245175443175e+03
            Start		  6.9635242680553411e+03
            Stop		  8.1539552300054429e+03
            Start		  9.7980549832811939e+03
            Stop		  1.0988485936711781e+04
            Start		  1.2632585697234448e+04
            Stop		  1.3823016642892801e+04
            Start		  1.5467116410821160e+04
            Stop		  1.6657547348432170e+04
            Start		  1.8301647123803941e+04
            Stop		  1.9492078053519224e+04
            Start		  2.1136177836032228e+04
            Stop		  2.2326608758348975e+04
            Start		  2.3970708547386068e+04
            Stop		  2.5161139463128322e+04
            Start		  2.6805239257783822e+04
            Stop		  2.7995670168066426e+04
            Start		  2.9639769967185795e+04
            Stop		  3.0830200873365480e+04
            Start		  3.2474300675596005e+04
            Stop		  3.3664731579211890e+04
            Start		  3.5308831383062061e+04
            Stop		  3.6499262285767996e+04
            Start		  3.8143362089672977e+04
            Stop		  3.9333792993165051e+04
            Start		  4.0977892795555381e+04
            Stop		  4.2168323701497407e+04
            Start		  4.3812423500867830e+04
            Stop		  4.5002854410818349e+04
            Start		  4.6646954205793954e+04
            Stop		  4.7837385121137828e+04
            Start		  4.9481484910534316e+04
            Stop		  5.0671915832421990e+04
            Start		  5.2316015615297685e+04
            Stop		  5.3506446544594619e+04
            Start		  5.5150546320291796e+04
            Stop		  5.6340977257540530e+04
            Start		  5.7985077025714301e+04
            Stop		  5.9175507971110703e+04
            Start		  6.0819607731743999e+04
            Stop		  6.2010038685128595e+04
            Start		  6.3654138438533162e+04
            Stop		  6.4844569399398191e+04
            Start		  6.6488669146200642e+04
            Stop		  6.7679100113712338e+04
            Start		  6.9323199854826729e+04
            Stop		  7.0513630827862027e+04
            Start		  7.2157730564449710e+04
            Stop		  7.3348161541645488e+04
            Start		  7.4992261275064157e+04
            Stop		  7.6182692254877024e+04
            Start		  7.7826791986621116e+04
            Stop		  7.9017222967395239e+04
            Start		  8.0661322699030177e+04
            Stop		  8.1851753679070025e+04
            Start		  8.3495853412163706e+04
            Stop		  8.4686284389808367e+04
            Start		  8.6330384125862271e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 49
            Strand		 28 50
            Strand		 28 51
            Strand		 28 52
            Strand		 28 53
            Strand		 28 54
            Strand		 28 55
            Strand		 28 56
            Strand		 28 57
            Strand		 28 58
            Strand		 28 59
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 28 60
            Strand		 28 61
            Strand		 28 62
            Strand		 28 63
            Strand		 28 65
            Strand		 28 66
            Strand		 28 67
            Strand		 28 68
            Strand		 28 69
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 28 70
            Strand		 28 71
            Strand		 29 36
            Strand		 29 37
            Strand		 29 38
            Strand		 29 39
            Strand		 29 40
            Start		  0.0000000000000000e+00
            Stop		  2.8025410635535650e+02
            Start		  1.9243630253600754e+03
            Stop		  3.1147889079529778e+03
            Start		  4.7588899712714228e+03
            Stop		  5.9493195171269281e+03
            Start		  7.5934206475153360e+03
            Stop		  8.7838502352698342e+03
            Start		  1.0427951356129664e+04
            Stop		  1.1618380949299331e+04
            Start		  1.3262482064808029e+04
            Stop		  1.4452911663337938e+04
            Start		  1.6097012774531328e+04
            Stop		  1.7287442376964696e+04
            Start		  1.8931543485237329e+04
            Stop		  2.0121973090008578e+04
            Start		  2.1766074196871945e+04
            Stop		  2.2956503802312745e+04
            Start		  2.4600604909337540e+04
            Stop		  2.5791034513753446e+04
            Start		  2.7435135622500253e+04
            Stop		  2.8625565224244718e+04
            Start		  3.0269666336195580e+04
            Stop		  3.1460095933742276e+04
            Start		  3.3104197050235591e+04
            Stop		  3.4294626642245450e+04
            Start		  3.5938727764417265e+04
            Stop		  3.7129157349797264e+04
            Start		  3.8773258478531250e+04
            Stop		  3.9963688056482497e+04
            Start		  4.1607789192371136e+04
            Stop		  4.2798218762423989e+04
            Start		  4.4442319905742610e+04
            Stop		  4.5632749467777219e+04
            Start		  4.7276850618471799e+04
            Stop		  4.8467280172723491e+04
            Start		  5.0111381330413016e+04
            Stop		  5.1301810877461983e+04
            Start		  5.2945912041455158e+04
            Stop		  5.4136341582201014e+04
            Start		  5.5780442751526534e+04
            Stop		  5.6970872287148864e+04
            Start		  5.8614973460598034e+04
            Stop		  5.9805402992504693e+04
            Start		  6.1449504168684412e+04
            Stop		  6.2639933698449684e+04
            Start		  6.4284034875843601e+04
            Stop		  6.5474464405139253e+04
            Start		  6.7118565582174226e+04
            Stop		  6.8308995112696008e+04
            Start		  6.9953096287811233e+04
            Stop		  7.1143525821204719e+04
            Start		  7.2787626992919963e+04
            Stop		  7.3978056530708142e+04
            Start		  7.5622157697688905e+04
            Stop		  7.6812587241205576e+04
            Start		  7.8456688402321437e+04
            Stop		  7.9647117952652537e+04
            Start		  8.1291219107026816e+04
            Stop		  8.2481648664963039e+04
            Start		  8.4125749812011141e+04
            Stop		  8.5316179378013039e+04
            Strand		 29 41
            Strand		 29 42
            Strand		 29 43
            Strand		 29 44
            Start		  1.1769799500435668e+02
            Stop		  9.8460303674128374e+02
            Start		  2.9522277599013441e+03
            Stop		  3.8191340330107837e+03
            Start		  5.7867594182125922e+03
            Stop		  6.6536643266283754e+03
            Start		  8.6212880324713624e+03
            Stop		  9.4881952714053477e+03
            Start		  1.1455820840987933e+04
            Stop		  1.2322725686558388e+04
            Start		  1.4290351348353566e+04
            Stop		  1.5157256624357364e+04
            Start		  1.7124882262737079e+04
            Stop		  1.7991787081654027e+04
            Start		  1.9959412526334130e+04
            Stop		  2.0826318018827147e+04
            Start		  2.2793943683008783e+04
            Stop		  2.3660848490533212e+04
            Start		  2.5628473865781150e+04
            Stop		  2.6495379428141678e+04
            Start		  2.8463005101589933e+04
            Stop		  2.9329909905162869e+04
            Start		  3.1297535257121217e+04
            Stop		  3.2164440843522028e+04
            Start		  3.4132066518554682e+04
            Stop		  3.4998971322907855e+04
            Start		  3.6966596664668854e+04
            Stop		  3.7833502262114205e+04
            Start		  3.9801127934255921e+04
            Stop		  4.0668032742844356e+04
            Start		  4.2635658077058906e+04
            Stop		  4.3502563682833017e+04
            Start		  4.5470189349265449e+04
            Stop		  4.6337094164428083e+04
            Start		  4.8304719491026415e+04
            Stop		  4.9171625104995241e+04
            Start		  5.1139250764275064e+04
            Stop		  5.2006155587081761e+04
            Start		  5.3973780905985644e+04
            Stop		  5.4840686527922306e+04
            Start		  5.6808312179976660e+04
            Stop		  5.7675217010126165e+04
            Start		  5.9642842322154975e+04
            Stop		  6.0509747950887264e+04
            Start		  6.2477373596942016e+04
            Stop		  6.3344278432841995e+04
            Start		  6.5311903739865549e+04
            Stop		  6.6178809373184558e+04
            Start		  6.8146435015523632e+04
            Stop		  6.9013339854576188e+04
            Start		  7.0980965159287749e+04
            Stop		  7.1847870794233808e+04
            Start		  7.3815496435793495e+04
            Stop		  7.4682401274849239e+04
            Start		  7.6650026580330203e+04
            Stop		  7.7516932213674372e+04
            Start		  7.9484557857530526e+04
            Stop		  8.0351462693436319e+04
            Start		  8.2319088002632008e+04
            Stop		  8.3185993631426041e+04
            Start		  8.5153619280259169e+04
            Stop		  8.6020524110405735e+04
            Strand		 29 45
            Start		  0.0000000000000000e+00
            Stop		  5.1217158422224372e+02
            Start		  2.4798173310589673e+03
            Stop		  3.3467015806152422e+03
            Start		  5.3143476500143715e+03
            Stop		  6.1812326155708970e+03
            Start		  8.1488787461656857e+03
            Stop		  9.0157628584063805e+03
            Start		  1.0983407529980028e+04
            Stop		  1.1850293811826748e+04
            Start		  1.3817940161792461e+04
            Stop		  1.4684824210983432e+04
            Start		  1.6652470771208998e+04
            Stop		  1.7519355152933924e+04
            Start		  1.9487001578581818e+04
            Stop		  2.0353885607522298e+04
            Start		  2.2321531863907316e+04
            Stop		  2.3188416547706525e+04
            Start		  2.5156062996945846e+04
            Stop		  2.6022947020343505e+04
            Start		  2.7990593176399787e+04
            Stop		  2.8857477959699030e+04
            Start		  3.0825124416997271e+04
            Stop		  3.1692008437729510e+04
            Start		  3.3659654562034950e+04
            Stop		  3.4526539376238972e+04
            Start		  3.6494185838547040e+04
            Stop		  3.7361069855452348e+04
            Start		  3.9328715972544829e+04
            Stop		  4.0195600793116224e+04
            Start		  4.2163247261142918e+04
            Stop		  4.3030131272206701e+04
            Start		  4.4997777391586424e+04
            Stop		  4.5864662209156231e+04
            Start		  4.7832308684149932e+04
            Stop		  4.8699192687868243e+04
            Start		  5.0666838813261289e+04
            Stop		  5.1533723624356331e+04
            Start		  5.3501370106861315e+04
            Stop		  5.4368254102840307e+04
            Start		  5.6335900235150351e+04
            Stop		  5.7202785039199516e+04
            Start		  5.9170431528621382e+04
            Stop		  6.0037315517757917e+04
            Start		  6.2004961656098203e+04
            Stop		  6.2871846454343045e+04
            Start		  6.4839492948939544e+04
            Stop		  6.5706376933302628e+04
            Start		  6.7674023075542776e+04
            Stop		  6.8540907870429233e+04
            Start		  7.0508554367575358e+04
            Stop		  7.1375438350059383e+04
            Start		  7.3343084493325077e+04
            Stop		  7.4209969287948887e+04
            Start		  7.6177615784580470e+04
            Stop		  7.7044499768406589e+04
            Start		  7.9012145909621642e+04
            Stop		  7.9879030707148049e+04
            Start		  8.1846677200289327e+04
            Stop		  8.2713561188447871e+04
            Start		  8.4681207324882198e+04
            Stop		  8.5548092127982323e+04
            Strand		 29 46
            Strand		 29 47
            Strand		 29 48
            Strand		 29 49
            Start		  3.4961924210310588e+02
            Stop		  1.5400504500248724e+03
            Start		  3.1841500999071723e+03
            Stop		  4.3745809485507261e+03
            Start		  6.0186806967379298e+03
            Stop		  7.2091116608041802e+03
            Start		  8.8532114118805894e+03
            Stop		  1.0043642367823943e+04
            Start		  1.1687742125936924e+04
            Stop		  1.2878173074247617e+04
            Start		  1.4522272839684862e+04
            Stop		  1.5712703779978354e+04
            Start		  1.7356803552886544e+04
            Stop		  1.8547234485195451e+04
            Start		  2.0191334265381443e+04
            Stop		  2.1381765190088357e+04
            Start		  2.3025864977037832e+04
            Stop		  2.4216295894861181e+04
            Start		  2.5860395687760829e+04
            Stop		  2.7050826599723372e+04
            Start		  2.8694926397496445e+04
            Stop		  2.9885357304880443e+04
            Start		  3.1529457106234084e+04
            Stop		  3.2719888010525003e+04
            Start		  3.4363987814006956e+04
            Stop		  3.5554418716828302e+04
            Start		  3.7198518520890604e+04
            Stop		  3.8388949423932630e+04
            Start		  4.0033049226999668e+04
            Stop		  4.1223480131945216e+04
            Start		  4.2867579932482782e+04
            Stop		  4.4058010840933348e+04
            Start		  4.5702110637516060e+04
            Stop		  4.6892541550921625e+04
            Start		  4.8536641342295356e+04
            Stop		  4.9727072261890622e+04
            Start		  5.1371172047027707e+04
            Stop		  5.2561602973778070e+04
            Start		  5.4205702751922290e+04
            Stop		  5.5396133686481269e+04
            Start		  5.7040233457181028e+04
            Stop		  5.8230664399861715e+04
            Start		  5.9874764162989981e+04
            Stop		  6.1065195113751368e+04
            Start		  6.2709294869511010e+04
            Stop		  6.3899725827959715e+04
            Start		  6.5543825576874762e+04
            Stop		  6.6734256542282325e+04
            Start		  6.8378356285174945e+04
            Stop		  6.9568787256509822e+04
            Start		  7.1212886994464061e+04
            Stop		  7.2403317970436969e+04
            Start		  7.4047417704751351e+04
            Stop		  7.5237848683871765e+04
            Start		  7.6881948416002197e+04
            Stop		  7.8072379396643853e+04
            Start		  7.9716479128139632e+04
            Stop		  8.0906910108612065e+04
            Start		  8.2551009841048013e+04
            Stop		  8.3741440819670403e+04
            Start		  8.5385540554577616e+04
            Stop		  8.6400000000000000e+04
            Strand		 29 50
            Strand		 29 51
            Strand		 29 52
            Strand		 29 53
            Strand		 29 54
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 29 55
            Strand		 29 56
            Strand		 29 57
            Strand		 29 58
            Strand		 29 59
            Strand		 29 60
            Strand		 29 61
            Strand		 29 62
            Strand		 29 63
            Strand		 29 64
            Strand		 29 66
            Strand		 29 67
            Strand		 29 68
            Strand		 29 69
            Strand		 29 70
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 29 71
            Strand		 30 36
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 30 37
            Strand		 30 38
            Strand		 30 39
            Strand		 30 40
            Strand		 30 41
            Strand		 30 42
            Strand		 30 43
            Strand		 30 44
            Strand		 30 45
            Strand		 30 46
            Strand		 30 47
            Start		  8.2204588671670786e+02
            Stop		  2.0124714060068668e+03
            Start		  3.6565724999732274e+03
            Stop		  4.8470020014092725e+03
            Start		  6.4911031703201106e+03
            Stop		  7.6815327165031185e+03
            Start		  9.3256338759419286e+03
            Stop		  1.0516063428169658e+04
            Start		  1.2160164580802884e+04
            Stop		  1.3350594140856170e+04
            Start		  1.4994695286102395e+04
            Stop		  1.6185124854187023e+04
            Start		  1.7829225991972216e+04
            Stop		  1.9019655568002367e+04
            Start		  2.0663756698573434e+04
            Stop		  2.1854186282108585e+04
            Start		  2.3498287406031657e+04
            Stop		  2.4688716996300114e+04
            Start		  2.6332818114435217e+04
            Stop		  2.7523247710367519e+04
            Start		  2.9167348823830987e+04
            Stop		  3.0357778424106804e+04
            Start		  3.2001879534222269e+04
            Stop		  3.3192309137328353e+04
            Start		  3.4836410245568630e+04
            Stop		  3.6026839849865246e+04
            Start		  3.7670940957787709e+04
            Stop		  3.8861370561580632e+04
            Start		  4.0505471670758823e+04
            Stop		  4.1695901272373681e+04
            Start		  4.3340002384328269e+04
            Stop		  4.4530431982184004e+04
            Start		  4.6174533098316053e+04
            Stop		  4.7364962690994347e+04
            Start		  4.9009063812523797e+04
            Stop		  5.0199493398831386e+04
            Start		  5.1843594526743538e+04
            Stop		  5.3034024105764373e+04
            Start		  5.4678125240766662e+04
            Stop		  5.5868554811902352e+04
            Start		  5.7512655954393260e+04
            Stop		  5.8703085517389161e+04
            Start		  6.0347186667440750e+04
            Stop		  6.1537616222397199e+04
            Start		  6.3181717379752030e+04
            Stop		  6.4372146927119858e+04
            Start		  6.6016248091202258e+04
            Stop		  6.7206677631763101e+04
            Start		  6.8850778801704393e+04
            Stop		  7.0041208336536220e+04
            Start		  7.1685309511212952e+04
            Stop		  7.2875739041642824e+04
            Start		  7.4519840219726088e+04
            Stop		  7.5710269747271916e+04
            Start		  7.7354370927285607e+04
            Stop		  7.8544800453589414e+04
            Start		  8.0188901633975198e+04
            Stop		  8.1379331160731119e+04
            Start		  8.3023432339916690e+04
            Stop		  8.4213861868796492e+04
            Start		  8.5857963045264623e+04
            Stop		  8.6400000000000000e+04
            Strand		 30 48
            Strand		 30 49
            Strand		 30 50
            Strand		 30 51
            Start		  1.8499065193280221e+03
            Stop		  2.7168163266292777e+03
            Start		  4.6844418886138919e+03
            Stop		  5.5513477424604871e+03
            Start		  7.5189726208786306e+03
            Stop		  8.3858775786809310e+03
            Start		  1.0353501506899906e+04
            Stop		  1.1220408533234264e+04
            Start		  1.3188034043647682e+04
            Stop		  1.4054938919501512e+04
            Start		  1.6022564727559715e+04
            Stop		  1.6889469859060871e+04
            Start		  1.8857095466662591e+04
            Stop		  1.9724000306612885e+04
            Start		  2.1691625789117556e+04
            Stop		  2.2558531243863461e+04
            Start		  2.4526156889449867e+04
            Stop		  2.5393061711793758e+04
            Start		  2.7360687092849708e+04
            Stop		  2.8227592648629641e+04
            Start		  3.0195218311353619e+04
            Stop		  3.1062123123431084e+04
            Start		  3.3029748474955435e+04
            Stop		  3.3896654060410918e+04
            Start		  3.5864279731861789e+04
            Stop		  3.6731184537837420e+04
            Start		  3.8698809881711350e+04
            Stop		  3.9565715475316014e+04
            Start		  4.1533341150701584e+04
            Stop		  4.2400245954133796e+04
            Start		  4.4367871295429904e+04
            Stop		  4.5234776892352951e+04
            Start		  4.7202402567888872e+04
            Stop		  4.8069307372234245e+04
            Start		  5.0036932710476511e+04
            Stop		  5.0903838311302148e+04
            Start		  5.2871463983726026e+04
            Stop		  5.3738368792114139e+04
            Start		  5.5705994125363628e+04
            Stop		  5.6572899731990372e+04
            Start		  5.8540525398749771e+04
            Stop		  5.9407430213564228e+04
            Start		  6.1375055540078247e+04
            Stop		  6.2241961154067758e+04
            Start		  6.4209586813637892e+04
            Stop		  6.5076491636143975e+04
            Start		  6.7044116955115533e+04
            Stop		  6.7911022576984789e+04
            Start		  6.9878648229091617e+04
            Stop		  7.0745553059230486e+04
            Start		  7.2713178371072732e+04
            Stop		  7.3580084000060102e+04
            Start		  7.5547709645713898e+04
            Stop		  7.6414614482117584e+04
            Start		  7.8382239788439605e+04
            Stop		  7.9249145422589587e+04
            Start		  8.1216771063904656e+04
            Stop		  8.2083675904135482e+04
            Start		  8.4051301207478202e+04
            Stop		  8.4918206843965701e+04
            Strand		 30 52
            Start		  1.3774968234374221e+03
            Stop		  2.2443838262597365e+03
            Start		  4.2120266885528672e+03
            Stop		  5.0789144247628810e+03
            Start		  7.0465595615223665e+03
            Stop		  7.9134453725308440e+03
            Start		  9.8810919663884688e+03
            Stop		  1.0747975919423699e+04
            Start		  1.2715621716883090e+04
            Stop		  1.3582506859692048e+04
            Start		  1.5550153381517348e+04
            Stop		  1.6417037363354324e+04
            Start		  1.8384683381738418e+04
            Stop		  1.9251568303440748e+04
            Start		  2.1219214796453063e+04
            Stop		  2.2086098793024710e+04
            Start		  2.4053744879972019e+04
            Stop		  2.4920629733399383e+04
            Start		  2.6888276211892175e+04
            Stop		  2.7755160218356217e+04
            Start		  2.9722806323441135e+04
            Stop		  3.0589691158748352e+04
            Start		  3.2557337628449808e+04
            Stop		  3.3424221641953838e+04
            Start		  3.5391867749841702e+04
            Stop		  3.6258752582020075e+04
            Start		  3.8226399046549101e+04
            Stop		  3.9093283064213771e+04
            Start		  4.1060929171799675e+04
            Stop		  4.1927814003661144e+04
            Start		  4.3895460466346252e+04
            Stop		  4.4762344484951427e+04
            Start		  4.6729990593405564e+04
            Stop		  4.7596875423594196e+04
            Start		  4.9564521887702867e+04
            Stop		  5.0431405903979539e+04
            Start		  5.2399052015729736e+04
            Stop		  5.3265936841771734e+04
            Start		  5.5233583310209935e+04
            Stop		  5.6100467321319484e+04
            Start		  5.8068113438698638e+04
            Stop		  5.8934998258362815e+04
            Start		  6.0902644733258785e+04
            Stop		  6.1769528737256514e+04
            Start		  6.3737174861789841e+04
            Stop		  6.4604059673782627e+04
            Start		  6.6571706156146727e+04
            Stop		  6.7438590152309713e+04
            Start		  6.9406236284348342e+04
            Stop		  7.0273121088639979e+04
            Start		  7.2240767578199171e+04
            Stop		  7.3107651567148132e+04
            Start		  7.5075297705774865e+04
            Stop		  7.5942182503637800e+04
            Start		  7.7909828998886762e+04
            Stop		  7.8776712982476893e+04
            Start		  8.0744359125654679e+04
            Stop		  8.1611243919453365e+04
            Start		  8.3578890417917180e+04
            Stop		  8.4445774398915310e+04
            Strand		 30 53
            Strand		 30 54
            Strand		 30 55
            Strand		 30 56
            Start		  0.0000000000000000e+00
            Stop		  4.3773298650876143e+02
            Start		  2.0818326277287761e+03
            Stop		  3.2722634434419374e+03
            Start		  4.9163631790736099e+03
            Stop		  6.1067941585581111e+03
            Start		  7.7508938912036210e+03
            Stop		  8.9413248707791627e+03
            Start		  1.0585424603693078e+04
            Stop		  1.1775855582243199e+04
            Start		  1.3419955316897462e+04
            Stop		  1.4610386292749768e+04
            Start		  1.6254486030625723e+04
            Stop		  1.7444917002262388e+04
            Start		  1.9089016744690332e+04
            Stop		  2.0279447710781857e+04
            Start		  2.1923547458887533e+04
            Stop		  2.3113978418353330e+04
            Start		  2.4758078173008005e+04
            Stop		  2.5948509125063403e+04
            Start		  2.7592608886845755e+04
            Stop		  2.8783039831036465e+04
            Start		  3.0427139600207131e+04
            Stop		  3.1617570536429332e+04
            Start		  3.3261670312919392e+04
            Stop		  3.4452101241424294e+04
            Start		  3.6096201024838265e+04
            Stop		  3.7286631946221118e+04
            Start		  3.8930731735854330e+04
            Stop		  4.0121162651028317e+04
            Start		  4.1765262445897730e+04
            Stop		  4.2955693356053976e+04
            Start		  4.4599793154941319e+04
            Stop		  4.5790224061496636e+04
            Start		  4.7434323863001788e+04
            Stop		  4.8624754767536506e+04
            Start		  5.0268854570138996e+04
            Stop		  5.1459285474327669e+04
            Start		  5.3103385276453286e+04
            Stop		  5.4293816181991220e+04
            Start		  5.5937915982081140e+04
            Stop		  5.7128346890610010e+04
            Start		  5.8772446687189105e+04
            Stop		  5.9962877600225009e+04
            Start		  6.1606977391966509e+04
            Stop		  6.2797408310833445e+04
            Start		  6.4441508096617246e+04
            Stop		  6.5631939022389022e+04
            Start		  6.7276038801350674e+04
            Stop		  6.8466469734803861e+04
            Start		  7.0110569506372558e+04
            Stop		  7.1301000447952436e+04
            Start		  7.2945100211875862e+04
            Stop		  7.4135531161677092e+04
            Start		  7.5779630918032548e+04
            Stop		  7.6970061875794840e+04
            Start		  7.8614161624985747e+04
            Stop		  7.9804592590105574e+04
            Start		  8.1448692332843668e+04
            Stop		  8.2639123304400666e+04
            Start		  8.4283223041674762e+04
            Stop		  8.5473654018472356e+04
            Strand		 30 57
            Strand		 30 58
            Strand		 30 59
            Strand		 30 60
            Strand		 30 61
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 30 62
            Strand		 30 63
            Strand		 30 64
            Strand		 30 65
            Strand		 30 67
            Strand		 30 68
            Strand		 30 69
            Strand		 30 70
            Strand		 30 71
            Strand		 31 36
            Strand		 31 37
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 31 38
            Strand		 31 39
            Strand		 31 40
            Strand		 31 41
            Strand		 31 42
            Start		  0.0000000000000000e+00
            Stop		  1.0676277869217756e+03
            Start		  2.7117289143014259e+03
            Stop		  3.9021584326076145e+03
            Start		  5.5462596023708493e+03
            Stop		  6.7366891460070447e+03
            Start		  8.3807903076766743e+03
            Stop		  9.5712198574524391e+03
            Start		  1.1215321012467426e+04
            Stop		  1.2405750569883494e+04
            Start		  1.4049851717614936e+04
            Stop		  1.5240281283013799e+04
            Start		  1.6884382423274896e+04
            Stop		  1.8074811996688393e+04
            Start		  1.9718913129616631e+04
            Stop		  2.0909342710720030e+04
            Start		  2.2553443836777402e+04
            Stop		  2.3743873424906393e+04
            Start		  2.5387974544858527e+04
            Stop		  2.6578404139038288e+04
            Start		  2.8222505253921034e+04
            Stop		  2.9412934852908911e+04
            Start		  3.1057035963982820e+04
            Stop		  3.2247465566322855e+04
            Start		  3.3891566675017959e+04
            Stop		  3.5081996279104816e+04
            Start		  3.6726097386957736e+04
            Stop		  3.7916526991107115e+04
            Start		  3.9560628099693742e+04
            Stop		  4.0751057702216378e+04
            Start		  4.2395158813082598e+04
            Stop		  4.3585588412358353e+04
            Start		  4.5229689526952236e+04
            Stop		  4.6420119121501237e+04
            Start		  4.8064220241109484e+04
            Stop		  4.9254649829657057e+04
            Start		  5.0898750955348572e+04
            Stop		  5.2089180536881162e+04
            Start		  5.3733281669460048e+04
            Stop		  5.4923711243269754e+04
            Start		  5.6567812383240125e+04
            Stop		  5.7758241948955729e+04
            Start		  5.9402343096499550e+04
            Stop		  6.0592772654102737e+04
            Start		  6.2236873809071825e+04
            Stop		  6.3427303358898076e+04
            Start		  6.5071404520820695e+04
            Stop		  6.6261834063544535e+04
            Start		  6.7905935231645999e+04
            Stop		  6.9096364768251224e+04
            Start		  7.0740465941488132e+04
            Stop		  7.1930895473224780e+04
            Start		  7.3574996650330562e+04
            Stop		  7.4765426178659967e+04
            Start		  7.6409527358200678e+04
            Stop		  7.7599956884731291e+04
            Start		  7.9244058065168501e+04
            Stop		  8.0434487591585304e+04
            Start		  8.2078588771343653e+04
            Stop		  8.3269018299334188e+04
            Start		  8.4913119476870517e+04
            Stop		  8.6103549008050773e+04
            Strand		 31 43
            Strand		 31 44
            Strand		 31 45
            Strand		 31 46
            Strand		 31 47
            Strand		 31 48
            Strand		 31 49
            Strand		 31 50
            Strand		 31 51
            Strand		 31 52
            Start		  9.0506723982533322e+02
            Stop		  1.7719764927834701e+03
            Start		  3.7395980737448326e+03
            Stop		  4.6065029513286136e+03
            Start		  6.5741285115613582e+03
            Stop		  7.4410335625759508e+03
            Start		  9.4086564665938185e+03
            Stop		  1.0275564569747130e+04
            Start		  1.2243187383783927e+04
            Stop		  1.3110095173614567e+04
            Start		  1.5077719288151007e+04
            Stop		  1.5944626124203893e+04
            Start		  1.7912251896205649e+04
            Stop		  1.8779156681916447e+04
            Start		  2.0746781592859443e+04
            Stop		  2.1613687620111930e+04
            Start		  2.3581313319046370e+04
            Stop		  2.4448218124599542e+04
            Start		  2.6415843314865211e+04
            Stop		  2.7282749061461542e+04
            Start		  2.9250374741127369e+04
            Stop		  3.0117279548317383e+04
            Start		  3.2084904836106241e+04
            Stop		  3.2951810485221300e+04
            Start		  3.4919436161890808e+04
            Stop		  3.5786340966561387e+04
            Start		  3.7753966289140524e+04
            Stop		  3.8620871903925974e+04
            Start		  4.0588497581014431e+04
            Stop		  4.1455402383942448e+04
            Start		  4.3423027718357618e+04
            Stop		  4.4289933322022865e+04
            Start		  4.6257558998463079e+04
            Stop		  4.7124463802198814e+04
            Start		  4.9092089138670388e+04
            Stop		  4.9958994741122704e+04
            Start		  5.1926620414493220e+04
            Stop		  5.2793525221941753e+04
            Start		  5.4761150555367465e+04
            Stop		  5.5628056161691886e+04
            Start		  5.7595681829607864e+04
            Stop		  5.8462586643204791e+04
            Start		  6.0430211970665368e+04
            Stop		  6.1297117583621366e+04
            Start		  6.3264743244468940e+04
            Stop		  6.4131648065652189e+04
            Start		  6.6099273385799330e+04
            Stop		  6.6966179006460094e+04
            Start		  6.8933804659782443e+04
            Stop		  6.9800709488707929e+04
            Start		  7.1768334801628109e+04
            Stop		  7.2635240429564277e+04
            Start		  7.4602866076175662e+04
            Stop		  7.5469770911679079e+04
            Start		  7.7437396218755690e+04
            Stop		  7.8304301852232806e+04
            Start		  8.0271927494088217e+04
            Stop		  8.1138832333883824e+04
            Start		  8.3106457637516200e+04
            Stop		  8.3973363273836512e+04
            Start		  8.5940988913695939e+04
            Stop		  8.6400000000000000e+04
            Strand		 31 53
            Start		  4.3265627191466069e+02
            Stop		  1.2995405894338012e+03
            Start		  3.2671854739938244e+03
            Stop		  4.1340717898105631e+03
            Start		  6.1017176889326347e+03
            Stop		  6.9686018635536693e+03
            Start		  8.9362472014543182e+03
            Stop		  9.8031328472157729e+03
            Start		  1.1770779104734223e+04
            Stop		  1.2637663168039508e+04
            Start		  1.4605307625139198e+04
            Stop		  1.5472194113350095e+04
            Start		  1.7439840519784917e+04
            Stop		  1.8306724541057003e+04
            Start		  2.0274370957516974e+04
            Stop		  2.1141255481901935e+04
            Start		  2.3108901934833393e+04
            Stop		  2.3975785946349442e+04
            Start		  2.5943432162855850e+04
            Stop		  2.6810316886853518e+04
            Start		  2.8777963350591333e+04
            Stop		  2.9644847363448866e+04
            Start		  3.1612493510066011e+04
            Stop		  3.2479378303783455e+04
            Start		  3.4447024767630159e+04
            Stop		  3.5313908784100269e+04
            Start		  3.7281554905067132e+04
            Stop		  3.8148439723991411e+04
            Start		  4.0116086186293258e+04
            Stop		  4.0982970205050930e+04
            Start		  4.2950616317039006e+04
            Stop		  4.3817501144245114e+04
            Start		  4.5785147606640196e+04
            Stop		  4.6652031624957221e+04
            Start		  4.8619677735661586e+04
            Stop		  4.9486562563314452e+04
            Start		  5.1454209028437552e+04
            Stop		  5.2321093043316585e+04
            Start		  5.4288739157187840e+04
            Stop		  5.5155623980840937e+04
            Start		  5.7123270451199933e+04
            Stop		  5.7990154460114434e+04
            Start		  5.9957800579919029e+04
            Stop		  6.0824685396954199e+04
            Start		  6.2792331874274401e+04
            Stop		  6.3659215875679722e+04
            Start		  6.5626862002790876e+04
            Stop		  6.6493746812101948e+04
            Start		  6.8461393296953873e+04
            Stop		  6.9328277290579412e+04
            Start		  7.1295923424993656e+04
            Stop		  7.2162808226923429e+04
            Start		  7.4130454718600042e+04
            Stop		  7.4997338705503629e+04
            Start		  7.6964984845926228e+04
            Stop		  7.7831869642122314e+04
            Start		  7.9799516138754087e+04
            Stop		  8.0666400121140658e+04
            Start		  8.2634046265238576e+04
            Stop		  8.3500931058338974e+04
            Start		  8.5468577557216384e+04
            Stop		  8.6335461059035471e+04
            Strand		 31 54
            Strand		 31 55
            Strand		 31 56
            Strand		 31 57
            Start		  1.1369934904418701e+03
            Stop		  2.3274200121231211e+03
            Start		  3.9715196809479021e+03
            Stop		  5.1619505831575952e+03
            Start		  6.8060503195843467e+03
            Stop		  7.9964813003252539e+03
            Start		  9.6405810328217776e+03
            Stop		  1.0831012011847626e+04
            Start		  1.2475111745760072e+04
            Stop		  1.3665542722690690e+04
            Start		  1.5309642459335997e+04
            Stop		  1.6500073432536126e+04
            Start		  1.8144173173310493e+04
            Stop		  1.9334604141383828e+04
            Start		  2.0978703887486645e+04
            Stop		  2.2169134849263668e+04
            Start		  2.3813234601655942e+04
            Stop		  2.5003665556248812e+04
            Start		  2.6647765315610246e+04
            Stop		  2.7838196262451595e+04
            Start		  2.9482296029150799e+04
            Stop		  3.0672726968018716e+04
            Start		  3.2316826742097008e+04
            Stop		  3.3507257673124805e+04
            Start		  3.5151357454294353e+04
            Stop		  3.6341788377964767e+04
            Start		  3.7985888165621145e+04
            Stop		  3.9176319082745162e+04
            Start		  4.0820418875993942e+04
            Stop		  4.2010849787675303e+04
            Start		  4.3654949585371105e+04
            Stop		  4.4845380492957855e+04
            Start		  4.6489480293754743e+04
            Stop		  4.7679911198780101e+04
            Start		  4.9324011001190469e+04
            Stop		  5.0514441905305619e+04
            Start		  5.2158541707765580e+04
            Stop		  5.3348972612667189e+04
            Start		  5.4993072413605107e+04
            Stop		  5.6183503320960896e+04
            Start		  5.7827603118866253e+04
            Stop		  5.9018034030241972e+04
            Start		  6.0662133823731754e+04
            Stop		  6.1852564740522248e+04
            Start		  6.3496664528401539e+04
            Stop		  6.4687095451769877e+04
            Start		  6.6331195233084174e+04
            Stop		  6.7521626163910492e+04
            Start		  6.9165725937987605e+04
            Stop		  7.0356156876830588e+04
            Start		  7.2000256643310160e+04
            Stop		  7.3190687590382440e+04
            Start		  7.4834787349231570e+04
            Stop		  7.6025218304390713e+04
            Start		  7.7669318055905431e+04
            Stop		  7.8859749018660077e+04
            Start		  8.0503848763452086e+04
            Stop		  8.1694279732983705e+04
            Start		  8.3338379471953827e+04
            Stop		  8.4528810447152544e+04
            Start		  8.6172910181450716e+04
            Stop		  8.6400000000000000e+04
            Strand		 31 58
            Strand		 31 59
            Strand		 31 60
            Strand		 31 61
            Strand		 31 62
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 31 63
            Strand		 31 64
            Strand		 31 65
            Strand		 31 66
            Strand		 31 68
            Strand		 31 69
            Strand		 31 70
            Strand		 31 71
            Strand		 32 36
            Strand		 32 37
            Strand		 32 38
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 32 39
            Strand		 32 40
            Strand		 32 41
            Strand		 32 42
            Strand		 32 43
            Start		  0.0000000000000000e+00
            Stop		  1.2278396492072143e+02
            Start		  1.7668853051271958e+03
            Stop		  2.9573148792536358e+03
            Start		  4.6014160379328832e+03
            Stop		  5.7918455748628339e+03
            Start		  7.4359467392585566e+03
            Stop		  8.6263762868668928e+03
            Start		  1.0270477444176562e+04
            Stop		  1.1460906998987672e+04
            Start		  1.3105008149184358e+04
            Stop		  1.4295437711901315e+04
            Start		  1.5939538854653565e+04
            Stop		  1.7129968425414208e+04
            Start		  1.8774069560751108e+04
            Stop		  1.9964499139348736e+04
            Start		  2.1608600267625767e+04
            Stop		  2.2799029853506618e+04
            Start		  2.4443130975391257e+04
            Stop		  2.5633560567679964e+04
            Start		  2.7277661684122479e+04
            Stop		  2.8468091281660112e+04
            Start		  3.0112192393851888e+04
            Stop		  3.1302621995246944e+04
            Start		  3.2946723104568140e+04
            Stop		  3.4137152708257461e+04
            Start		  3.5781253816216544e+04
            Stop		  3.6971683420534078e+04
            Start		  3.8615784528701457e+04
            Stop		  3.9806214131951274e+04
            Start		  4.1450315241890545e+04
            Stop		  4.2640744842421373e+04
            Start		  4.4284845955620520e+04
            Stop		  4.5475275551898114e+04
            Start		  4.7119376669704310e+04
            Stop		  4.8309806260378922e+04
            Start		  4.9953907383939411e+04
            Stop		  5.1144336967904848e+04
            Start		  5.2788438098116530e+04
            Stop		  5.3978867674558875e+04
            Start		  5.5622968812029008e+04
            Stop		  5.6813398380462269e+04
            Start		  5.8457499525481755e+04
            Stop		  5.9647929085769123e+04
            Start		  6.1292030238299834e+04
            Stop		  6.2482459790659726e+04
            Start		  6.4126560950336192e+04
            Stop		  6.5316990495332713e+04
            Start		  6.6961091661478058e+04
            Stop		  6.8151521199996045e+04
            Start		  6.9795622371651916e+04
            Stop		  7.0986051904858250e+04
            Start		  7.2630153080826683e+04
            Stop		  7.3820582610119018e+04
            Start		  7.5464683789015180e+04
            Stop		  7.6655113315960465e+04
            Start		  7.8299214496273475e+04
            Stop		  7.9489644022539287e+04
            Start		  8.1133745202698396e+04
            Stop		  8.2324174729979772e+04
            Start		  8.3968275908423428e+04
            Stop		  8.5158705438368270e+04
            Strand		 32 44
            Strand		 32 45
            Strand		 32 46
            Strand		 32 47
            Strand		 32 48
            Start		  0.0000000000000000e+00
            Stop		  3.5469709047099201e+02
            Start		  2.3223434113184653e+03
            Stop		  3.1892274503903254e+03
            Start		  5.1568742408805620e+03
            Stop		  6.0237583918434875e+03
            Start		  7.9914048277947550e+03
            Stop		  8.8582888324233754e+03
            Start		  1.0825935183873689e+04
            Stop		  1.1692819771899543e+04
            Start		  1.3660466243177094e+04
            Stop		  1.4527350240188018e+04
            Start		  1.6494996443977863e+04
            Stop		  1.7361881180049426e+04
            Start		  1.9329527658112573e+04
            Stop		  2.0196411657870438e+04
            Start		  2.2164057807886107e+04
            Stop		  2.3030942598161808e+04
            Start		  2.4998589073313382e+04
            Stop		  2.5865473079248484e+04
            Start		  2.7833119206607873e+04
            Stop		  2.8700004019675420e+04
            Start		  3.0667650489441185e+04
            Stop		  3.1534534501701401e+04
            Start		  3.3502180617824539e+04
            Stop		  3.4369065441913946e+04
            Start		  3.6336711906995479e+04
            Stop		  3.7203595923881381e+04
            Start		  3.9171242034359282e+04
            Stop		  4.0038126863562298e+04
            Start		  4.2005773326227652e+04
            Stop		  4.2872657344976746e+04
            Start		  4.4840303453822089e+04
            Stop		  4.5707188283900279e+04
            Start		  4.7674834747097622e+04
            Stop		  4.8541718764526340e+04
            Start		  5.0509364875201099e+04
            Stop		  5.1376249702597968e+04
            Start		  5.3343896169280910e+04
            Stop		  5.4210780182391027e+04
            Start		  5.6178426297775324e+04
            Stop		  5.7045311119664031e+04
            Start		  5.9012957592225037e+04
            Stop		  5.9879841598741863e+04
            Start		  6.1847487720822501e+04
            Stop		  6.2714372535408082e+04
            Start		  6.4682019015245503e+04
            Stop		  6.5548903014018462e+04
            Start		  6.7516549143606520e+04
            Stop		  6.8383433950374951e+04
            Start		  7.0351080437644661e+04
            Stop		  7.1217964428848674e+04
            Start		  7.3185610565459574e+04
            Stop		  7.4052495365246214e+04
            Start		  7.6020141858832882e+04
            Stop		  7.6887025843938260e+04
            Start		  7.8854671985883149e+04
            Stop		  7.9721556780720275e+04
            Start		  8.1689203278430912e+04
            Stop		  8.2556087259947919e+04
            Start		  8.4523733404629442e+04
            Stop		  8.5390618197390970e+04
            Strand		 32 49
            Strand		 32 50
            Strand		 32 51
            Strand		 32 52
            Strand		 32 53
            Start		  0.0000000000000000e+00
            Stop		  8.2712851223953510e+02
            Start		  2.7947528644082295e+03
            Stop		  3.6616638197636207e+03
            Start		  5.6292811178997308e+03
            Stop		  6.4961901731889047e+03
            Start		  8.4638122550502630e+03
            Stop		  9.3307207878750414e+03
            Start		  1.1298344166261968e+04
            Stop		  1.2165251765609959e+04
            Start		  1.4132873023779932e+04
            Stop		  1.4999782359326258e+04
            Start		  1.6967406855739398e+04
            Stop		  1.7834313302226190e+04
            Start		  1.9801939037194719e+04
            Stop		  2.0668843834013634e+04
            Start		  2.2636468879901800e+04
            Stop		  2.3503374771391445e+04
            Start		  2.5471000459855786e+04
            Stop		  2.6337905267221355e+04
            Start		  2.8305530504278257e+04
            Stop		  2.9172436204027610e+04
            Start		  3.1140061881549616e+04
            Stop		  3.2006966688099848e+04
            Start		  3.3974591992454763e+04
            Stop		  3.4841497625121658e+04
            Start		  3.6809123301788764e+04
            Stop		  3.7676028105691395e+04
            Start		  3.9643653434108397e+04
            Stop		  4.0510559043272224e+04
            Start		  4.2478184720343183e+04
            Stop		  4.3345089523227209e+04
            Start		  4.5312714859188251e+04
            Stop		  4.6179620461581566e+04
            Start		  4.8147246137276954e+04
            Stop		  4.9014150941939966e+04
            Start		  5.0981776277862729e+04
            Stop		  5.1848681881148543e+04
            Start		  5.3816307552936036e+04
            Stop		  5.4683212362205144e+04
            Start		  5.6650837693894784e+04
            Stop		  5.7517743302201648e+04
            Start		  5.9485368967887909e+04
            Stop		  6.0352273783913952e+04
            Start		  6.2319899109017366e+04
            Stop		  6.3186804724496025e+04
            Start		  6.5154430382822771e+04
            Stop		  6.6021335206636300e+04
            Start		  6.7988960524297960e+04
            Stop		  6.8855866147500128e+04
            Start		  7.0823491798433723e+04
            Stop		  7.1690396629742841e+04
            Start		  7.3658021940504303e+04
            Stop		  7.4524927570535932e+04
            Start		  7.6492553215296386e+04
            Stop		  7.7359458052530070e+04
            Start		  7.9327083358153148e+04
            Stop		  8.0193988992912360e+04
            Start		  8.2161614633768899e+04
            Stop		  8.3028519474347515e+04
            Start		  8.4996144777480920e+04
            Stop		  8.5863050414050449e+04
            Strand		 32 54
            Strand		 32 55
            Strand		 32 56
            Strand		 32 57
            Strand		 32 58
            Start		  1.9214823494575910e+02
            Stop		  1.3825765884421844e+03
            Start		  3.0266762319596560e+03
            Stop		  4.2171070168374445e+03
            Start		  5.8612067500360272e+03
            Stop		  7.0516377293049645e+03
            Start		  8.6957374619295006e+03
            Stop		  9.8861684413728053e+03
            Start		  1.1530268174692987e+04
            Stop		  1.2720699152520579e+04
            Start		  1.4364798888090734e+04
            Stop		  1.5555229862698632e+04
            Start		  1.7199329601953075e+04
            Stop		  1.8389760571877887e+04
            Start		  2.0033860316084956e+04
            Stop		  2.1224291280074227e+04
            Start		  2.2868391030279879e+04
            Stop		  2.4058821987346979e+04
            Start		  2.5702921744328563e+04
            Stop		  2.6893352693795830e+04
            Start		  2.8537452458028172e+04
            Stop		  2.9727883399556660e+04
            Start		  3.1371983171191107e+04
            Stop		  3.2562414104795596e+04
            Start		  3.4206513883653330e+04
            Stop		  3.5396944809701694e+04
            Start		  3.7041044595281550e+04
            Stop		  3.8231475514478647e+04
            Start		  3.9875575305979102e+04
            Stop		  4.1066006219335832e+04
            Start		  4.2710106015690093e+04
            Stop		  4.3900536924479158e+04
            Start		  4.5544636724401942e+04
            Stop		  4.6735067630102007e+04
            Start		  4.8379167432145936e+04
            Stop		  4.9569598336376686e+04
            Start		  5.1213698138995809e+04
            Stop		  5.2404129043446977e+04
            Start		  5.4048228845064492e+04
            Stop		  5.5238659751421757e+04
            Start		  5.6882759550499250e+04
            Stop		  5.8073190460370213e+04
            Start		  5.9717290255475091e+04
            Stop		  6.0907721170318815e+04
            Start		  6.2551820960187157e+04
            Stop		  6.3742251881250231e+04
            Start		  6.5386351664842201e+04
            Stop		  6.6576782593103911e+04
            Start		  6.8220882369649335e+04
            Stop		  6.9411313305779011e+04
            Start		  7.1055413074811120e+04
            Stop		  7.2245844019138545e+04
            Start		  7.3889943780514397e+04
            Stop		  7.5080374733015575e+04
            Start		  7.6724474486922249e+04
            Stop		  7.7914905447220488e+04
            Start		  7.9559005194166923e+04
            Stop		  8.0749436161549340e+04
            Start		  8.2393535902343690e+04
            Stop		  8.3583966875792757e+04
            Start		  8.5228066611507063e+04
            Stop		  8.6400000000000000e+04
            Strand		 32 59
            Strand		 32 60
            Strand		 32 61
            Strand		 32 62
            Strand		 32 63
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 32 64
            Strand		 32 65
            Strand		 32 66
            Strand		 32 67
            Strand		 32 69
            Strand		 32 70
            Strand		 32 71
            Strand		 33 36
            Strand		 33 37
            Strand		 33 38
            Strand		 33 39
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 33 40
            Strand		 33 41
            Strand		 33 42
            Strand		 33 43
            Strand		 33 44
            Start		  8.2204588671670717e+02
            Stop		  2.0124714060068650e+03
            Start		  3.6565724999732315e+03
            Stop		  4.8470020014092670e+03
            Start		  6.4911031703201124e+03
            Stop		  7.6815327165031113e+03
            Start		  9.3256338759419232e+03
            Stop		  1.0516063428169653e+04
            Start		  1.2160164580802875e+04
            Stop		  1.3350594140856156e+04
            Start		  1.4994695286102387e+04
            Stop		  1.6185124854187008e+04
            Start		  1.7829225991972213e+04
            Stop		  1.9019655568002352e+04
            Start		  2.0663756698573437e+04
            Stop		  2.1854186282108582e+04
            Start		  2.3498287406031632e+04
            Stop		  2.4688716996300111e+04
            Start		  2.6332818114435213e+04
            Stop		  2.7523247710367508e+04
            Start		  2.9167348823830976e+04
            Stop		  3.0357778424106786e+04
            Start		  3.2001879534222269e+04
            Stop		  3.3192309137328331e+04
            Start		  3.4836410245568608e+04
            Stop		  3.6026839849865239e+04
            Start		  3.7670940957787701e+04
            Stop		  3.8861370561580632e+04
            Start		  4.0505471670758801e+04
            Stop		  4.1695901272373674e+04
            Start		  4.3340002384328247e+04
            Stop		  4.4530431982183989e+04
            Start		  4.6174533098316031e+04
            Stop		  4.7364962690994333e+04
            Start		  4.9009063812523804e+04
            Stop		  5.0199493398831350e+04
            Start		  5.1843594526743524e+04
            Stop		  5.3034024105764358e+04
            Start		  5.4678125240766647e+04
            Stop		  5.5868554811902322e+04
            Start		  5.7512655954393224e+04
            Stop		  5.8703085517389118e+04
            Start		  6.0347186667440750e+04
            Stop		  6.1537616222397170e+04
            Start		  6.3181717379752008e+04
            Stop		  6.4372146927119844e+04
            Start		  6.6016248091202244e+04
            Stop		  6.7206677631763072e+04
            Start		  6.8850778801704335e+04
            Stop		  7.0041208336536161e+04
            Start		  7.1685309511212894e+04
            Stop		  7.2875739041642781e+04
            Start		  7.4519840219726029e+04
            Stop		  7.5710269747271843e+04
            Start		  7.7354370927285578e+04
            Stop		  7.8544800453589371e+04
            Start		  8.0188901633975183e+04
            Stop		  8.1379331160731075e+04
            Start		  8.3023432339916617e+04
            Stop		  8.4213861868796506e+04
            Start		  8.5857963045264594e+04
            Stop		  8.6400000000000000e+04
            Strand		 33 45
            Strand		 33 46
            Strand		 33 47
            Strand		 33 48
            Start		  1.8499065193280207e+03
            Stop		  2.7168163266292777e+03
            Start		  4.6844418886138874e+03
            Stop		  5.5513477424604862e+03
            Start		  7.5189726208786260e+03
            Stop		  8.3858775786809292e+03
            Start		  1.0353501506899902e+04
            Stop		  1.1220408533234271e+04
            Start		  1.3188034043647678e+04
            Stop		  1.4054938919501506e+04
            Start		  1.6022564727559706e+04
            Stop		  1.6889469859060882e+04
            Start		  1.8857095466662588e+04
            Stop		  1.9724000306612881e+04
            Start		  2.1691625789117548e+04
            Stop		  2.2558531243863454e+04
            Start		  2.4526156889449860e+04
            Stop		  2.5393061711793758e+04
            Start		  2.7360687092849686e+04
            Stop		  2.8227592648629648e+04
            Start		  3.0195218311353605e+04
            Stop		  3.1062123123431084e+04
            Start		  3.3029748474955421e+04
            Stop		  3.3896654060410918e+04
            Start		  3.5864279731861774e+04
            Stop		  3.6731184537837420e+04
            Start		  3.8698809881711342e+04
            Stop		  3.9565715475316007e+04
            Start		  4.1533341150701570e+04
            Stop		  4.2400245954133803e+04
            Start		  4.4367871295429897e+04
            Stop		  4.5234776892352958e+04
            Start		  4.7202402567888850e+04
            Stop		  4.8069307372234252e+04
            Start		  5.0036932710476489e+04
            Stop		  5.0903838311302148e+04
            Start		  5.2871463983726004e+04
            Stop		  5.3738368792114117e+04
            Start		  5.5705994125363613e+04
            Stop		  5.6572899731990365e+04
            Start		  5.8540525398749734e+04
            Stop		  5.9407430213564221e+04
            Start		  6.1375055540078232e+04
            Stop		  6.2241961154067736e+04
            Start		  6.4209586813637856e+04
            Stop		  6.5076491636143946e+04
            Start		  6.7044116955115489e+04
            Stop		  6.7911022576984775e+04
            Start		  6.9878648229091588e+04
            Stop		  7.0745553059230457e+04
            Start		  7.2713178371072718e+04
            Stop		  7.3580084000060087e+04
            Start		  7.5547709645713869e+04
            Stop		  7.6414614482117555e+04
            Start		  7.8382239788439576e+04
            Stop		  7.9249145422589587e+04
            Start		  8.1216771063904627e+04
            Stop		  8.2083675904135482e+04
            Start		  8.4051301207478158e+04
            Stop		  8.4918206843965701e+04
            Strand		 33 49
            Start		  1.3774968234374246e+03
            Stop		  2.2443838262597360e+03
            Start		  4.2120266885528772e+03
            Stop		  5.0789144247628810e+03
            Start		  7.0465595615223601e+03
            Stop		  7.9134453725308304e+03
            Start		  9.8810919663884724e+03
            Stop		  1.0747975919423685e+04
            Start		  1.2715621716883092e+04
            Stop		  1.3582506859692028e+04
            Start		  1.5550153381517348e+04
            Stop		  1.6417037363354288e+04
            Start		  1.8384683381738414e+04
            Stop		  1.9251568303440719e+04
            Start		  2.1219214796453060e+04
            Stop		  2.2086098793024681e+04
            Start		  2.4053744879972011e+04
            Stop		  2.4920629733399353e+04
            Start		  2.6888276211892167e+04
            Stop		  2.7755160218356170e+04
            Start		  2.9722806323441142e+04
            Stop		  3.0589691158748305e+04
            Start		  3.2557337628449804e+04
            Stop		  3.3424221641953802e+04
            Start		  3.5391867749841680e+04
            Stop		  3.6258752582020039e+04
            Start		  3.8226399046549108e+04
            Stop		  3.9093283064213720e+04
            Start		  4.1060929171799668e+04
            Stop		  4.1927814003661093e+04
            Start		  4.3895460466346238e+04
            Stop		  4.4762344484951376e+04
            Start		  4.6729990593405557e+04
            Stop		  4.7596875423594131e+04
            Start		  4.9564521887702860e+04
            Stop		  5.0431405903979474e+04
            Start		  5.2399052015729714e+04
            Stop		  5.3265936841771669e+04
            Start		  5.5233583310209928e+04
            Stop		  5.6100467321319404e+04
            Start		  5.8068113438698623e+04
            Stop		  5.8934998258362735e+04
            Start		  6.0902644733258770e+04
            Stop		  6.1769528737256442e+04
            Start		  6.3737174861789812e+04
            Stop		  6.4604059673782547e+04
            Start		  6.6571706156146713e+04
            Stop		  6.7438590152309596e+04
            Start		  6.9406236284348313e+04
            Stop		  7.0273121088639877e+04
            Start		  7.2240767578199171e+04
            Stop		  7.3107651567148030e+04
            Start		  7.5075297705774821e+04
            Stop		  7.5942182503637712e+04
            Start		  7.7909828998886776e+04
            Stop		  7.8776712982476791e+04
            Start		  8.0744359125654650e+04
            Stop		  8.1611243919453264e+04
            Start		  8.3578890417917166e+04
            Stop		  8.4445774398915222e+04
            Strand		 33 50
            Strand		 33 51
            Strand		 33 52
            Strand		 33 53
            Strand		 33 54
            Strand		 33 55
            Strand		 33 56
            Strand		 33 57
            Strand		 33 58
            Strand		 33 59
            Start		  0.0000000000000000e+00
            Stop		  4.3773298650876194e+02
            Start		  2.0818326277287811e+03
            Stop		  3.2722634434419365e+03
            Start		  4.9163631790736063e+03
            Stop		  6.1067941585581157e+03
            Start		  7.7508938912036228e+03
            Stop		  8.9413248707791608e+03
            Start		  1.0585424603693071e+04
            Stop		  1.1775855582243204e+04
            Start		  1.3419955316897465e+04
            Stop		  1.4610386292749770e+04
            Start		  1.6254486030625721e+04
            Stop		  1.7444917002262373e+04
            Start		  1.9089016744690325e+04
            Stop		  2.0279447710781860e+04
            Start		  2.1923547458887519e+04
            Stop		  2.3113978418353327e+04
            Start		  2.4758078173008005e+04
            Stop		  2.5948509125063392e+04
            Start		  2.7592608886845755e+04
            Stop		  2.8783039831036458e+04
            Start		  3.0427139600207134e+04
            Stop		  3.1617570536429328e+04
            Start		  3.3261670312919392e+04
            Stop		  3.4452101241424287e+04
            Start		  3.6096201024838265e+04
            Stop		  3.7286631946221118e+04
            Start		  3.8930731735854330e+04
            Stop		  4.0121162651028302e+04
            Start		  4.1765262445897730e+04
            Stop		  4.2955693356053984e+04
            Start		  4.4599793154941312e+04
            Stop		  4.5790224061496621e+04
            Start		  4.7434323863001795e+04
            Stop		  4.8624754767536506e+04
            Start		  5.0268854570138988e+04
            Stop		  5.1459285474327669e+04
            Start		  5.3103385276453278e+04
            Stop		  5.4293816181991213e+04
            Start		  5.5937915982081133e+04
            Stop		  5.7128346890610017e+04
            Start		  5.8772446687189084e+04
            Stop		  5.9962877600225002e+04
            Start		  6.1606977391966495e+04
            Stop		  6.2797408310833445e+04
            Start		  6.4441508096617225e+04
            Stop		  6.5631939022388993e+04
            Start		  6.7276038801350674e+04
            Stop		  6.8466469734803832e+04
            Start		  7.0110569506372514e+04
            Stop		  7.1301000447952436e+04
            Start		  7.2945100211875819e+04
            Stop		  7.4135531161677092e+04
            Start		  7.5779630918032490e+04
            Stop		  7.6970061875794825e+04
            Start		  7.8614161624985718e+04
            Stop		  7.9804592590105545e+04
            Start		  8.1448692332843639e+04
            Stop		  8.2639123304400651e+04
            Start		  8.4283223041674733e+04
            Stop		  8.5473654018472342e+04
            Strand		 33 60
            Strand		 33 61
            Strand		 33 62
            Strand		 33 63
            Strand		 33 64
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 33 65
            Strand		 33 66
            Strand		 33 67
            Strand		 33 68
            Strand		 33 70
            Strand		 33 71
            Strand		 34 36
            Strand		 34 37
            Strand		 34 38
            Strand		 34 39
            Strand		 34 40
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 34 41
            Strand		 34 42
            Strand		 34 43
            Strand		 34 44
            Strand		 34 45
            Start		  0.0000000000000000e+00
            Stop		  1.0676277869217699e+03
            Start		  2.7117289143014214e+03
            Stop		  3.9021584326076172e+03
            Start		  5.5462596023708447e+03
            Stop		  6.7366891460070419e+03
            Start		  8.3807903076766652e+03
            Stop		  9.5712198574524391e+03
            Start		  1.1215321012467419e+04
            Stop		  1.2405750569883494e+04
            Start		  1.4049851717614931e+04
            Stop		  1.5240281283013786e+04
            Start		  1.6884382423274896e+04
            Stop		  1.8074811996688393e+04
            Start		  1.9718913129616627e+04
            Stop		  2.0909342710720026e+04
            Start		  2.2553443836777402e+04
            Stop		  2.3743873424906389e+04
            Start		  2.5387974544858520e+04
            Stop		  2.6578404139038284e+04
            Start		  2.8222505253921023e+04
            Stop		  2.9412934852908904e+04
            Start		  3.1057035963982813e+04
            Stop		  3.2247465566322851e+04
            Start		  3.3891566675017952e+04
            Stop		  3.5081996279104795e+04
            Start		  3.6726097386957728e+04
            Stop		  3.7916526991107123e+04
            Start		  3.9560628099693728e+04
            Stop		  4.0751057702216385e+04
            Start		  4.2395158813082598e+04
            Stop		  4.3585588412358346e+04
            Start		  4.5229689526952228e+04
            Stop		  4.6420119121501237e+04
            Start		  4.8064220241109469e+04
            Stop		  4.9254649829657050e+04
            Start		  5.0898750955348551e+04
            Stop		  5.2089180536881162e+04
            Start		  5.3733281669460033e+04
            Stop		  5.4923711243269761e+04
            Start		  5.6567812383240118e+04
            Stop		  5.7758241948955707e+04
            Start		  5.9402343096499528e+04
            Stop		  6.0592772654102722e+04
            Start		  6.2236873809071796e+04
            Stop		  6.3427303358898054e+04
            Start		  6.5071404520820666e+04
            Stop		  6.6261834063544506e+04
            Start		  6.7905935231645984e+04
            Stop		  6.9096364768251195e+04
            Start		  7.0740465941488088e+04
            Stop		  7.1930895473224751e+04
            Start		  7.3574996650330548e+04
            Stop		  7.4765426178659938e+04
            Start		  7.6409527358200648e+04
            Stop		  7.7599956884731277e+04
            Start		  7.9244058065168458e+04
            Stop		  8.0434487591585275e+04
            Start		  8.2078588771343624e+04
            Stop		  8.3269018299334144e+04
            Start		  8.4913119476870474e+04
            Stop		  8.6103549008050730e+04
            Strand		 34 46
            Strand		 34 47
            Strand		 34 48
            Strand		 34 49
            Start		  9.0506723982533549e+02
            Stop		  1.7719764927834644e+03
            Start		  3.7395980737448344e+03
            Stop		  4.6065029513286108e+03
            Start		  6.5741285115613537e+03
            Stop		  7.4410335625759380e+03
            Start		  9.4086564665938113e+03
            Stop		  1.0275564569747119e+04
            Start		  1.2243187383783916e+04
            Stop		  1.3110095173614556e+04
            Start		  1.5077719288150989e+04
            Stop		  1.5944626124203876e+04
            Start		  1.7912251896205631e+04
            Stop		  1.8779156681916429e+04
            Start		  2.0746781592859417e+04
            Stop		  2.1613687620111912e+04
            Start		  2.3581313319046341e+04
            Stop		  2.4448218124599520e+04
            Start		  2.6415843314865175e+04
            Stop		  2.7282749061461513e+04
            Start		  2.9250374741127333e+04
            Stop		  3.0117279548317365e+04
            Start		  3.2084904836106194e+04
            Stop		  3.2951810485221271e+04
            Start		  3.4919436161890771e+04
            Stop		  3.5786340966561365e+04
            Start		  3.7753966289140481e+04
            Stop		  3.8620871903925930e+04
            Start		  4.0588497581014388e+04
            Stop		  4.1455402383942419e+04
            Start		  4.3423027718357574e+04
            Stop		  4.4289933322022829e+04
            Start		  4.6257558998463021e+04
            Stop		  4.7124463802198778e+04
            Start		  4.9092089138670322e+04
            Stop		  4.9958994741122660e+04
            Start		  5.1926620414493147e+04
            Stop		  5.2793525221941716e+04
            Start		  5.4761150555367392e+04
            Stop		  5.5628056161691842e+04
            Start		  5.7595681829607769e+04
            Stop		  5.8462586643204748e+04
            Start		  6.0430211970665296e+04
            Stop		  6.1297117583621315e+04
            Start		  6.3264743244468867e+04
            Stop		  6.4131648065652131e+04
            Start		  6.6099273385799257e+04
            Stop		  6.6966179006460021e+04
            Start		  6.8933804659782341e+04
            Stop		  6.9800709488707871e+04
            Start		  7.1768334801628007e+04
            Stop		  7.2635240429564234e+04
            Start		  7.4602866076175545e+04
            Stop		  7.5469770911679007e+04
            Start		  7.7437396218755559e+04
            Stop		  7.8304301852232733e+04
            Start		  8.0271927494088115e+04
            Stop		  8.1138832333883751e+04
            Start		  8.3106457637516083e+04
            Stop		  8.3973363273836439e+04
            Start		  8.5940988913695823e+04
            Stop		  8.6400000000000000e+04
            Strand		 34 50
            Start		  4.3265627191466433e+02
            Stop		  1.2995405894337989e+03
            Start		  3.2671854739938271e+03
            Stop		  4.1340717898105586e+03
            Start		  6.1017176889326420e+03
            Stop		  6.9686018635536648e+03
            Start		  8.9362472014543164e+03
            Stop		  9.8031328472157729e+03
            Start		  1.1770779104734223e+04
            Stop		  1.2637663168039504e+04
            Start		  1.4605307625139185e+04
            Stop		  1.5472194113350097e+04
            Start		  1.7439840519784924e+04
            Stop		  1.8306724541056999e+04
            Start		  2.0274370957516963e+04
            Stop		  2.1141255481901921e+04
            Start		  2.3108901934833379e+04
            Stop		  2.3975785946349439e+04
            Start		  2.5943432162855839e+04
            Stop		  2.6810316886853514e+04
            Start		  2.8777963350591323e+04
            Stop		  2.9644847363448855e+04
            Start		  3.1612493510066004e+04
            Stop		  3.2479378303783447e+04
            Start		  3.4447024767630137e+04
            Stop		  3.5313908784100262e+04
            Start		  3.7281554905067125e+04
            Stop		  3.8148439723991396e+04
            Start		  4.0116086186293251e+04
            Stop		  4.0982970205050922e+04
            Start		  4.2950616317038999e+04
            Stop		  4.3817501144245100e+04
            Start		  4.5785147606640174e+04
            Stop		  4.6652031624957206e+04
            Start		  4.8619677735661564e+04
            Stop		  4.9486562563314445e+04
            Start		  5.1454209028437523e+04
            Stop		  5.2321093043316585e+04
            Start		  5.4288739157187818e+04
            Stop		  5.5155623980840915e+04
            Start		  5.7123270451199904e+04
            Stop		  5.7990154460114398e+04
            Start		  5.9957800579918992e+04
            Stop		  6.0824685396954163e+04
            Start		  6.2792331874274365e+04
            Stop		  6.3659215875679693e+04
            Start		  6.5626862002790818e+04
            Stop		  6.6493746812101934e+04
            Start		  6.8461393296953844e+04
            Stop		  6.9328277290579368e+04
            Start		  7.1295923424993642e+04
            Stop		  7.2162808226923415e+04
            Start		  7.4130454718599998e+04
            Stop		  7.4997338705503600e+04
            Start		  7.6964984845926214e+04
            Stop		  7.7831869642122256e+04
            Start		  7.9799516138754057e+04
            Stop		  8.0666400121140643e+04
            Start		  8.2634046265238547e+04
            Stop		  8.3500931058338931e+04
            Start		  8.5468577557216340e+04
            Stop		  8.6335461059035428e+04
            Strand		 34 51
            Strand		 34 52
            Strand		 34 53
            Strand		 34 54
            Start		  1.1369934904418676e+03
            Stop		  2.3274200121231174e+03
            Start		  3.9715196809479044e+03
            Stop		  5.1619505831575952e+03
            Start		  6.8060503195843503e+03
            Stop		  7.9964813003252439e+03
            Start		  9.6405810328217703e+03
            Stop		  1.0831012011847617e+04
            Start		  1.2475111745760067e+04
            Stop		  1.3665542722690689e+04
            Start		  1.5309642459335988e+04
            Stop		  1.6500073432536119e+04
            Start		  1.8144173173310483e+04
            Stop		  1.9334604141383810e+04
            Start		  2.0978703887486623e+04
            Stop		  2.2169134849263646e+04
            Start		  2.3813234601655924e+04
            Stop		  2.5003665556248794e+04
            Start		  2.6647765315610221e+04
            Stop		  2.7838196262451584e+04
            Start		  2.9482296029150781e+04
            Stop		  3.0672726968018698e+04
            Start		  3.2316826742096982e+04
            Stop		  3.3507257673124783e+04
            Start		  3.5151357454294317e+04
            Stop		  3.6341788377964709e+04
            Start		  3.7985888165621116e+04
            Stop		  3.9176319082745133e+04
            Start		  4.0820418875993913e+04
            Stop		  4.2010849787675266e+04
            Start		  4.3654949585371083e+04
            Stop		  4.4845380492957825e+04
            Start		  4.6489480293754707e+04
            Stop		  4.7679911198780064e+04
            Start		  4.9324011001190433e+04
            Stop		  5.0514441905305575e+04
            Start		  5.2158541707765544e+04
            Stop		  5.3348972612667152e+04
            Start		  5.4993072413605063e+04
            Stop		  5.6183503320960852e+04
            Start		  5.7827603118866231e+04
            Stop		  5.9018034030241914e+04
            Start		  6.0662133823731710e+04
            Stop		  6.1852564740522212e+04
            Start		  6.3496664528401481e+04
            Stop		  6.4687095451769841e+04
            Start		  6.6331195233084101e+04
            Stop		  6.7521626163910434e+04
            Start		  6.9165725937987576e+04
            Stop		  7.0356156876830544e+04
            Start		  7.2000256643310116e+04
            Stop		  7.3190687590382367e+04
            Start		  7.4834787349231498e+04
            Stop		  7.6025218304390655e+04
            Start		  7.7669318055905358e+04
            Stop		  7.8859749018659990e+04
            Start		  8.0503848763452042e+04
            Stop		  8.1694279732983647e+04
            Start		  8.3338379471953755e+04
            Stop		  8.4528810447152442e+04
            Start		  8.6172910181450643e+04
            Stop		  8.6400000000000000e+04
            Strand		 34 55
            Strand		 34 56
            Strand		 34 57
            Strand		 34 58
            Strand		 34 59
            Strand		 34 60
            Strand		 34 61
            Strand		 34 62
            Strand		 34 63
            Strand		 34 64
            Strand		 34 65
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 34 66
            Strand		 34 67
            Strand		 34 68
            Strand		 34 69
            Strand		 34 71
            Strand		 35 36
            Strand		 35 37
            Strand		 35 38
            Strand		 35 39
            Strand		 35 40
            Strand		 35 41
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 35 42
            Strand		 35 43
            Strand		 35 44
            Strand		 35 45
            Strand		 35 46
            Start		  0.0000000000000000e+00
            Stop		  1.2278396492072024e+02
            Start		  1.7668853051271956e+03
            Stop		  2.9573148792536331e+03
            Start		  4.6014160379328860e+03
            Stop		  5.7918455748628467e+03
            Start		  7.4359467392585611e+03
            Stop		  8.6263762868668946e+03
            Start		  1.0270477444176569e+04
            Stop		  1.1460906998987673e+04
            Start		  1.3105008149184361e+04
            Stop		  1.4295437711901319e+04
            Start		  1.5939538854653571e+04
            Stop		  1.7129968425414219e+04
            Start		  1.8774069560751112e+04
            Stop		  1.9964499139348747e+04
            Start		  2.1608600267625763e+04
            Stop		  2.2799029853506639e+04
            Start		  2.4443130975391268e+04
            Stop		  2.5633560567679971e+04
            Start		  2.7277661684122490e+04
            Stop		  2.8468091281660145e+04
            Start		  3.0112192393851899e+04
            Stop		  3.1302621995246947e+04
            Start		  3.2946723104568169e+04
            Stop		  3.4137152708257490e+04
            Start		  3.5781253816216558e+04
            Stop		  3.6971683420534107e+04
            Start		  3.8615784528701486e+04
            Stop		  3.9806214131951303e+04
            Start		  4.1450315241890567e+04
            Stop		  4.2640744842421394e+04
            Start		  4.4284845955620542e+04
            Stop		  4.5475275551898121e+04
            Start		  4.7119376669704325e+04
            Stop		  4.8309806260378929e+04
            Start		  4.9953907383939426e+04
            Stop		  5.1144336967904863e+04
            Start		  5.2788438098116552e+04
            Stop		  5.3978867674558911e+04
            Start		  5.5622968812029030e+04
            Stop		  5.6813398380462291e+04
            Start		  5.8457499525481770e+04
            Stop		  5.9647929085769159e+04
            Start		  6.1292030238299856e+04
            Stop		  6.2482459790659777e+04
            Start		  6.4126560950336207e+04
            Stop		  6.5316990495332735e+04
            Start		  6.6961091661478058e+04
            Stop		  6.8151521199996074e+04
            Start		  6.9795622371651902e+04
            Stop		  7.0986051904858279e+04
            Start		  7.2630153080826727e+04
            Stop		  7.3820582610119018e+04
            Start		  7.5464683789015209e+04
            Stop		  7.6655113315960480e+04
            Start		  7.8299214496273504e+04
            Stop		  7.9489644022539302e+04
            Start		  8.1133745202698425e+04
            Stop		  8.2324174729979801e+04
            Start		  8.3968275908423457e+04
            Stop		  8.5158705438368270e+04
            Strand		 35 47
            Strand		 35 48
            Strand		 35 49
            Strand		 35 50
            Start		  0.0000000000000000e+00
            Stop		  8.2712851223954283e+02
            Start		  2.7947528644082277e+03
            Stop		  3.6616638197636189e+03
            Start		  5.6292811178997217e+03
            Stop		  6.4961901731889075e+03
            Start		  8.4638122550502612e+03
            Stop		  9.3307207878750487e+03
            Start		  1.1298344166261959e+04
            Stop		  1.2165251765609963e+04
            Start		  1.4132873023779923e+04
            Stop		  1.4999782359326262e+04
            Start		  1.6967406855739402e+04
            Stop		  1.7834313302226201e+04
            Start		  1.9801939037194716e+04
            Stop		  2.0668843834013642e+04
            Start		  2.2636468879901800e+04
            Stop		  2.3503374771391453e+04
            Start		  2.5471000459855783e+04
            Stop		  2.6337905267221377e+04
            Start		  2.8305530504278249e+04
            Stop		  2.9172436204027625e+04
            Start		  3.1140061881549613e+04
            Stop		  3.2006966688099867e+04
            Start		  3.3974591992454771e+04
            Stop		  3.4841497625121665e+04
            Start		  3.6809123301788764e+04
            Stop		  3.7676028105691425e+04
            Start		  3.9643653434108397e+04
            Stop		  4.0510559043272246e+04
            Start		  4.2478184720343190e+04
            Stop		  4.3345089523227223e+04
            Start		  4.5312714859188251e+04
            Stop		  4.6179620461581588e+04
            Start		  4.8147246137276947e+04
            Stop		  4.9014150941939995e+04
            Start		  5.0981776277862744e+04
            Stop		  5.1848681881148565e+04
            Start		  5.3816307552936043e+04
            Stop		  5.4683212362205151e+04
            Start		  5.6650837693894784e+04
            Stop		  5.7517743302201663e+04
            Start		  5.9485368967887895e+04
            Stop		  6.0352273783913974e+04
            Start		  6.2319899109017351e+04
            Stop		  6.3186804724496018e+04
            Start		  6.5154430382822749e+04
            Stop		  6.6021335206636315e+04
            Start		  6.7988960524297945e+04
            Stop		  6.8855866147500157e+04
            Start		  7.0823491798433723e+04
            Stop		  7.1690396629742856e+04
            Start		  7.3658021940504288e+04
            Stop		  7.4524927570535991e+04
            Start		  7.6492553215296371e+04
            Stop		  7.7359458052530099e+04
            Start		  7.9327083358153133e+04
            Stop		  8.0193988992912389e+04
            Start		  8.2161614633768870e+04
            Stop		  8.3028519474347559e+04
            Start		  8.4996144777480920e+04
            Stop		  8.5863050414050493e+04
            Strand		 35 51
            Start		  0.0000000000000000e+00
            Stop		  3.5469709047099309e+02
            Start		  2.3223434113184685e+03
            Stop		  3.1892274503903186e+03
            Start		  5.1568742408805620e+03
            Stop		  6.0237583918434902e+03
            Start		  7.9914048277947513e+03
            Stop		  8.8582888324233863e+03
            Start		  1.0825935183873697e+04
            Stop		  1.1692819771899540e+04
            Start		  1.3660466243177099e+04
            Stop		  1.4527350240188021e+04
            Start		  1.6494996443977874e+04
            Stop		  1.7361881180049440e+04
            Start		  1.9329527658112584e+04
            Stop		  2.0196411657870449e+04
            Start		  2.2164057807886125e+04
            Stop		  2.3030942598161819e+04
            Start		  2.4998589073313404e+04
            Stop		  2.5865473079248506e+04
            Start		  2.7833119206607895e+04
            Stop		  2.8700004019675431e+04
            Start		  3.0667650489441206e+04
            Stop		  3.1534534501701415e+04
            Start		  3.3502180617824561e+04
            Stop		  3.4369065441913968e+04
            Start		  3.6336711906995501e+04
            Stop		  3.7203595923881388e+04
            Start		  3.9171242034359304e+04
            Stop		  4.0038126863562327e+04
            Start		  4.2005773326227667e+04
            Stop		  4.2872657344976767e+04
            Start		  4.4840303453822118e+04
            Stop		  4.5707188283900301e+04
            Start		  4.7674834747097644e+04
            Stop		  4.8541718764526362e+04
            Start		  5.0509364875201121e+04
            Stop		  5.1376249702598005e+04
            Start		  5.3343896169280939e+04
            Stop		  5.4210780182391056e+04
            Start		  5.6178426297775361e+04
            Stop		  5.7045311119664060e+04
            Start		  5.9012957592225073e+04
            Stop		  5.9879841598741892e+04
            Start		  6.1847487720822537e+04
            Stop		  6.2714372535408103e+04
            Start		  6.4682019015245554e+04
            Stop		  6.5548903014018520e+04
            Start		  6.7516549143606549e+04
            Stop		  6.8383433950374994e+04
            Start		  7.0351080437644719e+04
            Stop		  7.1217964428848732e+04
            Start		  7.3185610565459632e+04
            Stop		  7.4052495365246228e+04
            Start		  7.6020141858832911e+04
            Stop		  7.6887025843938332e+04
            Start		  7.8854671985883208e+04
            Stop		  7.9721556780720333e+04
            Start		  8.1689203278430970e+04
            Stop		  8.2556087259947963e+04
            Start		  8.4523733404629485e+04
            Stop		  8.5390618197391013e+04
            Strand		 35 52
            Strand		 35 53
            Strand		 35 54
            Strand		 35 55
            Start		  1.9214823494575998e+02
            Stop		  1.3825765884421864e+03
            Start		  3.0266762319596569e+03
            Stop		  4.2171070168374472e+03
            Start		  5.8612067500360263e+03
            Stop		  7.0516377293049673e+03
            Start		  8.6957374619295024e+03
            Stop		  9.8861684413728126e+03
            Start		  1.1530268174692996e+04
            Stop		  1.2720699152520576e+04
            Start		  1.4364798888090740e+04
            Stop		  1.5555229862698630e+04
            Start		  1.7199329601953083e+04
            Stop		  1.8389760571877898e+04
            Start		  2.0033860316084953e+04
            Stop		  2.1224291280074234e+04
            Start		  2.2868391030279869e+04
            Stop		  2.4058821987346972e+04
            Start		  2.5702921744328571e+04
            Stop		  2.6893352693795827e+04
            Start		  2.8537452458028183e+04
            Stop		  2.9727883399556675e+04
            Start		  3.1371983171191103e+04
            Stop		  3.2562414104795615e+04
            Start		  3.4206513883653344e+04
            Stop		  3.5396944809701701e+04
            Start		  3.7041044595281579e+04
            Stop		  3.8231475514478647e+04
            Start		  3.9875575305979110e+04
            Stop		  4.1066006219335861e+04
            Start		  4.2710106015690100e+04
            Stop		  4.3900536924479173e+04
            Start		  4.5544636724401957e+04
            Stop		  4.6735067630102021e+04
            Start		  4.8379167432145958e+04
            Stop		  4.9569598336376708e+04
            Start		  5.1213698138995831e+04
            Stop		  5.2404129043446992e+04
            Start		  5.4048228845064521e+04
            Stop		  5.5238659751421772e+04
            Start		  5.6882759550499257e+04
            Stop		  5.8073190460370228e+04
            Start		  5.9717290255475091e+04
            Stop		  6.0907721170318822e+04
            Start		  6.2551820960187171e+04
            Stop		  6.3742251881250246e+04
            Start		  6.5386351664842208e+04
            Stop		  6.6576782593103955e+04
            Start		  6.8220882369649349e+04
            Stop		  6.9411313305779055e+04
            Start		  7.1055413074811091e+04
            Stop		  7.2245844019138603e+04
            Start		  7.3889943780514426e+04
            Stop		  7.5080374733015589e+04
            Start		  7.6724474486922292e+04
            Stop		  7.7914905447220503e+04
            Start		  7.9559005194166923e+04
            Stop		  8.0749436161549369e+04
            Start		  8.2393535902343734e+04
            Stop		  8.3583966875792787e+04
            Start		  8.5228066611507107e+04
            Stop		  8.6400000000000000e+04
            Strand		 35 56
            Strand		 35 57
            Strand		 35 58
            Strand		 35 59
            Strand		 35 60
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 35 61
            Strand		 35 62
            Strand		 35 63
            Strand		 35 64
            Strand		 35 65
            Strand		 35 66
            Strand		 35 67
            Strand		 35 68
            Strand		 35 69
            Strand		 35 70
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
            BEGIN ShortText

            END ShortText
            BEGIN LongText

            END LongText
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #ff0000
                AnimationColor		 #00c4c4
                AnimationLineWidth		 2
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

