stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Receiver

    Name		 Receiver8
<?xml version = "1.0" standalone = "yes"?>
<SCOPE>
    <VAR name = "Model">
        <VAR name = "Complex_Receiver_Model">
            <SCOPE Class = "Receiver">
                <VAR name = "Version">
                    <STRING>&quot;1.0.0 a&quot;</STRING>
                </VAR>
                <VAR name = "ComponentName">
                    <STRING>&quot;Complex_Receiver_Model&quot;</STRING>
                </VAR>
                <VAR name = "Type">
                    <STRING>&quot;Complex Receiver Model&quot;</STRING>
                </VAR>
                <VAR name = "AutoSelectDemodulator">
                    <BOOL>true</BOOL>
                </VAR>
                <VAR name = "Demodulator">
                    <VAR name = "BPSK">
                        <SCOPE Class = "Demodulator">
                            <VAR name = "Version">
                                <STRING>&quot;1.0.0 a&quot;</STRING>
                            </VAR>
                            <VAR name = "ComponentName">
                                <STRING>&quot;BPSK&quot;</STRING>
                            </VAR>
                            <VAR name = "Type">
                                <STRING>&quot;BPSK&quot;</STRING>
                            </VAR>
                        </SCOPE>
                    </VAR>
                </VAR>
                <VAR name = "UseFilter">
                    <BOOL>false</BOOL>
                </VAR>
                <VAR name = "Filter">
                    <VAR name = "Butterworth">
                        <SCOPE Class = "Filter">
                            <VAR name = "Version">
                                <STRING>&quot;1.0.0 a&quot;</STRING>
                            </VAR>
                            <VAR name = "ComponentName">
                                <STRING>&quot;Butterworth&quot;</STRING>
                            </VAR>
                            <VAR name = "Type">
                                <STRING>&quot;Butterworth&quot;</STRING>
                            </VAR>
                            <VAR name = "LowerBandwidthLimit">
                                <QUANTITY Dimension = "BandwidthUnit" Unit = "Hz">
                                    <REAL>-20000000</REAL>
                                </QUANTITY>
                            </VAR>
                            <VAR name = "UpperBandwidthLimit">
                                <QUANTITY Dimension = "BandwidthUnit" Unit = "Hz">
                                    <REAL>20000000</REAL>
                                </QUANTITY>
                            </VAR>
                            <VAR name = "InsertionLoss">
                                <QUANTITY Dimension = "RatioUnit" Unit = "units">
                                    <REAL>1</REAL>
                                </QUANTITY>
                            </VAR>
                            <VAR name = "Order">
                                <INT>4</INT>
                            </VAR>
                            <VAR name = "CutoffFrequency">
                                <QUANTITY Dimension = "BandwidthUnit" Unit = "Hz">
                                    <REAL>10000000</REAL>
                                </QUANTITY>
                            </VAR>
                        </SCOPE>
                    </VAR>
                </VAR>
                <VAR name = "Bandwidth">
                    <QUANTITY Dimension = "BandwidthUnit" Unit = "Hz">
                        <REAL>2000</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "AutoScaleBandwidth">
                    <BOOL>true</BOOL>
                </VAR>
                <VAR name = "PreReceiveGainsLosses">
                    <SCOPE>
                        <VAR name = "GainLossList">
                            <LIST />
                        </VAR>
                    </SCOPE>
                </VAR>
                <VAR name = "PreDemodGainsLosses">
                    <SCOPE>
                        <VAR name = "GainLossList">
                            <LIST />
                        </VAR>
                    </SCOPE>
                </VAR>
                <VAR name = "EnableLinkMargin">
                    <BOOL>false</BOOL>
                </VAR>
                <VAR name = "LinkMarginType">
                    <STRING>&quot;Eb/No&quot;</STRING>
                </VAR>
                <VAR name = "LinkMarginThreshold">
                    <QUANTITY Dimension = "RatioUnit" Unit = "units">
                        <REAL>1</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "RainOutagePercent">
                    <PROP name = "FormatString">
                        <STRING>&quot;%#6.3f&quot;</STRING>
                    </PROP>
                    <REAL>0.1</REAL>
                </VAR>
                <VAR name = "UseRain">
                    <BOOL>true</BOOL>
                </VAR>
                <VAR name = "AntennaControl">
                    <SCOPE>
                        <VAR name = "AntennaReferenceType">
                            <STRING>&quot;Embed&quot;</STRING>
                        </VAR>
                        <VAR name = "Antenna">
                            <VAR name = "Parabolic">
                                <SCOPE Class = "Antenna">
                                    <VAR name = "Version">
                                        <STRING>&quot;1.0.0 a&quot;</STRING>
                                    </VAR>
                                    <VAR name = "ComponentName">
                                        <STRING>&quot;Parabolic&quot;</STRING>
                                    </VAR>
                                    <VAR name = "Type">
                                        <STRING>&quot;Parabolic&quot;</STRING>
                                    </VAR>
                                    <VAR name = "DesignFrequency">
                                        <QUANTITY Dimension = "FrequencyUnit" Unit = "Hz">
                                            <REAL>14500000000</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "InputType">
                                        <STRING>&quot;Use Main-lobe Gain&quot;</STRING>
                                    </VAR>
                                    <VAR name = "Diameter">
                                        <QUANTITY Dimension = "SmallDistanceUnit" Unit = "m">
                                            <REAL>1.511241889982867</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "MainlobeGain">
                                        <QUANTITY Dimension = "RatioUnit" Unit = "units">
                                            <REAL>29001.80312047859</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "Beamwidth">
                                        <QUANTITY Dimension = "AngleUnit" Unit = "rad">
                                            <REAL>0.01407781110150462</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "BacklobeGain">
                                        <QUANTITY Dimension = "RatioUnit" Unit = "units">
                                            <REAL>0.001</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "UseAsMainlobeAttenuation">
                                        <BOOL>false</BOOL>
                                    </VAR>
                                    <VAR name = "Efficiency">
                                        <QUANTITY Dimension = "Percent" Unit = "unitValue">
                                            <REAL>0.55</REAL>
                                        </QUANTITY>
                                    </VAR>
                                </SCOPE>
                            </VAR>
                        </VAR>
                        <VAR name = "UsePolarization">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "Polarization">
                            <VAR name = "Linear">
                                <SCOPE Class = "Polarization">
                                    <VAR name = "ReferenceAxis">
                                        <STRING>&quot;X Axis&quot;</STRING>
                                    </VAR>
                                    <VAR name = "TiltAngle">
                                        <QUANTITY Dimension = "AngleUnit" Unit = "rad">
                                            <REAL>0</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "CrossPolLeakage">
                                        <QUANTITY Dimension = "RatioUnit" Unit = "units">
                                            <REAL>1e-06</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "Type">
                                        <STRING>&quot;Linear&quot;</STRING>
                                    </VAR>
                                </SCOPE>
                            </VAR>
                        </VAR>
                        <VAR name = "Orientation">
                            <VAR name = "Azimuth Elevation">
                                <SCOPE Class = "Orientation">
                                    <VAR name = "AzimuthAngle">
                                        <QUANTITY Dimension = "AngleUnit" Unit = "rad">
                                            <REAL>0</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "ElevationAngle">
                                        <QUANTITY Dimension = "AngleUnit" Unit = "rad">
                                            <REAL>1.570796326794897</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "AboutBoresight">
                                        <STRING>&quot;Rotate&quot;</STRING>
                                    </VAR>
                                    <VAR name = "Type">
                                        <STRING>&quot;Azimuth Elevation&quot;</STRING>
                                    </VAR>
                                    <VAR name = "XPositionOffset">
                                        <QUANTITY Dimension = "SmallDistanceUnit" Unit = "m">
                                            <REAL>0</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "YPositionOffset">
                                        <QUANTITY Dimension = "SmallDistanceUnit" Unit = "m">
                                            <REAL>0</REAL>
                                        </QUANTITY>
                                    </VAR>
                                    <VAR name = "ZPositionOffset">
                                        <QUANTITY Dimension = "SmallDistanceUnit" Unit = "m">
                                            <REAL>0</REAL>
                                        </QUANTITY>
                                    </VAR>
                                </SCOPE>
                            </VAR>
                        </VAR>
                    </SCOPE>
                </VAR>
                <VAR name = "ComputeSystemNoiseTemp">
                    <STRING>&quot;Constant&quot;</STRING>
                </VAR>
                <VAR name = "ConstantSystemNoiseTemp">
                    <QUANTITY Dimension = "Temperature" Unit = "K">
                        <REAL>290</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "ANT2LNALineLoss">
                    <QUANTITY Dimension = "RatioUnit" Unit = "units">
                        <REAL>1</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "ANT2LNALineTemperature">
                    <QUANTITY Dimension = "Temperature" Unit = "K">
                        <REAL>290</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "LNA2RcvrLineLoss">
                    <QUANTITY Dimension = "RatioUnit" Unit = "units">
                        <REAL>1</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "LNA2RcvrLineTemperature">
                    <QUANTITY Dimension = "Temperature" Unit = "K">
                        <REAL>290</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "LNAGain">
                    <QUANTITY Dimension = "RatioUnit" Unit = "units">
                        <REAL>1</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "LNANoiseFigure">
                    <QUANTITY Dimension = "RatioUnit" Unit = "units">
                        <REAL>1.258925411794167</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "LNATemperature">
                    <QUANTITY Dimension = "Temperature" Unit = "K">
                        <REAL>290</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "Frequency">
                    <QUANTITY Dimension = "FrequencyUnit" Unit = "Hz">
                        <REAL>14500000000</REAL>
                    </QUANTITY>
                </VAR>
                <VAR name = "FrequencyAutoTracking">
                    <BOOL>true</BOOL>
                </VAR>
                <VAR name = "AntennaNoise">
                    <SCOPE>
                        <VAR name = "ComputeOption">
                            <STRING>&quot;Constant&quot;</STRING>
                        </VAR>
                        <VAR name = "ComputeRainNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeAtmosAbsorpNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeUrbanTerrestrialNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeCloudsFogNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeTropoScintNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeIonoFadingNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeSunNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeEarthNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeCosmicNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "ComputeExternalNoise">
                            <BOOL>false</BOOL>
                        </VAR>
                        <VAR name = "InheritScenarioEarthTemperature">
                            <BOOL>true</BOOL>
                        </VAR>
                        <VAR name = "LocalEarthTemperature">
                            <QUANTITY Dimension = "Temperature" Unit = "K">
                                <REAL>290</REAL>
                            </QUANTITY>
                        </VAR>
                        <VAR name = "ConstantNoiseTemp">
                            <QUANTITY Dimension = "Temperature" Unit = "K">
                                <REAL>290</REAL>
                            </QUANTITY>
                        </VAR>
                        <VAR name = "OtherNoiseTemp">
                            <QUANTITY Dimension = "Temperature" Unit = "K">
                                <REAL>0</REAL>
                            </QUANTITY>
                        </VAR>
                    </SCOPE>
                </VAR>
            </SCOPE>
        </VAR>
    </VAR>
</SCOPE>
END Receiver

BEGIN Extensions

    BEGIN ExternData
    END ExternData

    BEGIN ADFFileData
    END ADFFileData

    BEGIN AccessConstraints
        LineOfSight IncludeIntervals

        UsePreferredMaxStep No
        PreferredMaxStep 360
    END AccessConstraints

    BEGIN ObjectCoverage
    END ObjectCoverage

    BEGIN Desc
    END Desc

    BEGIN Refraction
        RefractionModel		 Effective Radius Method

        UseRefractionInAccess		 No

        BEGIN ModelData
            RefractionCeiling		  5.0000000000000000e+03
            MaxTargetAltitude		  1.0000000000000000e+04
            EffectiveRadius		  1.3333333333333299e+00

            UseExtrapolation		 Yes


        END ModelData
    END Refraction

    BEGIN Crdn
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility1
            Description		 Displacement vector to Facility1
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 ../../
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility1-Receiver1
            Description		 Displacement vector to Facility1-Receiver1
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 ../../Receiver/Receiver1
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility1-Sensor1
            Description		 Displacement vector to Facility1-Sensor1
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 ../
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility1-Sensor1-Receiver8
            Description		 Displacement vector to Facility1-Sensor1-Receiver8
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility2
            Description		 Displacement vector to Facility2
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Facility/Facility2
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility2-Receiver2
            Description		 Displacement vector to Facility2-Receiver2
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Facility/Facility2/Receiver/Receiver2
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility5
            Description		 Displacement vector to Facility5
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Facility/Facility5
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Facility5-Receiver7
            Description		 Displacement vector to Facility5-Receiver7
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Facility/Facility5/Receiver/Receiver7
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO11
            Description		 Displacement vector to LEO11
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO11
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO11-Receiver3
            Description		 Displacement vector to LEO11-Receiver3
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO11/Receiver/Receiver3
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO11-Transmitter3
            Description		 Displacement vector to LEO11-Transmitter3
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO11/Transmitter/Transmitter3
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO12
            Description		 Displacement vector to LEO12
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO12
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO12-Receiver4
            Description		 Displacement vector to LEO12-Receiver4
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO12/Receiver/Receiver4
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO12-Transmitter4
            Description		 Displacement vector to LEO12-Transmitter4
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO12/Transmitter/Transmitter4
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO13
            Description		 Displacement vector to LEO13
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO13
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO13-Receiver5
            Description		 Displacement vector to LEO13-Receiver5
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO13/Receiver/Receiver5
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO13-Transmitter5
            Description		 Displacement vector to LEO13-Transmitter5
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO13/Transmitter/Transmitter5
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO14
            Description		 Displacement vector to LEO14
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO14
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO14-Receiver6
            Description		 Displacement vector to LEO14-Receiver6
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO14/Receiver/Receiver6
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO14-Transmitter6
            Description		 Displacement vector to LEO14-Transmitter6
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO14/Transmitter/Transmitter6
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO15
            Description		 Displacement vector to LEO15
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO15
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO15-Receiver9
            Description		 Displacement vector to LEO15-Receiver9
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO15/Receiver/Receiver9
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO15-Transmitter7
            Description		 Displacement vector to LEO15-Transmitter7
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO15/Transmitter/Transmitter7
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO16
            Description		 Displacement vector to LEO16
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO16
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO16-Receiver10
            Description		 Displacement vector to LEO16-Receiver10
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO16/Receiver/Receiver10
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO16-Transmitter8
            Description		 Displacement vector to LEO16-Transmitter8
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO16/Transmitter/Transmitter8
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO21
            Description		 Displacement vector to LEO21
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO21
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO21-Receiver11
            Description		 Displacement vector to LEO21-Receiver11
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO21/Receiver/Receiver11
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO21-Transmitter9
            Description		 Displacement vector to LEO21-Transmitter9
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO21/Transmitter/Transmitter9
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO22
            Description		 Displacement vector to LEO22
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO22
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO22-Receiver12
            Description		 Displacement vector to LEO22-Receiver12
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO22/Receiver/Receiver12
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO22-Transmitter12
            Description		 Displacement vector to LEO22-Transmitter12
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO22/Transmitter/Transmitter12
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO23
            Description		 Displacement vector to LEO23
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO23
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO23-Receiver13
            Description		 Displacement vector to LEO23-Receiver13
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO23/Receiver/Receiver13
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO23-Transmitter13
            Description		 Displacement vector to LEO23-Transmitter13
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO23/Transmitter/Transmitter13
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO24
            Description		 Displacement vector to LEO24
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO24
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO24-Receiver14
            Description		 Displacement vector to LEO24-Receiver14
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO24/Receiver/Receiver14
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO24-Transmitter14
            Description		 Displacement vector to LEO24-Transmitter14
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO24/Transmitter/Transmitter14
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO25
            Description		 Displacement vector to LEO25
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO25
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO25-Receiver15
            Description		 Displacement vector to LEO25-Receiver15
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO25/Receiver/Receiver15
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO25-Transmitter15
            Description		 Displacement vector to LEO25-Transmitter15
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO25/Transmitter/Transmitter15
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO26
            Description		 Displacement vector to LEO26
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO26
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO26-Receiver16
            Description		 Displacement vector to LEO26-Receiver16
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO26/Receiver/Receiver16
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO26-Transmitter16
            Description		 Displacement vector to LEO26-Transmitter16
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO26/Transmitter/Transmitter16
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO31
            Description		 Displacement vector to LEO31
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO31
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO31-Receiver17
            Description		 Displacement vector to LEO31-Receiver17
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO31/Receiver/Receiver17
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO31-Transmitter17
            Description		 Displacement vector to LEO31-Transmitter17
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO31/Transmitter/Transmitter17
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO32
            Description		 Displacement vector to LEO32
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO32
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO32-Receiver18
            Description		 Displacement vector to LEO32-Receiver18
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO32/Receiver/Receiver18
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO32-Transmitter18
            Description		 Displacement vector to LEO32-Transmitter18
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO32/Transmitter/Transmitter18
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO33
            Description		 Displacement vector to LEO33
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO33
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO33-Receiver19
            Description		 Displacement vector to LEO33-Receiver19
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO33/Receiver/Receiver19
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO33-Transmitter19
            Description		 Displacement vector to LEO33-Transmitter19
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO33/Transmitter/Transmitter19
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO34
            Description		 Displacement vector to LEO34
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO34
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO34-Receiver20
            Description		 Displacement vector to LEO34-Receiver20
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO34/Receiver/Receiver20
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO34-Transmitter20
            Description		 Displacement vector to LEO34-Transmitter20
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO34/Transmitter/Transmitter20
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO35
            Description		 Displacement vector to LEO35
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO35
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO35-Receiver21
            Description		 Displacement vector to LEO35-Receiver21
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO35/Receiver/Receiver21
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO35-Transmitter21
            Description		 Displacement vector to LEO35-Transmitter21
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO35/Transmitter/Transmitter21
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO36
            Description		 Displacement vector to LEO36
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO36
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO36-Receiver22
            Description		 Displacement vector to LEO36-Receiver22
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO36/Receiver/Receiver22
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO36-Transmitter22
            Description		 Displacement vector to LEO36-Transmitter22
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO36/Transmitter/Transmitter22
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO41
            Description		 Displacement vector to LEO41
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO41
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO41-Receiver23
            Description		 Displacement vector to LEO41-Receiver23
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO41/Receiver/Receiver23
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO41-Transmitter23
            Description		 Displacement vector to LEO41-Transmitter23
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO41/Transmitter/Transmitter23
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO42
            Description		 Displacement vector to LEO42
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO42
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO42-Receiver24
            Description		 Displacement vector to LEO42-Receiver24
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO42/Receiver/Receiver24
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO42-Transmitter24
            Description		 Displacement vector to LEO42-Transmitter24
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO42/Transmitter/Transmitter24
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO43
            Description		 Displacement vector to LEO43
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO43
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO43-Receiver25
            Description		 Displacement vector to LEO43-Receiver25
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO43/Receiver/Receiver25
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO43-Transmitter25
            Description		 Displacement vector to LEO43-Transmitter25
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO43/Transmitter/Transmitter25
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO44
            Description		 Displacement vector to LEO44
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO44
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO44-Receiver26
            Description		 Displacement vector to LEO44-Receiver26
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO44/Receiver/Receiver26
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO44-Transmitter26
            Description		 Displacement vector to LEO44-Transmitter26
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO44/Transmitter/Transmitter26
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO45
            Description		 Displacement vector to LEO45
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO45
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO45-Receiver27
            Description		 Displacement vector to LEO45-Receiver27
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO45/Receiver/Receiver27
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO45-Transmitter27
            Description		 Displacement vector to LEO45-Transmitter27
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO45/Transmitter/Transmitter27
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO46
            Description		 Displacement vector to LEO46
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO46
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO46-Receiver28
            Description		 Displacement vector to LEO46-Receiver28
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO46/Receiver/Receiver28
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO46-Transmitter28
            Description		 Displacement vector to LEO46-Transmitter28
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO46/Transmitter/Transmitter28
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO51
            Description		 Displacement vector to LEO51
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO51
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO51-Receiver29
            Description		 Displacement vector to LEO51-Receiver29
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO51/Receiver/Receiver29
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO51-Transmitter29
            Description		 Displacement vector to LEO51-Transmitter29
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO51/Transmitter/Transmitter29
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO52
            Description		 Displacement vector to LEO52
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO52
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO52-Receiver30
            Description		 Displacement vector to LEO52-Receiver30
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO52/Receiver/Receiver30
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO52-Transmitter30
            Description		 Displacement vector to LEO52-Transmitter30
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO52/Transmitter/Transmitter30
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO53
            Description		 Displacement vector to LEO53
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO53
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO53-Receiver31
            Description		 Displacement vector to LEO53-Receiver31
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO53/Receiver/Receiver31
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO53-Transmitter31
            Description		 Displacement vector to LEO53-Transmitter31
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO53/Transmitter/Transmitter31
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO54
            Description		 Displacement vector to LEO54
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO54
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO54-Receiver32
            Description		 Displacement vector to LEO54-Receiver32
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO54/Receiver/Receiver32
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO54-Transmitter32
            Description		 Displacement vector to LEO54-Transmitter32
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO54/Transmitter/Transmitter32
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO55
            Description		 Displacement vector to LEO55
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO55
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO55-Receiver33
            Description		 Displacement vector to LEO55-Receiver33
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO55/Receiver/Receiver33
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO55-Transmitter33
            Description		 Displacement vector to LEO55-Transmitter33
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO55/Transmitter/Transmitter33
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO56
            Description		 Displacement vector to LEO56
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO56
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO56-Receiver34
            Description		 Displacement vector to LEO56-Receiver34
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO56/Receiver/Receiver34
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO56-Transmitter34
            Description		 Displacement vector to LEO56-Transmitter34
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO56/Transmitter/Transmitter34
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO61
            Description		 Displacement vector to LEO61
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO61
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO61-Receiver35
            Description		 Displacement vector to LEO61-Receiver35
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO61/Receiver/Receiver35
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO61-Transmitter35
            Description		 Displacement vector to LEO61-Transmitter35
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO61/Transmitter/Transmitter35
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO62
            Description		 Displacement vector to LEO62
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO62
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO62-Receiver36
            Description		 Displacement vector to LEO62-Receiver36
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO62/Receiver/Receiver36
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO62-Transmitter36
            Description		 Displacement vector to LEO62-Transmitter36
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO62/Transmitter/Transmitter36
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO63
            Description		 Displacement vector to LEO63
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO63
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO63-Receiver37
            Description		 Displacement vector to LEO63-Receiver37
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO63/Receiver/Receiver37
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO63-Transmitter37
            Description		 Displacement vector to LEO63-Transmitter37
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO63/Transmitter/Transmitter37
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO64
            Description		 Displacement vector to LEO64
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO64
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO64-Receiver38
            Description		 Displacement vector to LEO64-Receiver38
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO64/Receiver/Receiver38
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO64-Transmitter38
            Description		 Displacement vector to LEO64-Transmitter38
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO64/Transmitter/Transmitter38
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO65
            Description		 Displacement vector to LEO65
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO65
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO65-Receiver39
            Description		 Displacement vector to LEO65-Receiver39
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO65/Receiver/Receiver39
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO65-Transmitter39
            Description		 Displacement vector to LEO65-Transmitter39
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO65/Transmitter/Transmitter39
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO66
            Description		 Displacement vector to LEO66
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO66
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO66-Receiver40
            Description		 Displacement vector to LEO66-Receiver40
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO66/Receiver/Receiver40
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 LEO66-Transmitter40
            Description		 Displacement vector to LEO66-Transmitter40
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Satellite/LEO66/Transmitter/Transmitter40
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target1
            Description		 Displacement vector to Target1
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target1
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target1-Transmitter1
            Description		 Displacement vector to Target1-Transmitter1
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target1/Transmitter/Transmitter1
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target2
            Description		 Displacement vector to Target2
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target2
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target2-Transmitter10
            Description		 Displacement vector to Target2-Transmitter10
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target2/Transmitter/Transmitter10
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target3
            Description		 Displacement vector to Target3
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target3
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
        BEGIN VECTOR
            Type		 VECTOR_TOVECTOR
            Name		 Target3-Transmitter2
            Description		 Displacement vector to Target3-Transmitter2
            Origin		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
            END POINT
            Destination		
            BEGIN POINT
                Type		 POINT_LINKTO
                Name		 Center
                RelativePath		 Target/Target3/Transmitter/Transmitter2
            END POINT
            LTDRefSystem		
            BEGIN SYSTEM
                Type		 SYSTEM_LINKTO
                Name		 BarycenterICRF
                AbsolutePath		 CentralBody/Sun
            END SYSTEM
            Apparent		 No
            TimeConvergence		  1.0000000000000000e-03
            TimeSense		 Receive
            IgnoreAberration		 No
        END VECTOR
    END Crdn

    BEGIN Graphics

        BEGIN Graphics

            ShowGfx		 On
            Relative		 Off
            ShowBoresight		 On
            BoresightMarker		 4
            BoresightColor		 #ffffff

        END Graphics

        BEGIN DisplayTimes
            DisplayType		 AlwaysOn
        END DisplayTimes
    END Graphics

    BEGIN ContourGfx
        ShowContours		 Off
    END ContourGfx

    BEGIN Contours
        ActiveContourType		 Antenna Gain

        BEGIN ContourSet Antenna Gain
            Altitude		 0
            ShowAtAltitude		 Off
            Projected		 On
            Relative		 On
            ShowLabels		 Off
            LineWidth		 1
            DecimalDigits		 1
            ColorRamp		 On
            ColorRampStartColor		 #0000ff
            ColorRampEndColor		 #ff0000
            BEGIN ContourDefinition
                BEGIN CntrAntAzEl
                    CoordinateSystem		 0
                    BEGIN AzElPatternDef
                        SetResolutionTogether		 0
                        NumAzPoints		 181
                        AzimuthRes		 2
                        MinAzimuth		 -180
                        MaxAzimuth		 180
                        NumElPoints		 91
                        ElevationRes		 1
                        MinElevation		 0
                        MaxElevation		 90
                    END AzElPatternDef
                END CntrAntAzEl
            END ContourDefinition
        END ContourSet
    END Contours

    BEGIN VO
    END VO

    BEGIN 3dVolume
        ActiveVolumeType		 Antenna Beam

        BEGIN VolumeSet Antenna Beam
            Scale		 100
            MinimumDisplayedGain		 1
            Frequency		 14500000000
            ShowAsWireframe		 0
            CoordinateSystem		 0
            BEGIN AzElPatternDef
                SetResolutionTogether		 1
                NumAzPoints		 361
                AzimuthRes		 1
                MinAzimuth		 -180
                MaxAzimuth		 180
                NumElPoints		 91
                ElevationRes		 1
                MinElevation		 0
                MaxElevation		 90
            END AzElPatternDef
            ColorMethod		 1
            MinToMaxStartColor		 #ff0000
            MinToMaxStopColor		 #0000ff
            RelativeToMaximum		 0
        END VolumeSet
        BEGIN VolumeGraphics
            ShowContours		 No
            ShowVolume		 Yes
        END VolumeGraphics
    END 3dVolume

END Extensions
