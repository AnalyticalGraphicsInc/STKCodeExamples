stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Chain

    Name		 SecondToFirst
    BEGIN Definition

        Object		 Constellation/SatTrans
        Object		 Constellation/SatRec
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 No
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 86400
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 15 Jun 2020 19:00:00.000000000
                Stop		 16 Jun 2020 19:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        SaveIntervalFile		 C:\Users\aclaybrook\Documents\STK 12\ConstellationAnalysisScenarios\TransRecTest\strand.int
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        BEGIN StrandObjIndexes
            StrandObj		 Satellite/LEO11/Transmitter/Transmitter3
            StrandObj		 Satellite/LEO12/Transmitter/Transmitter4
            StrandObj		 Satellite/LEO13/Transmitter/Transmitter5
            StrandObj		 Satellite/LEO14/Transmitter/Transmitter6
            StrandObj		 Satellite/LEO15/Transmitter/Transmitter7
            StrandObj		 Satellite/LEO16/Transmitter/Transmitter8
            StrandObj		 Satellite/LEO21/Transmitter/Transmitter9
            StrandObj		 Satellite/LEO22/Transmitter/Transmitter12
            StrandObj		 Satellite/LEO23/Transmitter/Transmitter13
            StrandObj		 Satellite/LEO24/Transmitter/Transmitter14
            StrandObj		 Satellite/LEO25/Transmitter/Transmitter15
            StrandObj		 Satellite/LEO26/Transmitter/Transmitter16
            StrandObj		 Satellite/LEO31/Transmitter/Transmitter17
            StrandObj		 Satellite/LEO32/Transmitter/Transmitter18
            StrandObj		 Satellite/LEO33/Transmitter/Transmitter19
            StrandObj		 Satellite/LEO34/Transmitter/Transmitter20
            StrandObj		 Satellite/LEO35/Transmitter/Transmitter21
            StrandObj		 Satellite/LEO36/Transmitter/Transmitter22
            StrandObj		 Satellite/LEO41/Transmitter/Transmitter23
            StrandObj		 Satellite/LEO42/Transmitter/Transmitter24
            StrandObj		 Satellite/LEO43/Transmitter/Transmitter25
            StrandObj		 Satellite/LEO44/Transmitter/Transmitter26
            StrandObj		 Satellite/LEO45/Transmitter/Transmitter27
            StrandObj		 Satellite/LEO46/Transmitter/Transmitter28
            StrandObj		 Satellite/LEO51/Transmitter/Transmitter29
            StrandObj		 Satellite/LEO52/Transmitter/Transmitter30
            StrandObj		 Satellite/LEO53/Transmitter/Transmitter31
            StrandObj		 Satellite/LEO54/Transmitter/Transmitter32
            StrandObj		 Satellite/LEO55/Transmitter/Transmitter33
            StrandObj		 Satellite/LEO56/Transmitter/Transmitter34
            StrandObj		 Satellite/LEO61/Transmitter/Transmitter35
            StrandObj		 Satellite/LEO62/Transmitter/Transmitter36
            StrandObj		 Satellite/LEO63/Transmitter/Transmitter37
            StrandObj		 Satellite/LEO64/Transmitter/Transmitter38
            StrandObj		 Satellite/LEO65/Transmitter/Transmitter39
            StrandObj		 Satellite/LEO66/Transmitter/Transmitter40
            StrandObj		 Satellite/LEO11/Receiver/Receiver3
            StrandObj		 Satellite/LEO12/Receiver/Receiver4
            StrandObj		 Satellite/LEO13/Receiver/Receiver5
            StrandObj		 Satellite/LEO14/Receiver/Receiver6
            StrandObj		 Satellite/LEO15/Receiver/Receiver9
            StrandObj		 Satellite/LEO16/Receiver/Receiver10
            StrandObj		 Satellite/LEO21/Receiver/Receiver11
            StrandObj		 Satellite/LEO22/Receiver/Receiver12
            StrandObj		 Satellite/LEO23/Receiver/Receiver13
            StrandObj		 Satellite/LEO24/Receiver/Receiver14
            StrandObj		 Satellite/LEO25/Receiver/Receiver15
            StrandObj		 Satellite/LEO26/Receiver/Receiver16
            StrandObj		 Satellite/LEO31/Receiver/Receiver17
            StrandObj		 Satellite/LEO32/Receiver/Receiver18
            StrandObj		 Satellite/LEO33/Receiver/Receiver19
            StrandObj		 Satellite/LEO34/Receiver/Receiver20
            StrandObj		 Satellite/LEO35/Receiver/Receiver21
            StrandObj		 Satellite/LEO36/Receiver/Receiver22
            StrandObj		 Satellite/LEO41/Receiver/Receiver23
            StrandObj		 Satellite/LEO42/Receiver/Receiver24
            StrandObj		 Satellite/LEO43/Receiver/Receiver25
            StrandObj		 Satellite/LEO44/Receiver/Receiver26
            StrandObj		 Satellite/LEO45/Receiver/Receiver27
            StrandObj		 Satellite/LEO46/Receiver/Receiver28
            StrandObj		 Satellite/LEO51/Receiver/Receiver29
            StrandObj		 Satellite/LEO52/Receiver/Receiver30
            StrandObj		 Satellite/LEO53/Receiver/Receiver31
            StrandObj		 Satellite/LEO54/Receiver/Receiver32
            StrandObj		 Satellite/LEO55/Receiver/Receiver33
            StrandObj		 Satellite/LEO56/Receiver/Receiver34
            StrandObj		 Satellite/LEO61/Receiver/Receiver35
            StrandObj		 Satellite/LEO62/Receiver/Receiver36
            StrandObj		 Satellite/LEO63/Receiver/Receiver37
            StrandObj		 Satellite/LEO64/Receiver/Receiver38
            StrandObj		 Satellite/LEO65/Receiver/Receiver39
            StrandObj		 Satellite/LEO66/Receiver/Receiver40
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 37
            Strand		 0 38
            Strand		 0 39
            Strand		 0 40
            Strand		 0 41
            Strand		 0 42
            Strand		 0 43
            Strand		 0 44
            Strand		 0 45
            Strand		 0 46
            Strand		 0 47
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 0 48
            Strand		 0 49
            Strand		 0 50
            Strand		 0 51
            Strand		 0 52
            Start		  1.6094145343278035e+03
            Stop		  2.7998371357176029e+03
            Start		  4.4439461440982186e+03
            Stop		  5.6343717598112089e+03
            Start		  7.2784728638444694e+03
            Stop		  8.4689023552105446e+03
            Start		  1.0113003537396811e+04
            Stop		  1.1303433066623893e+04
            Start		  1.2947534244143522e+04
            Stop		  1.4137963774717951e+04
            Start		  1.5782064949402264e+04
            Stop		  1.6972494484021114e+04
            Start		  1.8616595654341305e+04
            Stop		  1.9807025194310179e+04
            Start		  2.1451126359111855e+04
            Stop		  2.2641555905558740e+04
            Start		  2.4285657063925868e+04
            Stop		  2.5476086617686007e+04
            Start		  2.7120187768990596e+04
            Stop		  2.8310617330573219e+04
            Start		  2.9954718474502526e+04
            Stop		  3.1145148044068112e+04
            Start		  3.2789249180638471e+04
            Stop		  3.3979678757991780e+04
            Start		  3.5623779887547906e+04
            Stop		  3.6814209472146365e+04
            Start		  3.8458310595346302e+04
            Stop		  3.9648740186323914e+04
            Start		  4.1292841304110174e+04
            Stop		  4.2483270900315343e+04
            Start		  4.4127372013873661e+04
            Stop		  4.5317801613919786e+04
            Start		  4.6961902724626954e+04
            Stop		  4.8152332326953263e+04
            Start		  4.9796433436316867e+04
            Stop		  5.0986863039256918e+04
            Start		  5.2630964148849096e+04
            Stop		  5.3821393750703784e+04
            Start		  5.5465494862092339e+04
            Stop		  5.6655924461204566e+04
            Start		  5.8300025575884094e+04
            Stop		  5.9490455170711502e+04
            Start		  6.1134556290037784e+04
            Stop		  6.2324985879220345e+04
            Start		  6.3969087004351008e+04
            Stop		  6.5159516586770675e+04
            Start		  6.6803617718614289e+04
            Stop		  6.7994047293444179e+04
            Start		  6.9638148432620423e+04
            Stop		  7.0828577999361005e+04
            Start		  7.2472679146173527e+04
            Stop		  7.3663108704674392e+04
            Start		  7.5307209859097566e+04
            Stop		  7.6497639409564130e+04
            Start		  7.8141740571244183e+04
            Stop		  7.9332170114228546e+04
            Start		  8.0976271282499190e+04
            Stop		  8.2166700818875819e+04
            Start		  8.3810801992787528e+04
            Stop		  8.5001231523714945e+04
            Strand		 0 53
            Strand		 0 54
            Strand		 0 55
            Strand		 0 56
            Start		  0.0000000000000000e+00
            Stop		  6.6965530016261005e+02
            Start		  2.6372798841569675e+03
            Stop		  3.5041865919808515e+03
            Start		  5.4718115501907278e+03
            Stop		  6.3387166104280359e+03
            Start		  8.3063414733014306e+03
            Stop		  9.1732476195688869e+03
            Start		  1.1140872968714655e+04
            Stop		  1.2007777900248513e+04
            Start		  1.3975401633698722e+04
            Stop		  1.4842308849299288e+04
            Start		  1.6809934388834918e+04
            Stop		  1.7676839261193789e+04
            Start		  1.9644464929754031e+04
            Stop		  2.0511370201304133e+04
            Start		  2.2478995810406599e+04
            Stop		  2.3345900658278832e+04
            Start		  2.5313526086019359e+04
            Stop		  2.6180431596517876e+04
            Start		  2.8148057232997486e+04
            Stop		  2.9014962067995348e+04
            Start		  3.0982587421430486e+04
            Stop		  3.1849493005381384e+04
            Start		  3.3817118655977290e+04
            Stop		  3.4684023481328230e+04
            Start		  3.6651648815470711e+04
            Stop		  3.7518554418235333e+04
            Start		  3.9486180078640995e+04
            Stop		  4.0353084895564534e+04
            Start		  4.2320710228183008e+04
            Stop		  4.3187615832346535e+04
            Start		  4.5155241500336015e+04
            Stop		  4.6022146310289827e+04
            Start		  4.7989771646044115e+04
            Stop		  4.8856677247306026e+04
            Start		  5.0824302920577044e+04
            Stop		  5.1691207725835069e+04
            Start		  5.3658833064411665e+04
            Stop		  5.4525738663400771e+04
            Start		  5.6493364339130923e+04
            Stop		  5.7360269142665558e+04
            Start		  5.9327894481783485e+04
            Stop		  6.0194800080999798e+04
            Start		  6.2162425756057215e+04
            Stop		  6.3029330561115217e+04
            Start		  6.4996955897897307e+04
            Stop		  6.5863861500303348e+04
            Start		  6.7831487171697969e+04
            Stop		  6.8698391981267239e+04
            Start		  7.0666017313061981e+04
            Stop		  7.1532922921246354e+04
            Start		  7.3500548586618330e+04
            Stop		  7.4367453402919360e+04
            Start		  7.6335078727867745e+04
            Stop		  7.7201984343489210e+04
            Start		  7.9169610001508365e+04
            Stop		  8.0036514825612336e+04
            Start		  8.2004140143005512e+04
            Stop		  8.2871045766470095e+04
            Start		  8.4838671417063146e+04
            Stop		  8.5705576248707337e+04
            Strand		 0 57
            Start		  0.0000000000000000e+00
            Stop		  1.9722289945797996e+02
            Start		  2.1648677615133174e+03
            Stop		  3.0317538561456536e+03
            Start		  4.9994001929093392e+03
            Stop		  5.8662842293986014e+03
            Start		  7.8339309356063677e+03
            Stop		  8.7008151686506444e+03
            Start		  1.0668461612645311e+04
            Stop		  1.1535345612619831e+04
            Start		  1.3502991941219831e+04
            Stop		  1.4369876550338957e+04
            Start		  1.6337523030663244e+04
            Stop		  1.7204407018628383e+04
            Start		  1.9172053222872397e+04
            Stop		  2.0038937956906222e+04
            Start		  2.2006584447154168e+04
            Stop		  2.2873468433857764e+04
            Start		  2.4841114594060833e+04
            Stop		  2.5707999372947532e+04
            Start		  2.7675645862563419e+04
            Stop		  2.8542529853286138e+04
            Start		  3.0510175994396130e+04
            Stop		  3.1377060793095490e+04
            Start		  3.3344707277520953e+04
            Stop		  3.4211591274903978e+04
            Start		  3.6179237404514126e+04
            Stop		  3.7046122215190524e+04
            Start		  3.9013768692734229e+04
            Stop		  3.9880652697602054e+04
            Start		  4.1848298818498100e+04
            Stop		  4.2715183638036870e+04
            Start		  4.4682830108866219e+04
            Stop		  4.5549714120511526e+04
            Start		  4.7517360234757689e+04
            Stop		  4.8384245060739166e+04
            Start		  5.0351891526420375e+04
            Stop		  5.1218775542868752e+04
            Start		  5.3186421652958656e+04
            Stop		  5.4053306482569482e+04
            Start		  5.6020952945653313e+04
            Stop		  5.6887836964052840e+04
            Start		  5.8855483072975592e+04
            Stop		  5.9722367902998289e+04
            Start		  6.1690014366530209e+04
            Stop		  6.2556898383662003e+04
            Start		  6.4524544494548340e+04
            Stop		  6.5391429321754884e+04
            Start		  6.7359075788730872e+04
            Stop		  6.8225959801573015e+04
            Start		  7.0193605917206354e+04
            Stop		  7.1060490738863984e+04
            Start		  7.3028137211705369e+04
            Stop		  7.3895021217959089e+04
            Start		  7.5862667340310436e+04
            Stop		  7.6729552154638106e+04
            Start		  7.8697198634769622e+04
            Stop		  7.9564082633258702e+04
            Start		  8.1531728763150779e+04
            Stop		  8.2398613569621797e+04
            Start		  8.4366260057224150e+04
            Stop		  8.5233144048099071e+04
            Strand		 0 58
            Strand		 0 59
            Strand		 0 60
            Strand		 0 61
            Start		  3.4676244816461093e+01
            Stop		  1.2251025081380606e+03
            Start		  2.8692021993155281e+03
            Stop		  4.0596330610159312e+03
            Start		  5.7037328223071572e+03
            Stop		  6.8941637797996191e+03
            Start		  8.5382635304681171e+03
            Stop		  9.7286944938098623e+03
            Start		  1.1372794238492985e+04
            Stop		  1.2563225208009930e+04
            Start		  1.4207324947557143e+04
            Stop		  1.5397755921925789e+04
            Start		  1.7041855657617962e+04
            Stop		  1.8232286635376357e+04
            Start		  1.9876386368650234e+04
            Stop		  2.1066817348186705e+04
            Start		  2.2710917080582960e+04
            Stop		  2.3901348060210606e+04
            Start		  2.5545447793305702e+04
            Stop		  2.6735878771336393e+04
            Start		  2.8379978506673258e+04
            Stop		  2.9570409481491864e+04
            Start		  3.1214509220512096e+04
            Stop		  3.2404940190647416e+04
            Start		  3.4049039934627952e+04
            Stop		  3.5239470898817410e+04
            Start		  3.6883570648814326e+04
            Stop		  3.8074001606059443e+04
            Start		  3.9718101362861620e+04
            Stop		  4.0908532312471878e+04
            Start		  4.2552632076566297e+04
            Stop		  4.3743063018189569e+04
            Start		  4.5387162789739814e+04
            Stop		  4.6577593723377831e+04
            Start		  4.8221693502216935e+04
            Stop		  4.9412124428225288e+04
            Start		  5.1056224213862952e+04
            Stop		  5.2246655132935528e+04
            Start		  5.3890754924579625e+04
            Stop		  5.5081185837718149e+04
            Start		  5.6725285634309475e+04
            Stop		  5.7915716542779643e+04
            Start		  5.9559816343038321e+04
            Stop		  6.0750247248314190e+04
            Start		  6.2394347050795936e+04
            Stop		  6.3584777954495308e+04
            Start		  6.5228877757654642e+04
            Stop		  6.6419308661468051e+04
            Start		  6.8063408463726257e+04
            Stop		  6.9253839369342764e+04
            Start		  7.0897939169157078e+04
            Stop		  7.2088370078190244e+04
            Start		  7.3732469874121554e+04
            Stop		  7.4922900788038445e+04
            Start		  7.6567000578814506e+04
            Stop		  7.7757431498871621e+04
            Start		  7.9401531283442731e+04
            Stop		  8.0591962210630591e+04
            Start		  8.2236061988215719e+04
            Stop		  8.3426492923215570e+04
            Start		  8.5070592693336701e+04
            Stop		  8.6261023970370239e+04
            Strand		 0 62
            Strand		 0 63
            Strand		 0 64
            Strand		 0 65
            Strand		 0 66
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 0 67
            Strand		 0 68
            Strand		 0 69
            Strand		 0 70
            Strand		 0 71
            Strand		 1 36
            Strand		 1 38
            Strand		 1 39
            Strand		 1 40
            Strand		 1 41
            Strand		 1 42
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 1 43
            Strand		 1 44
            Strand		 1 45
            Strand		 1 46
            Strand		 1 47
            Strand		 1 48
            Strand		 1 49
            Strand		 1 50
            Strand		 1 51
            Strand		 1 52
            Strand		 1 53
            Start		  6.6456786120275854e+02
            Stop		  1.8549973758303806e+03
            Start		  3.4990985543587535e+03
            Stop		  4.6895280840170581e+03
            Start		  6.3336292626555405e+03
            Stop		  7.5240587901354502e+03
            Start		  9.1681599694687029e+03
            Stop		  1.0358589497205987e+04
            Start		  1.2002690675550479e+04
            Stop		  1.3193120205185540e+04
            Start		  1.4837221381020054e+04
            Stop		  1.6027650914144990e+04
            Start		  1.7671752086057611e+04
            Stop		  1.8862181624104363e+04
            Start		  2.0506282790860543e+04
            Stop		  2.1696712335040134e+04
            Start		  2.3340813495636765e+04
            Stop		  2.4531243046885869e+04
            Start		  2.6175344200595377e+04
            Stop		  2.7365773759535150e+04
            Start		  2.9009874905937446e+04
            Stop		  3.0200304472846208e+04
            Start		  3.1844405611847291e+04
            Stop		  3.3034835186648168e+04
            Start		  3.4678936318484259e+04
            Stop		  3.5869365900748562e+04
            Start		  3.7513467025975813e+04
            Stop		  3.8703896614941834e+04
            Start		  4.0347997734411947e+04
            Stop		  4.1538427329018210e+04
            Start		  4.3182528443841118e+04
            Stop		  4.4372958042773098e+04
            Start		  4.6017059154268267e+04
            Stop		  4.7207488756015970e+04
            Start		  4.8851589865654518e+04
            Stop		  5.0042019468578706e+04
            Start		  5.1686120577918824e+04
            Stop		  5.2876550180323029e+04
            Start		  5.4520651290941729e+04
            Stop		  5.5711080891146601e+04
            Start		  5.7355182004570335e+04
            Stop		  5.8545611600987453e+04
            Start		  6.0189712718625276e+04
            Stop		  6.1380142309826733e+04
            Start		  6.3024243432908428e+04
            Stop		  6.4214673017689543e+04
            Start		  6.5858774147211720e+04
            Stop		  6.7049203724643783e+04
            Start		  6.8693304861326062e+04
            Stop		  6.9883734430797325e+04
            Start		  7.1527835575050864e+04
            Stop		  7.2718265136293019e+04
            Start		  7.4362366288202582e+04
            Stop		  7.5552795841302664e+04
            Start		  7.7196897000622848e+04
            Stop		  7.8387326546019380e+04
            Start		  8.0031427712185410e+04
            Stop		  8.1221857250649016e+04
            Start		  8.2865958422801719e+04
            Stop		  8.4056387955401282e+04
            Start		  8.5700489132424860e+04
            Stop		  8.6400000000000000e+04
            Strand		 1 54
            Strand		 1 55
            Strand		 1 56
            Strand		 1 57
            Start		  1.6924371143518379e+03
            Stop		  2.5593430961083200e+03
            Start		  4.5269679805644055e+03
            Stop		  5.3938729255183271e+03
            Start		  7.3614967792308908e+03
            Stop		  8.2284038794386342e+03
            Start		  1.0196029398922652e+04
            Stop		  1.1062934277395712e+04
            Start		  1.3030560026025285e+04
            Stop		  1.3897465218981650e+04
            Start		  1.5865090818730390e+04
            Stop		  1.6731995671968747e+04
            Start		  1.8699621122201708e+04
            Stop		  1.9566526611259811e+04
            Start		  2.1534152240066949e+04
            Stop		  2.2401057082021864e+04
            Start		  2.4368682437556239e+04
            Stop		  2.5235588020261966e+04
            Start		  2.7203213662522598e+04
            Stop		  2.8070118496379022e+04
            Start		  3.0037743825173962e+04
            Stop		  3.0904649433844839e+04
            Start		  3.2872275085484398e+04
            Stop		  3.3739179911366409e+04
            Start		  3.5706805236501619e+04
            Stop		  3.6573710848321840e+04
            Start		  3.8541336508248482e+04
            Stop		  3.9408241326170166e+04
            Start		  4.1375866655065671e+04
            Stop		  4.2242772262945589e+04
            Start		  4.4210397930144230e+04
            Stop		  4.5077302741017462e+04
            Start		  4.7044928075049000e+04
            Stop		  4.7911833677970200e+04
            Start		  4.9879459350651305e+04
            Stop		  5.0746364156464719e+04
            Start		  5.2713989494321067e+04
            Stop		  5.3580895093920233e+04
            Start		  5.5548520769490264e+04
            Stop		  5.6415425573075954e+04
            Start		  5.8383050912174709e+04
            Stop		  5.9249956511272168e+04
            Start		  6.1217582186671214e+04
            Stop		  6.2084486991250225e+04
            Start		  6.4052112328578805e+04
            Stop		  6.4919017930296388e+04
            Start		  6.6886643602491939e+04
            Stop		  6.7753548411127485e+04
            Start		  6.9721173743895954e+04
            Stop		  7.0588079350985296e+04
            Start		  7.2555705017486427e+04
            Stop		  7.3422609832556162e+04
            Start		  7.5390235158724288e+04
            Stop		  7.6257140773046369e+04
            Start		  7.8224766432331831e+04
            Stop		  7.9091671255116671e+04
            Start		  8.1059296573762331e+04
            Stop		  8.1926202195950362e+04
            Start		  8.3893827847731038e+04
            Stop		  8.4760732678193570e+04
            Strand		 1 58
            Start		  1.2200259122918631e+03
            Stop		  2.0869098641782980e+03
            Start		  4.0545556124714622e+03
            Stop		  4.9214408018793411e+03
            Start		  6.8890873330568402e+03
            Stop		  7.7559713056458559e+03
            Start		  9.7236173178154477e+03
            Stop		  1.0590502242719973e+04
            Start		  1.2558148752186240e+04
            Stop		  1.3425032730404868e+04
            Start		  1.5392678831115240e+04
            Stop		  1.6259563668092262e+04
            Start		  1.8227210169650778e+04
            Stop		  1.9094094151058187e+04
            Start		  2.1061740279316597e+04
            Stop		  2.1928625089581394e+04
            Start		  2.3896271585717459e+04
            Stop		  2.4763155571574673e+04
            Start		  2.6730801705283193e+04
            Stop		  2.7597686510918982e+04
            Start		  2.9565333000898820e+04
            Stop		  3.0432216993064172e+04
            Start		  3.2399863123713189e+04
            Stop		  3.3266747933063765e+04
            Start		  3.5234394415862298e+04
            Stop		  3.6101278415536362e+04
            Start		  3.8068924539974549e+04
            Stop		  3.8935809355911129e+04
            Start		  4.0903455831313731e+04
            Stop		  4.1770339838524676e+04
            Start		  4.3737985956289085e+04
            Stop		  4.4604870778929318e+04
            Start		  4.6572517247874552e+04
            Stop		  4.7439401261371924e+04
            Start		  4.9407047373704110e+04
            Stop		  5.0273932201455929e+04
            Start		  5.2241578665973720e+04
            Stop		  5.3108462683411912e+04
            Start		  5.5076108792690597e+04
            Stop		  5.5942993622880378e+04
            Start		  5.7910640085773222e+04
            Stop		  5.8777524104107448e+04
            Start		  6.0745170213319310e+04
            Stop		  6.1612055042772299e+04
            Start		  6.3579701507139856e+04
            Stop		  6.4446585523151058e+04
            Start		  6.6414231635333839e+04
            Stop		  6.7281116460963691e+04
            Start		  6.9248762929668475e+04
            Stop		  7.0115646940520790e+04
            Start		  7.2083293058223266e+04
            Stop		  7.2950177877580572e+04
            Start		  7.4917824352752228e+04
            Stop		  7.5784708356484887e+04
            Start		  7.7752354481320392e+04
            Stop		  7.8619239293021805e+04
            Start		  8.0586885775688119e+04
            Stop		  8.1453769771555424e+04
            Start		  8.3421415903920599e+04
            Stop		  8.4288300707890186e+04
            Start		  8.6255945036735808e+04
            Stop		  8.6400000000000000e+04
            Strand		 1 59
            Strand		 1 60
            Strand		 1 61
            Strand		 1 62
            Start		  0.0000000000000000e+00
            Stop		  2.8025479238365915e+02
            Start		  1.9243623392691484e+03
            Stop		  3.1147895949934486e+03
            Start		  4.7588892837528165e+03
            Stop		  5.9493202044040736e+03
            Start		  7.5934199604545711e+03
            Stop		  8.7838509225958842e+03
            Start		  1.0427950669071592e+04
            Stop		  1.1618381636623542e+04
            Start		  1.3262481377756496e+04
            Stop		  1.4452912350663330e+04
            Start		  1.6097012087487552e+04
            Stop		  1.7287443064289182e+04
            Start		  1.8931542798201739e+04
            Stop		  2.0121973777330739e+04
            Start		  2.1766073509844711e+04
            Stop		  2.2956504489631028e+04
            Start		  2.4600604222318656e+04
            Stop		  2.5791035201066228e+04
            Start		  2.7435134935489299e+04
            Stop		  2.8625565911550584e+04
            Start		  3.0269665649191782e+04
            Stop		  3.1460096621040029e+04
            Start		  3.3104196363237810e+04
            Stop		  3.4294627329534233e+04
            Start		  3.5938727077424010e+04
            Stop		  3.7129158037076588e+04
            Start		  3.8773257791540775e+04
            Stop		  3.9963688743752275e+04
            Start		  4.1607788505381512e+04
            Stop		  4.2798219449684548e+04
            Start		  4.4442319218751756e+04
            Stop		  4.5632750155029316e+04
            Start		  4.7276849931477620e+04
            Stop		  4.8467280859968327e+04
            Start		  5.0111380643413482e+04
            Stop		  5.1301811564701100e+04
            Start		  5.2945911354448421e+04
            Stop		  5.4136342269436311e+04
            Start		  5.5780442064510942e+04
            Stop		  5.6970872974382495e+04
            Start		  5.8614972773572321e+04
            Stop		  5.9805403679738891e+04
            Start		  6.1449503481647705e+04
            Stop		  6.2639934385686814e+04
            Start		  6.4284034188795493e+04
            Stop		  6.5474465092381557e+04
            Start		  6.7118564895114789e+04
            Stop		  6.8308995799945755e+04
            Start		  6.9953095600741086e+04
            Stop		  7.1143526508463692e+04
            Start		  7.2787626305840196e+04
            Stop		  7.3978057217977956e+04
            Start		  7.5622157010601106e+04
            Stop		  7.6812587928487250e+04
            Start		  7.8456687715227570e+04
            Stop		  7.9647118639946784e+04
            Start		  8.1291218419929210e+04
            Stop		  8.2481649352269829e+04
            Start		  8.4125749124912356e+04
            Stop		  8.5316180065331995e+04
            Strand		 1 63
            Strand		 1 64
            Strand		 1 65
            Strand		 1 66
            Strand		 1 67
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 1 68
            Strand		 1 69
            Strand		 1 70
            Strand		 1 71
            Strand		 2 36
            Strand		 2 37
            Strand		 2 39
            Strand		 2 40
            Strand		 2 41
            Strand		 2 42
            Strand		 2 43
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 2 44
            Strand		 2 45
            Strand		 2 46
            Strand		 2 47
            Strand		 2 48
            Start		  0.0000000000000000e+00
            Stop		  9.1015393273526024e+02
            Start		  2.5542550489290384e+03
            Stop		  3.7446845111768803e+03
            Start		  5.3887856925873093e+03
            Stop		  6.5792152215183696e+03
            Start		  8.2233164006606166e+03
            Stop		  9.4137459280762432e+03
            Start		  1.1057847106930571e+04
            Stop		  1.2248276635752904e+04
            Start		  1.3892377812587596e+04
            Stop		  1.5082807344380828e+04
            Start		  1.6726908517747870e+04
            Stop		  1.7917338054007359e+04
            Start		  1.9561439222606255e+04
            Stop		  2.0751868764622955e+04
            Start		  2.2395969927368013e+04
            Stop		  2.3586399476175298e+04
            Start		  2.5230500632242900e+04
            Stop		  2.6420930188570856e+04
            Start		  2.8065031337435674e+04
            Stop		  2.9255460901679020e+04
            Start		  3.0899562043137161e+04
            Stop		  3.2089991615337825e+04
            Start		  3.3734092749515883e+04
            Stop		  3.4924522329361127e+04
            Start		  3.6568623456710637e+04
            Stop		  3.7759053043546715e+04
            Start		  3.9403154164824409e+04
            Stop		  4.0593583757685243e+04
            Start		  4.2237684873919847e+04
            Stop		  4.3428114471569344e+04
            Start		  4.5072215584016514e+04
            Stop		  4.6262645185002846e+04
            Start		  4.7906746295090030e+04
            Stop		  4.9097175897809248e+04
            Start		  5.0741277007073135e+04
            Stop		  5.1931706609839646e+04
            Start		  5.3575807719858625e+04
            Stop		  5.4766237320979089e+04
            Start		  5.6410338433304096e+04
            Stop		  5.7600768031151776e+04
            Start		  5.9244869147238183e+04
            Stop		  6.0435298740324288e+04
            Start		  6.2079399861468082e+04
            Stop		  6.3269829448507087e+04
            Start		  6.4913930575787999e+04
            Stop		  6.6104360155754111e+04
            Start		  6.7748461289988234e+04
            Stop		  6.8938890862160260e+04
            Start		  7.0582992003864303e+04
            Stop		  7.1773421567857440e+04
            Start		  7.3417522717226035e+04
            Stop		  7.4607952273008574e+04
            Start		  7.6252053429905878e+04
            Stop		  7.7442482977800479e+04
            Start		  7.9086584141766114e+04
            Stop		  8.0277013682435834e+04
            Start		  8.1921114852705199e+04
            Stop		  8.3111544387124057e+04
            Start		  8.4755645562661928e+04
            Stop		  8.5946075092072278e+04
            Strand		 2 49
            Strand		 2 50
            Strand		 2 51
            Strand		 2 52
            Strand		 2 53
            Strand		 2 54
            Strand		 2 55
            Strand		 2 56
            Strand		 2 57
            Strand		 2 58
            Start		  7.4759219828851224e+02
            Stop		  1.6144986041171635e+03
            Start		  3.5821244082730641e+03
            Stop		  4.4490298801901054e+03
            Start		  6.4166551196679366e+03
            Stop		  7.2835601958499392e+03
            Start		  9.2511852399307209e+03
            Stop		  1.0118091217556810e+04
            Start		  1.2085716538599445e+04
            Stop		  1.2952621478936459e+04
            Start		  1.4920245268052435e+04
            Stop		  1.5787152429742911e+04
            Start		  1.7754777958996256e+04
            Stop		  1.8621682834391300e+04
            Start		  2.0589308541723280e+04
            Stop		  2.1456213774597658e+04
            Start		  2.3423839380780159e+04
            Stop		  2.4290744229047134e+04
            Start		  2.6258369670139753e+04
            Stop		  2.7125275167186686e+04
            Start		  2.9092900803485038e+04
            Stop		  2.9959805637757581e+04
            Start		  3.1927430996440959e+04
            Stop		  3.2794336575052585e+04
            Start		  3.4761962226461845e+04
            Stop		  3.5628867050666107e+04
            Start		  3.7596492387399157e+04
            Stop		  3.8463397987529905e+04
            Start		  4.0431023649006405e+04
            Stop		  4.1297928464757650e+04
            Start		  4.3265553798943700e+04
            Stop		  4.4132459401554966e+04
            Start		  4.6100085070486886e+04
            Stop		  4.6966989879514149e+04
            Start		  4.8934615216226237e+04
            Stop		  4.9801520816602271e+04
            Start		  5.1769146490455270e+04
            Stop		  5.2636051295218116e+04
            Start		  5.4603676634200638e+04
            Stop		  5.5470582232900022e+04
            Start		  5.7438207908725715e+04
            Stop		  5.8305112712293012e+04
            Start		  6.0272738051266359e+04
            Stop		  6.1139643650767626e+04
            Start		  6.3107269325406996e+04
            Stop		  6.3974174131025575e+04
            Start		  6.5941799467159173e+04
            Stop		  6.6808705070353928e+04
            Start		  6.8776330740883699e+04
            Stop		  6.9643235551448379e+04
            Start		  7.1610860882208028e+04
            Stop		  7.2477766491543167e+04
            Start		  7.4445392155749403e+04
            Stop		  7.5312296973311619e+04
            Start		  7.7279922297017285e+04
            Stop		  7.8146827913952526e+04
            Start		  8.0114453570703627e+04
            Stop		  8.0981358396119220e+04
            Start		  8.2948983712275178e+04
            Stop		  8.3815889336991168e+04
            Start		  8.5783514986430295e+04
            Stop		  8.6400000000000000e+04
            Strand		 2 59
            Start		  2.7518194949710835e+02
            Stop		  1.1420669118283909e+03
            Start		  3.1097130525772423e+03
            Stop		  3.9765971511344155e+03
            Start		  5.9442418378392013e+03
            Stop		  6.8111281007025291e+03
            Start		  8.7787744729107781e+03
            Stop		  9.6456584964034009e+03
            Start		  1.1613305082820812e+04
            Stop		  1.2480189435146776e+04
            Start		  1.4447835891503802e+04
            Stop		  1.5314719887099749e+04
            Start		  1.7282366176259566e+04
            Stop		  1.8149250825245821e+04
            Start		  2.0116897308469106e+04
            Stop		  2.0983781296589830e+04
            Start		  2.2951427485991888e+04
            Stop		  2.3818312235424004e+04
            Start		  2.5785958724177173e+04
            Stop		  2.6652842713749116e+04
            Start		  2.8620488866132979e+04
            Stop		  2.9487373653341943e+04
            Start		  3.1455020139208391e+04
            Stop		  3.2321904134391636e+04
            Start		  3.4289550269472682e+04
            Stop		  3.5156435074553061e+04
            Start		  3.7124081554258155e+04
            Stop		  3.7990965556702722e+04
            Start		  3.9958611680957874e+04
            Stop		  4.0825496497127730e+04
            Start		  4.2793142970017987e+04
            Stop		  4.3660026979588802e+04
            Start		  4.5627673096028011e+04
            Stop		  4.6494557919924089e+04
            Start		  4.8462204387056008e+04
            Stop		  4.9329088402193483e+04
            Start		  5.1296734513430529e+04
            Stop		  5.2163619342100756e+04
            Start		  5.4131265805718460e+04
            Stop		  5.4998149823820910e+04
            Start		  5.6965795932806810e+04
            Stop		  5.7832680763035998e+04
            Start		  5.9800327226069559e+04
            Stop		  6.0667211243981779e+04
            Start		  6.2634857353884981e+04
            Stop		  6.3501742182360584e+04
            Start		  6.5469388647880362e+04
            Stop		  6.6336272662453557e+04
            Start		  6.8303918776239603e+04
            Stop		  6.9170803599997133e+04
            Start		  7.1138450070668609e+04
            Stop		  7.2005334079310982e+04
            Start		  7.3972980199270809e+04
            Stop		  7.4839865016165408e+04
            Start		  7.6807511493782440e+04
            Stop		  7.7674395494910321e+04
            Start		  7.9642041622276767e+04
            Stop		  8.0508926431341242e+04
            Start		  8.2476572916513775e+04
            Stop		  8.3343456909826666e+04
            Start		  8.5311103044565622e+04
            Stop		  8.6177987846173128e+04
            Strand		 2 60
            Strand		 2 61
            Strand		 2 62
            Strand		 2 63
            Start		  9.7951533442544837e+02
            Stop		  2.1699459402662674e+03
            Start		  3.8140456896078026e+03
            Stop		  5.0044766359521009e+03
            Start		  6.6485763920335048e+03
            Stop		  7.8390073510246684e+03
            Start		  9.4831070996800881e+03
            Stop		  1.0673538065232829e+04
            Start		  1.2317637808071238e+04
            Stop		  1.3508068779355021e+04
            Start		  1.5152168517466791e+04
            Stop		  1.6342599493136860e+04
            Start		  1.7986699227856774e+04
            Stop		  1.9177130206392147e+04
            Start		  2.0821229939199096e+04
            Stop		  2.2011660918955007e+04
            Start		  2.3655760651409269e+04
            Stop		  2.4846191630690068e+04
            Start		  2.6490291364364624e+04
            Stop		  2.7680722341498396e+04
            Start		  2.9324822077909746e+04
            Stop		  3.0515253051321688e+04
            Start		  3.2159352791863308e+04
            Stop		  3.3349783760144957e+04
            Start		  3.4993883506025944e+04
            Stop		  3.6184314467997137e+04
            Start		  3.7828414220189130e+04
            Stop		  3.9018845174949805e+04
            Start		  4.0662944934144281e+04
            Stop		  4.1853375881114036e+04
            Start		  4.3497475647691863e+04
            Stop		  4.4687906586635581e+04
            Start		  4.6332006360650237e+04
            Stop		  4.7522437291688366e+04
            Start		  4.9166537072863619e+04
            Stop		  5.0356967996466956e+04
            Start		  5.2001067784208819e+04
            Stop		  5.3191498701178010e+04
            Start		  5.4835598494600825e+04
            Stop		  5.6026029406031070e+04
            Start		  5.7670129203996410e+04
            Stop		  5.8860560111229504e+04
            Start		  6.0504659912396077e+04
            Stop		  6.1695090816961587e+04
            Start		  6.3339190619843968e+04
            Stop		  6.4529621523392052e+04
            Start		  6.6173721326426079e+04
            Stop		  6.7364152230655047e+04
            Start		  6.9008252032266289e+04
            Stop		  7.0198682938848229e+04
            Start		  7.1842782737521120e+04
            Stop		  7.3033213648028352e+04
            Start		  7.4677313442372688e+04
            Stop		  7.5867744358208816e+04
            Start		  7.7511844147020747e+04
            Stop		  7.8702275069359210e+04
            Start		  8.0346374851674060e+04
            Stop		  8.1536805781406481e+04
            Start		  8.3180905556541067e+04
            Stop		  8.4371336494238261e+04
            Start		  8.6015436261820723e+04
            Stop		  8.6400000000000000e+04
            Strand		 2 64
            Strand		 2 65
            Strand		 2 66
            Strand		 2 67
            Strand		 2 68
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 2 69
            Strand		 2 70
            Strand		 2 71
            Strand		 3 36
            Strand		 3 37
            Strand		 3 38
            Strand		 3 40
            Strand		 3 41
            Strand		 3 42
            Strand		 3 43
            Strand		 3 44
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 3 45
            Strand		 3 46
            Strand		 3 47
            Strand		 3 48
            Strand		 3 49
            Start		  1.6094145343278046e+03
            Stop		  2.7998371357176006e+03
            Start		  4.4439461440982150e+03
            Stop		  5.6343717598112180e+03
            Start		  7.2784728638444649e+03
            Stop		  8.4689023552105482e+03
            Start		  1.0113003537396809e+04
            Stop		  1.1303433066623886e+04
            Start		  1.2947534244143530e+04
            Stop		  1.4137963774717959e+04
            Start		  1.5782064949402264e+04
            Stop		  1.6972494484021121e+04
            Start		  1.8616595654341301e+04
            Stop		  1.9807025194310183e+04
            Start		  2.1451126359111855e+04
            Stop		  2.2641555905558733e+04
            Start		  2.4285657063925857e+04
            Stop		  2.5476086617686007e+04
            Start		  2.7120187768990596e+04
            Stop		  2.8310617330573223e+04
            Start		  2.9954718474502522e+04
            Stop		  3.1145148044068126e+04
            Start		  3.2789249180638464e+04
            Stop		  3.3979678757991780e+04
            Start		  3.5623779887547898e+04
            Stop		  3.6814209472146351e+04
            Start		  3.8458310595346302e+04
            Stop		  3.9648740186323914e+04
            Start		  4.1292841304110189e+04
            Stop		  4.2483270900315350e+04
            Start		  4.4127372013873646e+04
            Stop		  4.5317801613919779e+04
            Start		  4.6961902724626954e+04
            Stop		  4.8152332326953292e+04
            Start		  4.9796433436316867e+04
            Stop		  5.0986863039256910e+04
            Start		  5.2630964148849103e+04
            Stop		  5.3821393750703792e+04
            Start		  5.5465494862092346e+04
            Stop		  5.6655924461204566e+04
            Start		  5.8300025575884079e+04
            Stop		  5.9490455170711510e+04
            Start		  6.1134556290037799e+04
            Stop		  6.2324985879220338e+04
            Start		  6.3969087004351022e+04
            Stop		  6.5159516586770682e+04
            Start		  6.6803617718614274e+04
            Stop		  6.7994047293444179e+04
            Start		  6.9638148432620408e+04
            Stop		  7.0828577999361034e+04
            Start		  7.2472679146173527e+04
            Stop		  7.3663108704674392e+04
            Start		  7.5307209859097566e+04
            Stop		  7.6497639409564130e+04
            Start		  7.8141740571244198e+04
            Stop		  7.9332170114228560e+04
            Start		  8.0976271282499161e+04
            Stop		  8.2166700818875863e+04
            Start		  8.3810801992787528e+04
            Stop		  8.5001231523714901e+04
            Strand		 3 50
            Strand		 3 51
            Strand		 3 52
            Strand		 3 53
            Strand		 3 54
            Start		  0.0000000000000000e+00
            Stop		  1.9722289945797786e+02
            Start		  2.1648677615133179e+03
            Stop		  3.0317538561456486e+03
            Start		  4.9994001929093356e+03
            Stop		  5.8662842293986023e+03
            Start		  7.8339309356063732e+03
            Stop		  8.7008151686506426e+03
            Start		  1.0668461612645311e+04
            Stop		  1.1535345612619829e+04
            Start		  1.3502991941219832e+04
            Stop		  1.4369876550338959e+04
            Start		  1.6337523030663244e+04
            Stop		  1.7204407018628383e+04
            Start		  1.9172053222872397e+04
            Stop		  2.0038937956906222e+04
            Start		  2.2006584447154168e+04
            Stop		  2.2873468433857764e+04
            Start		  2.4841114594060833e+04
            Stop		  2.5707999372947528e+04
            Start		  2.7675645862563422e+04
            Stop		  2.8542529853286138e+04
            Start		  3.0510175994396133e+04
            Stop		  3.1377060793095487e+04
            Start		  3.3344707277520953e+04
            Stop		  3.4211591274903971e+04
            Start		  3.6179237404514126e+04
            Stop		  3.7046122215190517e+04
            Start		  3.9013768692734222e+04
            Stop		  3.9880652697602047e+04
            Start		  4.1848298818498100e+04
            Stop		  4.2715183638036870e+04
            Start		  4.4682830108866219e+04
            Stop		  4.5549714120511526e+04
            Start		  4.7517360234757682e+04
            Stop		  4.8384245060739166e+04
            Start		  5.0351891526420382e+04
            Stop		  5.1218775542868745e+04
            Start		  5.3186421652958641e+04
            Stop		  5.4053306482569482e+04
            Start		  5.6020952945653320e+04
            Stop		  5.6887836964052833e+04
            Start		  5.8855483072975585e+04
            Stop		  5.9722367902998267e+04
            Start		  6.1690014366530202e+04
            Stop		  6.2556898383662003e+04
            Start		  6.4524544494548361e+04
            Stop		  6.5391429321754869e+04
            Start		  6.7359075788730857e+04
            Stop		  6.8225959801573015e+04
            Start		  7.0193605917206340e+04
            Stop		  7.1060490738863984e+04
            Start		  7.3028137211705369e+04
            Stop		  7.3895021217959089e+04
            Start		  7.5862667340310436e+04
            Stop		  7.6729552154638091e+04
            Start		  7.8697198634769622e+04
            Stop		  7.9564082633258717e+04
            Start		  8.1531728763150764e+04
            Stop		  8.2398613569621797e+04
            Start		  8.4366260057224150e+04
            Stop		  8.5233144048099042e+04
            Strand		 3 55
            Strand		 3 56
            Strand		 3 57
            Strand		 3 58
            Strand		 3 59
            Start		  0.0000000000000000e+00
            Stop		  6.6965530016261050e+02
            Start		  2.6372798841569697e+03
            Stop		  3.5041865919808520e+03
            Start		  5.4718115501907187e+03
            Stop		  6.3387166104280350e+03
            Start		  8.3063414733014324e+03
            Stop		  9.1732476195688869e+03
            Start		  1.1140872968714644e+04
            Stop		  1.2007777900248515e+04
            Start		  1.3975401633698719e+04
            Stop		  1.4842308849299285e+04
            Start		  1.6809934388834921e+04
            Stop		  1.7676839261193792e+04
            Start		  1.9644464929754035e+04
            Stop		  2.0511370201304137e+04
            Start		  2.2478995810406599e+04
            Stop		  2.3345900658278832e+04
            Start		  2.5313526086019359e+04
            Stop		  2.6180431596517876e+04
            Start		  2.8148057232997482e+04
            Stop		  2.9014962067995351e+04
            Start		  3.0982587421430489e+04
            Stop		  3.1849493005381384e+04
            Start		  3.3817118655977290e+04
            Stop		  3.4684023481328230e+04
            Start		  3.6651648815470711e+04
            Stop		  3.7518554418235341e+04
            Start		  3.9486180078640995e+04
            Stop		  4.0353084895564534e+04
            Start		  4.2320710228183008e+04
            Stop		  4.3187615832346542e+04
            Start		  4.5155241500336007e+04
            Stop		  4.6022146310289820e+04
            Start		  4.7989771646044115e+04
            Stop		  4.8856677247306026e+04
            Start		  5.0824302920577044e+04
            Stop		  5.1691207725835062e+04
            Start		  5.3658833064411658e+04
            Stop		  5.4525738663400778e+04
            Start		  5.6493364339130923e+04
            Stop		  5.7360269142665558e+04
            Start		  5.9327894481783485e+04
            Stop		  6.0194800080999790e+04
            Start		  6.2162425756057215e+04
            Stop		  6.3029330561115203e+04
            Start		  6.4996955897897307e+04
            Stop		  6.5863861500303334e+04
            Start		  6.7831487171697969e+04
            Stop		  6.8698391981267239e+04
            Start		  7.0666017313061966e+04
            Stop		  7.1532922921246340e+04
            Start		  7.3500548586618315e+04
            Stop		  7.4367453402919360e+04
            Start		  7.6335078727867745e+04
            Stop		  7.7201984343489195e+04
            Start		  7.9169610001508379e+04
            Stop		  8.0036514825612307e+04
            Start		  8.2004140143005512e+04
            Stop		  8.2871045766470095e+04
            Start		  8.4838671417063131e+04
            Stop		  8.5705576248707337e+04
            Strand		 3 60
            Strand		 3 61
            Strand		 3 62
            Strand		 3 63
            Strand		 3 64
            Start		  3.4676244816463452e+01
            Stop		  1.2251025081380601e+03
            Start		  2.8692021993155286e+03
            Stop		  4.0596330610159303e+03
            Start		  5.7037328223071563e+03
            Stop		  6.8941637797996273e+03
            Start		  8.5382635304681226e+03
            Stop		  9.7286944938098604e+03
            Start		  1.1372794238492985e+04
            Stop		  1.2563225208009930e+04
            Start		  1.4207324947557145e+04
            Stop		  1.5397755921925793e+04
            Start		  1.7041855657617962e+04
            Stop		  1.8232286635376349e+04
            Start		  1.9876386368650237e+04
            Stop		  2.1066817348186705e+04
            Start		  2.2710917080582964e+04
            Stop		  2.3901348060210599e+04
            Start		  2.5545447793305713e+04
            Stop		  2.6735878771336389e+04
            Start		  2.8379978506673258e+04
            Stop		  2.9570409481491861e+04
            Start		  3.1214509220512100e+04
            Stop		  3.2404940190647412e+04
            Start		  3.4049039934627937e+04
            Stop		  3.5239470898817410e+04
            Start		  3.6883570648814326e+04
            Stop		  3.8074001606059443e+04
            Start		  3.9718101362861627e+04
            Stop		  4.0908532312471885e+04
            Start		  4.2552632076566297e+04
            Stop		  4.3743063018189569e+04
            Start		  4.5387162789739814e+04
            Stop		  4.6577593723377824e+04
            Start		  4.8221693502216949e+04
            Stop		  4.9412124428225288e+04
            Start		  5.1056224213862952e+04
            Stop		  5.2246655132935528e+04
            Start		  5.3890754924579625e+04
            Stop		  5.5081185837718149e+04
            Start		  5.6725285634309475e+04
            Stop		  5.7915716542779621e+04
            Start		  5.9559816343038328e+04
            Stop		  6.0750247248314197e+04
            Start		  6.2394347050795943e+04
            Stop		  6.3584777954495308e+04
            Start		  6.5228877757654649e+04
            Stop		  6.6419308661468051e+04
            Start		  6.8063408463726271e+04
            Stop		  6.9253839369342764e+04
            Start		  7.0897939169157078e+04
            Stop		  7.2088370078190230e+04
            Start		  7.3732469874121583e+04
            Stop		  7.4922900788038474e+04
            Start		  7.6567000578814506e+04
            Stop		  7.7757431498871636e+04
            Start		  7.9401531283442731e+04
            Stop		  8.0591962210630576e+04
            Start		  8.2236061988215748e+04
            Stop		  8.3426492923215585e+04
            Start		  8.5070592693336686e+04
            Stop		  8.6261023970370239e+04
            Strand		 3 65
            Strand		 3 66
            Strand		 3 67
            Strand		 3 68
            Strand		 3 69
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 3 70
            Strand		 3 71
            Strand		 4 36
            Strand		 4 37
            Strand		 4 38
            Strand		 4 39
            Strand		 4 41
            Strand		 4 42
            Strand		 4 43
            Strand		 4 44
            Strand		 4 45
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 4 46
            Strand		 4 47
            Strand		 4 48
            Strand		 4 49
            Strand		 4 50
            Start		  6.6456786120276001e+02
            Stop		  1.8549973758303815e+03
            Start		  3.4990985543587476e+03
            Stop		  4.6895280840170599e+03
            Start		  6.3336292626555378e+03
            Stop		  7.5240587901354511e+03
            Start		  9.1681599694687011e+03
            Stop		  1.0358589497205992e+04
            Start		  1.2002690675550479e+04
            Stop		  1.3193120205185538e+04
            Start		  1.4837221381020052e+04
            Stop		  1.6027650914144993e+04
            Start		  1.7671752086057611e+04
            Stop		  1.8862181624104360e+04
            Start		  2.0506282790860543e+04
            Stop		  2.1696712335040131e+04
            Start		  2.3340813495636776e+04
            Stop		  2.4531243046885869e+04
            Start		  2.6175344200595373e+04
            Stop		  2.7365773759535157e+04
            Start		  2.9009874905937453e+04
            Stop		  3.0200304472846201e+04
            Start		  3.1844405611847291e+04
            Stop		  3.3034835186648161e+04
            Start		  3.4678936318484259e+04
            Stop		  3.5869365900748569e+04
            Start		  3.7513467025975813e+04
            Stop		  3.8703896614941819e+04
            Start		  4.0347997734411954e+04
            Stop		  4.1538427329018217e+04
            Start		  4.3182528443841118e+04
            Stop		  4.4372958042773105e+04
            Start		  4.6017059154268281e+04
            Stop		  4.7207488756015977e+04
            Start		  4.8851589865654518e+04
            Stop		  5.0042019468578685e+04
            Start		  5.1686120577918824e+04
            Stop		  5.2876550180323029e+04
            Start		  5.4520651290941736e+04
            Stop		  5.5711080891146616e+04
            Start		  5.7355182004570335e+04
            Stop		  5.8545611600987460e+04
            Start		  6.0189712718625262e+04
            Stop		  6.1380142309826741e+04
            Start		  6.3024243432908435e+04
            Stop		  6.4214673017689558e+04
            Start		  6.5858774147211690e+04
            Stop		  6.7049203724643783e+04
            Start		  6.8693304861326076e+04
            Stop		  6.9883734430797311e+04
            Start		  7.1527835575050849e+04
            Stop		  7.2718265136293019e+04
            Start		  7.4362366288202582e+04
            Stop		  7.5552795841302664e+04
            Start		  7.7196897000622834e+04
            Stop		  7.8387326546019351e+04
            Start		  8.0031427712185396e+04
            Stop		  8.1221857250648987e+04
            Start		  8.2865958422801719e+04
            Stop		  8.4056387955401311e+04
            Start		  8.5700489132424860e+04
            Stop		  8.6400000000000000e+04
            Strand		 4 51
            Strand		 4 52
            Strand		 4 53
            Strand		 4 54
            Start		  1.6924371143518374e+03
            Stop		  2.5593430961083209e+03
            Start		  4.5269679805644028e+03
            Stop		  5.3938729255183271e+03
            Start		  7.3614967792308908e+03
            Stop		  8.2284038794386470e+03
            Start		  1.0196029398922650e+04
            Stop		  1.1062934277395716e+04
            Start		  1.3030560026025283e+04
            Stop		  1.3897465218981642e+04
            Start		  1.5865090818730381e+04
            Stop		  1.6731995671968747e+04
            Start		  1.8699621122201708e+04
            Stop		  1.9566526611259811e+04
            Start		  2.1534152240066946e+04
            Stop		  2.2401057082021864e+04
            Start		  2.4368682437556243e+04
            Stop		  2.5235588020261966e+04
            Start		  2.7203213662522598e+04
            Stop		  2.8070118496379029e+04
            Start		  3.0037743825173951e+04
            Stop		  3.0904649433844839e+04
            Start		  3.2872275085484398e+04
            Stop		  3.3739179911366409e+04
            Start		  3.5706805236501605e+04
            Stop		  3.6573710848321833e+04
            Start		  3.8541336508248482e+04
            Stop		  3.9408241326170173e+04
            Start		  4.1375866655065671e+04
            Stop		  4.2242772262945589e+04
            Start		  4.4210397930144230e+04
            Stop		  4.5077302741017462e+04
            Start		  4.7044928075049000e+04
            Stop		  4.7911833677970200e+04
            Start		  4.9879459350651312e+04
            Stop		  5.0746364156464711e+04
            Start		  5.2713989494321053e+04
            Stop		  5.3580895093920233e+04
            Start		  5.5548520769490264e+04
            Stop		  5.6415425573075947e+04
            Start		  5.8383050912174695e+04
            Stop		  5.9249956511272168e+04
            Start		  6.1217582186671207e+04
            Stop		  6.2084486991250233e+04
            Start		  6.4052112328578791e+04
            Stop		  6.4919017930296402e+04
            Start		  6.6886643602491924e+04
            Stop		  6.7753548411127500e+04
            Start		  6.9721173743895924e+04
            Stop		  7.0588079350985296e+04
            Start		  7.2555705017486413e+04
            Stop		  7.3422609832556176e+04
            Start		  7.5390235158724288e+04
            Stop		  7.6257140773046383e+04
            Start		  7.8224766432331846e+04
            Stop		  7.9091671255116686e+04
            Start		  8.1059296573762302e+04
            Stop		  8.1926202195950362e+04
            Start		  8.3893827847731052e+04
            Stop		  8.4760732678193584e+04
            Strand		 4 55
            Start		  1.2200259122918644e+03
            Stop		  2.0869098641782994e+03
            Start		  4.0545556124714672e+03
            Stop		  4.9214408018793301e+03
            Start		  6.8890873330568429e+03
            Stop		  7.7559713056458577e+03
            Start		  9.7236173178154513e+03
            Stop		  1.0590502242719971e+04
            Start		  1.2558148752186242e+04
            Stop		  1.3425032730404868e+04
            Start		  1.5392678831115238e+04
            Stop		  1.6259563668092256e+04
            Start		  1.8227210169650778e+04
            Stop		  1.9094094151058191e+04
            Start		  2.1061740279316589e+04
            Stop		  2.1928625089581401e+04
            Start		  2.3896271585717459e+04
            Stop		  2.4763155571574680e+04
            Start		  2.6730801705283193e+04
            Stop		  2.7597686510918982e+04
            Start		  2.9565333000898823e+04
            Stop		  3.0432216993064168e+04
            Start		  3.2399863123713181e+04
            Stop		  3.3266747933063758e+04
            Start		  3.5234394415862305e+04
            Stop		  3.6101278415536377e+04
            Start		  3.8068924539974556e+04
            Stop		  3.8935809355911122e+04
            Start		  4.0903455831313731e+04
            Stop		  4.1770339838524691e+04
            Start		  4.3737985956289092e+04
            Stop		  4.4604870778929311e+04
            Start		  4.6572517247874559e+04
            Stop		  4.7439401261371924e+04
            Start		  4.9407047373704103e+04
            Stop		  5.0273932201455937e+04
            Start		  5.2241578665973735e+04
            Stop		  5.3108462683411904e+04
            Start		  5.5076108792690604e+04
            Stop		  5.5942993622880385e+04
            Start		  5.7910640085773237e+04
            Stop		  5.8777524104107441e+04
            Start		  6.0745170213319310e+04
            Stop		  6.1612055042772306e+04
            Start		  6.3579701507139878e+04
            Stop		  6.4446585523151065e+04
            Start		  6.6414231635333839e+04
            Stop		  6.7281116460963691e+04
            Start		  6.9248762929668490e+04
            Stop		  7.0115646940520804e+04
            Start		  7.2083293058223280e+04
            Stop		  7.2950177877580572e+04
            Start		  7.4917824352752243e+04
            Stop		  7.5784708356484902e+04
            Start		  7.7752354481320377e+04
            Stop		  7.8619239293021790e+04
            Start		  8.0586885775688148e+04
            Stop		  8.1453769771555424e+04
            Start		  8.3421415903920613e+04
            Stop		  8.4288300707890186e+04
            Start		  8.6255945036735808e+04
            Stop		  8.6400000000000000e+04
            Strand		 4 56
            Strand		 4 57
            Strand		 4 58
            Strand		 4 59
            Strand		 4 60
            Strand		 4 61
            Strand		 4 62
            Strand		 4 63
            Strand		 4 64
            Strand		 4 65
            Start		  0.0000000000000000e+00
            Stop		  2.8025479238366114e+02
            Start		  1.9243623392691422e+03
            Stop		  3.1147895949934450e+03
            Start		  4.7588892837528174e+03
            Stop		  5.9493202044040709e+03
            Start		  7.5934199604545738e+03
            Stop		  8.7838509225958824e+03
            Start		  1.0427950669071593e+04
            Stop		  1.1618381636623542e+04
            Start		  1.3262481377756501e+04
            Stop		  1.4452912350663328e+04
            Start		  1.6097012087487552e+04
            Stop		  1.7287443064289186e+04
            Start		  1.8931542798201743e+04
            Stop		  2.0121973777330739e+04
            Start		  2.1766073509844722e+04
            Stop		  2.2956504489631021e+04
            Start		  2.4600604222318663e+04
            Stop		  2.5791035201066235e+04
            Start		  2.7435134935489303e+04
            Stop		  2.8625565911550584e+04
            Start		  3.0269665649191782e+04
            Stop		  3.1460096621040022e+04
            Start		  3.3104196363237817e+04
            Stop		  3.4294627329534240e+04
            Start		  3.5938727077423995e+04
            Stop		  3.7129158037076581e+04
            Start		  3.8773257791540767e+04
            Stop		  3.9963688743752260e+04
            Start		  4.1607788505381519e+04
            Stop		  4.2798219449684562e+04
            Start		  4.4442319218751763e+04
            Stop		  4.5632750155029331e+04
            Start		  4.7276849931477620e+04
            Stop		  4.8467280859968334e+04
            Start		  5.0111380643413497e+04
            Stop		  5.1301811564701136e+04
            Start		  5.2945911354448406e+04
            Stop		  5.4136342269436318e+04
            Start		  5.5780442064510949e+04
            Stop		  5.6970872974382481e+04
            Start		  5.8614972773572314e+04
            Stop		  5.9805403679738884e+04
            Start		  6.1449503481647713e+04
            Stop		  6.2639934385686814e+04
            Start		  6.4284034188795486e+04
            Stop		  6.5474465092381586e+04
            Start		  6.7118564895114789e+04
            Stop		  6.8308995799945755e+04
            Start		  6.9953095600741057e+04
            Stop		  7.1143526508463721e+04
            Start		  7.2787626305840211e+04
            Stop		  7.3978057217977956e+04
            Start		  7.5622157010601106e+04
            Stop		  7.6812587928487279e+04
            Start		  7.8456687715227570e+04
            Stop		  7.9647118639946770e+04
            Start		  8.1291218419929195e+04
            Stop		  8.2481649352269829e+04
            Start		  8.4125749124912385e+04
            Stop		  8.5316180065331966e+04
            Strand		 4 66
            Strand		 4 67
            Strand		 4 68
            Strand		 4 69
            Strand		 4 70
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 4 71
            Strand		 5 36
            Strand		 5 37
            Strand		 5 38
            Strand		 5 39
            Strand		 5 40
            Strand		 5 42
            Strand		 5 43
            Strand		 5 44
            Strand		 5 45
            Strand		 5 46
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 5 47
            Strand		 5 48
            Strand		 5 49
            Strand		 5 50
            Strand		 5 51
            Start		  0.0000000000000000e+00
            Stop		  9.1015393273525842e+02
            Start		  2.5542550489290347e+03
            Stop		  3.7446845111768826e+03
            Start		  5.3887856925873075e+03
            Stop		  6.5792152215183696e+03
            Start		  8.2233164006606148e+03
            Stop		  9.4137459280762432e+03
            Start		  1.1057847106930574e+04
            Stop		  1.2248276635752900e+04
            Start		  1.3892377812587598e+04
            Stop		  1.5082807344380823e+04
            Start		  1.6726908517747870e+04
            Stop		  1.7917338054007359e+04
            Start		  1.9561439222606255e+04
            Stop		  2.0751868764622948e+04
            Start		  2.2395969927368016e+04
            Stop		  2.3586399476175306e+04
            Start		  2.5230500632242885e+04
            Stop		  2.6420930188570870e+04
            Start		  2.8065031337435677e+04
            Stop		  2.9255460901679024e+04
            Start		  3.0899562043137157e+04
            Stop		  3.2089991615337840e+04
            Start		  3.3734092749515883e+04
            Stop		  3.4924522329361120e+04
            Start		  3.6568623456710637e+04
            Stop		  3.7759053043546723e+04
            Start		  3.9403154164824409e+04
            Stop		  4.0593583757685243e+04
            Start		  4.2237684873919832e+04
            Stop		  4.3428114471569344e+04
            Start		  4.5072215584016521e+04
            Stop		  4.6262645185002839e+04
            Start		  4.7906746295090030e+04
            Stop		  4.9097175897809248e+04
            Start		  5.0741277007073142e+04
            Stop		  5.1931706609839639e+04
            Start		  5.3575807719858625e+04
            Stop		  5.4766237320979082e+04
            Start		  5.6410338433304110e+04
            Stop		  5.7600768031151776e+04
            Start		  5.9244869147238198e+04
            Stop		  6.0435298740324302e+04
            Start		  6.2079399861468082e+04
            Stop		  6.3269829448507102e+04
            Start		  6.4913930575788028e+04
            Stop		  6.6104360155754111e+04
            Start		  6.7748461289988234e+04
            Stop		  6.8938890862160260e+04
            Start		  7.0582992003864303e+04
            Stop		  7.1773421567857440e+04
            Start		  7.3417522717226049e+04
            Stop		  7.4607952273008574e+04
            Start		  7.6252053429905878e+04
            Stop		  7.7442482977800508e+04
            Start		  7.9086584141766114e+04
            Stop		  8.0277013682435863e+04
            Start		  8.1921114852705214e+04
            Stop		  8.3111544387124100e+04
            Start		  8.4755645562661972e+04
            Stop		  8.5946075092072308e+04
            Strand		 5 52
            Strand		 5 53
            Strand		 5 54
            Strand		 5 55
            Start		  7.4759219828851110e+02
            Stop		  1.6144986041171649e+03
            Start		  3.5821244082730632e+03
            Stop		  4.4490298801901099e+03
            Start		  6.4166551196679293e+03
            Stop		  7.2835601958499346e+03
            Start		  9.2511852399307172e+03
            Stop		  1.0118091217556810e+04
            Start		  1.2085716538599441e+04
            Stop		  1.2952621478936455e+04
            Start		  1.4920245268052431e+04
            Stop		  1.5787152429742911e+04
            Start		  1.7754777958996252e+04
            Stop		  1.8621682834391308e+04
            Start		  2.0589308541723269e+04
            Stop		  2.1456213774597654e+04
            Start		  2.3423839380780159e+04
            Stop		  2.4290744229047134e+04
            Start		  2.6258369670139746e+04
            Stop		  2.7125275167186690e+04
            Start		  2.9092900803485038e+04
            Stop		  2.9959805637757578e+04
            Start		  3.1927430996440951e+04
            Stop		  3.2794336575052585e+04
            Start		  3.4761962226461837e+04
            Stop		  3.5628867050666115e+04
            Start		  3.7596492387399143e+04
            Stop		  3.8463397987529890e+04
            Start		  4.0431023649006405e+04
            Stop		  4.1297928464757650e+04
            Start		  4.3265553798943693e+04
            Stop		  4.4132459401554959e+04
            Start		  4.6100085070486879e+04
            Stop		  4.6966989879514142e+04
            Start		  4.8934615216226230e+04
            Stop		  4.9801520816602264e+04
            Start		  5.1769146490455270e+04
            Stop		  5.2636051295218116e+04
            Start		  5.4603676634200638e+04
            Stop		  5.5470582232900029e+04
            Start		  5.7438207908725715e+04
            Stop		  5.8305112712293012e+04
            Start		  6.0272738051266359e+04
            Stop		  6.1139643650767626e+04
            Start		  6.3107269325407004e+04
            Stop		  6.3974174131025575e+04
            Start		  6.5941799467159173e+04
            Stop		  6.6808705070353928e+04
            Start		  6.8776330740883714e+04
            Stop		  6.9643235551448379e+04
            Start		  7.1610860882208042e+04
            Stop		  7.2477766491543181e+04
            Start		  7.4445392155749403e+04
            Stop		  7.5312296973311619e+04
            Start		  7.7279922297017300e+04
            Stop		  7.8146827913952540e+04
            Start		  8.0114453570703641e+04
            Stop		  8.0981358396119205e+04
            Start		  8.2948983712275192e+04
            Stop		  8.3815889336991168e+04
            Start		  8.5783514986430295e+04
            Stop		  8.6400000000000000e+04
            Strand		 5 56
            Start		  2.7518194949710869e+02
            Stop		  1.1420669118283895e+03
            Start		  3.1097130525772454e+03
            Stop		  3.9765971511344151e+03
            Start		  5.9442418378392013e+03
            Stop		  6.8111281007025291e+03
            Start		  8.7787744729107762e+03
            Stop		  9.6456584964033937e+03
            Start		  1.1613305082820814e+04
            Stop		  1.2480189435146776e+04
            Start		  1.4447835891503802e+04
            Stop		  1.5314719887099751e+04
            Start		  1.7282366176259573e+04
            Stop		  1.8149250825245817e+04
            Start		  2.0116897308469113e+04
            Stop		  2.0983781296589827e+04
            Start		  2.2951427485991881e+04
            Stop		  2.3818312235424004e+04
            Start		  2.5785958724177170e+04
            Stop		  2.6652842713749105e+04
            Start		  2.8620488866132979e+04
            Stop		  2.9487373653341951e+04
            Start		  3.1455020139208387e+04
            Stop		  3.2321904134391636e+04
            Start		  3.4289550269472682e+04
            Stop		  3.5156435074553054e+04
            Start		  3.7124081554258148e+04
            Stop		  3.7990965556702729e+04
            Start		  3.9958611680957874e+04
            Stop		  4.0825496497127730e+04
            Start		  4.2793142970017980e+04
            Stop		  4.3660026979588802e+04
            Start		  4.5627673096028004e+04
            Stop		  4.6494557919924082e+04
            Start		  4.8462204387056008e+04
            Stop		  4.9329088402193476e+04
            Start		  5.1296734513430521e+04
            Stop		  5.2163619342100756e+04
            Start		  5.4131265805718460e+04
            Stop		  5.4998149823820917e+04
            Start		  5.6965795932806825e+04
            Stop		  5.7832680763035991e+04
            Start		  5.9800327226069552e+04
            Stop		  6.0667211243981772e+04
            Start		  6.2634857353884981e+04
            Stop		  6.3501742182360576e+04
            Start		  6.5469388647880362e+04
            Stop		  6.6336272662453557e+04
            Start		  6.8303918776239603e+04
            Stop		  6.9170803599997147e+04
            Start		  7.1138450070668594e+04
            Stop		  7.2005334079310982e+04
            Start		  7.3972980199270794e+04
            Stop		  7.4839865016165408e+04
            Start		  7.6807511493782440e+04
            Stop		  7.7674395494910321e+04
            Start		  7.9642041622276767e+04
            Stop		  8.0508926431341242e+04
            Start		  8.2476572916513775e+04
            Stop		  8.3343456909826666e+04
            Start		  8.5311103044565622e+04
            Stop		  8.6177987846173128e+04
            Strand		 5 57
            Strand		 5 58
            Strand		 5 59
            Strand		 5 60
            Start		  9.7951533442544712e+02
            Stop		  2.1699459402662646e+03
            Start		  3.8140456896078013e+03
            Stop		  5.0044766359521018e+03
            Start		  6.6485763920335030e+03
            Stop		  7.8390073510246602e+03
            Start		  9.4831070996800881e+03
            Stop		  1.0673538065232824e+04
            Start		  1.2317637808071238e+04
            Stop		  1.3508068779355013e+04
            Start		  1.5152168517466787e+04
            Stop		  1.6342599493136862e+04
            Start		  1.7986699227856770e+04
            Stop		  1.9177130206392132e+04
            Start		  2.0821229939199100e+04
            Stop		  2.2011660918955007e+04
            Start		  2.3655760651409277e+04
            Stop		  2.4846191630690071e+04
            Start		  2.6490291364364624e+04
            Stop		  2.7680722341498396e+04
            Start		  2.9324822077909757e+04
            Stop		  3.0515253051321673e+04
            Start		  3.2159352791863304e+04
            Stop		  3.3349783760144965e+04
            Start		  3.4993883506025930e+04
            Stop		  3.6184314467997130e+04
            Start		  3.7828414220189137e+04
            Stop		  3.9018845174949798e+04
            Start		  4.0662944934144267e+04
            Stop		  4.1853375881114021e+04
            Start		  4.3497475647691870e+04
            Stop		  4.4687906586635552e+04
            Start		  4.6332006360650237e+04
            Stop		  4.7522437291688351e+04
            Start		  4.9166537072863604e+04
            Stop		  5.0356967996466970e+04
            Start		  5.2001067784208804e+04
            Stop		  5.3191498701177996e+04
            Start		  5.4835598494600803e+04
            Stop		  5.6026029406031070e+04
            Start		  5.7670129203996410e+04
            Stop		  5.8860560111229519e+04
            Start		  6.0504659912396062e+04
            Stop		  6.1695090816961580e+04
            Start		  6.3339190619843961e+04
            Stop		  6.4529621523392030e+04
            Start		  6.6173721326426079e+04
            Stop		  6.7364152230655047e+04
            Start		  6.9008252032266319e+04
            Stop		  7.0198682938848229e+04
            Start		  7.1842782737521120e+04
            Stop		  7.3033213648028352e+04
            Start		  7.4677313442372659e+04
            Stop		  7.5867744358208816e+04
            Start		  7.7511844147020747e+04
            Stop		  7.8702275069359195e+04
            Start		  8.0346374851674060e+04
            Stop		  8.1536805781406511e+04
            Start		  8.3180905556541067e+04
            Stop		  8.4371336494238247e+04
            Start		  8.6015436261820738e+04
            Stop		  8.6400000000000000e+04
            Strand		 5 61
            Strand		 5 62
            Strand		 5 63
            Strand		 5 64
            Strand		 5 65
            Strand		 5 66
            Strand		 5 67
            Strand		 5 68
            Strand		 5 69
            Strand		 5 70
            Strand		 5 71
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 36
            Strand		 6 37
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 38
            Strand		 6 39
            Strand		 6 40
            Strand		 6 41
            Strand		 6 43
            Strand		 6 44
            Strand		 6 45
            Strand		 6 46
            Strand		 6 47
            Strand		 6 48
            Strand		 6 49
            Strand		 6 50
            Strand		 6 51
            Strand		 6 52
            Strand		 6 53
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 54
            Strand		 6 55
            Strand		 6 56
            Strand		 6 57
            Strand		 6 58
            Start		  1.4519398699378851e+03
            Stop		  2.6423672212989636e+03
            Start		  4.2864682872646954e+03
            Stop		  5.4768977422153812e+03
            Start		  7.1209989032396879e+03
            Stop		  8.3114284514708179e+03
            Start		  9.9555296155832693e+03
            Stop		  1.1145959155958895e+04
            Start		  1.2790060325932007e+04
            Stop		  1.3980489860857719e+04
            Start		  1.5624591035337193e+04
            Stop		  1.6815020566114905e+04
            Start		  1.8459121743748798e+04
            Stop		  1.9649551271928845e+04
            Start		  2.1293652451219474e+04
            Stop		  2.2484081978460039e+04
            Start		  2.4128183157840202e+04
            Stop		  2.5318612685838183e+04
            Start		  2.6962713863739533e+04
            Stop		  2.8153143394155733e+04
            Start		  2.9797244569077688e+04
            Stop		  3.0987674103463854e+04
            Start		  3.2631775274039632e+04
            Stop		  3.3822204813770215e+04
            Start		  3.5466305978826822e+04
            Stop		  3.6656735525038661e+04
            Start		  3.8300836683648457e+04
            Stop		  3.9491266237190757e+04
            Start		  4.1135367388712293e+04
            Stop		  4.2325796950109238e+04
            Start		  4.3969898094215416e+04
            Stop		  4.5160327663643213e+04
            Start		  4.6804428800335721e+04
            Stop		  4.7994858377614750e+04
            Start		  4.9638959507224019e+04
            Stop		  5.0829389091826633e+04
            Start		  5.2473490214997415e+04
            Stop		  5.3663919806071121e+04
            Start		  5.5308020923734228e+04
            Stop		  5.6498450520139013e+04
            Start		  5.8142551633470503e+04
            Stop		  5.9332981233828890e+04
            Start		  6.0977082344198345e+04
            Stop		  6.2167511946955849e+04
            Start		  6.3811613055866466e+04
            Stop		  6.5002042659359708e+04
            Start		  6.6646143768382259e+04
            Stop		  6.7836573370912040e+04
            Start		  6.9480674481615963e+04
            Stop		  7.0671104081521829e+04
            Start		  7.2315205195406292e+04
            Stop		  7.3505634791139353e+04
            Start		  7.5149735909567607e+04
            Stop		  7.6340165499758543e+04
            Start		  7.7984266623897944e+04
            Stop		  7.9174696207417015e+04
            Start		  8.0818797338188044e+04
            Stop		  8.2009226914194747e+04
            Start		  8.3653328052230354e+04
            Stop		  8.4843757620210206e+04
            Strand		 6 59
            Strand		 6 60
            Strand		 6 61
            Strand		 6 62
            Start		  0.0000000000000000e+00
            Stop		  5.1218200003930929e+02
            Start		  2.4798069220209054e+03
            Stop		  3.3467119912676944e+03
            Start		  5.3143372595671572e+03
            Stop		  6.1812430280485087e+03
            Start		  8.1488683371206816e+03
            Stop		  9.0157732693224989e+03
            Start		  1.0983397136195568e+04
            Stop		  1.1850304223631852e+04
            Start		  1.3817929752746328e+04
            Stop		  1.4684834622032375e+04
            Start		  1.6652460379524629e+04
            Stop		  1.7519365564541215e+04
            Start		  1.9486991169538804e+04
            Stop		  2.0353896018616397e+04
            Start		  2.2321521471866959e+04
            Stop		  2.3188426959245138e+04
            Start		  2.5156052587908569e+04
            Stop		  2.6022957431448984e+04
            Start		  2.7990582784225237e+04
            Stop		  2.8857488371210002e+04
            Start		  3.0825114007967335e+04
            Stop		  3.1692018848833839e+04
            Start		  3.3659644169814739e+04
            Stop		  3.4526549787735188e+04
            Start		  3.6494175429524701e+04
            Stop		  3.7361080266550554e+04
            Start		  3.9328705580312009e+04
            Stop		  4.0195611204601570e+04
            Start		  4.2163236852126982e+04
            Stop		  4.3030141683297006e+04
            Start		  4.4997766999351668e+04
            Stop		  4.5864672620632373e+04
            Start		  4.7832298275137946e+04
            Stop		  4.8699203098950922e+04
            Start		  5.0666828421026221e+04
            Stop		  5.1533734035825189e+04
            Start		  5.3501359697849861e+04
            Stop		  5.4368264513917209e+04
            Start		  5.6335889842913006e+04
            Stop		  5.7202795450663914e+04
            Start		  5.9170421119606697e+04
            Stop		  6.0037325928832201e+04
            Start		  6.2004951263855459e+04
            Stop		  6.2871856865806680e+04
            Start		  6.4839482539918099e+04
            Stop		  6.5706387344378192e+04
            Start		  6.7674012683291774e+04
            Stop		  6.8540918281896098e+04
            Start		  7.0508543958544687e+04
            Stop		  7.1375448761140127e+04
            Start		  7.3343074101064034e+04
            Stop		  7.4209979699422736e+04
            Start		  7.6177605375539453e+04
            Stop		  7.7044510179495803e+04
            Start		  7.9012135517350383e+04
            Stop		  7.9879041118631518e+04
            Start		  8.1846666791238735e+04
            Stop		  8.2713571599547577e+04
            Start		  8.4681196932602441e+04
            Stop		  8.5548102539476662e+04
            Strand		 6 63
            Start		  0.0000000000000000e+00
            Stop		  3.9749042875994512e+01
            Start		  2.0073944261790903e+03
            Stop		  2.8742800289243605e+03
            Start		  4.8419262567603482e+03
            Stop		  5.7088103394637692e+03
            Start		  7.6764548059230383e+03
            Stop		  8.5433412822883020e+03
            Start		  1.0510987679638238e+04
            Stop		  1.1377871703720977e+04
            Start		  1.3345518137156647e+04
            Stop		  1.4212402640846285e+04
            Start		  1.6180049101587972e+04
            Stop		  1.7046933100457340e+04
            Start		  1.9014579337622778e+04
            Stop		  1.9881464037116151e+04
            Start		  2.1849110522121922e+04
            Stop		  2.2715994509772863e+04
            Start		  2.4683640684652164e+04
            Stop		  2.5550525446865846e+04
            Start		  2.7518171940980410e+04
            Stop		  2.8385055924366276e+04
            Start		  3.0352702078671718e+04
            Stop		  3.1219586862195716e+04
            Start		  3.3187233358189034e+04
            Stop		  3.4054117341902449e+04
            Start		  3.6021763487228469e+04
            Stop		  3.6888648280580550e+04
            Start		  3.8856294774058239e+04
            Stop		  3.9723178761594128e+04
            Start		  4.1690824900001098e+04
            Stop		  4.2557709701077642e+04
            Start		  4.4525356189130711e+04
            Stop		  4.5392240182973146e+04
            Start		  4.7359886314061456e+04
            Stop		  4.8226771123077560e+04
            Start		  5.0194417604087488e+04
            Stop		  5.1061301605508837e+04
            Start		  5.3028947728941421e+04
            Stop		  5.3895832545941492e+04
            Start		  5.5863479019629885e+04
            Stop		  5.6730363028545995e+04
            Start		  5.8698009144917611e+04
            Stop		  5.9564893968957149e+04
            Start		  6.1532540436357602e+04
            Stop		  6.2399424451367624e+04
            Start		  6.4367070562369605e+04
            Stop		  6.5233955391411146e+04
            Start		  6.7201601854664594e+04
            Stop		  6.8068485873302372e+04
            Start		  7.0036131981517756e+04
            Stop		  7.0903016812696049e+04
            Start		  7.2870663274670733e+04
            Stop		  7.3737547293835727e+04
            Start		  7.5705193402319943e+04
            Stop		  7.6572078232410189e+04
            Start		  7.8539724696200748e+04
            Stop		  7.9406608712697518e+04
            Start		  8.1374254824457559e+04
            Stop		  8.2241139650425714e+04
            Start		  8.4208786118814984e+04
            Stop		  8.5075670129908292e+04
            Strand		 6 64
            Strand		 6 65
            Strand		 6 66
            Strand		 6 67
            Start		  0.0000000000000000e+00
            Stop		  1.0676284737931455e+03
            Start		  2.7117282269070288e+03
            Stop		  3.9021591198710848e+03
            Start		  5.5462589153053977e+03
            Stop		  6.7366898332963101e+03
            Start		  8.3807896206031364e+03
            Stop		  9.5712205447473116e+03
            Start		  1.1215320325392313e+04
            Stop		  1.2405751257186344e+04
            Start		  1.4049851030540014e+04
            Stop		  1.5240281970323902e+04
            Start		  1.6884381736201878e+04
            Stop		  1.8074812684004919e+04
            Start		  1.9718912442546956e+04
            Stop		  2.0909343398042045e+04
            Start		  2.2553443149712522e+04
            Stop		  2.3743874112232592e+04
            Start		  2.5387973857799909e+04
            Stop		  2.6578404826367088e+04
            Start		  2.8222504566869935e+04
            Stop		  2.9412935540238552e+04
            Start		  3.1057035276940238e+04
            Stop		  3.2247466253651459e+04
            Start		  3.3891565987984512e+04
            Stop		  3.5081996966430452e+04
            Start		  3.6726096699933703e+04
            Stop		  3.7916527678427934e+04
            Start		  3.9560627412678950e+04
            Stop		  4.0751058389530626e+04
            Start		  4.2395158126076458e+04
            Stop		  4.3585589099664510e+04
            Start		  4.5229688839953757e+04
            Stop		  4.6420119808798110e+04
            Start		  4.8064219554117262e+04
            Stop		  4.9254650516943788e+04
            Start		  5.0898750268360862e+04
            Stop		  5.2089181224157343e+04
            Start		  5.3733280982474877e+04
            Stop		  5.4923711930535450e+04
            Start		  5.6567811696255274e+04
            Stop		  5.7758242636211442e+04
            Start		  5.9402342409512690e+04
            Stop		  6.0592773341349464e+04
            Start		  6.2236873122080695e+04
            Stop		  6.3427304046137280e+04
            Start		  6.5071403833823118e+04
            Stop		  6.6261834750777954e+04
            Start		  6.7905934544640011e+04
            Stop		  6.9096365455481093e+04
            Start		  7.0740465254472045e+04
            Stop		  7.1930896160453471e+04
            Start		  7.3574995963303096e+04
            Stop		  7.4765426865889996e+04
            Start		  7.6409526671161031e+04
            Stop		  7.7599957571965206e+04
            Start		  7.9244057378116384e+04
            Stop		  8.0434488278825578e+04
            Start		  8.2078588084279341e+04
            Stop		  8.3269018986583062e+04
            Start		  8.4913118789794840e+04
            Stop		  8.6103549695310212e+04
            Strand		 6 68
            Strand		 6 69
            Strand		 6 70
            Strand		 6 71
            Strand		 7 36
            Strand		 7 37
            Strand		 7 38
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 7 39
            Strand		 7 40
            Strand		 7 41
            Strand		 7 42
            Strand		 7 44
            Strand		 7 45
            Strand		 7 46
            Strand		 7 47
            Strand		 7 48
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 7 49
            Strand		 7 50
            Strand		 7 51
            Strand		 7 52
            Strand		 7 53
            Strand		 7 54
            Strand		 7 55
            Strand		 7 56
            Strand		 7 57
            Strand		 7 58
            Strand		 7 59
            Start		  5.0709733844830532e+02
            Stop		  1.6975235347039736e+03
            Start		  3.3416246372469977e+03
            Stop		  4.5320541755715722e+03
            Start		  6.1761553329451490e+03
            Stop		  7.3665848831474495e+03
            Start		  9.0106860452147776e+03
            Stop		  1.0201115587715276e+04
            Start		  1.1845216755909551e+04
            Stop		  1.3035646292530322e+04
            Start		  1.4679747465647593e+04
            Stop		  1.5870176997642593e+04
            Start		  1.7514278174386134e+04
            Stop		  1.8704707703251886e+04
            Start		  2.0348808882162342e+04
            Stop		  2.1539238409527876e+04
            Start		  2.3183339589053845e+04
            Stop		  2.4373769116611511e+04
            Start		  2.6017870295177261e+04
            Stop		  2.7208299824608133e+04
            Start		  2.8852401000682985e+04
            Stop		  3.0042830533583045e+04
            Start		  3.1686931705748604e+04
            Stop		  3.2877361243558524e+04
            Start		  3.4521462410570988e+04
            Stop		  3.5711891954512954e+04
            Start		  3.7355993115357800e+04
            Stop		  3.8546422666381703e+04
            Start		  4.0190523820318282e+04
            Stop		  4.1380953379059953e+04
            Start		  4.3025054525654086e+04
            Stop		  4.4215484092407351e+04
            Start		  4.5859585231550423e+04
            Stop		  4.7050014806254156e+04
            Start		  4.8694115938167939e+04
            Stop		  4.9884545520408668e+04
            Start		  5.1528646645635599e+04
            Stop		  5.2719076234665670e+04
            Start		  5.4363177354045154e+04
            Stop		  5.5553606948815359e+04
            Start		  5.7197708063446960e+04
            Stop		  5.8388137662652771e+04
            Start		  6.0032238773847850e+04
            Stop		  6.1222668375986541e+04
            Start		  6.2866769485210869e+04
            Stop		  6.4057199088647409e+04
            Start		  6.5701300197456774e+04
            Stop		  6.6891729800495654e+04
            Start		  6.8535830910467674e+04
            Stop		  6.9726260511427245e+04
            Start		  7.1370361624092067e+04
            Stop		  7.2560791221378415e+04
            Start		  7.4204892338151505e+04
            Stop		  7.5395321930328297e+04
            Start		  7.7039423052448576e+04
            Stop		  7.8229852638300188e+04
            Start		  7.9873953766775405e+04
            Stop		  8.1064383345360140e+04
            Start		  8.2708484480922911e+04
            Stop		  8.3898914051614294e+04
            Start		  8.5543015194689826e+04
            Stop		  8.6400000000000000e+04
            Strand		 7 60
            Strand		 7 61
            Strand		 7 62
            Strand		 7 63
            Start		  1.5349633527852195e+03
            Stop		  2.4018684006998797e+03
            Start		  4.3694934039026793e+03
            Stop		  5.2363994181141807e+03
            Start		  7.2040247679547574e+03
            Stop		  8.0709296866927771e+03
            Start		  1.0038553472968111e+04
            Stop		  1.0905460638024595e+04
            Start		  1.2873086183421618e+04
            Stop		  1.3739991046763356e+04
            Start		  1.5707616749216964e+04
            Stop		  1.6574521988928940e+04
            Start		  1.8542147599975309e+04
            Stop		  1.9409052446542173e+04
            Start		  2.1376677882209657e+04
            Stop		  2.2243583387208291e+04
            Start		  2.4211209018063470e+04
            Stop		  2.5078113860673446e+04
            Start		  2.7045739207659768e+04
            Stop		  2.7912644800552353e+04
            Start		  2.9880270437845174e+04
            Stop		  3.0747175278694940e+04
            Start		  3.2714800597398116e+04
            Stop		  3.3581706217737526e+04
            Start		  3.5549331859177684e+04
            Stop		  3.6416236696821346e+04
            Start		  3.8383862009166798e+04
            Stop		  3.9250767635007214e+04
            Start		  4.1218393281646218e+04
            Stop		  4.2085298113866935e+04
            Start		  4.4052923428608949e+04
            Stop		  4.4919829051306413e+04
            Start		  4.6887454704637770e+04
            Stop		  4.7754359529720277e+04
            Start		  4.9721984850482695e+04
            Stop		  5.0588890466649602e+04
            Start		  5.2556516127447969e+04
            Stop		  5.3423420944772479e+04
            Start		  5.5391046272573862e+04
            Stop		  5.6257951881515553e+04
            Start		  5.8225577549403752e+04
            Stop		  5.9092482359651847e+04
            Start		  6.1060107693770755e+04
            Stop		  6.1927013296564619e+04
            Start		  6.3894638969980275e+04
            Stop		  6.4761543775049155e+04
            Start		  6.6729169113493990e+04
            Stop		  6.7596074712458008e+04
            Start		  6.9563700388892001e+04
            Stop		  7.0430605191575931e+04
            Start		  7.2398230531544643e+04
            Stop		  7.3265136129721053e+04
            Start		  7.5232761806142575e+04
            Stop		  7.6099666609651089e+04
            Start		  7.8067291948055368e+04
            Stop		  7.8934197548644777e+04
            Start		  8.0901823222023842e+04
            Stop		  8.1768728029425736e+04
            Start		  8.3736353363439848e+04
            Stop		  8.4603258969232877e+04
            Strand		 7 64
            Start		  1.0625512618612188e+03
            Stop		  1.9294386315198562e+03
            Start		  3.8970826851370657e+03
            Stop		  4.7639705189373335e+03
            Start		  6.7316126515943661e+03
            Stop		  7.5984971029313219e+03
            Start		  9.5661432180218981e+03
            Stop		  1.0433027696511210e+04
            Start		  1.2400671045521143e+04
            Stop		  1.3267558737148367e+04
            Start		  1.5235204000641981e+04
            Stop		  1.6102089344711210e+04
            Start		  1.8069733962548791e+04
            Stop		  1.8936620304430067e+04
            Start		  2.0904266952192069e+04
            Stop		  2.1771150884485727e+04
            Start		  2.3738796502646288e+04
            Stop		  2.4605681823736573e+04
            Start		  2.6573328371305437e+04
            Stop		  2.7440212336904460e+04
            Start		  2.9407858305327216e+04
            Stop		  3.0274743274817327e+04
            Start		  3.2242389788764209e+04
            Stop		  3.3109273766219601e+04
            Start		  3.5076919850383121e+04
            Stop		  3.5943804704771632e+04
            Start		  3.7911451204820733e+04
            Stop		  3.8778335189561963e+04
            Start		  4.0745981308479575e+04
            Stop		  4.1612866128919974e+04
            Start		  4.3580512619979883e+04
            Stop		  4.4447396612001714e+04
            Start		  4.6415042737521435e+04
            Stop		  4.7281927552019770e+04
            Start		  4.9249574034905869e+04
            Stop		  5.0116458034819152e+04
            Start		  5.2084104157257825e+04
            Stop		  5.2950988975220214e+04
            Start		  5.4918635450304704e+04
            Stop		  5.5785519457964845e+04
            Start		  5.7753165574677689e+04
            Stop		  5.8620050398404361e+04
            Start		  6.0587696866800834e+04
            Stop		  6.1454580880918867e+04
            Start		  6.3422226992409269e+04
            Stop		  6.4289111821045655e+04
            Start		  6.6256758284828364e+04
            Stop		  6.7123642303058281e+04
            Start		  6.9091288411450849e+04
            Stop		  6.9958173242575547e+04
            Start		  7.1925819704555586e+04
            Stop		  7.2792703723856524e+04
            Start		  7.4760349832052147e+04
            Stop		  7.5627234662573464e+04
            Start		  7.7594881125855740e+04
            Stop		  7.8461765143005323e+04
            Start		  8.0429411254019724e+04
            Stop		  8.1296296080870059e+04
            Start		  8.3263942548328996e+04
            Stop		  8.4130826560477813e+04
            Start		  8.6098472676866048e+04
            Stop		  8.6400000000000000e+04
            Strand		 7 65
            Strand		 7 66
            Strand		 7 67
            Strand		 7 68
            Start		  0.0000000000000000e+00
            Stop		  1.2278465095995627e+02
            Start		  1.7668846185296261e+03
            Stop		  2.9573155667584188e+03
            Start		  4.6014153508718800e+03
            Stop		  5.7918462621293747e+03
            Start		  7.4359460521841793e+03
            Stop		  8.6263769741605556e+03
            Start		  1.0270476757101958e+04
            Stop		  1.1460907686287876e+04
            Start		  1.3105007462109168e+04
            Stop		  1.4295438399209082e+04
            Start		  1.5939538167579722e+04
            Stop		  1.7129969112728719e+04
            Start		  1.8774068873680197e+04
            Stop		  1.9964499826669060e+04
            Start		  2.1608599580559116e+04
            Stop		  2.2799030540831587e+04
            Start		  2.4443130288330398e+04
            Stop		  2.5633561255008088e+04
            Start		  2.7277660997068750e+04
            Stop		  2.8468091968989698e+04
            Start		  3.0112191706806389e+04
            Stop		  3.1302622682576104e+04
            Start		  3.2946722417531622e+04
            Stop		  3.4137153395584312e+04
            Start		  3.5781253129189383e+04
            Stop		  3.6971684107856687e+04
            Start		  3.8615783841683638e+04
            Stop		  3.9806214819267901e+04
            Start		  4.1450314554881610e+04
            Stop		  4.2640745529730382e+04
            Start		  4.4284845268619603e+04
            Stop		  4.5475276239198196e+04
            Start		  4.7119375982710189e+04
            Stop		  4.8309806947669087e+04
            Start		  4.9953906696950406e+04
            Stop		  5.1144337655184572e+04
            Start		  5.2788437411130741e+04
            Stop		  5.3978868361828048e+04
            Start		  5.5622968125044281e+04
            Stop		  5.6813399067721206e+04
            Start		  5.8457498838495834e+04
            Stop		  5.9647929773018710e+04
            Start		  6.1292029551310399e+04
            Stop		  6.2482460477901259e+04
            Start		  6.4126560263341009e+04
            Stop		  6.5316991182567857e+04
            Start		  6.6961090974475082e+04
            Stop		  6.8151521887226889e+04
            Start		  6.9795621684639336e+04
            Stop		  7.0986052592087057e+04
            Start		  7.2630152393803146e+04
            Stop		  7.3820583297348276e+04
            Start		  7.5464683101979710e+04
            Stop		  7.6655114003192808e+04
            Start		  7.8299213809225534e+04
            Stop		  7.9489644709777203e+04
            Start		  8.1133744515638129e+04
            Stop		  8.2324175417225546e+04
            Start		  8.3968275221351418e+04
            Stop		  8.5158706125623983e+04
            Strand		 7 69
            Strand		 7 70
            Strand		 7 71
            Strand		 8 36
            Strand		 8 37
            Strand		 8 38
            Strand		 8 39
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 8 40
            Strand		 8 41
            Strand		 8 42
            Strand		 8 43
            Strand		 8 45
            Strand		 8 46
            Strand		 8 47
            Strand		 8 48
            Strand		 8 49
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 8 50
            Strand		 8 51
            Strand		 8 52
            Strand		 8 53
            Strand		 8 54
            Start		  0.0000000000000000e+00
            Stop		  7.5267990260965246e+02
            Start		  2.3967810495778926e+03
            Stop		  3.5872106099621019e+03
            Start		  5.2313117627960164e+03
            Stop		  6.4217413147581492e+03
            Start		  8.0658424747299086e+03
            Stop		  9.2562720194854737e+03
            Start		  1.0900373185777395e+04
            Stop		  1.2090802724236744e+04
            Start		  1.3734903895846730e+04
            Stop		  1.4925333429225648e+04
            Start		  1.6569434604916172e+04
            Stop		  1.7759864134649262e+04
            Start		  1.9403965313006578e+04
            Stop		  2.0594394840685767e+04
            Start		  2.2238496020181861e+04
            Stop		  2.3428925547486604e+04
            Start		  2.5073026726546144e+04
            Stop		  2.6263456255169578e+04
            Start		  2.7907557432239231e+04
            Stop		  2.9097986963813753e+04
            Start		  3.0742088137430444e+04
            Stop		  3.1932517673455950e+04
            Start		  3.3576618842311174e+04
            Stop		  3.4767048384089154e+04
            Start		  3.6411149547086497e+04
            Stop		  3.7601579095662870e+04
            Start		  3.9245680251966121e+04
            Stop		  4.0436109808085246e+04
            Start		  4.2080210957155257e+04
            Stop		  4.3270640521227149e+04
            Start		  4.4914741662845525e+04
            Stop		  4.6105171234927860e+04
            Start		  4.7749272369206614e+04
            Stop		  4.8939701949002134e+04
            Start		  5.0583803076378754e+04
            Stop		  5.1774232663248229e+04
            Start		  5.3418333784466660e+04
            Stop		  5.4608763377456911e+04
            Start		  5.6252864493534747e+04
            Stop		  5.7443294091420539e+04
            Start		  5.9087395203604610e+04
            Stop		  6.0277824804942262e+04
            Start		  6.1921925914653686e+04
            Stop		  6.3112355517844539e+04
            Start		  6.4756456626616593e+04
            Stop		  6.5946886229977055e+04
            Start		  6.7590987339387793e+04
            Stop		  6.8781416941223390e+04
            Start		  7.0425518052826315e+04
            Stop		  7.1615947651505820e+04
            Start		  7.3260048766761902e+04
            Stop		  7.4450478360789042e+04
            Start		  7.6094579481002555e+04
            Stop		  7.7285009069081687e+04
            Start		  7.8929110195342815e+04
            Stop		  8.0119539776435719e+04
            Start		  8.1763640909573049e+04
            Stop		  8.2954070482944400e+04
            Start		  8.4598171623488321e+04
            Stop		  8.5788601188738059e+04
            Strand		 8 55
            Strand		 8 56
            Strand		 8 57
            Strand		 8 58
            Strand		 8 59
            Strand		 8 60
            Strand		 8 61
            Strand		 8 62
            Strand		 8 63
            Strand		 8 64
            Start		  5.9011978096945631e+02
            Stop		  1.4570248489748230e+03
            Start		  3.4246504910648105e+03
            Stop		  4.2915555825444480e+03
            Start		  6.2591811724778972e+03
            Stop		  7.1260866441557428e+03
            Start		  9.0937119063017781e+03
            Stop		  9.9606168539194459e+03
            Start		  1.1928240819225512e+04
            Stop		  1.2795147812226831e+04
            Start		  1.4762773322104340e+04
            Stop		  1.5629678198210893e+04
            Start		  1.7597304022593333e+04
            Stop		  1.8464209141188781e+04
            Start		  2.0431834739146900e+04
            Stop		  2.1298739591000820e+04
            Start		  2.3266365065716065e+04
            Stop		  2.4133270531601367e+04
            Start		  2.6100896157801311e+04
            Stop		  2.6967801002299275e+04
            Start		  2.8935426362199451e+04
            Stop		  2.9802331941940243e+04
            Start		  3.1769957578131733e+04
            Stop		  3.2636862418963865e+04
            Start		  3.4604487742717822e+04
            Stop		  3.5471393357723915e+04
            Start		  3.7439018999901164e+04
            Stop		  3.8305923836246337e+04
            Start		  4.0273549151626823e+04
            Stop		  4.1140454774166232e+04
            Start		  4.3108080422619263e+04
            Stop		  4.3974985252694270e+04
            Start		  4.5942610570145145e+04
            Stop		  4.6809516189932692e+04
            Start		  4.8777141845629689e+04
            Stop		  4.9644046668161536e+04
            Start		  5.1611671991567964e+04
            Stop		  5.2478577604990140e+04
            Start		  5.4446203268224825e+04
            Stop		  5.5313108083060288e+04
            Start		  5.7280733413222973e+04
            Stop		  5.8147639019820614e+04
            Start		  6.0115264689768883e+04
            Stop		  6.0982169498030256e+04
            Start		  6.2949794833896856e+04
            Stop		  6.3816700435075320e+04
            Start		  6.5784326109808491e+04
            Stop		  6.6651230913741456e+04
            Start		  6.8618856253042381e+04
            Stop		  6.9485761851374671e+04
            Start		  7.1453387528151346e+04
            Stop		  7.2320292330749187e+04
            Start		  7.4287917670541501e+04
            Stop		  7.5154823269171815e+04
            Start		  7.7122448944899807e+04
            Stop		  7.7989353749388305e+04
            Start		  7.9956979086616222e+04
            Stop		  8.0823884688664402e+04
            Start		  8.2791510360432934e+04
            Stop		  8.3658415169711807e+04
            Start		  8.5626040501753785e+04
            Stop		  8.6400000000000000e+04
            Strand		 8 65
            Start		  1.1770840404237069e+02
            Stop		  9.8459262597796419e+02
            Start		  2.9522381511111653e+03
            Stop		  3.8191236207390252e+03
            Start		  5.7867698272583702e+03
            Stop		  6.6536539156466088e+03
            Start		  8.6212984265302639e+03
            Stop		  9.4881848596514228e+03
            Start		  1.1455831250036048e+04
            Stop		  1.2322715275485103e+04
            Start		  1.4290361740066985e+04
            Stop		  1.5157246212766331e+04
            Start		  1.7124892671783309e+04
            Stop		  1.7991776670550920e+04
            Start		  1.9959422918395689e+04
            Stop		  2.0826307607292671e+04
            Start		  2.2793954092050251e+04
            Stop		  2.3660838079422643e+04
            Start		  2.5628484257968674e+04
            Stop		  2.6495369016629535e+04
            Start		  2.8463015510624486e+04
            Stop		  2.9329899494053854e+04
            Start		  3.1297545649349726e+04
            Stop		  3.2164430432022207e+04
            Start		  3.4132076927581307e+04
            Stop		  3.4998960911804752e+04
            Start		  3.6966607056907102e+04
            Stop		  3.7833491850624399e+04
            Start		  3.9801138343275008e+04
            Stop		  4.0668022331749336e+04
            Start		  4.2635668469296761e+04
            Stop		  4.3502553271352648e+04
            Start		  4.5470199758278846e+04
            Stop		  4.6337083753341569e+04
            Start		  4.8304729883262262e+04
            Stop		  4.9171614693523297e+04
            Start		  5.1139261173285806e+04
            Stop		  5.2006145176002567e+04
            Start		  5.3973791298221477e+04
            Stop		  5.4840676116456620e+04
            Start		  5.6808322588988536e+04
            Stop		  5.7675206599051642e+04
            Start		  5.9642852714394197e+04
            Stop		  6.0509737539424532e+04
            Start		  6.2477384005958898e+04
            Stop		  6.3344268021768403e+04
            Start		  6.5311914132111597e+04
            Stop		  6.6178798961720720e+04
            Start		  6.8146445424548743e+04
            Stop		  6.9013329443499388e+04
            Start		  7.0980975551543263e+04
            Stop		  7.1847860382764702e+04
            Start		  7.3815506844828822e+04
            Stop		  7.4682390863765293e+04
            Start		  7.6650036972596296e+04
            Stop		  7.7516921802196535e+04
            Start		  7.9484568266576316e+04
            Stop		  8.0351452282342405e+04
            Start		  8.2319098394908011e+04
            Stop		  8.3185983219937407e+04
            Start		  8.5153629689313791e+04
            Stop		  8.6020513699300616e+04
            Strand		 8 66
            Strand		 8 67
            Strand		 8 68
            Strand		 8 69
            Start		  8.2204520065341364e+02
            Stop		  2.0124720929902471e+03
            Start		  3.6565718124077257e+03
            Stop		  4.8470026886459827e+03
            Start		  6.4911024832514440e+03
            Stop		  7.6815334037972279e+03
            Start		  9.3256331888679688e+03
            Stop		  1.0516064115467001e+04
            Start		  1.2160163893727600e+04
            Stop		  1.3350594828161526e+04
            Start		  1.4994694599027920e+04
            Stop		  1.6185125541499370e+04
            Start		  1.7829225304900225e+04
            Stop		  1.9019656255320835e+04
            Start		  2.0663756011505182e+04
            Stop		  2.1854186969432132e+04
            Start		  2.3498286718968688e+04
            Stop		  2.4688717683627347e+04
            Start		  2.6332817427378970e+04
            Stop		  2.7523248397696774e+04
            Start		  2.9167348136782621e+04
            Stop		  3.0357779111436288e+04
            Start		  3.2001878847182663e+04
            Stop		  3.3192309824656164e+04
            Start		  3.4836409558538304e+04
            Stop		  3.6026840537189455e+04
            Start		  3.7670940270766776e+04
            Stop		  3.8861371248899428e+04
            Start		  4.0505470983746985e+04
            Stop		  4.1695901959685347e+04
            Start		  4.3340001697324777e+04
            Stop		  4.4530432669487149e+04
            Start		  4.6174532411319786e+04
            Stop		  4.7364963378287888e+04
            Start		  4.9009063125533270e+04
            Stop		  5.0199494086114573e+04
            Start		  5.1843593839756868e+04
            Stop		  5.3034024793037010e+04
            Start		  5.4678124553781818e+04
            Stop		  5.5868555499164584e+04
            Start		  5.7512655267407958e+04
            Stop		  5.8703086204641695e+04
            Start		  6.0347185980452705e+04
            Stop		  6.1537616909641183e+04
            Start		  6.3181716692758979e+04
            Stop		  6.4372147614356873e+04
            Start		  6.6016247404202033e+04
            Stop		  6.7206678318995066e+04
            Start		  6.8850778114695131e+04
            Stop		  7.0041209023765361e+04
            Start		  7.1685308824193125e+04
            Stop		  7.2875739728871617e+04
            Start		  7.4519839532694590e+04
            Stop		  7.5710270434502891e+04
            Start		  7.7354370240241755e+04
            Stop		  7.8544801140825133e+04
            Start		  8.0188900946918962e+04
            Stop		  8.1379331847973968e+04
            Start		  8.3023431652848420e+04
            Stop		  8.4213862556048654e+04
            Start		  8.5857962358185410e+04
            Stop		  8.6400000000000000e+04
            Strand		 8 70
            Strand		 8 71
            Strand		 9 36
            Strand		 9 37
            Strand		 9 38
            Strand		 9 39
            Strand		 9 40
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 9 41
            Strand		 9 42
            Strand		 9 43
            Strand		 9 44
            Strand		 9 46
            Strand		 9 47
            Strand		 9 48
            Strand		 9 49
            Strand		 9 50
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 9 51
            Strand		 9 52
            Strand		 9 53
            Strand		 9 54
            Strand		 9 55
            Start		  1.4519398699378851e+03
            Stop		  2.6423672212989691e+03
            Start		  4.2864682872646999e+03
            Stop		  5.4768977422153766e+03
            Start		  7.1209989032396888e+03
            Stop		  8.3114284514708106e+03
            Start		  9.9555296155832730e+03
            Stop		  1.1145959155958895e+04
            Start		  1.2790060325932007e+04
            Stop		  1.3980489860857715e+04
            Start		  1.5624591035337193e+04
            Stop		  1.6815020566114898e+04
            Start		  1.8459121743748798e+04
            Stop		  1.9649551271928845e+04
            Start		  2.1293652451219470e+04
            Stop		  2.2484081978460032e+04
            Start		  2.4128183157840198e+04
            Stop		  2.5318612685838183e+04
            Start		  2.6962713863739526e+04
            Stop		  2.8153143394155719e+04
            Start		  2.9797244569077688e+04
            Stop		  3.0987674103463851e+04
            Start		  3.2631775274039628e+04
            Stop		  3.3822204813770230e+04
            Start		  3.5466305978826822e+04
            Stop		  3.6656735525038661e+04
            Start		  3.8300836683648464e+04
            Stop		  3.9491266237190743e+04
            Start		  4.1135367388712286e+04
            Stop		  4.2325796950109259e+04
            Start		  4.3969898094215401e+04
            Stop		  4.5160327663643235e+04
            Start		  4.6804428800335729e+04
            Stop		  4.7994858377614742e+04
            Start		  4.9638959507223997e+04
            Stop		  5.0829389091826626e+04
            Start		  5.2473490214997437e+04
            Stop		  5.3663919806071121e+04
            Start		  5.5308020923734257e+04
            Stop		  5.6498450520139020e+04
            Start		  5.8142551633470495e+04
            Stop		  5.9332981233828883e+04
            Start		  6.0977082344198359e+04
            Stop		  6.2167511946955856e+04
            Start		  6.3811613055866466e+04
            Stop		  6.5002042659359708e+04
            Start		  6.6646143768382288e+04
            Stop		  6.7836573370912069e+04
            Start		  6.9480674481615992e+04
            Stop		  7.0671104081521815e+04
            Start		  7.2315205195406321e+04
            Stop		  7.3505634791139382e+04
            Start		  7.5149735909567622e+04
            Stop		  7.6340165499758543e+04
            Start		  7.7984266623897958e+04
            Stop		  7.9174696207417044e+04
            Start		  8.0818797338188029e+04
            Stop		  8.2009226914194762e+04
            Start		  8.3653328052230383e+04
            Stop		  8.4843757620210206e+04
            Strand		 9 56
            Strand		 9 57
            Strand		 9 58
            Strand		 9 59
            Strand		 9 60
            Start		  0.0000000000000000e+00
            Stop		  3.9749042875993602e+01
            Start		  2.0073944261790914e+03
            Stop		  2.8742800289243537e+03
            Start		  4.8419262567603464e+03
            Stop		  5.7088103394637683e+03
            Start		  7.6764548059230419e+03
            Stop		  8.5433412822883038e+03
            Start		  1.0510987679638245e+04
            Stop		  1.1377871703720974e+04
            Start		  1.3345518137156643e+04
            Stop		  1.4212402640846280e+04
            Start		  1.6180049101587978e+04
            Stop		  1.7046933100457343e+04
            Start		  1.9014579337622781e+04
            Stop		  1.9881464037116151e+04
            Start		  2.1849110522121915e+04
            Stop		  2.2715994509772856e+04
            Start		  2.4683640684652160e+04
            Stop		  2.5550525446865850e+04
            Start		  2.7518171940980410e+04
            Stop		  2.8385055924366283e+04
            Start		  3.0352702078671718e+04
            Stop		  3.1219586862195716e+04
            Start		  3.3187233358189034e+04
            Stop		  3.4054117341902442e+04
            Start		  3.6021763487228469e+04
            Stop		  3.6888648280580550e+04
            Start		  3.8856294774058239e+04
            Stop		  3.9723178761594128e+04
            Start		  4.1690824900001098e+04
            Stop		  4.2557709701077642e+04
            Start		  4.4525356189130711e+04
            Stop		  4.5392240182973139e+04
            Start		  4.7359886314061456e+04
            Stop		  4.8226771123077553e+04
            Start		  5.0194417604087503e+04
            Stop		  5.1061301605508830e+04
            Start		  5.3028947728941428e+04
            Stop		  5.3895832545941499e+04
            Start		  5.5863479019629893e+04
            Stop		  5.6730363028546002e+04
            Start		  5.8698009144917603e+04
            Stop		  5.9564893968957142e+04
            Start		  6.1532540436357587e+04
            Stop		  6.2399424451367602e+04
            Start		  6.4367070562369605e+04
            Stop		  6.5233955391411153e+04
            Start		  6.7201601854664608e+04
            Stop		  6.8068485873302358e+04
            Start		  7.0036131981517741e+04
            Stop		  7.0903016812696063e+04
            Start		  7.2870663274670733e+04
            Stop		  7.3737547293835727e+04
            Start		  7.5705193402319943e+04
            Stop		  7.6572078232410189e+04
            Start		  7.8539724696200748e+04
            Stop		  7.9406608712697533e+04
            Start		  8.1374254824457574e+04
            Stop		  8.2241139650425714e+04
            Start		  8.4208786118814984e+04
            Stop		  8.5075670129908292e+04
            Strand		 9 61
            Strand		 9 62
            Strand		 9 63
            Strand		 9 64
            Strand		 9 65
            Start		  0.0000000000000000e+00
            Stop		  5.1218200003931031e+02
            Start		  2.4798069220209027e+03
            Stop		  3.3467119912676940e+03
            Start		  5.3143372595671563e+03
            Stop		  6.1812430280485078e+03
            Start		  8.1488683371206816e+03
            Stop		  9.0157732693224989e+03
            Start		  1.0983397136195568e+04
            Stop		  1.1850304223631851e+04
            Start		  1.3817929752746320e+04
            Stop		  1.4684834622032382e+04
            Start		  1.6652460379524622e+04
            Stop		  1.7519365564541215e+04
            Start		  1.9486991169538804e+04
            Stop		  2.0353896018616393e+04
            Start		  2.2321521471866959e+04
            Stop		  2.3188426959245142e+04
            Start		  2.5156052587908569e+04
            Stop		  2.6022957431448987e+04
            Start		  2.7990582784225237e+04
            Stop		  2.8857488371210002e+04
            Start		  3.0825114007967335e+04
            Stop		  3.1692018848833843e+04
            Start		  3.3659644169814739e+04
            Stop		  3.4526549787735188e+04
            Start		  3.6494175429524701e+04
            Stop		  3.7361080266550554e+04
            Start		  3.9328705580312009e+04
            Stop		  4.0195611204601570e+04
            Start		  4.2163236852126982e+04
            Stop		  4.3030141683297006e+04
            Start		  4.4997766999351668e+04
            Stop		  4.5864672620632373e+04
            Start		  4.7832298275137946e+04
            Stop		  4.8699203098950922e+04
            Start		  5.0666828421026221e+04
            Stop		  5.1533734035825197e+04
            Start		  5.3501359697849861e+04
            Stop		  5.4368264513917209e+04
            Start		  5.6335889842912999e+04
            Stop		  5.7202795450663907e+04
            Start		  5.9170421119606690e+04
            Stop		  6.0037325928832201e+04
            Start		  6.2004951263855459e+04
            Stop		  6.2871856865806672e+04
            Start		  6.4839482539918114e+04
            Stop		  6.5706387344378192e+04
            Start		  6.7674012683291774e+04
            Stop		  6.8540918281896113e+04
            Start		  7.0508543958544673e+04
            Stop		  7.1375448761140113e+04
            Start		  7.3343074101064034e+04
            Stop		  7.4209979699422736e+04
            Start		  7.6177605375539453e+04
            Stop		  7.7044510179495803e+04
            Start		  7.9012135517350369e+04
            Stop		  7.9879041118631518e+04
            Start		  8.1846666791238749e+04
            Stop		  8.2713571599547591e+04
            Start		  8.4681196932602441e+04
            Stop		  8.5548102539476662e+04
            Strand		 9 66
            Strand		 9 67
            Strand		 9 68
            Strand		 9 69
            Strand		 9 70
            Start		  0.0000000000000000e+00
            Stop		  1.0676284737931480e+03
            Start		  2.7117282269070311e+03
            Stop		  3.9021591198710867e+03
            Start		  5.5462589153054005e+03
            Stop		  6.7366898332963083e+03
            Start		  8.3807896206031401e+03
            Stop		  9.5712205447473079e+03
            Start		  1.1215320325392313e+04
            Stop		  1.2405751257186350e+04
            Start		  1.4049851030540018e+04
            Stop		  1.5240281970323904e+04
            Start		  1.6884381736201878e+04
            Stop		  1.8074812684004919e+04
            Start		  1.9718912442546953e+04
            Stop		  2.0909343398042049e+04
            Start		  2.2553443149712522e+04
            Stop		  2.3743874112232588e+04
            Start		  2.5387973857799905e+04
            Stop		  2.6578404826367088e+04
            Start		  2.8222504566869939e+04
            Stop		  2.9412935540238559e+04
            Start		  3.1057035276940242e+04
            Stop		  3.2247466253651466e+04
            Start		  3.3891565987984519e+04
            Stop		  3.5081996966430452e+04
            Start		  3.6726096699933718e+04
            Stop		  3.7916527678427934e+04
            Start		  3.9560627412678965e+04
            Stop		  4.0751058389530626e+04
            Start		  4.2395158126076458e+04
            Stop		  4.3585589099664518e+04
            Start		  4.5229688839953757e+04
            Stop		  4.6420119808798103e+04
            Start		  4.8064219554117255e+04
            Stop		  4.9254650516943795e+04
            Start		  5.0898750268360869e+04
            Stop		  5.2089181224157364e+04
            Start		  5.3733280982474869e+04
            Stop		  5.4923711930535472e+04
            Start		  5.6567811696255289e+04
            Stop		  5.7758242636211435e+04
            Start		  5.9402342409512690e+04
            Stop		  6.0592773341349472e+04
            Start		  6.2236873122080709e+04
            Stop		  6.3427304046137273e+04
            Start		  6.5071403833823104e+04
            Stop		  6.6261834750777984e+04
            Start		  6.7905934544639997e+04
            Stop		  6.9096365455481107e+04
            Start		  7.0740465254472016e+04
            Stop		  7.1930896160453485e+04
            Start		  7.3574995963303096e+04
            Stop		  7.4765426865890011e+04
            Start		  7.6409526671161031e+04
            Stop		  7.7599957571965220e+04
            Start		  7.9244057378116384e+04
            Stop		  8.0434488278825593e+04
            Start		  8.2078588084279370e+04
            Stop		  8.3269018986583047e+04
            Start		  8.4913118789794840e+04
            Stop		  8.6103549695310197e+04
            Strand		 9 71
            Strand		 10 36
            Strand		 10 37
            Strand		 10 38
            Strand		 10 39
            Strand		 10 40
            Strand		 10 41
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 10 42
            Strand		 10 43
            Strand		 10 44
            Strand		 10 45
            Strand		 10 47
            Strand		 10 48
            Strand		 10 49
            Strand		 10 50
            Strand		 10 51
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 10 52
            Strand		 10 53
            Strand		 10 54
            Strand		 10 55
            Strand		 10 56
            Start		  5.0709733844830504e+02
            Stop		  1.6975235347039745e+03
            Start		  3.3416246372469977e+03
            Stop		  4.5320541755715676e+03
            Start		  6.1761553329451463e+03
            Stop		  7.3665848831474505e+03
            Start		  9.0106860452147812e+03
            Stop		  1.0201115587715278e+04
            Start		  1.1845216755909549e+04
            Stop		  1.3035646292530320e+04
            Start		  1.4679747465647595e+04
            Stop		  1.5870176997642593e+04
            Start		  1.7514278174386138e+04
            Stop		  1.8704707703251886e+04
            Start		  2.0348808882162342e+04
            Stop		  2.1539238409527876e+04
            Start		  2.3183339589053838e+04
            Stop		  2.4373769116611507e+04
            Start		  2.6017870295177258e+04
            Stop		  2.7208299824608130e+04
            Start		  2.8852401000682989e+04
            Stop		  3.0042830533583034e+04
            Start		  3.1686931705748586e+04
            Stop		  3.2877361243558524e+04
            Start		  3.4521462410570988e+04
            Stop		  3.5711891954512954e+04
            Start		  3.7355993115357807e+04
            Stop		  3.8546422666381710e+04
            Start		  4.0190523820318282e+04
            Stop		  4.1380953379059945e+04
            Start		  4.3025054525654086e+04
            Stop		  4.4215484092407358e+04
            Start		  4.5859585231550438e+04
            Stop		  4.7050014806254156e+04
            Start		  4.8694115938167924e+04
            Stop		  4.9884545520408661e+04
            Start		  5.1528646645635592e+04
            Stop		  5.2719076234665663e+04
            Start		  5.4363177354045140e+04
            Stop		  5.5553606948815359e+04
            Start		  5.7197708063446938e+04
            Stop		  5.8388137662652764e+04
            Start		  6.0032238773847843e+04
            Stop		  6.1222668375986555e+04
            Start		  6.2866769485210854e+04
            Stop		  6.4057199088647416e+04
            Start		  6.5701300197456774e+04
            Stop		  6.6891729800495668e+04
            Start		  6.8535830910467659e+04
            Stop		  6.9726260511427259e+04
            Start		  7.1370361624092053e+04
            Stop		  7.2560791221378400e+04
            Start		  7.4204892338151520e+04
            Stop		  7.5395321930328311e+04
            Start		  7.7039423052448605e+04
            Stop		  7.8229852638300203e+04
            Start		  7.9873953766775419e+04
            Stop		  8.1064383345360140e+04
            Start		  8.2708484480922882e+04
            Stop		  8.3898914051614309e+04
            Start		  8.5543015194689826e+04
            Stop		  8.6400000000000000e+04
            Strand		 10 57
            Strand		 10 58
            Strand		 10 59
            Strand		 10 60
            Start		  1.5349633527852166e+03
            Stop		  2.4018684006998792e+03
            Start		  4.3694934039026757e+03
            Stop		  5.2363994181141798e+03
            Start		  7.2040247679547629e+03
            Stop		  8.0709296866927752e+03
            Start		  1.0038553472968111e+04
            Stop		  1.0905460638024595e+04
            Start		  1.2873086183421619e+04
            Stop		  1.3739991046763353e+04
            Start		  1.5707616749216973e+04
            Stop		  1.6574521988928940e+04
            Start		  1.8542147599975309e+04
            Stop		  1.9409052446542177e+04
            Start		  2.1376677882209657e+04
            Stop		  2.2243583387208291e+04
            Start		  2.4211209018063466e+04
            Stop		  2.5078113860673446e+04
            Start		  2.7045739207659761e+04
            Stop		  2.7912644800552356e+04
            Start		  2.9880270437845182e+04
            Stop		  3.0747175278694940e+04
            Start		  3.2714800597398109e+04
            Stop		  3.3581706217737526e+04
            Start		  3.5549331859177684e+04
            Stop		  3.6416236696821346e+04
            Start		  3.8383862009166791e+04
            Stop		  3.9250767635007222e+04
            Start		  4.1218393281646218e+04
            Stop		  4.2085298113866942e+04
            Start		  4.4052923428608949e+04
            Stop		  4.4919829051306420e+04
            Start		  4.6887454704637763e+04
            Stop		  4.7754359529720277e+04
            Start		  4.9721984850482695e+04
            Stop		  5.0588890466649602e+04
            Start		  5.2556516127447969e+04
            Stop		  5.3423420944772479e+04
            Start		  5.5391046272573854e+04
            Stop		  5.6257951881515546e+04
            Start		  5.8225577549403752e+04
            Stop		  5.9092482359651847e+04
            Start		  6.1060107693770769e+04
            Stop		  6.1927013296564626e+04
            Start		  6.3894638969980260e+04
            Stop		  6.4761543775049184e+04
            Start		  6.6729169113494005e+04
            Stop		  6.7596074712458008e+04
            Start		  6.9563700388892001e+04
            Stop		  7.0430605191575931e+04
            Start		  7.2398230531544643e+04
            Stop		  7.3265136129721053e+04
            Start		  7.5232761806142575e+04
            Stop		  7.6099666609651089e+04
            Start		  7.8067291948055368e+04
            Stop		  7.8934197548644777e+04
            Start		  8.0901823222023842e+04
            Stop		  8.1768728029425736e+04
            Start		  8.3736353363439848e+04
            Stop		  8.4603258969232891e+04
            Strand		 10 61
            Start		  1.0625512618612192e+03
            Stop		  1.9294386315198562e+03
            Start		  3.8970826851370671e+03
            Stop		  4.7639705189373326e+03
            Start		  6.7316126515943661e+03
            Stop		  7.5984971029313156e+03
            Start		  9.5661432180218981e+03
            Stop		  1.0433027696511208e+04
            Start		  1.2400671045521141e+04
            Stop		  1.3267558737148373e+04
            Start		  1.5235204000641985e+04
            Stop		  1.6102089344711208e+04
            Start		  1.8069733962548795e+04
            Stop		  1.8936620304430064e+04
            Start		  2.0904266952192069e+04
            Stop		  2.1771150884485738e+04
            Start		  2.3738796502646295e+04
            Stop		  2.4605681823736573e+04
            Start		  2.6573328371305433e+04
            Stop		  2.7440212336904453e+04
            Start		  2.9407858305327220e+04
            Stop		  3.0274743274817327e+04
            Start		  3.2242389788764216e+04
            Stop		  3.3109273766219594e+04
            Start		  3.5076919850383114e+04
            Stop		  3.5943804704771646e+04
            Start		  3.7911451204820740e+04
            Stop		  3.8778335189561963e+04
            Start		  4.0745981308479590e+04
            Stop		  4.1612866128919981e+04
            Start		  4.3580512619979891e+04
            Stop		  4.4447396612001721e+04
            Start		  4.6415042737521457e+04
            Stop		  4.7281927552019770e+04
            Start		  4.9249574034905876e+04
            Stop		  5.0116458034819152e+04
            Start		  5.2084104157257825e+04
            Stop		  5.2950988975220222e+04
            Start		  5.4918635450304704e+04
            Stop		  5.5785519457964845e+04
            Start		  5.7753165574677689e+04
            Stop		  5.8620050398404346e+04
            Start		  6.0587696866800827e+04
            Stop		  6.1454580880918867e+04
            Start		  6.3422226992409269e+04
            Stop		  6.4289111821045648e+04
            Start		  6.6256758284828349e+04
            Stop		  6.7123642303058237e+04
            Start		  6.9091288411450849e+04
            Stop		  6.9958173242575533e+04
            Start		  7.1925819704555557e+04
            Stop		  7.2792703723856524e+04
            Start		  7.4760349832052147e+04
            Stop		  7.5627234662573450e+04
            Start		  7.7594881125855725e+04
            Stop		  7.8461765143005294e+04
            Start		  8.0429411254019724e+04
            Stop		  8.1296296080870015e+04
            Start		  8.3263942548329011e+04
            Stop		  8.4130826560477784e+04
            Start		  8.6098472676866048e+04
            Stop		  8.6400000000000000e+04
            Strand		 10 62
            Strand		 10 63
            Strand		 10 64
            Strand		 10 65
            Strand		 10 66
            Strand		 10 67
            Strand		 10 68
            Strand		 10 69
            Strand		 10 70
            Strand		 10 71
            Start		  0.0000000000000000e+00
            Stop		  1.2278465095995942e+02
            Start		  1.7668846185296206e+03
            Stop		  2.9573155667584274e+03
            Start		  4.6014153508718864e+03
            Stop		  5.7918462621293838e+03
            Start		  7.4359460521841793e+03
            Stop		  8.6263769741605611e+03
            Start		  1.0270476757101962e+04
            Stop		  1.1460907686287874e+04
            Start		  1.3105007462109175e+04
            Stop		  1.4295438399209086e+04
            Start		  1.5939538167579723e+04
            Stop		  1.7129969112728708e+04
            Start		  1.8774068873680197e+04
            Stop		  1.9964499826669060e+04
            Start		  2.1608599580559123e+04
            Stop		  2.2799030540831580e+04
            Start		  2.4443130288330391e+04
            Stop		  2.5633561255008088e+04
            Start		  2.7277660997068753e+04
            Stop		  2.8468091968989698e+04
            Start		  3.0112191706806389e+04
            Stop		  3.1302622682576104e+04
            Start		  3.2946722417531622e+04
            Stop		  3.4137153395584319e+04
            Start		  3.5781253129189376e+04
            Stop		  3.6971684107856687e+04
            Start		  3.8615783841683653e+04
            Stop		  3.9806214819267894e+04
            Start		  4.1450314554881610e+04
            Stop		  4.2640745529730360e+04
            Start		  4.4284845268619611e+04
            Stop		  4.5475276239198189e+04
            Start		  4.7119375982710197e+04
            Stop		  4.8309806947669094e+04
            Start		  4.9953906696950420e+04
            Stop		  5.1144337655184572e+04
            Start		  5.2788437411130741e+04
            Stop		  5.3978868361828056e+04
            Start		  5.5622968125044288e+04
            Stop		  5.6813399067721220e+04
            Start		  5.8457498838495820e+04
            Stop		  5.9647929773018710e+04
            Start		  6.1292029551310385e+04
            Stop		  6.2482460477901266e+04
            Start		  6.4126560263341024e+04
            Stop		  6.5316991182567850e+04
            Start		  6.6961090974475097e+04
            Stop		  6.8151521887226860e+04
            Start		  6.9795621684639336e+04
            Stop		  7.0986052592087071e+04
            Start		  7.2630152393803117e+04
            Stop		  7.3820583297348290e+04
            Start		  7.5464683101979681e+04
            Stop		  7.6655114003192808e+04
            Start		  7.8299213809225548e+04
            Stop		  7.9489644709777189e+04
            Start		  8.1133744515638115e+04
            Stop		  8.2324175417225546e+04
            Start		  8.3968275221351432e+04
            Stop		  8.5158706125623998e+04
            Strand		 11 36
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 11 37
            Strand		 11 38
            Strand		 11 39
            Strand		 11 40
            Strand		 11 41
            Strand		 11 42
            Strand		 11 43
            Strand		 11 44
            Strand		 11 45
            Strand		 11 46
            Strand		 11 48
            Strand		 11 49
            Strand		 11 50
            Strand		 11 51
            Strand		 11 52
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 11 53
            Strand		 11 54
            Strand		 11 55
            Strand		 11 56
            Strand		 11 57
            Start		  0.0000000000000000e+00
            Stop		  7.5267990260965087e+02
            Start		  2.3967810495778904e+03
            Stop		  3.5872106099621042e+03
            Start		  5.2313117627960100e+03
            Stop		  6.4217413147581456e+03
            Start		  8.0658424747299105e+03
            Stop		  9.2562720194854792e+03
            Start		  1.0900373185777395e+04
            Stop		  1.2090802724236752e+04
            Start		  1.3734903895846721e+04
            Stop		  1.4925333429225650e+04
            Start		  1.6569434604916176e+04
            Stop		  1.7759864134649273e+04
            Start		  1.9403965313006582e+04
            Stop		  2.0594394840685763e+04
            Start		  2.2238496020181865e+04
            Stop		  2.3428925547486608e+04
            Start		  2.5073026726546137e+04
            Stop		  2.6263456255169585e+04
            Start		  2.7907557432239235e+04
            Stop		  2.9097986963813753e+04
            Start		  3.0742088137430455e+04
            Stop		  3.1932517673455957e+04
            Start		  3.3576618842311174e+04
            Stop		  3.4767048384089168e+04
            Start		  3.6411149547086490e+04
            Stop		  3.7601579095662877e+04
            Start		  3.9245680251966129e+04
            Stop		  4.0436109808085246e+04
            Start		  4.2080210957155250e+04
            Stop		  4.3270640521227157e+04
            Start		  4.4914741662845525e+04
            Stop		  4.6105171234927868e+04
            Start		  4.7749272369206621e+04
            Stop		  4.8939701949002134e+04
            Start		  5.0583803076378768e+04
            Stop		  5.1774232663248229e+04
            Start		  5.3418333784466646e+04
            Stop		  5.4608763377456911e+04
            Start		  5.6252864493534755e+04
            Stop		  5.7443294091420554e+04
            Start		  5.9087395203604603e+04
            Stop		  6.0277824804942255e+04
            Start		  6.1921925914653686e+04
            Stop		  6.3112355517844553e+04
            Start		  6.4756456626616593e+04
            Stop		  6.5946886229977099e+04
            Start		  6.7590987339387793e+04
            Stop		  6.8781416941223404e+04
            Start		  7.0425518052826315e+04
            Stop		  7.1615947651505805e+04
            Start		  7.3260048766761916e+04
            Stop		  7.4450478360789057e+04
            Start		  7.6094579481002555e+04
            Stop		  7.7285009069081672e+04
            Start		  7.8929110195342815e+04
            Stop		  8.0119539776435719e+04
            Start		  8.1763640909573020e+04
            Stop		  8.2954070482944400e+04
            Start		  8.4598171623488306e+04
            Stop		  8.5788601188738059e+04
            Strand		 11 58
            Strand		 11 59
            Strand		 11 60
            Strand		 11 61
            Start		  5.9011978096945450e+02
            Stop		  1.4570248489748235e+03
            Start		  3.4246504910648100e+03
            Stop		  4.2915555825444580e+03
            Start		  6.2591811724779036e+03
            Stop		  7.1260866441557409e+03
            Start		  9.0937119063017726e+03
            Stop		  9.9606168539194441e+03
            Start		  1.1928240819225512e+04
            Stop		  1.2795147812226825e+04
            Start		  1.4762773322104333e+04
            Stop		  1.5629678198210899e+04
            Start		  1.7597304022593329e+04
            Stop		  1.8464209141188781e+04
            Start		  2.0431834739146896e+04
            Stop		  2.1298739591000820e+04
            Start		  2.3266365065716065e+04
            Stop		  2.4133270531601363e+04
            Start		  2.6100896157801319e+04
            Stop		  2.6967801002299282e+04
            Start		  2.8935426362199454e+04
            Stop		  2.9802331941940254e+04
            Start		  3.1769957578131736e+04
            Stop		  3.2636862418963872e+04
            Start		  3.4604487742717829e+04
            Stop		  3.5471393357723922e+04
            Start		  3.7439018999901171e+04
            Stop		  3.8305923836246337e+04
            Start		  4.0273549151626838e+04
            Stop		  4.1140454774166232e+04
            Start		  4.3108080422619270e+04
            Stop		  4.3974985252694278e+04
            Start		  4.5942610570145145e+04
            Stop		  4.6809516189932685e+04
            Start		  4.8777141845629696e+04
            Stop		  4.9644046668161529e+04
            Start		  5.1611671991567957e+04
            Stop		  5.2478577604990147e+04
            Start		  5.4446203268224825e+04
            Stop		  5.5313108083060288e+04
            Start		  5.7280733413222959e+04
            Stop		  5.8147639019820614e+04
            Start		  6.0115264689768883e+04
            Stop		  6.0982169498030249e+04
            Start		  6.2949794833896849e+04
            Stop		  6.3816700435075334e+04
            Start		  6.5784326109808448e+04
            Stop		  6.6651230913741441e+04
            Start		  6.8618856253042351e+04
            Stop		  6.9485761851374671e+04
            Start		  7.1453387528151332e+04
            Stop		  7.2320292330749173e+04
            Start		  7.4287917670541472e+04
            Stop		  7.5154823269171800e+04
            Start		  7.7122448944899792e+04
            Stop		  7.7989353749388290e+04
            Start		  7.9956979086616222e+04
            Stop		  8.0823884688664388e+04
            Start		  8.2791510360432920e+04
            Stop		  8.3658415169711807e+04
            Start		  8.5626040501753785e+04
            Stop		  8.6400000000000000e+04
            Strand		 11 62
            Start		  1.1770840404237488e+02
            Stop		  9.8459262597795339e+02
            Start		  2.9522381511111671e+03
            Stop		  3.8191236207390270e+03
            Start		  5.7867698272583630e+03
            Stop		  6.6536539156466097e+03
            Start		  8.6212984265302657e+03
            Stop		  9.4881848596514192e+03
            Start		  1.1455831250036046e+04
            Stop		  1.2322715275485107e+04
            Start		  1.4290361740066979e+04
            Stop		  1.5157246212766331e+04
            Start		  1.7124892671783309e+04
            Stop		  1.7991776670550917e+04
            Start		  1.9959422918395696e+04
            Stop		  2.0826307607292671e+04
            Start		  2.2793954092050255e+04
            Stop		  2.3660838079422640e+04
            Start		  2.5628484257968674e+04
            Stop		  2.6495369016629538e+04
            Start		  2.8463015510624489e+04
            Stop		  2.9329899494053858e+04
            Start		  3.1297545649349737e+04
            Stop		  3.2164430432022211e+04
            Start		  3.4132076927581307e+04
            Stop		  3.4998960911804759e+04
            Start		  3.6966607056907102e+04
            Stop		  3.7833491850624399e+04
            Start		  3.9801138343275015e+04
            Stop		  4.0668022331749344e+04
            Start		  4.2635668469296768e+04
            Stop		  4.3502553271352655e+04
            Start		  4.5470199758278854e+04
            Stop		  4.6337083753341576e+04
            Start		  4.8304729883262262e+04
            Stop		  4.9171614693523297e+04
            Start		  5.1139261173285813e+04
            Stop		  5.2006145176002567e+04
            Start		  5.3973791298221484e+04
            Stop		  5.4840676116456620e+04
            Start		  5.6808322588988529e+04
            Stop		  5.7675206599051635e+04
            Start		  5.9642852714394190e+04
            Stop		  6.0509737539424539e+04
            Start		  6.2477384005958891e+04
            Stop		  6.3344268021768403e+04
            Start		  6.5311914132111597e+04
            Stop		  6.6178798961720706e+04
            Start		  6.8146445424548743e+04
            Stop		  6.9013329443499373e+04
            Start		  7.0980975551543263e+04
            Stop		  7.1847860382764702e+04
            Start		  7.3815506844828822e+04
            Stop		  7.4682390863765308e+04
            Start		  7.6650036972596296e+04
            Stop		  7.7516921802196550e+04
            Start		  7.9484568266576316e+04
            Stop		  8.0351452282342405e+04
            Start		  8.2319098394907996e+04
            Stop		  8.3185983219937392e+04
            Start		  8.5153629689313791e+04
            Stop		  8.6020513699300616e+04
            Strand		 11 63
            Strand		 11 64
            Strand		 11 65
            Strand		 11 66
            Start		  8.2204520065341330e+02
            Stop		  2.0124720929902492e+03
            Start		  3.6565718124077221e+03
            Stop		  4.8470026886459873e+03
            Start		  6.4911024832514413e+03
            Stop		  7.6815334037972298e+03
            Start		  9.3256331888679706e+03
            Stop		  1.0516064115467001e+04
            Start		  1.2160163893727597e+04
            Stop		  1.3350594828161524e+04
            Start		  1.4994694599027922e+04
            Stop		  1.6185125541499378e+04
            Start		  1.7829225304900225e+04
            Stop		  1.9019656255320824e+04
            Start		  2.0663756011505189e+04
            Stop		  2.1854186969432132e+04
            Start		  2.3498286718968691e+04
            Stop		  2.4688717683627347e+04
            Start		  2.6332817427378963e+04
            Stop		  2.7523248397696781e+04
            Start		  2.9167348136782617e+04
            Stop		  3.0357779111436292e+04
            Start		  3.2001878847182667e+04
            Stop		  3.3192309824656157e+04
            Start		  3.4836409558538297e+04
            Stop		  3.6026840537189455e+04
            Start		  3.7670940270766769e+04
            Stop		  3.8861371248899428e+04
            Start		  4.0505470983746978e+04
            Stop		  4.1695901959685347e+04
            Start		  4.3340001697324784e+04
            Stop		  4.4530432669487149e+04
            Start		  4.6174532411319786e+04
            Stop		  4.7364963378287881e+04
            Start		  4.9009063125533263e+04
            Stop		  5.0199494086114588e+04
            Start		  5.1843593839756883e+04
            Stop		  5.3034024793037010e+04
            Start		  5.4678124553781810e+04
            Stop		  5.5868555499164584e+04
            Start		  5.7512655267407965e+04
            Stop		  5.8703086204641688e+04
            Start		  6.0347185980452719e+04
            Stop		  6.1537616909641183e+04
            Start		  6.3181716692758993e+04
            Stop		  6.4372147614356894e+04
            Start		  6.6016247404202062e+04
            Stop		  6.7206678318995051e+04
            Start		  6.8850778114695146e+04
            Stop		  7.0041209023765347e+04
            Start		  7.1685308824193096e+04
            Stop		  7.2875739728871617e+04
            Start		  7.4519839532694590e+04
            Stop		  7.5710270434502905e+04
            Start		  7.7354370240241769e+04
            Stop		  7.8544801140825119e+04
            Start		  8.0188900946918948e+04
            Stop		  8.1379331847973954e+04
            Start		  8.3023431652848420e+04
            Stop		  8.4213862556048669e+04
            Start		  8.5857962358185410e+04
            Stop		  8.6400000000000000e+04
            Strand		 11 67
            Strand		 11 68
            Strand		 11 69
            Strand		 11 70
            Strand		 11 71
            Strand		 12 36
            Strand		 12 37
            Strand		 12 38
            Start		  0.0000000000000000e+00
            Stop		  9.1015461970999149e+02
            Start		  2.5542543634820217e+03
            Stop		  3.7446851984128325e+03
            Start		  5.3887850055525842e+03
            Stop		  6.5792159088099052e+03
            Start		  8.2233157136238497e+03
            Stop		  9.4137466153627192e+03
            Start		  1.1057846419893473e+04
            Stop		  1.2248277323039782e+04
            Start		  1.3892377125550616e+04
            Stop		  1.5082808031667715e+04
            Start		  1.6726907830710967e+04
            Stop		  1.7917338741294257e+04
            Start		  1.9561438535569439e+04
            Stop		  2.0751869451909835e+04
            Start		  2.2395969240331295e+04
            Stop		  2.3586400163462164e+04
            Start		  2.5230499945206266e+04
            Stop		  2.6420930875857670e+04
            Start		  2.8065030650399109e+04
            Stop		  2.9255461588965773e+04
            Start		  3.0899561356100676e+04
            Stop		  3.2089992302624501e+04
            Start		  3.3734092062479431e+04
            Stop		  3.4924523016647712e+04
            Start		  3.6568622769674228e+04
            Stop		  3.7759053730833228e+04
            Start		  3.9403153477788008e+04
            Stop		  4.0593584444971661e+04
            Start		  4.2237684186883453e+04
            Stop		  4.3428115158855690e+04
            Start		  4.5072214896980091e+04
            Stop		  4.6262645872289089e+04
            Start		  4.7906745608053592e+04
            Stop		  4.9097176585095425e+04
            Start		  5.0741276320036624e+04
            Stop		  5.1931707297125773e+04
            Start		  5.3575807032822064e+04
            Stop		  5.4766238008265180e+04
            Start		  5.6410337746267433e+04
            Stop		  5.7600768718437837e+04
            Start		  5.9244868460201447e+04
            Stop		  6.0435299427610335e+04
            Start		  6.2079399174431252e+04
            Stop		  6.3269830135793163e+04
            Start		  6.4913929888751067e+04
            Stop		  6.6104360843040238e+04
            Start		  6.7748460602951207e+04
            Stop		  6.8938891549446431e+04
            Start		  7.0582991316827232e+04
            Stop		  7.1773422255143669e+04
            Start		  7.3417522030188891e+04
            Stop		  7.4607952960294861e+04
            Start		  7.6252052742868676e+04
            Stop		  7.7442483665086853e+04
            Start		  7.9086583454728869e+04
            Stop		  8.0277014369722325e+04
            Start		  8.1921114165667954e+04
            Stop		  8.3111545074410649e+04
            Start		  8.4755644875624683e+04
            Stop		  8.5946075779358929e+04
            Strand		 12 39
            Strand		 12 40
            Strand		 12 41
            Strand		 12 42
            Strand		 12 43
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 12 44
            Strand		 12 45
            Strand		 12 46
            Strand		 12 47
            Strand		 12 49
            Strand		 12 50
            Strand		 12 51
            Strand		 12 52
            Strand		 12 53
            Strand		 12 54
            Strand		 12 55
            Strand		 12 56
            Strand		 12 57
            Strand		 12 58
            Strand		 12 59
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 12 60
            Strand		 12 61
            Strand		 12 62
            Strand		 12 63
            Strand		 12 64
            Start		  1.2944643982918728e+03
            Stop		  2.4848932701276058e+03
            Start		  4.1289943154478387e+03
            Stop		  5.3194238303213597e+03
            Start		  6.9635249551263214e+03
            Stop		  8.1539545427098419e+03
            Start		  9.7980556703555794e+03
            Stop		  1.0988485249413910e+04
            Start		  1.2632586384310176e+04
            Stop		  1.3823015955586836e+04
            Start		  1.5467117097895938e+04
            Stop		  1.6657546661119224e+04
            Start		  1.8301647810876126e+04
            Stop		  1.9492077366200159e+04
            Start		  2.1136178523100498e+04
            Stop		  2.2326608071024857e+04
            Start		  2.3970709234448848e+04
            Stop		  2.5161138775800609e+04
            Start		  2.6805239944839694e+04
            Stop		  2.7995669480736789e+04
            Start		  2.9639770654233591e+04
            Stop		  3.0830200186035774e+04
            Start		  3.2474301362634873e+04
            Stop		  3.3664730891884035e+04
            Start		  3.5308832070091499e+04
            Stop		  3.6499261598443940e+04
            Start		  3.8143362776692942e+04
            Stop		  3.9333792305846619e+04
            Start		  4.0977893482566185e+04
            Stop		  4.2168323014186273e+04
            Start		  4.3812424187870267e+04
            Stop		  4.5002853723515916e+04
            Start		  4.6646954892789217e+04
            Stop		  4.7837384433845182e+04
            Start		  4.9481485597523970e+04
            Stop		  5.0671915145139777e+04
            Start		  5.2316016302283606e+04
            Stop		  5.3506445857323080e+04
            Start		  5.5150547007276124e+04
            Stop		  5.6340976570279432e+04
            Start		  5.7985077712699320e+04
            Stop		  5.9175507283859260e+04
            Start		  6.0819608418732038e+04
            Stop		  6.2010037997885644e+04
            Start		  6.3654139125526512e+04
            Stop		  6.4844568712162087e+04
            Start		  6.6488669833201377e+04
            Stop		  6.7679099426481102e+04
            Start		  6.9323200541836763e+04
            Stop		  7.0513630140633395e+04
            Start		  7.2157731251470614e+04
            Stop		  7.3348160854416943e+04
            Start		  7.4992261962096934e+04
            Stop		  7.6182691567646019e+04
            Start		  7.7826792673666350e+04
            Stop		  7.9017222280159200e+04
            Start		  8.0661323386087955e+04
            Stop		  8.1851752991826594e+04
            Start		  8.3495854099233518e+04
            Stop		  8.4686283702555389e+04
            Start		  8.6330384812942983e+04
            Stop		  8.6400000000000000e+04
            Strand		 12 65
            Strand		 12 66
            Strand		 12 67
            Strand		 12 68
            Start		  0.0000000000000000e+00
            Stop		  3.5470750193072217e+02
            Start		  2.3223330022853606e+03
            Stop		  3.1892378612428747e+03
            Start		  5.1568638475012895e+03
            Stop		  6.0237688033143077e+03
            Start		  7.9913944187538991e+03
            Stop		  8.8582992434387452e+03
            Start		  1.0825924791290276e+04
            Stop		  1.1692830183386657e+04
            Start		  1.3660455834130616e+04
            Stop		  1.4527360651264713e+04
            Start		  1.6494986051615877e+04
            Stop		  1.7361891591545213e+04
            Start		  1.9329517249062941e+04
            Stop		  2.0196422068971140e+04
            Start		  2.2164047415586178e+04
            Stop		  2.3030953009663150e+04
            Start		  2.4998578664263245e+04
            Stop		  2.5865483490359540e+04
            Start		  2.7833108814326872e+04
            Stop		  2.8700014431180036e+04
            Start		  3.0667640080393638e+04
            Stop		  3.1534544912816407e+04
            Start		  3.3502170225552502e+04
            Stop		  3.4369075853419024e+04
            Start		  3.6336701497953421e+04
            Stop		  3.7203606334995973e+04
            Start		  3.9171231642095176e+04
            Stop		  4.0038137275064670e+04
            Start		  4.2005762917193228e+04
            Stop		  4.2872667756087278e+04
            Start		  4.4840293061566554e+04
            Stop		  4.5707198695396888e+04
            Start		  4.7674824338071754e+04
            Stop		  4.8541729175629909e+04
            Start		  5.0509354482954106e+04
            Stop		  5.1376260114086537e+04
            Start		  5.3343885760263052e+04
            Stop		  5.4210790593485894e+04
            Start		  5.6178415905535534e+04
            Stop		  5.7045321531143527e+04
            Start		  5.9012947183213168e+04
            Stop		  5.9879852009827722e+04
            Start		  6.1847477328587178e+04
            Stop		  6.2714382946878999e+04
            Start		  6.4682008606236355e+04
            Stop		  6.5548913425096616e+04
            Start		  6.7516538751371932e+04
            Stop		  6.8383444361839458e+04
            Start		  7.0351070028634160e+04
            Stop		  7.1217974839921997e+04
            Start		  7.3185600173221610e+04
            Stop		  7.4052505776707680e+04
            Start		  7.6020131449816996e+04
            Stop		  7.6887036255010637e+04
            Start		  7.8854661593637953e+04
            Stop		  7.9721567192182963e+04
            Start		  8.1689192869406252e+04
            Stop		  8.2556097671023672e+04
            Start		  8.4523723012374263e+04
            Stop		  8.5390628608859173e+04
            Strand		 12 69
            Start		  1.8499169280055480e+03
            Stop		  2.7168059162395684e+03
            Start		  4.6844522956610554e+03
            Stop		  5.5513373253692926e+03
            Start		  7.5189830299084460e+03
            Stop		  8.3858671676549529e+03
            Start		  1.0353511899309175e+04
            Stop		  1.1220398121222974e+04
            Start		  1.3188044452691980e+04
            Stop		  1.4054928508413173e+04
            Start		  1.6022575118426106e+04
            Stop		  1.6889459447387566e+04
            Start		  1.8857105875711644e+04
            Stop		  1.9723989895506082e+04
            Start		  2.1691636180895486e+04
            Stop		  2.2558520832301521e+04
            Start		  2.4526167298500532e+04
            Stop		  2.5393051300679817e+04
            Start		  2.7360697484950007e+04
            Stop		  2.8227582237103914e+04
            Start		  3.0195228720402512e+04
            Stop		  3.1062112712314265e+04
            Start		  3.3029758867166143e+04
            Stop		  3.3896643648897742e+04
            Start		  3.5864290140905752e+04
            Stop		  3.6731174126721082e+04
            Start		  3.8698820273955775e+04
            Stop		  3.9565705063809641e+04
            Start		  4.1533351559738127e+04
            Stop		  4.2400235543021299e+04
            Start		  4.4367881687680099e+04
            Stop		  4.5234766480853570e+04
            Start		  4.7202412976916668e+04
            Stop		  4.8069296961128573e+04
            Start		  5.0036943102722769e+04
            Stop		  5.0903827899811302e+04
            Start		  5.2871474392745295e+04
            Stop		  5.3738358381017344e+04
            Start		  5.5706004517603738e+04
            Stop		  5.6572889320509094e+04
            Start		  5.8540535807762244e+04
            Stop		  5.9407419802476928e+04
            Start		  6.1375065932313599e+04
            Stop		  6.2241950742595705e+04
            Start		  6.4209597222646727e+04
            Stop		  6.5076481225065123e+04
            Start		  6.7044127347349408e+04
            Stop		  6.7911012165520064e+04
            Start		  6.9878658638100896e+04
            Stop		  7.0745542648157381e+04
            Start		  7.2713188763309256e+04
            Stop		  7.3580073588599305e+04
            Start		  7.5547720054727848e+04
            Stop		  7.6414604071046342e+04
            Start		  7.8382250180682735e+04
            Stop		  7.9249135011128456e+04
            Start		  8.1216781472926974e+04
            Stop		  8.2083665493061635e+04
            Start		  8.4051311599731140e+04
            Stop		  8.4918196432499710e+04
            Strand		 12 70
            Strand		 12 71
            Strand		 13 36
            Strand		 13 37
            Strand		 13 38
            Strand		 13 39
            Start		  1.6094138482456067e+03
            Stop		  2.7998378248883255e+03
            Start		  4.4439454616409030e+03
            Stop		  5.6343724469220060e+03
            Start		  7.2784721763687494e+03
            Stop		  8.4689030424515477e+03
            Start		  1.0113002850362369e+04
            Stop		  1.1303433753915115e+04
            Start		  1.2947533557106830e+04
            Stop		  1.4137964462004516e+04
            Start		  1.5782064262365297e+04
            Stop		  1.6972495171308037e+04
            Start		  1.8616594967304471e+04
            Stop		  1.9807025881597077e+04
            Start		  2.1451125672075119e+04
            Stop		  2.2641556592845605e+04
            Start		  2.4285656376889194e+04
            Stop		  2.5476087304972836e+04
            Start		  2.7120187081954013e+04
            Stop		  2.8310618017859993e+04
            Start		  2.9954717787466005e+04
            Stop		  3.1145148731354828e+04
            Start		  3.2789248493602026e+04
            Stop		  3.3979679445278387e+04
            Start		  3.5623779200511482e+04
            Stop		  3.6814210159432900e+04
            Start		  3.8458309908309900e+04
            Stop		  3.9648740873610353e+04
            Start		  4.1292840617073787e+04
            Stop		  4.2483271587601696e+04
            Start		  4.4127371326837252e+04
            Stop		  4.5317802301206066e+04
            Start		  4.6961902037590509e+04
            Stop		  4.8152333014239513e+04
            Start		  4.9796432749280393e+04
            Stop		  5.0986863726543066e+04
            Start		  5.2630963461812549e+04
            Stop		  5.3821394437989889e+04
            Start		  5.5465494175055705e+04
            Stop		  5.6655925148490656e+04
            Start		  5.8300024888847372e+04
            Stop		  5.9490455857997556e+04
            Start		  6.1134555603000983e+04
            Stop		  6.2324986566506414e+04
            Start		  6.3969086317314104e+04
            Stop		  6.5159517274056794e+04
            Start		  6.6803617031577305e+04
            Stop		  6.7994047980730349e+04
            Start		  6.9638147745583352e+04
            Stop		  7.0828578686647234e+04
            Start		  7.2472678459136398e+04
            Stop		  7.3663109391960679e+04
            Start		  7.5307209172060364e+04
            Stop		  7.6497640096850504e+04
            Start		  7.8141739884206938e+04
            Stop		  7.9332170801514992e+04
            Start		  8.0976270595461930e+04
            Stop		  8.2166701506162382e+04
            Start		  8.3810801305750269e+04
            Stop		  8.5001232211001538e+04
            Strand		 13 40
            Strand		 13 41
            Strand		 13 42
            Strand		 13 43
            Strand		 13 44
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 13 45
            Strand		 13 46
            Strand		 13 47
            Strand		 13 48
            Strand		 13 50
            Strand		 13 51
            Strand		 13 52
            Strand		 13 53
            Strand		 13 54
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 13 55
            Strand		 13 56
            Strand		 13 57
            Strand		 13 58
            Strand		 13 59
            Strand		 13 60
            Strand		 13 61
            Strand		 13 62
            Strand		 13 63
            Strand		 13 64
            Strand		 13 65
            Start		  3.4961992814772583e+02
            Stop		  1.5400497631902988e+03
            Start		  3.1841507853420226e+03
            Stop		  4.3745802613591213e+03
            Start		  6.0186813838155977e+03
            Stop		  7.2091109735100245e+03
            Start		  8.8532120989539490e+03
            Stop		  1.0043641680528764e+04
            Start		  1.1687742813012566e+04
            Stop		  1.2878172386944150e+04
            Start		  1.4522273526760127e+04
            Stop		  1.5712703092667634e+04
            Start		  1.7356804239959743e+04
            Stop		  1.8547233797878318e+04
            Start		  2.0191334952451209e+04
            Stop		  2.1381764502765760e+04
            Start		  2.3025865664102603e+04
            Stop		  2.4216295207534477e+04
            Start		  2.5860396374819131e+04
            Stop		  2.7050825912394164e+04
            Start		  2.8694927084547042e+04
            Stop		  2.9885356617550540e+04
            Start		  3.1529457793275993e+04
            Stop		  3.2719887323196312e+04
            Start		  3.4363988501039552e+04
            Stop		  3.5554418029502762e+04
            Start		  3.7198519207913698e+04
            Stop		  3.8388948736612125e+04
            Start		  4.0033049914013456e+04
            Stop		  4.1223479444631463e+04
            Start		  4.2867580619487890e+04
            Stop		  4.4058010153627874e+04
            Start		  4.5702111324513542e+04
            Stop		  4.6892540863625574e+04
            Start		  4.8536642029286682e+04
            Stop		  4.9727071574604881e+04
            Start		  5.1371172734014683e+04
            Stop		  5.2561602286502952e+04
            Start		  5.4205703438906901e+04
            Stop		  5.5396132999216687e+04
            Start		  5.7040234144165537e+04
            Stop		  5.8230663712607151e+04
            Start		  5.9874764849976717e+04
            Stop		  6.1065194426505717e+04
            Start		  6.2709295556502315e+04
            Stop		  6.3899725140721508e+04
            Start		  6.5543826263872805e+04
            Stop		  6.6734255855049705e+04
            Start		  6.8378356972181704e+04
            Stop		  6.9568786569280550e+04
            Start		  7.1212887681481196e+04
            Stop		  7.2403317283208613e+04
            Start		  7.4047418391780069e+04
            Stop		  7.5237847996641838e+04
            Start		  7.6881949103043225e+04
            Stop		  7.8072378709409808e+04
            Start		  7.9716479815193263e+04
            Stop		  8.0906909421371325e+04
            Start		  8.2551010528113824e+04
            Stop		  8.3741440132420787e+04
            Start		  8.5385541241654806e+04
            Stop		  8.6400000000000000e+04
            Strand		 13 66
            Strand		 13 67
            Strand		 13 68
            Strand		 13 69
            Start		  1.3774864174208651e+03
            Stop		  2.2443942361931445e+03
            Start		  4.2120162644770580e+03
            Stop		  5.0789248359683424e+03
            Start		  7.0465491671758828e+03
            Stop		  7.9134557837242592e+03
            Start		  9.8810815573438413e+03
            Stop		  1.0747986330551459e+04
            Start		  1.2715611323863264e+04
            Stop		  1.3582517271079110e+04
            Start		  1.5550142972468997e+04
            Stop		  1.6417047774466919e+04
            Start		  1.8384672989193965e+04
            Stop		  1.9251578714901454e+04
            Start		  2.1219204387402737e+04
            Stop		  2.2086109204137330e+04
            Start		  2.4053734487599679e+04
            Stop		  2.4920640144888846e+04
            Start		  2.6888265802842503e+04
            Stop		  2.7755170629471300e+04
            Start		  2.9722795931133154e+04
            Stop		  3.0589701570248755e+04
            Start		  3.2557327219403785e+04
            Stop		  3.3424232053069769e+04
            Start		  3.5391857357561013e+04
            Stop		  3.6258762993522949e+04
            Start		  3.8226388637509393e+04
            Stop		  3.9093293475327540e+04
            Start		  4.1060918779534259e+04
            Stop		  4.1927824415161296e+04
            Start		  4.3895450057314614e+04
            Stop		  4.4762354896059936e+04
            Start		  4.6729980201151448e+04
            Stop		  4.7596885835088091e+04
            Start		  4.9564511478679786e+04
            Stop		  5.0431416315080329e+04
            Start		  5.2399041623484809e+04
            Stop		  5.3265947253257204e+04
            Start		  5.5233572901194369e+04
            Stop		  5.6100477732411258e+04
            Start		  5.8068103046460470e+04
            Stop		  5.8935008669839248e+04
            Start		  6.0902634324248211e+04
            Stop		  6.1769539148339536e+04
            Start		  6.3737164469555108e+04
            Stop		  6.4604070085251078e+04
            Start		  6.6571695747137564e+04
            Stop		  6.7438600563385844e+04
            Start		  6.9406225892112998e+04
            Stop		  7.0273131500102987e+04
            Start		  7.2240757169187316e+04
            Stop		  7.3107661978220596e+04
            Start		  7.5075287313534805e+04
            Stop		  7.5942192915099120e+04
            Start		  7.7909818589868257e+04
            Stop		  7.8776723393549837e+04
            Start		  8.0744348733406354e+04
            Stop		  8.1611254330917393e+04
            Start		  8.3578880008888998e+04
            Stop		  8.4445784809993071e+04
            Strand		 13 70
            Start		  9.0507764888625979e+02
            Stop		  1.7719660817944402e+03
            Start		  3.7396084787584446e+03
            Stop		  4.6064925414053851e+03
            Start		  6.5741389612522535e+03
            Stop		  7.4410231507523031e+03
            Start		  9.4086668619556494e+03
            Stop		  1.0275554158729201e+04
            Start		  1.2243197841205812e+04
            Stop		  1.3110084761411303e+04
            Start		  1.5077729674589244e+04
            Stop		  1.5944615712278524e+04
            Start		  1.7912262305256310e+04
            Stop		  1.8779146270500569e+04
            Start		  2.0746791983150397e+04
            Stop		  2.1613677208481608e+04
            Start		  2.3581323728097708e+04
            Stop		  2.4448207713391996e+04
            Start		  2.6415853706500508e+04
            Stop		  2.7282738649917428e+04
            Start		  2.9250385150177019e+04
            Stop		  3.0117269137171257e+04
            Start		  3.2084915228175407e+04
            Stop		  3.2951800073703052e+04
            Start		  3.4919446570935870e+04
            Stop		  3.5786330555435386e+04
            Start		  3.7753976681343171e+04
            Stop		  3.8620861492417716e+04
            Start		  4.0588507990052349e+04
            Stop		  4.1455391972826117e+04
            Start		  4.3423038110596426e+04
            Stop		  4.4289922910522066e+04
            Start		  4.6257569407492367e+04
            Stop		  4.7124453391090894e+04
            Start		  4.9092099530914296e+04
            Stop		  4.9958984329630315e+04
            Start		  5.1926630823513806e+04
            Stop		  5.2793514810843109e+04
            Start		  5.4761160947607641e+04
            Stop		  5.5628045750208999e+04
            Start		  5.7595692238621261e+04
            Stop		  5.8462576232115833e+04
            Start		  6.0430222362901062e+04
            Stop		  6.1297107172147851e+04
            Start		  6.3264753653478147e+04
            Stop		  6.4131637654572020e+04
            Start		  6.6099283778033132e+04
            Stop		  6.6966168594994306e+04
            Start		  6.8933815068791344e+04
            Stop		  6.9800699077634112e+04
            Start		  7.1768345193863861e+04
            Stop		  7.2635230018103102e+04
            Start		  7.4602876485188506e+04
            Stop		  7.5469760500607852e+04
            Start		  7.7437406610997481e+04
            Stop		  7.8304291440772038e+04
            Start		  8.0271937903108934e+04
            Stop		  8.1138821922810719e+04
            Start		  8.3106468029767348e+04
            Stop		  8.3973352862371583e+04
            Start		  8.5940999322727133e+04
            Stop		  8.6400000000000000e+04
            Strand		 13 71
            Strand		 14 36
            Strand		 14 37
            Strand		 14 38
            Strand		 14 39
            Strand		 14 40
            Start		  6.6456717360346954e+02
            Stop		  1.8549980631333624e+03
            Start		  3.4990978673330696e+03
            Stop		  4.6895287713042062e+03
            Start		  6.3336285756180641e+03
            Stop		  7.5240594774221481e+03
            Start		  9.1681592824315994e+03
            Stop		  1.0358590184492839e+04
            Start		  1.2002689988513446e+04
            Stop		  1.3193120892472418e+04
            Start		  1.4837220693983105e+04
            Stop		  1.6027651601431888e+04
            Start		  1.7671751399020748e+04
            Stop		  1.8862182311391258e+04
            Start		  2.0506282103823763e+04
            Stop		  2.1696713022327003e+04
            Start		  2.3340812808600083e+04
            Stop		  2.4531243734172716e+04
            Start		  2.6175343513558764e+04
            Stop		  2.7365774446821953e+04
            Start		  2.9009874218900921e+04
            Stop		  3.0200305160132928e+04
            Start		  3.1844404924810809e+04
            Stop		  3.3034835873934819e+04
            Start		  3.4678935631447828e+04
            Stop		  3.5869366588035140e+04
            Start		  3.7513466338939419e+04
            Stop		  3.8703897302228303e+04
            Start		  4.0347997047375560e+04
            Stop		  4.1538428016304599e+04
            Start		  4.3182527756804731e+04
            Stop		  4.4372958730059407e+04
            Start		  4.6017058467231851e+04
            Stop		  4.7207489443302191e+04
            Start		  4.8851589178618036e+04
            Stop		  5.0042020155864855e+04
            Start		  5.1686119890882299e+04
            Stop		  5.2876550867609149e+04
            Start		  5.4520650603905116e+04
            Stop		  5.5711081578432691e+04
            Start		  5.7355181317533643e+04
            Stop		  5.8545612288273529e+04
            Start		  6.0189712031588504e+04
            Stop		  6.1380142997112802e+04
            Start		  6.3024242745871561e+04
            Stop		  6.4214673704975627e+04
            Start		  6.5858773460174751e+04
            Stop		  6.7049204411929924e+04
            Start		  6.8693304174289005e+04
            Stop		  6.9883735118083510e+04
            Start		  7.1527834888013749e+04
            Stop		  7.2718265823579262e+04
            Start		  7.4362365601165395e+04
            Stop		  7.5552796528588995e+04
            Start		  7.7196896313585574e+04
            Stop		  7.8387327233305783e+04
            Start		  8.0031427025148165e+04
            Stop		  8.1221857937935521e+04
            Start		  8.2865957735764459e+04
            Stop		  8.4056388642687889e+04
            Start		  8.5700488445387600e+04
            Stop		  8.6400000000000000e+04
            Strand		 14 41
            Strand		 14 42
            Strand		 14 43
            Strand		 14 44
            Strand		 14 45
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 14 46
            Strand		 14 47
            Strand		 14 48
            Strand		 14 49
            Strand		 14 51
            Strand		 14 52
            Strand		 14 53
            Strand		 14 54
            Strand		 14 55
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 14 56
            Strand		 14 57
            Strand		 14 58
            Strand		 14 59
            Strand		 14 60
            Start		  0.0000000000000000e+00
            Stop		  5.9520621464314161e+02
            Start		  2.2393072314003916e+03
            Stop		  3.4297366924323433e+03
            Start		  5.0738378125426425e+03
            Stop		  6.2642674042002072e+03
            Start		  7.9083685275332718e+03
            Stop		  9.0987981115527309e+03
            Start		  1.0742899241675048e+04
            Stop		  1.1933328818225546e+04
            Start		  1.3577429955563501e+04
            Stop		  1.4767859524158832e+04
            Start		  1.6411960668964410e+04
            Stop		  1.7602390229520453e+04
            Start		  1.9246491381708263e+04
            Stop		  2.0436920934493432e+04
            Start		  2.2081022093652140e+04
            Stop		  2.3271451639278494e+04
            Start		  2.4915552804688363e+04
            Stop		  2.6105982344084612e+04
            Start		  2.7750083514749123e+04
            Stop		  2.8940513049119862e+04
            Start		  3.0584614223809491e+04
            Stop		  3.1775043754582242e+04
            Start		  3.3419144931888455e+04
            Stop		  3.4609574460651078e+04
            Start		  3.6253675639048131e+04
            Stop		  3.7444105167479058e+04
            Start		  3.9088206345391016e+04
            Stop		  4.0278635875185559e+04
            Start		  4.1922737051055476e+04
            Stop		  4.3113166583851445e+04
            Start		  4.4757267756209716e+04
            Stop		  4.5947697293515404e+04
            Start		  4.7591798461044367e+04
            Stop		  4.8782228004172408e+04
            Start		  5.0426329165764051e+04
            Stop		  5.1616758715773765e+04
            Start		  5.3260859870578512e+04
            Stop		  5.4451289428229386e+04
            Start		  5.6095390575693375e+04
            Stop		  5.7285820141411670e+04
            Start		  5.8929921281301031e+04
            Stop		  6.0120350855161138e+04
            Start		  6.1764451987572291e+04
            Stop		  6.2954881569293459e+04
            Start		  6.4598982694648847e+04
            Stop		  6.5789412283607453e+04
            Start		  6.7433513402637007e+04
            Stop		  6.8623942997893944e+04
            Start		  7.0268044111603172e+04
            Stop		  7.1458473711945131e+04
            Start		  7.3102574821570684e+04
            Stop		  7.4293004425563442e+04
            Start		  7.5937105532518937e+04
            Stop		  7.7127535138570442e+04
            Start		  7.8771636244384470e+04
            Stop		  7.9962065850814382e+04
            Start		  8.1606166957063338e+04
            Stop		  8.2796596562177248e+04
            Start		  8.4440697670416019e+04
            Stop		  8.5631127272579615e+04
            Strand		 14 61
            Strand		 14 62
            Strand		 14 63
            Strand		 14 64
            Strand		 14 65
            Strand		 14 66
            Strand		 14 67
            Strand		 14 68
            Strand		 14 69
            Strand		 14 70
            Start		  4.3264586289648764e+02
            Stop		  1.2995510000431318e+03
            Start		  3.2671750915392713e+03
            Stop		  4.1340822040505554e+03
            Start		  6.1017072798997669e+03
            Stop		  6.9686122744673321e+03
            Start		  8.9362368109984254e+03
            Stop		  9.8031432595639199e+03
            Start		  1.1770768695691564e+04
            Stop		  1.2637673579090666e+04
            Start		  1.4605297231310906e+04
            Stop		  1.5472204525133895e+04
            Start		  1.7439830110736839e+04
            Stop		  1.8306734952152681e+04
            Start		  2.0274360566010979e+04
            Stop		  2.1141265893501153e+04
            Start		  2.3108891525783329e+04
            Stop		  2.3975796357459720e+04
            Start		  2.5943421770854238e+04
            Stop		  2.6810327298391563e+04
            Start		  2.8777952941542651e+04
            Stop		  2.9644857774564163e+04
            Start		  3.1612483117890690e+04
            Stop		  3.2479388715300516e+04
            Start		  3.4447014358585991e+04
            Stop		  3.5313919195215931e+04
            Start		  3.7281544512835026e+04
            Stop		  3.8148450135499079e+04
            Start		  4.0116075777256097e+04
            Stop		  4.0982980616163382e+04
            Start		  4.2950605924792646e+04
            Stop		  4.3817511555745317e+04
            Start		  4.5785137197611431e+04
            Stop		  4.6652042036063445e+04
            Start		  4.8619667343416004e+04
            Stop		  4.9486572974806331e+04
            Start		  5.1454198619417155e+04
            Stop		  5.2321103454414479e+04
            Start		  5.4288728764947315e+04
            Stop		  5.5155634392323591e+04
            Start		  5.7123260042186346e+04
            Stop		  5.7990164871203182e+04
            Start		  5.9957790187683058e+04
            Stop		  6.0824695808427823e+04
            Start		  6.2792321465264708e+04
            Stop		  6.3659226286760182e+04
            Start		  6.5626851610556623e+04
            Stop		  6.6493757223568231e+04
            Start		  6.8461382887944259e+04
            Stop		  6.9328287701653899e+04
            Start		  7.1295913032757278e+04
            Stop		  7.2162818638385434e+04
            Start		  7.4130444309586324e+04
            Stop		  7.4997349116575773e+04
            Start		  7.6964974453683782e+04
            Stop		  7.7831880053584056e+04
            Start		  7.9799505729732598e+04
            Stop		  8.0666410532214766e+04
            Start		  8.2634035872986904e+04
            Stop		  8.3500941469804791e+04
            Start		  8.5468567148184549e+04
            Stop		  8.6335471478154024e+04
            Strand		 14 71
            Start		  0.0000000000000000e+00
            Stop		  8.2711810306011773e+02
            Start		  2.7947632770952664e+03
            Stop		  3.6616534084233058e+03
            Start		  5.6292915195859050e+03
            Stop		  6.4961797628675031e+03
            Start		  8.4638227095804377e+03
            Stop		  9.3307103759086622e+03
            Start		  1.1298354558385900e+04
            Stop		  1.2165241354254376e+04
            Start		  1.4132883480471686e+04
            Stop		  1.4999771947041285e+04
            Start		  1.6967417239282193e+04
            Stop		  1.7834302890019775e+04
            Start		  1.9801949446245868e+04
            Stop		  2.0668833422556021e+04
            Start		  2.2636479269248222e+04
            Stop		  2.3503364359663836e+04
            Start		  2.5471010868906920e+04
            Stop		  2.6337894855997518e+04
            Start		  2.8305540895594335e+04
            Stop		  2.9172425792449973e+04
            Start		  3.1140072290598066e+04
            Stop		  3.2006956276947982e+04
            Start		  3.3974602384414196e+04
            Stop		  3.4841487213592460e+04
            Start		  3.6809133710831680e+04
            Stop		  3.7676017694564245e+04
            Start		  3.9643663826271855e+04
            Stop		  4.0510548631761492e+04
            Start		  4.2478195129378335e+04
            Stop		  4.3345079112112042e+04
            Start		  4.5312725251411677e+04
            Stop		  4.6179610050081785e+04
            Start		  4.8147256546303273e+04
            Stop		  4.9014140530834527e+04
            Start		  5.0981786670099551e+04
            Stop		  5.1848671469658715e+04
            Start		  5.3816317961954002e+04
            Stop		  5.4683201951109579e+04
            Start		  5.6650848086131249e+04
            Stop		  5.7517732890721825e+04
            Start		  5.9485379376899538e+04
            Stop		  6.0352263372828071e+04
            Start		  6.2319909501251343e+04
            Stop		  6.3186794313025319e+04
            Start		  6.5154440791831410e+04
            Stop		  6.6021324795558612e+04
            Start		  6.7988970916531704e+04
            Stop		  6.8855855736036305e+04
            Start		  7.0823502207443496e+04
            Stop		  7.1690386218670363e+04
            Start		  7.3658032332741568e+04
            Stop		  7.4524917159075441e+04
            Start		  7.6492563624311486e+04
            Stop		  7.7359447641458741e+04
            Start		  7.9327093750397747e+04
            Stop		  8.0193978581450734e+04
            Start		  8.2161625042792890e+04
            Stop		  8.3028509063272853e+04
            Start		  8.4996155169735677e+04
            Stop		  8.5863040002583235e+04
            Strand		 15 36
            Strand		 15 37
            Strand		 15 38
            Strand		 15 39
            Strand		 15 40
            Strand		 15 41
            Start		  0.0000000000000000e+00
            Stop		  9.1015461970999422e+02
            Start		  2.5542543634820245e+03
            Stop		  3.7446851984128366e+03
            Start		  5.3887850055525842e+03
            Stop		  6.5792159088099061e+03
            Start		  8.2233157136238533e+03
            Stop		  9.4137466153627247e+03
            Start		  1.1057846419893471e+04
            Stop		  1.2248277323039785e+04
            Start		  1.3892377125550622e+04
            Stop		  1.5082808031667711e+04
            Start		  1.6726907830710978e+04
            Stop		  1.7917338741294261e+04
            Start		  1.9561438535569447e+04
            Stop		  2.0751869451909839e+04
            Start		  2.2395969240331287e+04
            Stop		  2.3586400163462156e+04
            Start		  2.5230499945206262e+04
            Stop		  2.6420930875857677e+04
            Start		  2.8065030650399112e+04
            Stop		  2.9255461588965773e+04
            Start		  3.0899561356100665e+04
            Stop		  3.2089992302624509e+04
            Start		  3.3734092062479431e+04
            Stop		  3.4924523016647727e+04
            Start		  3.6568622769674228e+04
            Stop		  3.7759053730833228e+04
            Start		  3.9403153477788015e+04
            Stop		  4.0593584444971653e+04
            Start		  4.2237684186883438e+04
            Stop		  4.3428115158855690e+04
            Start		  4.5072214896980098e+04
            Stop		  4.6262645872289089e+04
            Start		  4.7906745608053585e+04
            Stop		  4.9097176585095418e+04
            Start		  5.0741276320036639e+04
            Stop		  5.1931707297125766e+04
            Start		  5.3575807032822049e+04
            Stop		  5.4766238008265180e+04
            Start		  5.6410337746267447e+04
            Stop		  5.7600768718437845e+04
            Start		  5.9244868460201447e+04
            Stop		  6.0435299427610342e+04
            Start		  6.2079399174431259e+04
            Stop		  6.3269830135793149e+04
            Start		  6.4913929888751081e+04
            Stop		  6.6104360843040238e+04
            Start		  6.7748460602951222e+04
            Stop		  6.8938891549446416e+04
            Start		  7.0582991316827232e+04
            Stop		  7.1773422255143654e+04
            Start		  7.3417522030188891e+04
            Stop		  7.4607952960294875e+04
            Start		  7.6252052742868676e+04
            Stop		  7.7442483665086838e+04
            Start		  7.9086583454728869e+04
            Stop		  8.0277014369722325e+04
            Start		  8.1921114165667954e+04
            Stop		  8.3111545074410678e+04
            Start		  8.4755644875624712e+04
            Stop		  8.5946075779358958e+04
            Strand		 15 42
            Strand		 15 43
            Strand		 15 44
            Strand		 15 45
            Strand		 15 46
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 15 47
            Strand		 15 48
            Strand		 15 49
            Strand		 15 50
            Strand		 15 52
            Strand		 15 53
            Strand		 15 54
            Strand		 15 55
            Strand		 15 56
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 15 57
            Strand		 15 58
            Strand		 15 59
            Strand		 15 60
            Strand		 15 61
            Start		  1.2944643982918742e+03
            Stop		  2.4848932701276076e+03
            Start		  4.1289943154478406e+03
            Stop		  5.3194238303213651e+03
            Start		  6.9635249551263232e+03
            Stop		  8.1539545427098428e+03
            Start		  9.7980556703555758e+03
            Stop		  1.0988485249413910e+04
            Start		  1.2632586384310174e+04
            Stop		  1.3823015955586836e+04
            Start		  1.5467117097895938e+04
            Stop		  1.6657546661119224e+04
            Start		  1.8301647810876133e+04
            Stop		  1.9492077366200159e+04
            Start		  2.1136178523100494e+04
            Stop		  2.2326608071024857e+04
            Start		  2.3970709234448859e+04
            Stop		  2.5161138775800609e+04
            Start		  2.6805239944839690e+04
            Stop		  2.7995669480736786e+04
            Start		  2.9639770654233584e+04
            Stop		  3.0830200186035785e+04
            Start		  3.2474301362634869e+04
            Stop		  3.3664730891884043e+04
            Start		  3.5308832070091506e+04
            Stop		  3.6499261598443925e+04
            Start		  3.8143362776692942e+04
            Stop		  3.9333792305846619e+04
            Start		  4.0977893482566185e+04
            Stop		  4.2168323014186273e+04
            Start		  4.3812424187870267e+04
            Stop		  4.5002853723515916e+04
            Start		  4.6646954892789210e+04
            Stop		  4.7837384433845182e+04
            Start		  4.9481485597523977e+04
            Stop		  5.0671915145139792e+04
            Start		  5.2316016302283620e+04
            Stop		  5.3506445857323080e+04
            Start		  5.5150547007276124e+04
            Stop		  5.6340976570279425e+04
            Start		  5.7985077712699327e+04
            Stop		  5.9175507283859253e+04
            Start		  6.0819608418732038e+04
            Stop		  6.2010037997885651e+04
            Start		  6.3654139125526504e+04
            Stop		  6.4844568712162087e+04
            Start		  6.6488669833201391e+04
            Stop		  6.7679099426481102e+04
            Start		  6.9323200541836763e+04
            Stop		  7.0513630140633395e+04
            Start		  7.2157731251470599e+04
            Stop		  7.3348160854416958e+04
            Start		  7.4992261962096934e+04
            Stop		  7.6182691567646005e+04
            Start		  7.7826792673666365e+04
            Stop		  7.9017222280159200e+04
            Start		  8.0661323386087955e+04
            Stop		  8.1851752991826608e+04
            Start		  8.3495854099233504e+04
            Stop		  8.4686283702555404e+04
            Start		  8.6330384812942983e+04
            Stop		  8.6400000000000000e+04
            Strand		 15 62
            Strand		 15 63
            Strand		 15 64
            Strand		 15 65
            Strand		 15 66
            Start		  1.8499169280055501e+03
            Stop		  2.7168059162395712e+03
            Start		  4.6844522956610563e+03
            Stop		  5.5513373253692935e+03
            Start		  7.5189830299084442e+03
            Stop		  8.3858671676549529e+03
            Start		  1.0353511899309175e+04
            Stop		  1.1220398121222972e+04
            Start		  1.3188044452691984e+04
            Stop		  1.4054928508413173e+04
            Start		  1.6022575118426108e+04
            Stop		  1.6889459447387566e+04
            Start		  1.8857105875711644e+04
            Stop		  1.9723989895506082e+04
            Start		  2.1691636180895486e+04
            Stop		  2.2558520832301521e+04
            Start		  2.4526167298500528e+04
            Stop		  2.5393051300679821e+04
            Start		  2.7360697484950011e+04
            Stop		  2.8227582237103914e+04
            Start		  3.0195228720402516e+04
            Stop		  3.1062112712314265e+04
            Start		  3.3029758867166151e+04
            Stop		  3.3896643648897734e+04
            Start		  3.5864290140905752e+04
            Stop		  3.6731174126721075e+04
            Start		  3.8698820273955775e+04
            Stop		  3.9565705063809641e+04
            Start		  4.1533351559738119e+04
            Stop		  4.2400235543021292e+04
            Start		  4.4367881687680092e+04
            Stop		  4.5234766480853570e+04
            Start		  4.7202412976916676e+04
            Stop		  4.8069296961128573e+04
            Start		  5.0036943102722769e+04
            Stop		  5.0903827899811302e+04
            Start		  5.2871474392745295e+04
            Stop		  5.3738358381017351e+04
            Start		  5.5706004517603738e+04
            Stop		  5.6572889320509086e+04
            Start		  5.8540535807762251e+04
            Stop		  5.9407419802476943e+04
            Start		  6.1375065932313599e+04
            Stop		  6.2241950742595705e+04
            Start		  6.4209597222646749e+04
            Stop		  6.5076481225065108e+04
            Start		  6.7044127347349422e+04
            Stop		  6.7911012165520064e+04
            Start		  6.9878658638100911e+04
            Stop		  7.0745542648157381e+04
            Start		  7.2713188763309270e+04
            Stop		  7.3580073588599305e+04
            Start		  7.5547720054727863e+04
            Stop		  7.6414604071046342e+04
            Start		  7.8382250180682749e+04
            Stop		  7.9249135011128441e+04
            Start		  8.1216781472926959e+04
            Stop		  8.2083665493061650e+04
            Start		  8.4051311599731154e+04
            Stop		  8.4918196432499724e+04
            Strand		 15 67
            Strand		 15 68
            Strand		 15 69
            Strand		 15 70
            Strand		 15 71
            Start		  0.0000000000000000e+00
            Stop		  3.5470750193072269e+02
            Start		  2.3223330022853629e+03
            Stop		  3.1892378612428747e+03
            Start		  5.1568638475012858e+03
            Stop		  6.0237688033143049e+03
            Start		  7.9913944187538982e+03
            Stop		  8.8582992434387452e+03
            Start		  1.0825924791290274e+04
            Stop		  1.1692830183386657e+04
            Start		  1.3660455834130616e+04
            Stop		  1.4527360651264715e+04
            Start		  1.6494986051615877e+04
            Stop		  1.7361891591545213e+04
            Start		  1.9329517249062941e+04
            Stop		  2.0196422068971140e+04
            Start		  2.2164047415586178e+04
            Stop		  2.3030953009663150e+04
            Start		  2.4998578664263252e+04
            Stop		  2.5865483490359540e+04
            Start		  2.7833108814326872e+04
            Stop		  2.8700014431180036e+04
            Start		  3.0667640080393645e+04
            Stop		  3.1534544912816415e+04
            Start		  3.3502170225552509e+04
            Stop		  3.4369075853419024e+04
            Start		  3.6336701497953421e+04
            Stop		  3.7203606334995966e+04
            Start		  3.9171231642095183e+04
            Stop		  4.0038137275064684e+04
            Start		  4.2005762917193228e+04
            Stop		  4.2872667756087285e+04
            Start		  4.4840293061566561e+04
            Stop		  4.5707198695396888e+04
            Start		  4.7674824338071761e+04
            Stop		  4.8541729175629916e+04
            Start		  5.0509354482954113e+04
            Stop		  5.1376260114086552e+04
            Start		  5.3343885760263052e+04
            Stop		  5.4210790593485894e+04
            Start		  5.6178415905535519e+04
            Stop		  5.7045321531143534e+04
            Start		  5.9012947183213168e+04
            Stop		  5.9879852009827729e+04
            Start		  6.1847477328587185e+04
            Stop		  6.2714382946879021e+04
            Start		  6.4682008606236326e+04
            Stop		  6.5548913425096645e+04
            Start		  6.7516538751371947e+04
            Stop		  6.8383444361839458e+04
            Start		  7.0351070028634189e+04
            Stop		  7.1217974839922012e+04
            Start		  7.3185600173221595e+04
            Stop		  7.4052505776707665e+04
            Start		  7.6020131449816981e+04
            Stop		  7.6887036255010651e+04
            Start		  7.8854661593637938e+04
            Stop		  7.9721567192182963e+04
            Start		  8.1689192869406223e+04
            Stop		  8.2556097671023686e+04
            Start		  8.4523723012374263e+04
            Stop		  8.5390628608859188e+04
            Strand		 16 36
            Start		  1.6094138482455978e+03
            Stop		  2.7998378248883291e+03
            Start		  4.4439454616409048e+03
            Stop		  5.6343724469220006e+03
            Start		  7.2784721763687503e+03
            Stop		  8.4689030424515422e+03
            Start		  1.0113002850362371e+04
            Stop		  1.1303433753915117e+04
            Start		  1.2947533557106832e+04
            Stop		  1.4137964462004516e+04
            Start		  1.5782064262365298e+04
            Stop		  1.6972495171308037e+04
            Start		  1.8616594967304471e+04
            Stop		  1.9807025881597077e+04
            Start		  2.1451125672075112e+04
            Stop		  2.2641556592845602e+04
            Start		  2.4285656376889194e+04
            Stop		  2.5476087304972836e+04
            Start		  2.7120187081954002e+04
            Stop		  2.8310618017859993e+04
            Start		  2.9954717787466008e+04
            Stop		  3.1145148731354817e+04
            Start		  3.2789248493602019e+04
            Stop		  3.3979679445278394e+04
            Start		  3.5623779200511482e+04
            Stop		  3.6814210159432907e+04
            Start		  3.8458309908309893e+04
            Stop		  3.9648740873610353e+04
            Start		  4.1292840617073787e+04
            Stop		  4.2483271587601703e+04
            Start		  4.4127371326837245e+04
            Stop		  4.5317802301206073e+04
            Start		  4.6961902037590524e+04
            Stop		  4.8152333014239492e+04
            Start		  4.9796432749280386e+04
            Stop		  5.0986863726543073e+04
            Start		  5.2630963461812549e+04
            Stop		  5.3821394437989882e+04
            Start		  5.5465494175055705e+04
            Stop		  5.6655925148490649e+04
            Start		  5.8300024888847380e+04
            Stop		  5.9490455857997564e+04
            Start		  6.1134555603001005e+04
            Stop		  6.2324986566506421e+04
            Start		  6.3969086317314112e+04
            Stop		  6.5159517274056816e+04
            Start		  6.6803617031577305e+04
            Stop		  6.7994047980730349e+04
            Start		  6.9638147745583352e+04
            Stop		  7.0828578686647219e+04
            Start		  7.2472678459136398e+04
            Stop		  7.3663109391960650e+04
            Start		  7.5307209172060349e+04
            Stop		  7.6497640096850504e+04
            Start		  7.8141739884206938e+04
            Stop		  7.9332170801514978e+04
            Start		  8.0976270595461930e+04
            Stop		  8.2166701506162397e+04
            Start		  8.3810801305750269e+04
            Stop		  8.5001232211001567e+04
            Strand		 16 37
            Strand		 16 38
            Strand		 16 39
            Strand		 16 40
            Strand		 16 41
            Strand		 16 42
            Strand		 16 43
            Strand		 16 44
            Strand		 16 45
            Strand		 16 46
            Strand		 16 47
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 16 48
            Strand		 16 49
            Strand		 16 50
            Strand		 16 51
            Strand		 16 53
            Strand		 16 54
            Strand		 16 55
            Strand		 16 56
            Strand		 16 57
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 16 58
            Strand		 16 59
            Strand		 16 60
            Strand		 16 61
            Strand		 16 62
            Start		  3.4961992814773492e+02
            Stop		  1.5400497631902938e+03
            Start		  3.1841507853420198e+03
            Stop		  4.3745802613591231e+03
            Start		  6.0186813838156013e+03
            Stop		  7.2091109735100308e+03
            Start		  8.8532120989539508e+03
            Stop		  1.0043641680528770e+04
            Start		  1.1687742813012568e+04
            Stop		  1.2878172386944152e+04
            Start		  1.4522273526760133e+04
            Stop		  1.5712703092667636e+04
            Start		  1.7356804239959740e+04
            Stop		  1.8547233797878322e+04
            Start		  2.0191334952451201e+04
            Stop		  2.1381764502765764e+04
            Start		  2.3025865664102606e+04
            Stop		  2.4216295207534480e+04
            Start		  2.5860396374819135e+04
            Stop		  2.7050825912394168e+04
            Start		  2.8694927084547042e+04
            Stop		  2.9885356617550544e+04
            Start		  3.1529457793275986e+04
            Stop		  3.2719887323196312e+04
            Start		  3.4363988501039552e+04
            Stop		  3.5554418029502762e+04
            Start		  3.7198519207913698e+04
            Stop		  3.8388948736612118e+04
            Start		  4.0033049914013456e+04
            Stop		  4.1223479444631463e+04
            Start		  4.2867580619487882e+04
            Stop		  4.4058010153627882e+04
            Start		  4.5702111324513549e+04
            Stop		  4.6892540863625574e+04
            Start		  4.8536642029286682e+04
            Stop		  4.9727071574604888e+04
            Start		  5.1371172734014675e+04
            Stop		  5.2561602286502952e+04
            Start		  5.4205703438906909e+04
            Stop		  5.5396132999216672e+04
            Start		  5.7040234144165537e+04
            Stop		  5.8230663712607136e+04
            Start		  5.9874764849976717e+04
            Stop		  6.1065194426505717e+04
            Start		  6.2709295556502315e+04
            Stop		  6.3899725140721486e+04
            Start		  6.5543826263872805e+04
            Stop		  6.6734255855049705e+04
            Start		  6.8378356972181689e+04
            Stop		  6.9568786569280550e+04
            Start		  7.1212887681481196e+04
            Stop		  7.2403317283208627e+04
            Start		  7.4047418391780040e+04
            Stop		  7.5237847996641809e+04
            Start		  7.6881949103043225e+04
            Stop		  7.8072378709409793e+04
            Start		  7.9716479815193263e+04
            Stop		  8.0906909421371325e+04
            Start		  8.2551010528113868e+04
            Stop		  8.3741440132420830e+04
            Start		  8.5385541241654835e+04
            Stop		  8.6400000000000000e+04
            Strand		 16 63
            Strand		 16 64
            Strand		 16 65
            Strand		 16 66
            Start		  1.3774864174208647e+03
            Stop		  2.2443942361931454e+03
            Start		  4.2120162644770571e+03
            Stop		  5.0789248359683452e+03
            Start		  7.0465491671758800e+03
            Stop		  7.9134557837242619e+03
            Start		  9.8810815573438413e+03
            Stop		  1.0747986330551454e+04
            Start		  1.2715611323863262e+04
            Stop		  1.3582517271079110e+04
            Start		  1.5550142972468997e+04
            Stop		  1.6417047774466919e+04
            Start		  1.8384672989193965e+04
            Stop		  1.9251578714901454e+04
            Start		  2.1219204387402733e+04
            Stop		  2.2086109204137327e+04
            Start		  2.4053734487599679e+04
            Stop		  2.4920640144888843e+04
            Start		  2.6888265802842503e+04
            Stop		  2.7755170629471297e+04
            Start		  2.9722795931133158e+04
            Stop		  3.0589701570248752e+04
            Start		  3.2557327219403775e+04
            Stop		  3.3424232053069762e+04
            Start		  3.5391857357561013e+04
            Stop		  3.6258762993522942e+04
            Start		  3.8226388637509386e+04
            Stop		  3.9093293475327533e+04
            Start		  4.1060918779534259e+04
            Stop		  4.1927824415161303e+04
            Start		  4.3895450057314622e+04
            Stop		  4.4762354896059936e+04
            Start		  4.6729980201151448e+04
            Stop		  4.7596885835088098e+04
            Start		  4.9564511478679793e+04
            Stop		  5.0431416315080329e+04
            Start		  5.2399041623484802e+04
            Stop		  5.3265947253257204e+04
            Start		  5.5233572901194369e+04
            Stop		  5.6100477732411266e+04
            Start		  5.8068103046460477e+04
            Stop		  5.8935008669839248e+04
            Start		  6.0902634324248218e+04
            Stop		  6.1769539148339536e+04
            Start		  6.3737164469555115e+04
            Stop		  6.4604070085251071e+04
            Start		  6.6571695747137579e+04
            Stop		  6.7438600563385844e+04
            Start		  6.9406225892112998e+04
            Stop		  7.0273131500102972e+04
            Start		  7.2240757169187316e+04
            Stop		  7.3107661978220596e+04
            Start		  7.5075287313534805e+04
            Stop		  7.5942192915099135e+04
            Start		  7.7909818589868257e+04
            Stop		  7.8776723393549837e+04
            Start		  8.0744348733406354e+04
            Stop		  8.1611254330917393e+04
            Start		  8.3578880008888998e+04
            Stop		  8.4445784809993071e+04
            Strand		 16 67
            Start		  9.0507764888626252e+02
            Stop		  1.7719660817944448e+03
            Start		  3.7396084787584500e+03
            Stop		  4.6064925414053860e+03
            Start		  6.5741389612522535e+03
            Stop		  7.4410231507523013e+03
            Start		  9.4086668619556513e+03
            Stop		  1.0275554158729203e+04
            Start		  1.2243197841205814e+04
            Stop		  1.3110084761411303e+04
            Start		  1.5077729674589242e+04
            Stop		  1.5944615712278523e+04
            Start		  1.7912262305256307e+04
            Stop		  1.8779146270500565e+04
            Start		  2.0746791983150397e+04
            Stop		  2.1613677208481608e+04
            Start		  2.3581323728097708e+04
            Stop		  2.4448207713392003e+04
            Start		  2.6415853706500504e+04
            Stop		  2.7282738649917424e+04
            Start		  2.9250385150177019e+04
            Stop		  3.0117269137171257e+04
            Start		  3.2084915228175407e+04
            Stop		  3.2951800073703052e+04
            Start		  3.4919446570935870e+04
            Stop		  3.5786330555435386e+04
            Start		  3.7753976681343163e+04
            Stop		  3.8620861492417709e+04
            Start		  4.0588507990052349e+04
            Stop		  4.1455391972826103e+04
            Start		  4.3423038110596426e+04
            Stop		  4.4289922910522051e+04
            Start		  4.6257569407492359e+04
            Stop		  4.7124453391090894e+04
            Start		  4.9092099530914289e+04
            Stop		  4.9958984329630315e+04
            Start		  5.1926630823513813e+04
            Stop		  5.2793514810843109e+04
            Start		  5.4761160947607641e+04
            Stop		  5.5628045750208999e+04
            Start		  5.7595692238621275e+04
            Stop		  5.8462576232115840e+04
            Start		  6.0430222362901055e+04
            Stop		  6.1297107172147851e+04
            Start		  6.3264753653478147e+04
            Stop		  6.4131637654572027e+04
            Start		  6.6099283778033117e+04
            Stop		  6.6966168594994306e+04
            Start		  6.8933815068791344e+04
            Stop		  6.9800699077634097e+04
            Start		  7.1768345193863846e+04
            Stop		  7.2635230018103117e+04
            Start		  7.4602876485188506e+04
            Stop		  7.5469760500607852e+04
            Start		  7.7437406610997481e+04
            Stop		  7.8304291440772038e+04
            Start		  8.0271937903108934e+04
            Stop		  8.1138821922810719e+04
            Start		  8.3106468029767333e+04
            Stop		  8.3973352862371597e+04
            Start		  8.5940999322727148e+04
            Stop		  8.6400000000000000e+04
            Strand		 16 68
            Strand		 16 69
            Strand		 16 70
            Strand		 16 71
            Strand		 17 36
            Strand		 17 37
            Start		  6.6456717360346795e+02
            Stop		  1.8549980631333660e+03
            Start		  3.4990978673330710e+03
            Stop		  4.6895287713042044e+03
            Start		  6.3336285756180641e+03
            Stop		  7.5240594774221472e+03
            Start		  9.1681592824315994e+03
            Stop		  1.0358590184492834e+04
            Start		  1.2002689988513444e+04
            Stop		  1.3193120892472418e+04
            Start		  1.4837220693983098e+04
            Stop		  1.6027651601431886e+04
            Start		  1.7671751399020752e+04
            Stop		  1.8862182311391254e+04
            Start		  2.0506282103823774e+04
            Stop		  2.1696713022327011e+04
            Start		  2.3340812808600083e+04
            Stop		  2.4531243734172724e+04
            Start		  2.6175343513558761e+04
            Stop		  2.7365774446821943e+04
            Start		  2.9009874218900917e+04
            Stop		  3.0200305160132943e+04
            Start		  3.1844404924810813e+04
            Stop		  3.3034835873934819e+04
            Start		  3.4678935631447828e+04
            Stop		  3.5869366588035140e+04
            Start		  3.7513466338939419e+04
            Stop		  3.8703897302228310e+04
            Start		  4.0347997047375560e+04
            Stop		  4.1538428016304599e+04
            Start		  4.3182527756804739e+04
            Stop		  4.4372958730059421e+04
            Start		  4.6017058467231851e+04
            Stop		  4.7207489443302191e+04
            Start		  4.8851589178618036e+04
            Stop		  5.0042020155864848e+04
            Start		  5.1686119890882313e+04
            Stop		  5.2876550867609141e+04
            Start		  5.4520650603905116e+04
            Stop		  5.5711081578432684e+04
            Start		  5.7355181317533650e+04
            Stop		  5.8545612288273507e+04
            Start		  6.0189712031588504e+04
            Stop		  6.1380142997112816e+04
            Start		  6.3024242745871568e+04
            Stop		  6.4214673704975598e+04
            Start		  6.5858773460174736e+04
            Stop		  6.7049204411929910e+04
            Start		  6.8693304174289020e+04
            Stop		  6.9883735118083525e+04
            Start		  7.1527834888013749e+04
            Stop		  7.2718265823579248e+04
            Start		  7.4362365601165395e+04
            Stop		  7.5552796528589010e+04
            Start		  7.7196896313585588e+04
            Stop		  7.8387327233305768e+04
            Start		  8.0031427025148165e+04
            Stop		  8.1221857937935521e+04
            Start		  8.2865957735764474e+04
            Stop		  8.4056388642687874e+04
            Start		  8.5700488445387600e+04
            Stop		  8.6400000000000000e+04
            Strand		 17 38
            Strand		 17 39
            Strand		 17 40
            Strand		 17 41
            Strand		 17 42
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 17 43
            Strand		 17 44
            Strand		 17 45
            Strand		 17 46
            Strand		 17 47
            Strand		 17 48
            Strand		 17 49
            Strand		 17 50
            Strand		 17 51
            Strand		 17 52
            Strand		 17 54
            Strand		 17 55
            Strand		 17 56
            Strand		 17 57
            Strand		 17 58
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 17 59
            Strand		 17 60
            Strand		 17 61
            Strand		 17 62
            Strand		 17 63
            Start		  0.0000000000000000e+00
            Stop		  5.9520621464313626e+02
            Start		  2.2393072314003957e+03
            Stop		  3.4297366924323455e+03
            Start		  5.0738378125426452e+03
            Stop		  6.2642674042002100e+03
            Start		  7.9083685275332664e+03
            Stop		  9.0987981115527327e+03
            Start		  1.0742899241675053e+04
            Stop		  1.1933328818225551e+04
            Start		  1.3577429955563497e+04
            Stop		  1.4767859524158828e+04
            Start		  1.6411960668964410e+04
            Stop		  1.7602390229520446e+04
            Start		  1.9246491381708252e+04
            Stop		  2.0436920934493424e+04
            Start		  2.2081022093652140e+04
            Stop		  2.3271451639278497e+04
            Start		  2.4915552804688359e+04
            Stop		  2.6105982344084616e+04
            Start		  2.7750083514749113e+04
            Stop		  2.8940513049119862e+04
            Start		  3.0584614223809480e+04
            Stop		  3.1775043754582242e+04
            Start		  3.3419144931888441e+04
            Stop		  3.4609574460651085e+04
            Start		  3.6253675639048117e+04
            Stop		  3.7444105167479058e+04
            Start		  3.9088206345391009e+04
            Stop		  4.0278635875185573e+04
            Start		  4.1922737051055483e+04
            Stop		  4.3113166583851438e+04
            Start		  4.4757267756209738e+04
            Stop		  4.5947697293515404e+04
            Start		  4.7591798461044353e+04
            Stop		  4.8782228004172401e+04
            Start		  5.0426329165764044e+04
            Stop		  5.1616758715773758e+04
            Start		  5.3260859870578519e+04
            Stop		  5.4451289428229371e+04
            Start		  5.6095390575693367e+04
            Stop		  5.7285820141411685e+04
            Start		  5.8929921281301031e+04
            Stop		  6.0120350855161152e+04
            Start		  6.1764451987572291e+04
            Stop		  6.2954881569293451e+04
            Start		  6.4598982694648876e+04
            Stop		  6.5789412283607453e+04
            Start		  6.7433513402637036e+04
            Stop		  6.8623942997893930e+04
            Start		  7.0268044111603187e+04
            Stop		  7.1458473711945117e+04
            Start		  7.3102574821570670e+04
            Stop		  7.4293004425563471e+04
            Start		  7.5937105532518966e+04
            Stop		  7.7127535138570456e+04
            Start		  7.8771636244384485e+04
            Stop		  7.9962065850814412e+04
            Start		  8.1606166957063338e+04
            Stop		  8.2796596562177234e+04
            Start		  8.4440697670416019e+04
            Stop		  8.5631127272579586e+04
            Strand		 17 64
            Strand		 17 65
            Strand		 17 66
            Strand		 17 67
            Start		  4.3264586289648679e+02
            Stop		  1.2995510000431323e+03
            Start		  3.2671750915392740e+03
            Stop		  4.1340822040505536e+03
            Start		  6.1017072798997724e+03
            Stop		  6.9686122744673330e+03
            Start		  8.9362368109984254e+03
            Stop		  9.8031432595639271e+03
            Start		  1.1770768695691566e+04
            Stop		  1.2637673579090666e+04
            Start		  1.4605297231310906e+04
            Stop		  1.5472204525133895e+04
            Start		  1.7439830110736839e+04
            Stop		  1.8306734952152685e+04
            Start		  2.0274360566010990e+04
            Stop		  2.1141265893501157e+04
            Start		  2.3108891525783329e+04
            Stop		  2.3975796357459723e+04
            Start		  2.5943421770854231e+04
            Stop		  2.6810327298391563e+04
            Start		  2.8777952941542651e+04
            Stop		  2.9644857774564160e+04
            Start		  3.1612483117890686e+04
            Stop		  3.2479388715300509e+04
            Start		  3.4447014358585999e+04
            Stop		  3.5313919195215931e+04
            Start		  3.7281544512835018e+04
            Stop		  3.8148450135499072e+04
            Start		  4.0116075777256105e+04
            Stop		  4.0982980616163375e+04
            Start		  4.2950605924792646e+04
            Stop		  4.3817511555745303e+04
            Start		  4.5785137197611431e+04
            Stop		  4.6652042036063438e+04
            Start		  4.8619667343416004e+04
            Stop		  4.9486572974806331e+04
            Start		  5.1454198619417155e+04
            Stop		  5.2321103454414479e+04
            Start		  5.4288728764947307e+04
            Stop		  5.5155634392323591e+04
            Start		  5.7123260042186346e+04
            Stop		  5.7990164871203197e+04
            Start		  5.9957790187683058e+04
            Stop		  6.0824695808427823e+04
            Start		  6.2792321465264715e+04
            Stop		  6.3659226286760160e+04
            Start		  6.5626851610556623e+04
            Stop		  6.6493757223568246e+04
            Start		  6.8461382887944259e+04
            Stop		  6.9328287701653899e+04
            Start		  7.1295913032757293e+04
            Stop		  7.2162818638385448e+04
            Start		  7.4130444309586324e+04
            Stop		  7.4997349116575773e+04
            Start		  7.6964974453683797e+04
            Stop		  7.7831880053584056e+04
            Start		  7.9799505729732613e+04
            Stop		  8.0666410532214766e+04
            Start		  8.2634035872986875e+04
            Stop		  8.3500941469804791e+04
            Start		  8.5468567148184549e+04
            Stop		  8.6335471478154024e+04
            Strand		 17 68
            Start		  0.0000000000000000e+00
            Stop		  8.2711810306011705e+02
            Start		  2.7947632770952700e+03
            Stop		  3.6616534084233035e+03
            Start		  5.6292915195859023e+03
            Stop		  6.4961797628675085e+03
            Start		  8.4638227095804323e+03
            Stop		  9.3307103759086658e+03
            Start		  1.1298354558385900e+04
            Stop		  1.2165241354254380e+04
            Start		  1.4132883480471688e+04
            Stop		  1.4999771947041290e+04
            Start		  1.6967417239282189e+04
            Stop		  1.7834302890019782e+04
            Start		  1.9801949446245868e+04
            Stop		  2.0668833422556025e+04
            Start		  2.2636479269248230e+04
            Stop		  2.3503364359663839e+04
            Start		  2.5471010868906917e+04
            Stop		  2.6337894855997518e+04
            Start		  2.8305540895594331e+04
            Stop		  2.9172425792449969e+04
            Start		  3.1140072290598058e+04
            Stop		  3.2006956276947974e+04
            Start		  3.3974602384414189e+04
            Stop		  3.4841487213592460e+04
            Start		  3.6809133710831680e+04
            Stop		  3.7676017694564245e+04
            Start		  3.9643663826271848e+04
            Stop		  4.0510548631761485e+04
            Start		  4.2478195129378335e+04
            Stop		  4.3345079112112035e+04
            Start		  4.5312725251411677e+04
            Stop		  4.6179610050081777e+04
            Start		  4.8147256546303259e+04
            Stop		  4.9014140530834527e+04
            Start		  5.0981786670099551e+04
            Stop		  5.1848671469658722e+04
            Start		  5.3816317961954002e+04
            Stop		  5.4683201951109579e+04
            Start		  5.6650848086131249e+04
            Stop		  5.7517732890721811e+04
            Start		  5.9485379376899538e+04
            Stop		  6.0352263372828078e+04
            Start		  6.2319909501251343e+04
            Stop		  6.3186794313025312e+04
            Start		  6.5154440791831395e+04
            Stop		  6.6021324795558612e+04
            Start		  6.7988970916531718e+04
            Stop		  6.8855855736036305e+04
            Start		  7.0823502207443496e+04
            Stop		  7.1690386218670363e+04
            Start		  7.3658032332741568e+04
            Stop		  7.4524917159075441e+04
            Start		  7.6492563624311486e+04
            Stop		  7.7359447641458741e+04
            Start		  7.9327093750397762e+04
            Stop		  8.0193978581450734e+04
            Start		  8.2161625042792890e+04
            Stop		  8.3028509063272839e+04
            Start		  8.4996155169735663e+04
            Stop		  8.5863040002583250e+04
            Strand		 17 69
            Strand		 17 70
            Strand		 17 71
            Strand		 18 36
            Strand		 18 37
            Strand		 18 38
            Strand		 18 39
            Start		  0.0000000000000000e+00
            Stop		  1.9723331032518755e+02
            Start		  2.1648573682887327e+03
            Stop		  3.0317642680321524e+03
            Start		  4.9993897838775974e+03
            Stop		  5.8662946404180620e+03
            Start		  7.8339205441236263e+03
            Stop		  8.7008255802733256e+03
            Start		  1.0668451203612336e+04
            Stop		  1.1535356023693816e+04
            Start		  1.3502981549258238e+04
            Stop		  1.4369886961873515e+04
            Start		  1.6337512621629905e+04
            Stop		  1.7204417429719324e+04
            Start		  1.9172042830724557e+04
            Stop		  2.0038948368409987e+04
            Start		  2.2006574038120852e+04
            Stop		  2.2873478844953643e+04
            Start		  2.4841104201843013e+04
            Stop		  2.5708009784440324e+04
            Start		  2.7675635453530322e+04
            Stop		  2.8542540264383264e+04
            Start		  3.0510165602152621e+04
            Stop		  3.1377071204584263e+04
            Start		  3.3344696868488107e+04
            Stop		  3.4211601686001246e+04
            Start		  3.6179227012261428e+04
            Stop		  3.7046132626677689e+04
            Start		  3.9013758283701689e+04
            Stop		  3.9880663108699126e+04
            Start		  4.1848288426242238e+04
            Stop		  4.2715194049523248e+04
            Start		  4.4682819699833912e+04
            Stop		  4.5549724531608335e+04
            Start		  4.7517349842500778e+04
            Stop		  4.8384255472225123e+04
            Start		  5.0351881117388206e+04
            Stop		  5.1218785953965336e+04
            Start		  5.3186411260701367e+04
            Stop		  5.4053316894055177e+04
            Start		  5.6020942536621158e+04
            Stop		  5.6887847375149286e+04
            Start		  5.8855472680718114e+04
            Stop		  5.9722378314483889e+04
            Start		  6.1690003957497924e+04
            Stop		  6.2556908794758434e+04
            Start		  6.4524534102290629e+04
            Stop		  6.5391439733240528e+04
            Start		  6.7359065379698353e+04
            Stop		  6.8225970212669563e+04
            Start		  7.0193595524948338e+04
            Stop		  7.1060501150349824e+04
            Start		  7.3028126802672574e+04
            Stop		  7.3895031629055855e+04
            Start		  7.5862656948052128e+04
            Stop		  7.6729562566124165e+04
            Start		  7.8697188225736536e+04
            Stop		  7.9564093044355759e+04
            Start		  8.1531718370892137e+04
            Stop		  8.2398623981108190e+04
            Start		  8.4366249648190773e+04
            Stop		  8.5233154459196419e+04
            Strand		 18 40
            Start		  1.6924475241791383e+03
            Stop		  2.5593326793852866e+03
            Start		  4.5269783895865412e+03
            Stop		  5.3938625146994991e+03
            Start		  7.3615071736612117e+03
            Stop		  8.2283934677552024e+03
            Start		  1.0196039807953328e+04
            Stop		  1.1062923866396808e+04
            Start		  1.3030570418123822e+04
            Stop		  1.3897454807427921e+04
            Start		  1.5865101227762050e+04
            Stop		  1.6731985260903519e+04
            Start		  1.8699631514373876e+04
            Stop		  1.9566516199749654e+04
            Start		  2.1534162649099067e+04
            Stop		  2.2401046670935066e+04
            Start		  2.4368692829775682e+04
            Stop		  2.5235577608767388e+04
            Start		  2.7203224071555069e+04
            Stop		  2.8070108085285381e+04
            Start		  3.0037754217416077e+04
            Stop		  3.0904639022355746e+04
            Start		  3.2872285494517193e+04
            Stop		  3.3739169500270480e+04
            Start		  3.5706815628753604e+04
            Stop		  3.6573700436834552e+04
            Start		  3.8541346917281589e+04
            Stop		  3.9408230915073327e+04
            Start		  4.1375877047321825e+04
            Stop		  4.2242761851458759e+04
            Start		  4.4210408339177578e+04
            Stop		  4.5077292329920150e+04
            Start		  4.7044938467306871e+04
            Stop		  4.7911823266483356e+04
            Start		  4.9879469759684798e+04
            Stop		  5.0746353745367094e+04
            Start		  5.2713999886579586e+04
            Stop		  5.3580884682433287e+04
            Start		  5.5548531178523786e+04
            Stop		  5.6415415161978177e+04
            Start		  5.8383061304433395e+04
            Stop		  5.9249946099785171e+04
            Start		  6.1217592595704627e+04
            Stop		  6.2084476580152434e+04
            Start		  6.4052122720837404e+04
            Stop		  6.4919007518809434e+04
            Start		  6.6886654011525141e+04
            Stop		  6.7753538000029788e+04
            Start		  6.9721184136154305e+04
            Stop		  7.0588068939498495e+04
            Start		  7.2555715426519353e+04
            Stop		  7.3422599421458654e+04
            Start		  7.5390245550982392e+04
            Stop		  7.6257130361559815e+04
            Start		  7.8224776841364452e+04
            Stop		  7.9091660844019469e+04
            Start		  8.1059306966020114e+04
            Stop		  8.1926191784464128e+04
            Start		  8.3893838256763382e+04
            Stop		  8.4760722267096702e+04
            Strand		 18 41
            Strand		 18 42
            Strand		 18 43
            Strand		 18 44
            Start		  0.0000000000000000e+00
            Stop		  7.5268058974760504e+02
            Start		  2.3967803625151528e+03
            Stop		  3.5872112972570339e+03
            Start		  5.2313110757604018e+03
            Stop		  6.4217420020440049e+03
            Start		  8.0658417876925996e+03
            Stop		  9.2562727067719316e+03
            Start		  1.0900372498740162e+04
            Stop		  1.2090803411523262e+04
            Start		  1.3734903208809483e+04
            Stop		  1.4925334116512260e+04
            Start		  1.6569433917878952e+04
            Stop		  1.7759864821935946e+04
            Start		  1.9403964625969398e+04
            Stop		  2.0594395527972527e+04
            Start		  2.2238495333144721e+04
            Stop		  2.3428926234773411e+04
            Start		  2.5073026039509074e+04
            Stop		  2.6263456942456440e+04
            Start		  2.7907556745202237e+04
            Stop		  2.9097987651100644e+04
            Start		  3.0742087450393537e+04
            Stop		  3.1932518360742844e+04
            Start		  3.3576618155274366e+04
            Stop		  3.4767049071376045e+04
            Start		  3.6411148860049769e+04
            Stop		  3.7601579782949724e+04
            Start		  3.9245679564929480e+04
            Stop		  4.0436110495372042e+04
            Start		  4.2080210270118681e+04
            Stop		  4.3270641208513880e+04
            Start		  4.4914740975809022e+04
            Stop		  4.6105171922214533e+04
            Start		  4.7749271682170169e+04
            Stop		  4.8939702636288705e+04
            Start		  5.0583802389342345e+04
            Stop		  5.1774233350534712e+04
            Start		  5.3418333097430244e+04
            Stop		  5.4608764064743315e+04
            Start		  5.6252863806498361e+04
            Stop		  5.7443294778706862e+04
            Start		  5.9087394516568173e+04
            Stop		  6.0277825492228483e+04
            Start		  6.1921925227617226e+04
            Stop		  6.3112356205130680e+04
            Start		  6.4756455939580032e+04
            Stop		  6.5946886917263197e+04
            Start		  6.7590986652351203e+04
            Stop		  6.8781417628509429e+04
            Start		  7.0425517365789638e+04
            Stop		  7.1615948338791844e+04
            Start		  7.3260048079725151e+04
            Stop		  7.4450479048075096e+04
            Start		  7.6094578793965702e+04
            Stop		  7.7285009756367726e+04
            Start		  7.8929109508305890e+04
            Stop		  8.0119540463721802e+04
            Start		  8.1763640222535993e+04
            Stop		  8.2954071170230527e+04
            Start		  8.4598170936451206e+04
            Stop		  8.5788601876024244e+04
            Strand		 18 45
            Strand		 18 46
            Strand		 18 47
            Strand		 18 48
            Strand		 18 49
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 18 50
            Strand		 18 51
            Strand		 18 52
            Strand		 18 53
            Strand		 18 55
            Strand		 18 56
            Strand		 18 57
            Strand		 18 58
            Strand		 18 59
            Strand		 18 60
            Strand		 18 61
            Strand		 18 62
            Strand		 18 63
            Strand		 18 64
            Strand		 18 65
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 18 66
            Strand		 18 67
            Strand		 18 68
            Strand		 18 69
            Strand		 18 70
            Start		  1.1369941764393297e+03
            Stop		  2.3274193252086548e+03
            Start		  3.9715203664749665e+03
            Stop		  5.1619498959633565e+03
            Start		  6.8060510066255802e+03
            Stop		  7.9964806130646220e+03
            Start		  9.6405817198719797e+03
            Stop		  1.0831011324587736e+04
            Start		  1.2475112432818236e+04
            Stop		  1.3665542035424198e+04
            Start		  1.5309643146400838e+04
            Stop		  1.6500072745262347e+04
            Start		  1.8144173860380964e+04
            Stop		  1.9334603454102071e+04
            Start		  2.0978704574561703e+04
            Stop		  2.2169134161973489e+04
            Start		  2.3813235288734097e+04
            Stop		  2.5003664868949974e+04
            Start		  2.6647766002689801e+04
            Stop		  2.7838195575144280e+04
            Start		  2.9482296716229899e+04
            Stop		  3.0672726280703449e+04
            Start		  3.2316827429173754e+04
            Stop		  3.3507256985802502e+04
            Start		  3.5151358141366836e+04
            Stop		  3.6341787690636724e+04
            Start		  3.7985888852687604e+04
            Stop		  3.9176318395413015e+04
            Start		  4.0820419563052776e+04
            Stop		  4.2010849100340893e+04
            Start		  4.3654950272421011e+04
            Stop		  4.4845379805623255e+04
            Start		  4.6489480980794746e+04
            Stop		  4.7679910511447393e+04
            Start		  4.9324011688220089e+04
            Stop		  5.0514441217977022e+04
            Start		  5.2158542394784687e+04
            Stop		  5.3348971925344711e+04
            Start		  5.4993073100614063e+04
            Stop		  5.6183502633646371e+04
            Start		  5.7827603805865947e+04
            Stop		  5.9018033342936920e+04
            Start		  6.0662134510723467e+04
            Stop		  6.1852564053227936e+04
            Start		  6.3496665215386980e+04
            Stop		  6.4687094764486988e+04
            Start		  6.6331195920065409e+04
            Stop		  6.7521625476639267e+04
            Start		  6.9165726624966963e+04
            Stop		  7.0356156189570727e+04
            Start		  7.2000257330290086e+04
            Stop		  7.3190686903133261e+04
            Start		  7.4834788036214668e+04
            Stop		  7.6025217617150876e+04
            Start		  7.7669318742894131e+04
            Stop		  7.8859748331427822e+04
            Start		  8.0503849450448790e+04
            Stop		  8.1694279045756892e+04
            Start		  8.3338380158960514e+04
            Stop		  8.4528809759928627e+04
            Start		  8.6172910868469015e+04
            Stop		  8.6400000000000000e+04
            Strand		 18 71
            Strand		 19 36
            Strand		 19 37
            Strand		 19 38
            Strand		 19 39
            Strand		 19 40
            Start		  1.2200155032573841e+03
            Stop		  2.0869202750440240e+03
            Start		  4.0545452165392726e+03
            Stop		  4.9214512129978712e+03
            Start		  6.8890769240229592e+03
            Stop		  7.7559817166687517e+03
            Start		  9.7236069243061866e+03
            Stop		  1.0590512654083053e+04
            Start		  1.2558138343152550e+04
            Stop		  1.3425043141477663e+04
            Start		  1.5392668438433195e+04
            Stop		  1.6259574079537610e+04
            Start		  1.8227199760617255e+04
            Stop		  1.9094104562147575e+04
            Start		  2.1061729886914909e+04
            Stop		  2.1928635501054381e+04
            Start		  2.3896261176684144e+04
            Stop		  2.4763165982669565e+04
            Start		  2.6730791312976442e+04
            Stop		  2.7597696922401141e+04
            Start		  2.9565322591865777e+04
            Stop		  3.0432227404160771e+04
            Start		  3.2399852731438685e+04
            Stop		  3.3266758344548805e+04
            Start		  3.5234384006829554e+04
            Stop		  3.6101288826633354e+04
            Start		  3.8068914147711112e+04
            Stop		  3.8935819767396933e+04
            Start		  4.0903445422281271e+04
            Stop		  4.1770350249621588e+04
            Start		  4.3737975564029526e+04
            Stop		  4.4604881190415188e+04
            Start		  4.6572506838842295e+04
            Stop		  4.7439411672468625e+04
            Start		  4.9407036981445919e+04
            Stop		  5.0273942612941668e+04
            Start		  5.2241568256941573e+04
            Stop		  5.3108473094508430e+04
            Start		  5.5076098400432857e+04
            Stop		  5.5943004034366000e+04
            Start		  5.7910629676741039e+04
            Stop		  5.8777534515203879e+04
            Start		  6.0745159821061621e+04
            Stop		  6.1612065454257892e+04
            Start		  6.3579691098107563e+04
            Stop		  6.4446595934247525e+04
            Start		  6.6414221243075997e+04
            Stop		  6.7281126872449400e+04
            Start		  6.9248752520635899e+04
            Stop		  7.0115657351617410e+04
            Start		  7.2083282665965147e+04
            Stop		  7.2950188289066471e+04
            Start		  7.4917813943719360e+04
            Stop		  7.5784718767581755e+04
            Start		  7.7752344089061968e+04
            Stop		  7.8619249704508009e+04
            Start		  8.0586875366654946e+04
            Stop		  8.1453780182652568e+04
            Start		  8.3421405511661884e+04
            Stop		  8.4288311119376667e+04
            Start		  8.6255934626242655e+04
            Stop		  8.6400000000000000e+04
            Strand		 19 41
            Start		  7.4760260676252233e+02
            Stop		  1.6144881940072851e+03
            Start		  3.5821348173795986e+03
            Stop		  4.4490194583509701e+03
            Start		  6.4166655286857322e+03
            Stop		  7.2835497849448866e+03
            Start		  9.2511956276103519e+03
            Stop		  1.0118080804749370e+04
            Start		  1.2085726947628122e+04
            Stop		  1.2952611067878543e+04
            Start		  1.4920255660926983e+04
            Stop		  1.5787142017812264e+04
            Start		  1.7754788368027217e+04
            Stop		  1.8621672423298944e+04
            Start		  2.0589318932757029e+04
            Stop		  2.1456203362959448e+04
            Start		  2.3423849789812113e+04
            Stop		  2.4290733817949393e+04
            Start		  2.6258380061966429e+04
            Stop		  2.7125264755648372e+04
            Start		  2.9092911212517509e+04
            Stop		  2.9959795226659709e+04
            Start		  3.1927441388547777e+04
            Stop		  3.2794326163548503e+04
            Start		  3.4761972635494712e+04
            Stop		  3.5628856639568556e+04
            Start		  3.7596502779604634e+04
            Stop		  3.8463387576037429e+04
            Start		  4.0431034058039586e+04
            Stop		  4.1297918053660142e+04
            Start		  4.3265564191183905e+04
            Stop		  4.4132448990066274e+04
            Start		  4.6100095479520285e+04
            Stop		  4.6966979468416539e+04
            Start		  4.8934625608478651e+04
            Stop		  4.9801510405114735e+04
            Start		  5.1769156899488786e+04
            Stop		  5.2636040884120375e+04
            Start		  5.4603687026457279e+04
            Stop		  5.5470571821412836e+04
            Start		  5.7438218317759209e+04
            Stop		  5.8305102301195198e+04
            Start		  6.0272748443524382e+04
            Stop		  6.1139633239280542e+04
            Start		  6.3107279734440359e+04
            Stop		  6.3974163719927790e+04
            Start		  6.5941809859417481e+04
            Stop		  6.6808694658866996e+04
            Start		  6.8776341149916829e+04
            Stop		  6.9643225140350725e+04
            Start		  7.1610871274466263e+04
            Stop		  7.2477756080056439e+04
            Start		  7.4445402564782227e+04
            Stop		  7.5312286562214213e+04
            Start		  7.7279932689275258e+04
            Stop		  7.8146817502466103e+04
            Start		  8.0114463979736174e+04
            Stop		  8.0981347985022076e+04
            Start		  8.2948994104532889e+04
            Stop		  8.3815878925505051e+04
            Start		  8.5783525395462537e+04
            Stop		  8.6400000000000000e+04
            Strand		 19 42
            Strand		 19 43
            Strand		 19 44
            Strand		 19 45
            Start		  1.4519391836849277e+03
            Stop		  2.6423679081884466e+03
            Start		  4.2864676018056834e+03
            Stop		  5.4768984294252259e+03
            Start		  7.1209982161999824e+03
            Stop		  8.3114291387634112e+03
            Start		  9.9555289285466861e+03
            Stop		  1.1145959843244958e+04
            Start		  1.2790059638894712e+04
            Stop		  1.3980490548144324e+04
            Start		  1.5624590348299977e+04
            Stop		  1.6815021253401570e+04
            Start		  1.8459121056711610e+04
            Stop		  1.9649551959215583e+04
            Start		  2.1293651764182323e+04
            Stop		  2.2484082665746839e+04
            Start		  2.4128182470803109e+04
            Stop		  2.5318613373125034e+04
            Start		  2.6962713176702513e+04
            Stop		  2.8153144081442613e+04
            Start		  2.9797243882040755e+04
            Stop		  3.0987674790750749e+04
            Start		  3.2631774587002768e+04
            Stop		  3.3822205501057120e+04
            Start		  3.5466305291790050e+04
            Stop		  3.6656736212325523e+04
            Start		  3.8300835996611786e+04
            Stop		  3.9491266924477583e+04
            Start		  4.1135366701675703e+04
            Stop		  4.2325797637396019e+04
            Start		  4.3969897407178876e+04
            Stop		  4.5160328350929907e+04
            Start		  4.6804428113299240e+04
            Stop		  4.7994859064901364e+04
            Start		  4.9638958820187574e+04
            Stop		  5.0829389779113160e+04
            Start		  5.2473489527961014e+04
            Stop		  5.3663920493357560e+04
            Start		  5.5308020236697826e+04
            Stop		  5.6498451207425373e+04
            Start		  5.8142550946434087e+04
            Stop		  5.9332981921115163e+04
            Start		  6.0977081657161900e+04
            Stop		  6.2167512634242055e+04
            Start		  6.3811612368829963e+04
            Stop		  6.5002043346645834e+04
            Start		  6.6646143081345683e+04
            Stop		  6.7836574058198166e+04
            Start		  6.9480673794579343e+04
            Stop		  7.0671104768807869e+04
            Start		  7.2315204508369570e+04
            Stop		  7.3505635478425422e+04
            Start		  7.5149735222530770e+04
            Stop		  7.6340166187044582e+04
            Start		  7.7984265936861033e+04
            Stop		  7.9174696894703127e+04
            Start		  8.0818796651151060e+04
            Stop		  8.2009227601480874e+04
            Start		  8.3653327365193298e+04
            Stop		  8.4843758307496362e+04
            Strand		 19 46
            Strand		 19 47
            Strand		 19 48
            Strand		 19 49
            Strand		 19 50
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 19 51
            Strand		 19 52
            Strand		 19 53
            Strand		 19 54
            Strand		 19 56
            Strand		 19 57
            Strand		 19 58
            Strand		 19 59
            Strand		 19 60
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 19 61
            Strand		 19 62
            Strand		 19 63
            Strand		 19 64
            Strand		 19 65
            Strand		 19 66
            Strand		 19 67
            Strand		 19 68
            Strand		 19 69
            Strand		 19 70
            Strand		 19 71
            Start		  1.9214892103032665e+02
            Stop		  1.3825759019211862e+03
            Start		  3.0266769173487355e+03
            Stop		  4.2171063297173887e+03
            Start		  5.8612074371063936e+03
            Stop		  7.0516370420444109e+03
            Start		  8.6957381489760501e+03
            Stop		  9.8861677541146473e+03
            Start		  1.1530268861748762e+04
            Stop		  1.2720698465256286e+04
            Start		  1.4364799575153445e+04
            Stop		  1.5555229175427399e+04
            Start		  1.7199330289021811e+04
            Stop		  1.8389759884598836e+04
            Start		  2.0033861003158650e+04
            Stop		  2.1224290592786932e+04
            Start		  2.2868391717357194e+04
            Stop		  2.4058821300051066e+04
            Start		  2.5702922431407886e+04
            Stop		  2.6893352006491339e+04
            Start		  2.8537453145107658e+04
            Stop		  2.9727882712243983e+04
            Start		  3.1371983858268868e+04
            Stop		  3.2562413417475556e+04
            Start		  3.4206514570727471e+04
            Stop		  3.5396944122375455e+04
            Start		  3.7041045282350256e+04
            Stop		  3.8231474827147707e+04
            Start		  3.9875575993040671e+04
            Stop		  4.1066005532002004e+04
            Start		  4.2710106702743127e+04
            Stop		  4.3900536237144421e+04
            Start		  4.5544637411445394e+04
            Stop		  4.6735066942768492e+04
            Start		  4.8379168119179121e+04
            Stop		  4.9569597649046540e+04
            Start		  5.1213698826018444e+04
            Stop		  5.2404128356122288e+04
            Start		  5.4048229532076817e+04
            Stop		  5.5238659064104431e+04
            Start		  5.6882760237501956e+04
            Stop		  5.8073189773061917e+04
            Start		  5.9717290942469357e+04
            Stop		  6.0907720483020865e+04
            Start		  6.2551821647174555e+04
            Stop		  6.3742251193963537e+04
            Start		  6.5386352351824658e+04
            Stop		  6.6576781905828888e+04
            Start		  6.8220883056629114e+04
            Stop		  6.9411312618515542e+04
            Start		  7.1055413761790624e+04
            Stop		  7.2245843331886019e+04
            Start		  7.3889944467496243e+04
            Stop		  7.5080374045772885e+04
            Start		  7.6724475173908941e+04
            Stop		  7.7914904759986035e+04
            Start		  7.9559005881160789e+04
            Stop		  8.0749435474321042e+04
            Start		  8.2393536589346913e+04
            Stop		  8.3583966188568287e+04
            Start		  8.5228067298521448e+04
            Stop		  8.6400000000000000e+04
            Strand		 20 36
            Start		  0.0000000000000000e+00
            Stop		  6.6964488958439756e+02
            Start		  2.6372902645089816e+03
            Stop		  3.5041761771672241e+03
            Start		  5.4718219592147943e+03
            Stop		  6.3387061996808070e+03
            Start		  8.3063518639627728e+03
            Stop		  9.1732372072071539e+03
            Start		  1.1140883377743517e+04
            Stop		  1.2007767489283822e+04
            Start		  1.3975412027558192e+04
            Stop		  1.4842298437528974e+04
            Start		  1.6809944797865934e+04
            Stop		  1.7676828850138365e+04
            Start		  1.9644475321375063e+04
            Stop		  2.0511359789720307e+04
            Start		  2.2479006219438532e+04
            Stop		  2.3345890247194184e+04
            Start		  2.5313536478041489e+04
            Stop		  2.6180421184997849e+04
            Start		  2.8148067642029924e+04
            Stop		  2.9014951656901991e+04
            Start		  3.0982597813602581e+04
            Stop		  3.1849482593883469e+04
            Start		  3.3817129065010107e+04
            Stop		  3.4684013070232220e+04
            Start		  3.6651659207698023e+04
            Stop		  3.7518544006744960e+04
            Start		  3.9486190487674139e+04
            Stop		  4.0353074484467594e+04
            Start		  4.2320720620430489e+04
            Stop		  4.3187605420858592e+04
            Start		  4.5155251909369385e+04
            Stop		  4.6022135899192435e+04
            Start		  4.7989782038298952e+04
            Stop		  4.8856666835818782e+04
            Start		  5.0824313329610559e+04
            Stop		  5.1691197314737408e+04
            Start		  5.3658843456669128e+04
            Stop		  5.4525728251913664e+04
            Start		  5.6493374748164439e+04
            Stop		  5.7360258731567759e+04
            Start		  5.9327904874041807e+04
            Stop		  6.0194789669512742e+04
            Start		  6.2162436165090607e+04
            Stop		  6.3029320150017418e+04
            Start		  6.4996966290155760e+04
            Stop		  6.5863851088816416e+04
            Start		  6.7831497580731128e+04
            Stop		  6.8698381570169557e+04
            Start		  7.0666027705320288e+04
            Stop		  7.1532912509759582e+04
            Start		  7.3500558995651212e+04
            Stop		  7.4367442991821910e+04
            Start		  7.6335089120125791e+04
            Stop		  7.7201973932002715e+04
            Start		  7.9169620410540942e+04
            Stop		  8.0036504414515177e+04
            Start		  8.2004150535263238e+04
            Stop		  8.2871035354983949e+04
            Start		  8.4838681826095417e+04
            Stop		  8.5705565837610513e+04
            Strand		 20 37
            Strand		 20 38
            Strand		 20 39
            Strand		 20 40
            Strand		 20 41
            Start		  2.7517155552284981e+02
            Stop		  1.1420773238136705e+03
            Start		  3.1097026435478811e+03
            Stop		  3.9766075618901123e+03
            Start		  5.9442314429035350e+03
            Stop		  6.8111385123064056e+03
            Start		  8.7787640638786706e+03
            Stop		  9.6456689073781690e+03
            Start		  1.1613294690394670e+04
            Stop		  1.2480199846674361e+04
            Start		  1.4447825482470718e+04
            Stop		  1.5314730298157543e+04
            Start		  1.7282355783979201e+04
            Stop		  1.8149261236748283e+04
            Start		  2.0116886899435831e+04
            Stop		  2.0983791707675067e+04
            Start		  2.2951417093736254e+04
            Stop		  2.3818322646916869e+04
            Start		  2.5785948315144018e+04
            Stop		  2.6652853124842914e+04
            Start		  2.8620478473878808e+04
            Stop		  2.9487384064830963e+04
            Start		  3.1455009730175469e+04
            Stop		  3.2321914545487925e+04
            Start		  3.4289539877217008e+04
            Stop		  3.5156445486040422e+04
            Start		  3.7124071145225513e+04
            Stop		  3.7990975967799568e+04
            Start		  3.9958601288701175e+04
            Stop		  4.0825506908614268e+04
            Start		  4.2793132560985607e+04
            Stop		  4.3660037390685604e+04
            Start		  4.5627662703770868e+04
            Stop		  4.6494568331410141e+04
            Start		  4.8462193978023817e+04
            Stop		  4.9329098813290104e+04
            Start		  5.1296724121173196e+04
            Stop		  5.2163629753586531e+04
            Start		  5.4131255396686320e+04
            Stop		  5.4998160234917385e+04
            Start		  5.6965785540549354e+04
            Stop		  5.7832691174521628e+04
            Start		  5.9800316817037332e+04
            Stop		  6.0667221655078203e+04
            Start		  6.2634846961627329e+04
            Stop		  6.3501752593846199e+04
            Start		  6.5469378238847938e+04
            Stop		  6.6336283073550047e+04
            Start		  6.8303908383981703e+04
            Stop		  6.9170814011482915e+04
            Start		  7.1138439661635945e+04
            Stop		  7.2005344490407646e+04
            Start		  7.3972969807012574e+04
            Stop		  7.4839875427651408e+04
            Start		  7.6807501084749470e+04
            Stop		  7.7674405906007290e+04
            Start		  7.9642031230018256e+04
            Stop		  8.0508936842827519e+04
            Start		  8.2476562507480485e+04
            Stop		  8.3343467320923941e+04
            Start		  8.5311092652306819e+04
            Stop		  8.6177998257659710e+04
            Strand		 20 42
            Strand		 20 43
            Strand		 20 44
            Strand		 20 45
            Strand		 20 46
            Start		  5.0709665237205706e+02
            Stop		  1.6975242215888964e+03
            Start		  3.3416239498801147e+03
            Stop		  4.5320548628418292e+03
            Start		  6.1761546459129577e+03
            Stop		  7.3665855704360019e+03
            Start		  9.0106853581775958e+03
            Stop		  1.0201116275001565e+04
            Start		  1.1845216068872292e+04
            Stop		  1.3035646979816875e+04
            Start		  1.4679746778610355e+04
            Stop		  1.5870177684929233e+04
            Start		  1.7514277487348922e+04
            Stop		  1.8704708390538606e+04
            Start		  2.0348808195125170e+04
            Stop		  2.1539239096814665e+04
            Start		  2.3183338902016723e+04
            Stop		  2.4373769803898336e+04
            Start		  2.6017869608140216e+04
            Stop		  2.7208300511894991e+04
            Start		  2.8852400313646023e+04
            Stop		  3.0042831220869924e+04
            Start		  3.1686931018711719e+04
            Stop		  3.2877361930845422e+04
            Start		  3.4521461723534201e+04
            Stop		  3.5711892641799837e+04
            Start		  3.7355992428321100e+04
            Stop		  3.8546423353668542e+04
            Start		  4.0190523133281662e+04
            Stop		  4.1380954066346727e+04
            Start		  4.3025053838617547e+04
            Stop		  4.4215484779694067e+04
            Start		  4.5859584544513935e+04
            Stop		  4.7050015493540792e+04
            Start		  4.8694115251131487e+04
            Stop		  4.9884546207695232e+04
            Start		  5.1528645958599198e+04
            Stop		  5.2719076921952117e+04
            Start		  5.4363176667008753e+04
            Stop		  5.5553607636101748e+04
            Start		  5.7197707376410530e+04
            Stop		  5.8388138349939079e+04
            Start		  6.0032238086811405e+04
            Stop		  6.1222669063272762e+04
            Start		  6.2866768798174387e+04
            Stop		  6.4057199775933550e+04
            Start		  6.5701299510420242e+04
            Stop		  6.6891730487781751e+04
            Start		  6.8535830223431069e+04
            Stop		  6.9726261198713342e+04
            Start		  7.1370360937055331e+04
            Stop		  7.2560791908664454e+04
            Start		  7.4204891651114711e+04
            Stop		  7.5395322617614351e+04
            Start		  7.7039422365411723e+04
            Stop		  7.8229853325586271e+04
            Start		  7.9873953079738450e+04
            Stop		  8.1064384032646252e+04
            Start		  8.2708483793885869e+04
            Stop		  8.3898914738900450e+04
            Start		  8.5543014507652711e+04
            Stop		  8.6400000000000000e+04
            Strand		 20 47
            Strand		 20 48
            Strand		 20 49
            Strand		 20 50
            Strand		 20 51
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 20 52
            Strand		 20 53
            Strand		 20 54
            Strand		 20 55
            Strand		 20 57
            Strand		 20 58
            Strand		 20 59
            Strand		 20 60
            Strand		 20 61
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 20 62
            Strand		 20 63
            Strand		 20 64
            Strand		 20 65
            Strand		 20 66
            Start		  0.0000000000000000e+00
            Stop		  4.3773230050979140e+02
            Start		  2.0818333137542400e+03
            Stop		  3.2722627563422593e+03
            Start		  4.9163638661378864e+03
            Stop		  6.1067934712964106e+03
            Start		  7.7508945782474129e+03
            Stop		  8.9413241835228018e+03
            Start		  1.0585425290746358e+04
            Stop		  1.1775854894980976e+04
            Start		  1.3419956003957914e+04
            Stop		  1.4610385605480973e+04
            Start		  1.6254486717692584e+04
            Stop		  1.7444916314985981e+04
            Start		  1.9089017431762502e+04
            Stop		  2.0279447023497360e+04
            Start		  2.1923548145963818e+04
            Stop		  2.3113977731060291e+04
            Start		  2.4758078860086847e+04
            Stop		  2.5948508437761717e+04
            Start		  2.7592609573925387e+04
            Stop		  2.8783039143726437e+04
            Start		  3.0427140287285671e+04
            Stop		  3.1617569849111613e+04
            Start		  3.3261670999994923e+04
            Stop		  3.4452100554099932e+04
            Start		  3.6096201711908951e+04
            Stop		  3.7286631258891539e+04
            Start		  3.8930732422918423e+04
            Stop		  4.0121161963695216e+04
            Start		  4.1765263132953740e+04
            Stop		  4.2955692668719304e+04
            Start		  4.4599793841988037e+04
            Stop		  4.5790223374162437e+04
            Start		  4.7434324550038422e+04
            Stop		  4.8624754080204977e+04
            Start		  5.0268855257165131e+04
            Stop		  5.1459284787000899e+04
            Start		  5.3103385963468994e+04
            Stop		  5.4293815494671238e+04
            Start		  5.5937916669086939e+04
            Stop		  5.7128346203298534e+04
            Start		  5.8772447374185998e+04
            Stop		  5.9962876912923479e+04
            Start		  6.1606978078955966e+04
            Stop		  6.2797407623542880e+04
            Start		  6.4441508783601064e+04
            Stop		  6.5631938335110026e+04
            Start		  6.7276039488331051e+04
            Stop		  6.8466469047536521e+04
            Start		  7.0110570193351828e+04
            Stop		  7.1300999760696359e+04
            Start		  7.2945100898856632e+04
            Stop		  7.4135530474431216e+04
            Start		  7.5779631605017290e+04
            Stop		  7.6970061188557811e+04
            Start		  7.8614162311976921e+04
            Stop		  7.9804591902875414e+04
            Start		  8.1448693019843500e+04
            Stop		  8.2639122617175162e+04
            Start		  8.4283223728685218e+04
            Stop		  8.5473653331248919e+04
            Strand		 20 67
            Strand		 20 68
            Strand		 20 69
            Strand		 20 70
            Strand		 20 71
            Strand		 21 36
            Start		  0.0000000000000000e+00
            Stop		  1.9723331032518985e+02
            Start		  2.1648573682887331e+03
            Stop		  3.0317642680321519e+03
            Start		  4.9993897838775947e+03
            Stop		  5.8662946404180611e+03
            Start		  7.8339205441236263e+03
            Stop		  8.7008255802733256e+03
            Start		  1.0668451203612338e+04
            Stop		  1.1535356023693814e+04
            Start		  1.3502981549258238e+04
            Stop		  1.4369886961873510e+04
            Start		  1.6337512621629903e+04
            Stop		  1.7204417429719331e+04
            Start		  1.9172042830724546e+04
            Stop		  2.0038948368409987e+04
            Start		  2.2006574038120852e+04
            Stop		  2.2873478844953643e+04
            Start		  2.4841104201843013e+04
            Stop		  2.5708009784440328e+04
            Start		  2.7675635453530322e+04
            Stop		  2.8542540264383271e+04
            Start		  3.0510165602152625e+04
            Stop		  3.1377071204584270e+04
            Start		  3.3344696868488107e+04
            Stop		  3.4211601686001246e+04
            Start		  3.6179227012261428e+04
            Stop		  3.7046132626677689e+04
            Start		  3.9013758283701696e+04
            Stop		  3.9880663108699133e+04
            Start		  4.1848288426242238e+04
            Stop		  4.2715194049523248e+04
            Start		  4.4682819699833904e+04
            Stop		  4.5549724531608335e+04
            Start		  4.7517349842500771e+04
            Stop		  4.8384255472225130e+04
            Start		  5.0351881117388206e+04
            Stop		  5.1218785953965336e+04
            Start		  5.3186411260701374e+04
            Stop		  5.4053316894055191e+04
            Start		  5.6020942536621151e+04
            Stop		  5.6887847375149286e+04
            Start		  5.8855472680718114e+04
            Stop		  5.9722378314483889e+04
            Start		  6.1690003957497924e+04
            Stop		  6.2556908794758441e+04
            Start		  6.4524534102290629e+04
            Stop		  6.5391439733240535e+04
            Start		  6.7359065379698353e+04
            Stop		  6.8225970212669548e+04
            Start		  7.0193595524948338e+04
            Stop		  7.1060501150349824e+04
            Start		  7.3028126802672588e+04
            Stop		  7.3895031629055855e+04
            Start		  7.5862656948052143e+04
            Stop		  7.6729562566124194e+04
            Start		  7.8697188225736536e+04
            Stop		  7.9564093044355774e+04
            Start		  8.1531718370892151e+04
            Stop		  8.2398623981108190e+04
            Start		  8.4366249648190787e+04
            Stop		  8.5233154459196419e+04
            Strand		 21 37
            Start		  1.6924475241791401e+03
            Stop		  2.5593326793852889e+03
            Start		  4.5269783895865421e+03
            Stop		  5.3938625146994964e+03
            Start		  7.3615071736612117e+03
            Stop		  8.2283934677551988e+03
            Start		  1.0196039807953335e+04
            Stop		  1.1062923866396812e+04
            Start		  1.3030570418123831e+04
            Stop		  1.3897454807427923e+04
            Start		  1.5865101227762050e+04
            Stop		  1.6731985260903519e+04
            Start		  1.8699631514373876e+04
            Stop		  1.9566516199749654e+04
            Start		  2.1534162649099067e+04
            Stop		  2.2401046670935066e+04
            Start		  2.4368692829775682e+04
            Stop		  2.5235577608767388e+04
            Start		  2.7203224071555076e+04
            Stop		  2.8070108085285377e+04
            Start		  3.0037754217416074e+04
            Stop		  3.0904639022355750e+04
            Start		  3.2872285494517193e+04
            Stop		  3.3739169500270487e+04
            Start		  3.5706815628753604e+04
            Stop		  3.6573700436834552e+04
            Start		  3.8541346917281589e+04
            Stop		  3.9408230915073327e+04
            Start		  4.1375877047321832e+04
            Stop		  4.2242761851458752e+04
            Start		  4.4210408339177578e+04
            Stop		  4.5077292329920150e+04
            Start		  4.7044938467306863e+04
            Stop		  4.7911823266483356e+04
            Start		  4.9879469759684798e+04
            Stop		  5.0746353745367094e+04
            Start		  5.2713999886579593e+04
            Stop		  5.3580884682433280e+04
            Start		  5.5548531178523786e+04
            Stop		  5.6415415161978184e+04
            Start		  5.8383061304433402e+04
            Stop		  5.9249946099785157e+04
            Start		  6.1217592595704627e+04
            Stop		  6.2084476580152419e+04
            Start		  6.4052122720837411e+04
            Stop		  6.4919007518809442e+04
            Start		  6.6886654011525141e+04
            Stop		  6.7753538000029774e+04
            Start		  6.9721184136154319e+04
            Stop		  7.0588068939498509e+04
            Start		  7.2555715426519339e+04
            Stop		  7.3422599421458654e+04
            Start		  7.5390245550982392e+04
            Stop		  7.6257130361559815e+04
            Start		  7.8224776841364437e+04
            Stop		  7.9091660844019483e+04
            Start		  8.1059306966020114e+04
            Stop		  8.1926191784464143e+04
            Start		  8.3893838256763382e+04
            Stop		  8.4760722267096702e+04
            Strand		 21 38
            Strand		 21 39
            Strand		 21 40
            Strand		 21 41
            Strand		 21 42
            Strand		 21 43
            Strand		 21 44
            Strand		 21 45
            Strand		 21 46
            Strand		 21 47
            Start		  0.0000000000000000e+00
            Stop		  7.5268058974760163e+02
            Start		  2.3967803625151596e+03
            Stop		  3.5872112972570399e+03
            Start		  5.2313110757604072e+03
            Stop		  6.4217420020440040e+03
            Start		  8.0658417876926042e+03
            Stop		  9.2562727067719352e+03
            Start		  1.0900372498740166e+04
            Stop		  1.2090803411523262e+04
            Start		  1.3734903208809485e+04
            Stop		  1.4925334116512253e+04
            Start		  1.6569433917878945e+04
            Stop		  1.7759864821935953e+04
            Start		  1.9403964625969395e+04
            Stop		  2.0594395527972527e+04
            Start		  2.2238495333144718e+04
            Stop		  2.3428926234773415e+04
            Start		  2.5073026039509074e+04
            Stop		  2.6263456942456443e+04
            Start		  2.7907556745202241e+04
            Stop		  2.9097987651100644e+04
            Start		  3.0742087450393537e+04
            Stop		  3.1932518360742841e+04
            Start		  3.3576618155274351e+04
            Stop		  3.4767049071376045e+04
            Start		  3.6411148860049769e+04
            Stop		  3.7601579782949724e+04
            Start		  3.9245679564929473e+04
            Stop		  4.0436110495372050e+04
            Start		  4.2080210270118674e+04
            Stop		  4.3270641208513895e+04
            Start		  4.4914740975809022e+04
            Stop		  4.6105171922214533e+04
            Start		  4.7749271682170154e+04
            Stop		  4.8939702636288712e+04
            Start		  5.0583802389342338e+04
            Stop		  5.1774233350534720e+04
            Start		  5.3418333097430237e+04
            Stop		  5.4608764064743307e+04
            Start		  5.6252863806498361e+04
            Stop		  5.7443294778706862e+04
            Start		  5.9087394516568165e+04
            Stop		  6.0277825492228476e+04
            Start		  6.1921925227617234e+04
            Stop		  6.3112356205130709e+04
            Start		  6.4756455939580053e+04
            Stop		  6.5946886917263182e+04
            Start		  6.7590986652351217e+04
            Stop		  6.8781417628509458e+04
            Start		  7.0425517365789638e+04
            Stop		  7.1615948338791859e+04
            Start		  7.3260048079725137e+04
            Stop		  7.4450479048075082e+04
            Start		  7.6094578793965702e+04
            Stop		  7.7285009756367712e+04
            Start		  7.8929109508305890e+04
            Stop		  8.0119540463721802e+04
            Start		  8.1763640222536007e+04
            Stop		  8.2954071170230542e+04
            Start		  8.4598170936451206e+04
            Stop		  8.5788601876024244e+04
            Strand		 21 48
            Strand		 21 49
            Strand		 21 50
            Strand		 21 51
            Strand		 21 52
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 21 53
            Strand		 21 54
            Strand		 21 55
            Strand		 21 56
            Strand		 21 58
            Strand		 21 59
            Strand		 21 60
            Strand		 21 61
            Strand		 21 62
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 21 63
            Strand		 21 64
            Strand		 21 65
            Strand		 21 66
            Strand		 21 67
            Start		  1.1369941764393325e+03
            Stop		  2.3274193252086579e+03
            Start		  3.9715203664749642e+03
            Stop		  5.1619498959633574e+03
            Start		  6.8060510066255747e+03
            Stop		  7.9964806130646230e+03
            Start		  9.6405817198719778e+03
            Stop		  1.0831011324587736e+04
            Start		  1.2475112432818238e+04
            Stop		  1.3665542035424192e+04
            Start		  1.5309643146400835e+04
            Stop		  1.6500072745262343e+04
            Start		  1.8144173860380968e+04
            Stop		  1.9334603454102067e+04
            Start		  2.0978704574561696e+04
            Stop		  2.2169134161973492e+04
            Start		  2.3813235288734104e+04
            Stop		  2.5003664868950003e+04
            Start		  2.6647766002689790e+04
            Stop		  2.7838195575144273e+04
            Start		  2.9482296716229896e+04
            Stop		  3.0672726280703446e+04
            Start		  3.2316827429173754e+04
            Stop		  3.3507256985802516e+04
            Start		  3.5151358141366836e+04
            Stop		  3.6341787690636731e+04
            Start		  3.7985888852687596e+04
            Stop		  3.9176318395413022e+04
            Start		  4.0820419563052776e+04
            Stop		  4.2010849100340885e+04
            Start		  4.3654950272421011e+04
            Stop		  4.4845379805623226e+04
            Start		  4.6489480980794753e+04
            Stop		  4.7679910511447408e+04
            Start		  4.9324011688220082e+04
            Stop		  5.0514441217977030e+04
            Start		  5.2158542394784687e+04
            Stop		  5.3348971925344704e+04
            Start		  5.4993073100614078e+04
            Stop		  5.6183502633646371e+04
            Start		  5.7827603805865954e+04
            Stop		  5.9018033342936928e+04
            Start		  6.0662134510723459e+04
            Stop		  6.1852564053227929e+04
            Start		  6.3496665215386973e+04
            Stop		  6.4687094764487003e+04
            Start		  6.6331195920065409e+04
            Stop		  6.7521625476639296e+04
            Start		  6.9165726624966977e+04
            Stop		  7.0356156189570771e+04
            Start		  7.2000257330290115e+04
            Stop		  7.3190686903133275e+04
            Start		  7.4834788036214683e+04
            Stop		  7.6025217617150905e+04
            Start		  7.7669318742894146e+04
            Stop		  7.8859748331427836e+04
            Start		  8.0503849450448804e+04
            Stop		  8.1694279045756877e+04
            Start		  8.3338380158960514e+04
            Stop		  8.4528809759928670e+04
            Start		  8.6172910868469058e+04
            Stop		  8.6400000000000000e+04
            Strand		 21 68
            Strand		 21 69
            Strand		 21 70
            Strand		 21 71
            Strand		 22 36
            Strand		 22 37
            Start		  1.2200155032573819e+03
            Stop		  2.0869202750440249e+03
            Start		  4.0545452165392717e+03
            Stop		  4.9214512129978721e+03
            Start		  6.8890769240229583e+03
            Stop		  7.7559817166687553e+03
            Start		  9.7236069243061829e+03
            Stop		  1.0590512654083057e+04
            Start		  1.2558138343152557e+04
            Stop		  1.3425043141477659e+04
            Start		  1.5392668438433193e+04
            Stop		  1.6259574079537613e+04
            Start		  1.8227199760617248e+04
            Stop		  1.9094104562147575e+04
            Start		  2.1061729886914902e+04
            Stop		  2.1928635501054388e+04
            Start		  2.3896261176684144e+04
            Stop		  2.4763165982669572e+04
            Start		  2.6730791312976435e+04
            Stop		  2.7597696922401134e+04
            Start		  2.9565322591865781e+04
            Stop		  3.0432227404160778e+04
            Start		  3.2399852731438677e+04
            Stop		  3.3266758344548805e+04
            Start		  3.5234384006829569e+04
            Stop		  3.6101288826633354e+04
            Start		  3.8068914147711119e+04
            Stop		  3.8935819767396933e+04
            Start		  4.0903445422281278e+04
            Stop		  4.1770350249621595e+04
            Start		  4.3737975564029526e+04
            Stop		  4.4604881190415195e+04
            Start		  4.6572506838842310e+04
            Stop		  4.7439411672468632e+04
            Start		  4.9407036981445934e+04
            Stop		  5.0273942612941675e+04
            Start		  5.2241568256941566e+04
            Stop		  5.3108473094508423e+04
            Start		  5.5076098400432864e+04
            Stop		  5.5943004034366008e+04
            Start		  5.7910629676741031e+04
            Stop		  5.8777534515203872e+04
            Start		  6.0745159821061614e+04
            Stop		  6.1612065454257892e+04
            Start		  6.3579691098107556e+04
            Stop		  6.4446595934247525e+04
            Start		  6.6414221243075983e+04
            Stop		  6.7281126872449400e+04
            Start		  6.9248752520635884e+04
            Stop		  7.0115657351617425e+04
            Start		  7.2083282665965147e+04
            Stop		  7.2950188289066471e+04
            Start		  7.4917813943719346e+04
            Stop		  7.5784718767581755e+04
            Start		  7.7752344089061968e+04
            Stop		  7.8619249704507980e+04
            Start		  8.0586875366654946e+04
            Stop		  8.1453780182652583e+04
            Start		  8.3421405511661869e+04
            Stop		  8.4288311119376667e+04
            Start		  8.6255934626242641e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 38
            Start		  7.4760260676252346e+02
            Stop		  1.6144881940072837e+03
            Start		  3.5821348173796000e+03
            Stop		  4.4490194583509647e+03
            Start		  6.4166655286857376e+03
            Stop		  7.2835497849448893e+03
            Start		  9.2511956276103465e+03
            Stop		  1.0118080804749361e+04
            Start		  1.2085726947628120e+04
            Stop		  1.2952611067878534e+04
            Start		  1.4920255660926976e+04
            Stop		  1.5787142017812268e+04
            Start		  1.7754788368027221e+04
            Stop		  1.8621672423298944e+04
            Start		  2.0589318932757022e+04
            Stop		  2.1456203362959433e+04
            Start		  2.3423849789812113e+04
            Stop		  2.4290733817949393e+04
            Start		  2.6258380061966433e+04
            Stop		  2.7125264755648379e+04
            Start		  2.9092911212517516e+04
            Stop		  2.9959795226659709e+04
            Start		  3.1927441388547777e+04
            Stop		  3.2794326163548518e+04
            Start		  3.4761972635494712e+04
            Stop		  3.5628856639568541e+04
            Start		  3.7596502779604634e+04
            Stop		  3.8463387576037429e+04
            Start		  4.0431034058039593e+04
            Stop		  4.1297918053660142e+04
            Start		  4.3265564191183897e+04
            Stop		  4.4132448990066281e+04
            Start		  4.6100095479520292e+04
            Stop		  4.6966979468416539e+04
            Start		  4.8934625608478644e+04
            Stop		  4.9801510405114743e+04
            Start		  5.1769156899488793e+04
            Stop		  5.2636040884120375e+04
            Start		  5.4603687026457272e+04
            Stop		  5.5470571821412836e+04
            Start		  5.7438218317759201e+04
            Stop		  5.8305102301195206e+04
            Start		  6.0272748443524382e+04
            Stop		  6.1139633239280563e+04
            Start		  6.3107279734440352e+04
            Stop		  6.3974163719927790e+04
            Start		  6.5941809859417481e+04
            Stop		  6.6808694658866996e+04
            Start		  6.8776341149916814e+04
            Stop		  6.9643225140350725e+04
            Start		  7.1610871274466263e+04
            Stop		  7.2477756080056439e+04
            Start		  7.4445402564782227e+04
            Stop		  7.5312286562214213e+04
            Start		  7.7279932689275258e+04
            Stop		  7.8146817502466103e+04
            Start		  8.0114463979736160e+04
            Stop		  8.0981347985022090e+04
            Start		  8.2948994104532874e+04
            Stop		  8.3815878925505051e+04
            Start		  8.5783525395462537e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 39
            Strand		 22 40
            Strand		 22 41
            Strand		 22 42
            Start		  1.4519391836849277e+03
            Stop		  2.6423679081884461e+03
            Start		  4.2864676018056862e+03
            Stop		  5.4768984294252268e+03
            Start		  7.1209982161999815e+03
            Stop		  8.3114291387634130e+03
            Start		  9.9555289285466861e+03
            Stop		  1.1145959843244964e+04
            Start		  1.2790059638894707e+04
            Stop		  1.3980490548144322e+04
            Start		  1.5624590348299975e+04
            Stop		  1.6815021253401570e+04
            Start		  1.8459121056711614e+04
            Stop		  1.9649551959215580e+04
            Start		  2.1293651764182319e+04
            Stop		  2.2484082665746839e+04
            Start		  2.4128182470803109e+04
            Stop		  2.5318613373125030e+04
            Start		  2.6962713176702506e+04
            Stop		  2.8153144081442610e+04
            Start		  2.9797243882040751e+04
            Stop		  3.0987674790750745e+04
            Start		  3.2631774587002783e+04
            Stop		  3.3822205501057113e+04
            Start		  3.5466305291790057e+04
            Stop		  3.6656736212325530e+04
            Start		  3.8300835996611793e+04
            Stop		  3.9491266924477561e+04
            Start		  4.1135366701675695e+04
            Stop		  4.2325797637396026e+04
            Start		  4.3969897407178876e+04
            Stop		  4.5160328350929907e+04
            Start		  4.6804428113299240e+04
            Stop		  4.7994859064901364e+04
            Start		  4.9638958820187574e+04
            Stop		  5.0829389779113160e+04
            Start		  5.2473489527961014e+04
            Stop		  5.3663920493357553e+04
            Start		  5.5308020236697848e+04
            Stop		  5.6498451207425387e+04
            Start		  5.8142550946434094e+04
            Stop		  5.9332981921115155e+04
            Start		  6.0977081657161900e+04
            Stop		  6.2167512634242019e+04
            Start		  6.3811612368829949e+04
            Stop		  6.5002043346645856e+04
            Start		  6.6646143081345697e+04
            Stop		  6.7836574058198137e+04
            Start		  6.9480673794579372e+04
            Stop		  7.0671104768807898e+04
            Start		  7.2315204508369570e+04
            Stop		  7.3505635478425451e+04
            Start		  7.5149735222530784e+04
            Stop		  7.6340166187044568e+04
            Start		  7.7984265936861033e+04
            Stop		  7.9174696894703127e+04
            Start		  8.0818796651151046e+04
            Stop		  8.2009227601480874e+04
            Start		  8.3653327365193283e+04
            Stop		  8.4843758307496362e+04
            Strand		 22 43
            Strand		 22 44
            Strand		 22 45
            Strand		 22 46
            Strand		 22 47
            Strand		 22 48
            Strand		 22 49
            Strand		 22 50
            Strand		 22 51
            Strand		 22 52
            Strand		 22 53
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 22 54
            Strand		 22 55
            Strand		 22 56
            Strand		 22 57
            Strand		 22 59
            Strand		 22 60
            Strand		 22 61
            Strand		 22 62
            Strand		 22 63
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 22 64
            Strand		 22 65
            Strand		 22 66
            Strand		 22 67
            Strand		 22 68
            Start		  1.9214892103032469e+02
            Stop		  1.3825759019211857e+03
            Start		  3.0266769173487337e+03
            Stop		  4.2171063297173914e+03
            Start		  5.8612074371063954e+03
            Stop		  7.0516370420444127e+03
            Start		  8.6957381489760519e+03
            Stop		  9.8861677541146546e+03
            Start		  1.1530268861748758e+04
            Stop		  1.2720698465256290e+04
            Start		  1.4364799575153444e+04
            Stop		  1.5555229175427403e+04
            Start		  1.7199330289021815e+04
            Stop		  1.8389759884598836e+04
            Start		  2.0033861003158658e+04
            Stop		  2.1224290592786914e+04
            Start		  2.2868391717357197e+04
            Stop		  2.4058821300051066e+04
            Start		  2.5702922431407882e+04
            Stop		  2.6893352006491328e+04
            Start		  2.8537453145107662e+04
            Stop		  2.9727882712243987e+04
            Start		  3.1371983858268872e+04
            Stop		  3.2562413417475545e+04
            Start		  3.4206514570727457e+04
            Stop		  3.5396944122375455e+04
            Start		  3.7041045282350249e+04
            Stop		  3.8231474827147715e+04
            Start		  3.9875575993040664e+04
            Stop		  4.1066005532002004e+04
            Start		  4.2710106702743120e+04
            Stop		  4.3900536237144435e+04
            Start		  4.5544637411445387e+04
            Stop		  4.6735066942768484e+04
            Start		  4.8379168119179114e+04
            Stop		  4.9569597649046533e+04
            Start		  5.1213698826018430e+04
            Stop		  5.2404128356122288e+04
            Start		  5.4048229532076832e+04
            Stop		  5.5238659064104431e+04
            Start		  5.6882760237501971e+04
            Stop		  5.8073189773061917e+04
            Start		  5.9717290942469343e+04
            Stop		  6.0907720483020858e+04
            Start		  6.2551821647174547e+04
            Stop		  6.3742251193963508e+04
            Start		  6.5386352351824644e+04
            Stop		  6.6576781905828888e+04
            Start		  6.8220883056629100e+04
            Stop		  6.9411312618515527e+04
            Start		  7.1055413761790638e+04
            Stop		  7.2245843331886019e+04
            Start		  7.3889944467496243e+04
            Stop		  7.5080374045772885e+04
            Start		  7.6724475173908926e+04
            Stop		  7.7914904759986021e+04
            Start		  7.9559005881160789e+04
            Stop		  8.0749435474321057e+04
            Start		  8.2393536589346913e+04
            Stop		  8.3583966188568273e+04
            Start		  8.5228067298521433e+04
            Stop		  8.6400000000000000e+04
            Strand		 22 69
            Strand		 22 70
            Strand		 22 71
            Strand		 23 36
            Strand		 23 37
            Strand		 23 38
            Start		  2.7517155552285044e+02
            Stop		  1.1420773238136712e+03
            Start		  3.1097026435478820e+03
            Stop		  3.9766075618901159e+03
            Start		  5.9442314429035396e+03
            Stop		  6.8111385123064056e+03
            Start		  8.7787640638786688e+03
            Stop		  9.6456689073781599e+03
            Start		  1.1613294690394656e+04
            Stop		  1.2480199846674361e+04
            Start		  1.4447825482470716e+04
            Stop		  1.5314730298157538e+04
            Start		  1.7282355783979194e+04
            Stop		  1.8149261236748287e+04
            Start		  2.0116886899435824e+04
            Stop		  2.0983791707675071e+04
            Start		  2.2951417093736254e+04
            Stop		  2.3818322646916866e+04
            Start		  2.5785948315144014e+04
            Stop		  2.6652853124842917e+04
            Start		  2.8620478473878804e+04
            Stop		  2.9487384064830971e+04
            Start		  3.1455009730175469e+04
            Stop		  3.2321914545487933e+04
            Start		  3.4289539877217001e+04
            Stop		  3.5156445486040429e+04
            Start		  3.7124071145225520e+04
            Stop		  3.7990975967799575e+04
            Start		  3.9958601288701182e+04
            Stop		  4.0825506908614261e+04
            Start		  4.2793132560985599e+04
            Stop		  4.3660037390685604e+04
            Start		  4.5627662703770868e+04
            Stop		  4.6494568331410148e+04
            Start		  4.8462193978023810e+04
            Stop		  4.9329098813290111e+04
            Start		  5.1296724121173196e+04
            Stop		  5.2163629753586531e+04
            Start		  5.4131255396686320e+04
            Stop		  5.4998160234917392e+04
            Start		  5.6965785540549354e+04
            Stop		  5.7832691174521628e+04
            Start		  5.9800316817037332e+04
            Stop		  6.0667221655078196e+04
            Start		  6.2634846961627321e+04
            Stop		  6.3501752593846213e+04
            Start		  6.5469378238847959e+04
            Stop		  6.6336283073550032e+04
            Start		  6.8303908383981703e+04
            Stop		  6.9170814011482915e+04
            Start		  7.1138439661635945e+04
            Stop		  7.2005344490407646e+04
            Start		  7.3972969807012574e+04
            Stop		  7.4839875427651408e+04
            Start		  7.6807501084749470e+04
            Stop		  7.7674405906007290e+04
            Start		  7.9642031230018256e+04
            Stop		  8.0508936842827519e+04
            Start		  8.2476562507480499e+04
            Stop		  8.3343467320923941e+04
            Start		  8.5311092652306834e+04
            Stop		  8.6177998257659725e+04
            Strand		 23 39
            Start		  0.0000000000000000e+00
            Stop		  6.6964488958439381e+02
            Start		  2.6372902645089857e+03
            Stop		  3.5041761771672182e+03
            Start		  5.4718219592147925e+03
            Stop		  6.3387061996808043e+03
            Start		  8.3063518639627728e+03
            Stop		  9.1732372072071521e+03
            Start		  1.1140883377743519e+04
            Stop		  1.2007767489283820e+04
            Start		  1.3975412027558188e+04
            Stop		  1.4842298437528985e+04
            Start		  1.6809944797865934e+04
            Stop		  1.7676828850138372e+04
            Start		  1.9644475321375059e+04
            Stop		  2.0511359789720318e+04
            Start		  2.2479006219438532e+04
            Stop		  2.3345890247194187e+04
            Start		  2.5313536478041489e+04
            Stop		  2.6180421184997849e+04
            Start		  2.8148067642029928e+04
            Stop		  2.9014951656901983e+04
            Start		  3.0982597813602581e+04
            Stop		  3.1849482593883462e+04
            Start		  3.3817129065010129e+04
            Stop		  3.4684013070232220e+04
            Start		  3.6651659207698023e+04
            Stop		  3.7518544006744960e+04
            Start		  3.9486190487674132e+04
            Stop		  4.0353074484467601e+04
            Start		  4.2320720620430497e+04
            Stop		  4.3187605420858614e+04
            Start		  4.5155251909369392e+04
            Stop		  4.6022135899192435e+04
            Start		  4.7989782038298952e+04
            Stop		  4.8856666835818774e+04
            Start		  5.0824313329610559e+04
            Stop		  5.1691197314737408e+04
            Start		  5.3658843456669128e+04
            Stop		  5.4525728251913664e+04
            Start		  5.6493374748164431e+04
            Stop		  5.7360258731567774e+04
            Start		  5.9327904874041800e+04
            Stop		  6.0194789669512749e+04
            Start		  6.2162436165090599e+04
            Stop		  6.3029320150017411e+04
            Start		  6.4996966290155760e+04
            Stop		  6.5863851088816402e+04
            Start		  6.7831497580731128e+04
            Stop		  6.8698381570169557e+04
            Start		  7.0666027705320288e+04
            Stop		  7.1532912509759582e+04
            Start		  7.3500558995651212e+04
            Stop		  7.4367442991821925e+04
            Start		  7.6335089120125791e+04
            Stop		  7.7201973932002686e+04
            Start		  7.9169620410540912e+04
            Stop		  8.0036504414515162e+04
            Start		  8.2004150535263238e+04
            Stop		  8.2871035354983935e+04
            Start		  8.4838681826095431e+04
            Stop		  8.5705565837610484e+04
            Strand		 23 40
            Strand		 23 41
            Strand		 23 42
            Strand		 23 43
            Start		  5.0709665237205706e+02
            Stop		  1.6975242215888968e+03
            Start		  3.3416239498801119e+03
            Stop		  4.5320548628418292e+03
            Start		  6.1761546459129695e+03
            Stop		  7.3665855704360001e+03
            Start		  9.0106853581775940e+03
            Stop		  1.0201116275001563e+04
            Start		  1.1845216068872294e+04
            Stop		  1.3035646979816876e+04
            Start		  1.4679746778610366e+04
            Stop		  1.5870177684929229e+04
            Start		  1.7514277487348922e+04
            Stop		  1.8704708390538606e+04
            Start		  2.0348808195125166e+04
            Stop		  2.1539239096814668e+04
            Start		  2.3183338902016727e+04
            Stop		  2.4373769803898344e+04
            Start		  2.6017869608140216e+04
            Stop		  2.7208300511895002e+04
            Start		  2.8852400313646023e+04
            Stop		  3.0042831220869917e+04
            Start		  3.1686931018711708e+04
            Stop		  3.2877361930845407e+04
            Start		  3.4521461723534194e+04
            Stop		  3.5711892641799830e+04
            Start		  3.7355992428321093e+04
            Stop		  3.8546423353668535e+04
            Start		  4.0190523133281669e+04
            Stop		  4.1380954066346741e+04
            Start		  4.3025053838617547e+04
            Stop		  4.4215484779694067e+04
            Start		  4.5859584544513935e+04
            Stop		  4.7050015493540785e+04
            Start		  4.8694115251131479e+04
            Stop		  4.9884546207695232e+04
            Start		  5.1528645958599191e+04
            Stop		  5.2719076921952103e+04
            Start		  5.4363176667008745e+04
            Stop		  5.5553607636101740e+04
            Start		  5.7197707376410530e+04
            Stop		  5.8388138349939087e+04
            Start		  6.0032238086811405e+04
            Stop		  6.1222669063272748e+04
            Start		  6.2866768798174380e+04
            Stop		  6.4057199775933550e+04
            Start		  6.5701299510420242e+04
            Stop		  6.6891730487781751e+04
            Start		  6.8535830223431083e+04
            Stop		  6.9726261198713328e+04
            Start		  7.1370360937055331e+04
            Stop		  7.2560791908664454e+04
            Start		  7.4204891651114740e+04
            Stop		  7.5395322617614365e+04
            Start		  7.7039422365411709e+04
            Stop		  7.8229853325586242e+04
            Start		  7.9873953079738450e+04
            Stop		  8.1064384032646223e+04
            Start		  8.2708483793885869e+04
            Stop		  8.3898914738900465e+04
            Start		  8.5543014507652697e+04
            Stop		  8.6400000000000000e+04
            Strand		 23 44
            Strand		 23 45
            Strand		 23 46
            Strand		 23 47
            Strand		 23 48
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 23 49
            Strand		 23 50
            Strand		 23 51
            Strand		 23 52
            Strand		 23 53
            Strand		 23 54
            Strand		 23 55
            Strand		 23 56
            Strand		 23 57
            Strand		 23 58
            Strand		 23 60
            Strand		 23 61
            Strand		 23 62
            Strand		 23 63
            Strand		 23 64
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 23 65
            Strand		 23 66
            Strand		 23 67
            Strand		 23 68
            Strand		 23 69
            Start		  0.0000000000000000e+00
            Stop		  4.3773230050979600e+02
            Start		  2.0818333137542395e+03
            Stop		  3.2722627563422611e+03
            Start		  4.9163638661378845e+03
            Stop		  6.1067934712964079e+03
            Start		  7.7508945782474138e+03
            Stop		  8.9413241835228018e+03
            Start		  1.0585425290746367e+04
            Stop		  1.1775854894980981e+04
            Start		  1.3419956003957906e+04
            Stop		  1.4610385605480971e+04
            Start		  1.6254486717692584e+04
            Stop		  1.7444916314985996e+04
            Start		  1.9089017431762499e+04
            Stop		  2.0279447023497367e+04
            Start		  2.1923548145963810e+04
            Stop		  2.3113977731060291e+04
            Start		  2.4758078860086847e+04
            Stop		  2.5948508437761713e+04
            Start		  2.7592609573925391e+04
            Stop		  2.8783039143726437e+04
            Start		  3.0427140287285671e+04
            Stop		  3.1617569849111624e+04
            Start		  3.3261670999994938e+04
            Stop		  3.4452100554099954e+04
            Start		  3.6096201711908958e+04
            Stop		  3.7286631258891539e+04
            Start		  3.8930732422918423e+04
            Stop		  4.0121161963695224e+04
            Start		  4.1765263132953747e+04
            Stop		  4.2955692668719304e+04
            Start		  4.4599793841988030e+04
            Stop		  4.5790223374162459e+04
            Start		  4.7434324550038422e+04
            Stop		  4.8624754080204992e+04
            Start		  5.0268855257165131e+04
            Stop		  5.1459284787000914e+04
            Start		  5.3103385963469009e+04
            Stop		  5.4293815494671224e+04
            Start		  5.5937916669086939e+04
            Stop		  5.7128346203298541e+04
            Start		  5.8772447374185977e+04
            Stop		  5.9962876912923464e+04
            Start		  6.1606978078955974e+04
            Stop		  6.2797407623542895e+04
            Start		  6.4441508783601108e+04
            Stop		  6.5631938335110040e+04
            Start		  6.7276039488331066e+04
            Stop		  6.8466469047536550e+04
            Start		  7.0110570193351828e+04
            Stop		  7.1300999760696330e+04
            Start		  7.2945100898856588e+04
            Stop		  7.4135530474431231e+04
            Start		  7.5779631605017261e+04
            Stop		  7.6970061188557811e+04
            Start		  7.8614162311976921e+04
            Stop		  7.9804591902875443e+04
            Start		  8.1448693019843500e+04
            Stop		  8.2639122617175162e+04
            Start		  8.4283223728685218e+04
            Stop		  8.5473653331248948e+04
            Strand		 23 70
            Strand		 23 71
            Strand		 24 36
            Strand		 24 37
            Strand		 24 38
            Strand		 24 39
            Strand		 24 40
            Strand		 24 41
            Start		  9.7951602047059475e+02
            Stop		  2.1699452532635901e+03
            Start		  3.8140463767702618e+03
            Stop		  5.0044759486611092e+03
            Start		  6.6485770790662136e+03
            Stop		  7.8390066637379068e+03
            Start		  9.4831077867165550e+03
            Stop		  1.0673537377946410e+04
            Start		  1.2317638495107603e+04
            Stop		  1.3508068092068654e+04
            Start		  1.5152169204503178e+04
            Stop		  1.6342598805850590e+04
            Start		  1.7986699914893179e+04
            Stop		  1.9177129519105933e+04
            Start		  2.0821230626235556e+04
            Stop		  2.2011660231668873e+04
            Start		  2.3655761338445780e+04
            Stop		  2.4846190943403984e+04
            Start		  2.6490292051401208e+04
            Stop		  2.7680721654212331e+04
            Start		  2.9324822764946406e+04
            Stop		  3.0515252364035638e+04
            Start		  3.2159353478900048e+04
            Stop		  3.3349783072858911e+04
            Start		  3.4993884193062775e+04
            Stop		  3.6184313780711054e+04
            Start		  3.7828414907226048e+04
            Stop		  3.9018844487663693e+04
            Start		  4.0662945621181279e+04
            Stop		  4.1853375193827866e+04
            Start		  4.3497476334728934e+04
            Stop		  4.4687905899349331e+04
            Start		  4.6332007047687359e+04
            Stop		  4.7522436604402057e+04
            Start		  4.9166537759900777e+04
            Stop		  5.0356967309180574e+04
            Start		  5.2001068471246021e+04
            Stop		  5.3191498013891520e+04
            Start		  5.4835599181638041e+04
            Stop		  5.6026028718744506e+04
            Start		  5.7670129891033619e+04
            Stop		  5.8860559423942846e+04
            Start		  6.0504660599433242e+04
            Stop		  6.1695090129674849e+04
            Start		  6.3339191306881105e+04
            Stop		  6.4529620836105234e+04
            Start		  6.6173722013463121e+04
            Stop		  6.7364151543368207e+04
            Start		  6.9008252719303273e+04
            Stop		  7.0198682251561360e+04
            Start		  7.1842783424558016e+04
            Stop		  7.3033212960741439e+04
            Start		  7.4677314129409482e+04
            Stop		  7.5867743670921904e+04
            Start		  7.7511844834057483e+04
            Stop		  7.8702274382072341e+04
            Start		  8.0346375538710694e+04
            Stop		  8.1536805094119656e+04
            Start		  8.3180906243577585e+04
            Stop		  8.4371335806951480e+04
            Start		  8.6015436948857212e+04
            Stop		  8.6400000000000000e+04
            Strand		 24 42
            Strand		 24 43
            Strand		 24 44
            Strand		 24 45
            Start		  0.0000000000000000e+00
            Stop		  3.9759453579812828e+01
            Start		  2.0073840337373335e+03
            Stop		  2.8742904409855446e+03
            Start		  4.8419158477302672e+03
            Stop		  5.7088207504061211e+03
            Start		  7.6764444114667567e+03
            Stop		  8.5433516939600704e+03
            Start		  1.0510977270606058e+04
            Stop		  1.1377882114767850e+04
            Start		  1.3345507745229817e+04
            Stop		  1.4212413052397525e+04
            Start		  1.6180038692554905e+04
            Stop		  1.7046943511539441e+04
            Start		  1.9014568945494899e+04
            Stop		  1.9881474448625861e+04
            Start		  2.1849100113088483e+04
            Stop		  2.2716004920865991e+04
            Start		  2.4683630292443275e+04
            Stop		  2.5550535858360934e+04
            Start		  2.7518161531946880e+04
            Stop		  2.8385066335462772e+04
            Start		  3.0352691686431575e+04
            Stop		  3.1219597273685613e+04
            Start		  3.3187222949155585e+04
            Stop		  3.4054127752999913e+04
            Start		  3.6021753094976651e+04
            Stop		  3.6888658692068537e+04
            Start		  3.8856284365024985e+04
            Stop		  3.9723189172691767e+04
            Start		  4.1690814507745148e+04
            Stop		  4.2557720112564821e+04
            Start		  4.4525345780097727e+04
            Stop		  4.5392250594070632e+04
            Start		  4.7359875921804196e+04
            Stop		  4.8226781534564252e+04
            Start		  5.0194407195054824e+04
            Stop		  5.1061312016606062e+04
            Start		  5.3028937336683870e+04
            Stop		  5.3895842957427798e+04
            Start		  5.5863468610597483e+04
            Stop		  5.6730373439642935e+04
            Start		  5.8697998752660082e+04
            Stop		  5.9564904380443128e+04
            Start		  6.1532530027325389e+04
            Stop		  6.2399434862464281e+04
            Start		  6.4367060170112134e+04
            Stop		  6.5233965802896877e+04
            Start		  6.7201591445632468e+04
            Stop		  6.8068496284398832e+04
            Start		  7.0036121589260263e+04
            Stop		  7.0903027224181642e+04
            Start		  7.2870652865638549e+04
            Stop		  7.3737557704932115e+04
            Start		  7.5705183010062363e+04
            Stop		  7.6572088643895739e+04
            Start		  7.8539714287168419e+04
            Stop		  7.9406619123793978e+04
            Start		  8.1374244432199746e+04
            Stop		  8.2241150061911394e+04
            Start		  8.4208775709782378e+04
            Stop		  8.5075680541004855e+04
            Strand		 24 46
            Start		  1.5349737618038382e+03
            Stop		  2.4018579899124657e+03
            Start		  4.3695037935024648e+03
            Stop		  5.2363890055828051e+03
            Start		  7.2040351769840572e+03
            Stop		  8.0709192757042993e+03
            Start		  1.0038563866474702e+04
            Stop		  1.0905450226195477e+04
            Start		  1.2873096592452835e+04
            Stop		  1.3739980635698043e+04
            Start		  1.5707627140642722e+04
            Stop		  1.6574511577325025e+04
            Start		  1.8542158009007115e+04
            Stop		  1.9409042035453906e+04
            Start		  2.1376688274165503e+04
            Stop		  2.2243572975681534e+04
            Start		  2.4211219427095439e+04
            Stop		  2.5078103449579019e+04
            Start		  2.7045749599808918e+04
            Stop		  2.7912634389052484e+04
            Start		  2.9880280846877271e+04
            Stop		  3.0747164867598982e+04
            Start		  3.2714810989617039e+04
            Stop		  3.3581695806246986e+04
            Start		  3.5549342268209941e+04
            Stop		  3.6416226285724973e+04
            Start		  3.8383872401410852e+04
            Stop		  3.9250757223519824e+04
            Start		  4.1218403690678744e+04
            Stop		  4.2085287702770343e+04
            Start		  4.4052933820862141e+04
            Stop		  4.4919818639819954e+04
            Start		  4.6887465113670587e+04
            Stop		  4.7754349118623439e+04
            Start		  4.9721995242739329e+04
            Stop		  5.0588880055163252e+04
            Start		  5.2556526536481091e+04
            Stop		  5.3423410533675349e+04
            Start		  5.5391056664831878e+04
            Stop		  5.6257941470029014e+04
            Start		  5.8225587958437129e+04
            Stop		  5.9092471948554426e+04
            Start		  6.1060118086029390e+04
            Stop		  6.1927002885077869e+04
            Start		  6.3894649379013776e+04
            Stop		  6.4761533363951494e+04
            Start		  6.6729179505752851e+04
            Stop		  6.7596064300971062e+04
            Start		  6.9563710797925552e+04
            Stop		  7.0430594780478117e+04
            Start		  7.2398240923803474e+04
            Stop		  7.3265125718234005e+04
            Start		  7.5232772215175995e+04
            Stop		  7.6099656198553232e+04
            Start		  7.8067302340314069e+04
            Stop		  7.8934187137157758e+04
            Start		  8.0901833631057088e+04
            Stop		  8.1768717618327966e+04
            Start		  8.3736363755698287e+04
            Stop		  8.4603248557746032e+04
            Strand		 24 47
            Strand		 24 48
            Strand		 24 49
            Strand		 24 50
            Start		  0.0000000000000000e+00
            Stop		  5.9520690098017678e+02
            Start		  2.2393065456292456e+03
            Stop		  3.4297373796034094e+03
            Start		  5.0738371254913336e+03
            Stop		  6.2642680914938492e+03
            Start		  7.9083678404975235e+03
            Stop		  9.0987987988383356e+03
            Start		  1.0742898554638004e+04
            Stop		  1.1933329505511689e+04
            Start		  1.3577429268526452e+04
            Stop		  1.4767860211445004e+04
            Start		  1.6411959981927288e+04
            Stop		  1.7602390916806704e+04
            Start		  1.9246490694671083e+04
            Stop		  2.0436921621779758e+04
            Start		  2.2081021406614927e+04
            Stop		  2.3271452326564911e+04
            Start		  2.4915552117651128e+04
            Stop		  2.6105983031371128e+04
            Start		  2.7750082827711893e+04
            Stop		  2.8940513736406450e+04
            Start		  3.0584613536772271e+04
            Stop		  3.1775044441868922e+04
            Start		  3.3419144244851275e+04
            Stop		  3.4609575147937830e+04
            Start		  3.6253674952010988e+04
            Stop		  3.7444105854765876e+04
            Start		  3.9088205658353931e+04
            Stop		  4.0278636562472413e+04
            Start		  4.1922736364018492e+04
            Stop		  4.3113167271138307e+04
            Start		  4.4757267069172805e+04
            Stop		  4.5947697980802281e+04
            Start		  4.7591797774007537e+04
            Stop		  4.8782228691459277e+04
            Start		  5.0426328478727308e+04
            Stop		  5.1616759403060591e+04
            Start		  5.3260859183541877e+04
            Stop		  5.4451290115516145e+04
            Start		  5.6095389888656799e+04
            Stop		  5.7285820828698386e+04
            Start		  5.8929920594264513e+04
            Stop		  6.0120351542447781e+04
            Start		  6.1764451300535860e+04
            Stop		  6.2954882256580022e+04
            Start		  6.4598982007612445e+04
            Stop		  6.5789412970893900e+04
            Start		  6.7433512715600635e+04
            Stop		  6.8623943685180333e+04
            Start		  7.0268043424566786e+04
            Stop		  7.1458474399231432e+04
            Start		  7.3102574134534254e+04
            Stop		  7.4293005112849671e+04
            Start		  7.5937104845482507e+04
            Stop		  7.7127535825856554e+04
            Start		  7.8771635557347967e+04
            Stop		  7.9962066538100466e+04
            Start		  8.1606166270026806e+04
            Stop		  8.2796597249463273e+04
            Start		  8.4440696983379399e+04
            Stop		  8.5631127959865611e+04
            Strand		 24 51
            Strand		 24 52
            Strand		 24 53
            Strand		 24 54
            Strand		 24 55
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 24 56
            Strand		 24 57
            Strand		 24 58
            Strand		 24 59
            Strand		 24 61
            Strand		 24 62
            Strand		 24 63
            Strand		 24 64
            Strand		 24 65
            Strand		 24 66
            Strand		 24 67
            Strand		 24 68
            Strand		 24 69
            Strand		 24 70
            Strand		 24 71
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 36
            Start		  3.4676930964083340e+01
            Stop		  1.2251018212145489e+03
            Start		  2.8692028848144846e+03
            Stop		  4.0596323737954981e+03
            Start		  5.7037335093435777e+03
            Stop		  6.8941630925073387e+03
            Start		  8.5382642175039928e+03
            Stop		  9.7286938065237864e+03
            Start		  1.1372794925529415e+04
            Stop		  1.2563224520723508e+04
            Start		  1.4207325634593515e+04
            Stop		  1.5397755234639477e+04
            Start		  1.7041856344654359e+04
            Stop		  1.8232285948090121e+04
            Start		  1.9876387055686671e+04
            Stop		  2.1066816660900542e+04
            Start		  2.2710917767619456e+04
            Stop		  2.3901347372924509e+04
            Start		  2.5545448480342264e+04
            Stop		  2.6735878084050331e+04
            Start		  2.8379979193709893e+04
            Stop		  2.9570408794205814e+04
            Start		  3.1214509907548818e+04
            Stop		  3.2404939503361398e+04
            Start		  3.4049040621664753e+04
            Stop		  3.5239470211531348e+04
            Start		  3.6883571335851208e+04
            Stop		  3.8074000918773338e+04
            Start		  3.9718102049898596e+04
            Stop		  4.0908531625185729e+04
            Start		  4.2552632763603338e+04
            Stop		  4.3743062330903347e+04
            Start		  4.5387163476776921e+04
            Stop		  4.6577593036091559e+04
            Start		  4.8221694189254093e+04
            Stop		  4.9412123740938929e+04
            Start		  5.1056224900900161e+04
            Stop		  5.2246654445649074e+04
            Start		  5.3890755611616834e+04
            Stop		  5.5081185150431615e+04
            Start		  5.6725286321346684e+04
            Stop		  5.7915715855492992e+04
            Start		  5.9559817030075494e+04
            Stop		  6.0750246561027474e+04
            Start		  6.2394347737833079e+04
            Stop		  6.3584777267208512e+04
            Start		  6.5228878444691720e+04
            Stop		  6.6419307974181196e+04
            Start		  6.8063409150763255e+04
            Stop		  6.9253838682055895e+04
            Start		  7.0897939856194003e+04
            Stop		  7.2088369390903332e+04
            Start		  7.3732470561158407e+04
            Stop		  7.4922900100751562e+04
            Start		  7.6567001265851271e+04
            Stop		  7.7757430811584753e+04
            Start		  7.9401531970479409e+04
            Stop		  8.0591961523343736e+04
            Start		  8.2236062675252324e+04
            Stop		  8.3426492235928788e+04
            Start		  8.5070593380373175e+04
            Stop		  8.6261023283963135e+04
            Strand		 25 37
            Strand		 25 38
            Strand		 25 39
            Strand		 25 40
            Strand		 25 41
            Strand		 25 42
            Strand		 25 43
            Strand		 25 44
            Strand		 25 45
            Strand		 25 46
            Start		  1.0625408519517562e+03
            Stop		  1.9294493132962878e+03
            Start		  3.8970722760685226e+03
            Stop		  4.7639809303371458e+03
            Start		  6.7316022457623967e+03
            Stop		  7.5985075128024027e+03
            Start		  9.5661327844269836e+03
            Stop		  1.0433038108525958e+04
            Start		  1.2400660649245325e+04
            Stop		  1.3267569148073409e+04
            Start		  1.5235193536927240e+04
            Stop		  1.6102099757005995e+04
            Start		  1.8069723575100124e+04
            Stop		  1.8936630716245785e+04
            Start		  2.0904256543156556e+04
            Stop		  2.1771161295905538e+04
            Start		  2.3738786112066991e+04
            Stop		  2.4605692235317350e+04
            Start		  2.6573317962271227e+04
            Stop		  2.7440222748099459e+04
            Start		  2.9407847913604386e+04
            Stop		  3.0274753686331362e+04
            Start		  3.2242379379730522e+04
            Stop		  3.3109284177347938e+04
            Start		  3.5076909458291440e+04
            Stop		  3.5943815116266444e+04
            Start		  3.7911440795787377e+04
            Stop		  3.8778345600669410e+04
            Start		  4.0745970916272585e+04
            Stop		  4.1612876540409066e+04
            Start		  4.3580502210946841e+04
            Stop		  4.4447407023102372e+04
            Start		  4.6415032345278996e+04
            Stop		  4.7281937963506993e+04
            Start		  4.9249563625873147e+04
            Stop		  5.0116468445917424e+04
            Start		  5.2084093765004684e+04
            Stop		  5.2950999386706710e+04
            Start		  5.4918625041272258e+04
            Stop		  5.5785529869062149e+04
            Start		  5.7753155182421440e+04
            Stop		  5.8620060809890412e+04
            Start		  6.0587686457768585e+04
            Stop		  6.1454591292015677e+04
            Start		  6.3422216600152169e+04
            Stop		  6.4289122232531408e+04
            Start		  6.6256747875796194e+04
            Stop		  6.7123652714154770e+04
            Start		  6.9091278019193502e+04
            Stop		  6.9958183654061126e+04
            Start		  7.1925809295523417e+04
            Stop		  7.2792714134952941e+04
            Start		  7.4760339439794610e+04
            Stop		  7.5627245074058999e+04
            Start		  7.7594870716823425e+04
            Stop		  7.8461775554101710e+04
            Start		  8.0429400861761984e+04
            Stop		  8.1296306492355681e+04
            Start		  8.3263932139296434e+04
            Stop		  8.4130836971574332e+04
            Start		  8.6098462284608002e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 47
            Start		  5.9013019007223988e+02
            Stop		  1.4570144227801134e+03
            Start		  3.4246609000833810e+03
            Stop		  4.2915451718429094e+03
            Start		  6.2591915605636896e+03
            Stop		  7.1260762313059395e+03
            Start		  9.0937223153300274e+03
            Stop		  9.9606064429787093e+03
            Start		  1.1928251212210385e+04
            Stop		  1.2795137400307754e+04
            Start		  1.4762783731135107e+04
            Stop		  1.5629667787162327e+04
            Start		  1.7597314413848071e+04
            Stop		  1.8464198729554959e+04
            Start		  2.0431845148178523e+04
            Stop		  2.1298729179917704e+04
            Start		  2.3266375457606329e+04
            Stop		  2.4133260120064242e+04
            Start		  2.6100906566833251e+04
            Stop		  2.6967790591206358e+04
            Start		  2.8935436754324179e+04
            Stop		  2.9802321530436737e+04
            Start		  3.1769967987163865e+04
            Stop		  3.2636852007868318e+04
            Start		  3.4604498134927824e+04
            Stop		  3.5471382946232086e+04
            Start		  3.7439029408933515e+04
            Stop		  3.8305913425150051e+04
            Start		  4.0273559543867712e+04
            Stop		  4.1140444362678340e+04
            Start		  4.3108090831651883e+04
            Stop		  4.3974974841597643e+04
            Start		  4.5942620962397275e+04
            Stop		  4.6809505778445979e+04
            Start		  4.8777152254662615e+04
            Stop		  4.9644036257064610e+04
            Start		  5.1611682383824271e+04
            Stop		  5.2478567193503637e+04
            Start		  5.4446213677258034e+04
            Stop		  5.5313097671963056e+04
            Start		  5.7280743805480910e+04
            Stop		  5.8147628608333966e+04
            Start		  6.0115275098802304e+04
            Stop		  6.0982159086932741e+04
            Start		  6.2949805226155448e+04
            Stop		  6.3816690023588497e+04
            Start		  6.5784336518841999e+04
            Stop		  6.6651220502643715e+04
            Start		  6.8618866645301183e+04
            Stop		  6.9485751439887666e+04
            Start		  7.1453397937184869e+04
            Stop		  7.2320281919651345e+04
            Start		  7.4287928062800274e+04
            Stop		  7.5154812857684752e+04
            Start		  7.7122459353933198e+04
            Stop		  7.7989343338290448e+04
            Start		  7.9956989478874864e+04
            Stop		  8.0823874277177441e+04
            Start		  8.2791520769466093e+04
            Stop		  8.3658404758614066e+04
            Start		  8.5626050894012136e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 48
            Strand		 25 49
            Strand		 25 50
            Strand		 25 51
            Start		  1.2944637122386478e+03
            Stop		  2.4848939568872247e+03
            Start		  4.1289936298264365e+03
            Stop		  5.3194245175480273e+03
            Start		  6.9635242680907968e+03
            Stop		  8.1539552300012410e+03
            Start		  9.7980549833190726e+03
            Stop		  1.0988485936699633e+04
            Start		  1.2632585697273104e+04
            Stop		  1.3823016642873023e+04
            Start		  1.5467116410858845e+04
            Stop		  1.6657547348405442e+04
            Start		  1.8301647123838964e+04
            Stop		  1.9492078053486461e+04
            Start		  2.1136177836063300e+04
            Stop		  2.2326608758311246e+04
            Start		  2.3970708547411617e+04
            Stop		  2.5161139463087082e+04
            Start		  2.6805239257802456e+04
            Stop		  2.7995670168023353e+04
            Start		  2.9639769967196360e+04
            Stop		  3.0830200873322432e+04
            Start		  3.2474300675597682e+04
            Stop		  3.3664731579170759e+04
            Start		  3.5308831383054363e+04
            Stop		  3.6499262285730714e+04
            Start		  3.8143362089655850e+04
            Stop		  3.9333792993133458e+04
            Start		  4.0977892795529173e+04
            Stop		  4.2168323701473142e+04
            Start		  4.3812423500833334e+04
            Stop		  4.5002854410802800e+04
            Start		  4.6646954205752365e+04
            Stop		  4.7837385121132058e+04
            Start		  4.9481484910487226e+04
            Stop		  5.0671915832426639e+04
            Start		  5.2316015615246935e+04
            Stop		  5.3506446544609869e+04
            Start		  5.5150546320239533e+04
            Stop		  5.6340977257566148e+04
            Start		  5.7985077025662780e+04
            Stop		  5.9175507971145918e+04
            Start		  6.0819607731695578e+04
            Stop		  6.2010038685172251e+04
            Start		  6.3654138438490088e+04
            Stop		  6.4844569399448592e+04
            Start		  6.6488669146165004e+04
            Stop		  6.7679100113767548e+04
            Start		  6.9323199854800376e+04
            Stop		  7.0513630827919711e+04
            Start		  7.2157730564434198e+04
            Stop		  7.3348161541703201e+04
            Start		  7.4992261275060519e+04
            Stop		  7.6182692254932190e+04
            Start		  7.7826791986629876e+04
            Stop		  7.9017222967445312e+04
            Start		  8.0661322699051409e+04
            Stop		  8.1851753679112648e+04
            Start		  8.3495853412196870e+04
            Stop		  8.4686284389841414e+04
            Start		  8.6330384125906276e+04
            Stop		  8.6400000000000000e+04
            Strand		 25 52
            Strand		 25 53
            Strand		 25 54
            Strand		 25 55
            Strand		 25 56
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 57
            Strand		 25 58
            Strand		 25 59
            Strand		 25 60
            Strand		 25 62
            Strand		 25 63
            Strand		 25 64
            Strand		 25 65
            Strand		 25 66
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 67
            Strand		 25 68
            Strand		 25 69
            Strand		 25 70
            Strand		 25 71
            Strand		 26 36
            Strand		 26 37
            Start		  0.0000000000000000e+00
            Stop		  2.8025410637502142e+02
            Start		  1.9243630253254155e+03
            Stop		  3.1147889079789957e+03
            Start		  4.7588899712394950e+03
            Stop		  5.9493195171583202e+03
            Start		  7.5934206474876946e+03
            Stop		  8.7838502353053264e+03
            Start		  1.0427951356107702e+04
            Stop		  1.1618380949337419e+04
            Start		  1.3262482064792905e+04
            Stop		  1.4452911663376963e+04
            Start		  1.6097012774523926e+04
            Stop		  1.7287442377002935e+04
            Start		  1.8931543485238155e+04
            Stop		  2.0121973090044557e+04
            Start		  2.1766074196881189e+04
            Stop		  2.2956503802344898e+04
            Start		  2.4600604909355188e+04
            Stop		  2.5791034513780145e+04
            Start		  2.7435135622525911e+04
            Stop		  2.8625565224264530e+04
            Start		  3.0269666336228467e+04
            Stop		  3.1460095933753986e+04
            Start		  3.3104197050274590e+04
            Stop		  3.4294626642248179e+04
            Start		  3.5938727764460862e+04
            Stop		  3.7129157349790519e+04
            Start		  3.8773258478577707e+04
            Stop		  3.9963688056466148e+04
            Start		  4.1607789192418546e+04
            Stop		  4.2798218762398363e+04
            Start		  4.4442319905788856e+04
            Stop		  4.5632749467743066e+04
            Start		  4.7276850618514763e+04
            Stop		  4.8467280172681982e+04
            Start		  5.0111381330450677e+04
            Stop		  5.1301810877414697e+04
            Start		  5.2945912041485622e+04
            Stop		  5.4136341582149813e+04
            Start		  5.5780442751548158e+04
            Stop		  5.6970872287095881e+04
            Start		  5.8614973460609515e+04
            Stop		  5.9805402992452204e+04
            Start		  6.1449504168684849e+04
            Stop		  6.2639933698400040e+04
            Start		  6.4284034875832585e+04
            Stop		  6.5474464405094797e+04
            Start		  6.7118565582151830e+04
            Stop		  6.8308995112658886e+04
            Start		  6.9953096287778055e+04
            Stop		  7.1143525821176809e+04
            Start		  7.2787626992877063e+04
            Stop		  7.3978056530691058e+04
            Start		  7.5622157697637871e+04
            Stop		  7.6812587241200396e+04
            Start		  7.8456688402264248e+04
            Stop		  7.9647117952659886e+04
            Start		  8.1291219106965800e+04
            Stop		  8.2481648664983019e+04
            Start		  8.4125749811948888e+04
            Stop		  8.5316179378045257e+04
            Strand		 26 38
            Strand		 26 39
            Strand		 26 40
            Strand		 26 41
            Strand		 26 42
            Start		  0.0000000000000000e+00
            Stop		  5.1217158422709247e+02
            Start		  2.4798173310444658e+03
            Stop		  3.3467015806232102e+03
            Start		  5.3143476499986828e+03
            Stop		  6.1812326155817309e+03
            Start		  8.1488787461494139e+03
            Stop		  9.0157628584196573e+03
            Start		  1.0983407529963999e+04
            Stop		  1.1850293811841944e+04
            Start		  1.3817940161777311e+04
            Stop		  1.4684824210999901e+04
            Start		  1.6652470771195574e+04
            Stop		  1.7519355152950957e+04
            Start		  1.9487001578570522e+04
            Stop		  2.0353885607539280e+04
            Start		  2.2321531863898828e+04
            Stop		  2.3188416547722754e+04
            Start		  2.5156062996940516e+04
            Stop		  2.6022947020358210e+04
            Start		  2.7990593176398161e+04
            Stop		  2.8857477959711490e+04
            Start		  3.0825124416999439e+04
            Stop		  3.1692008437739056e+04
            Start		  3.3659654562041149e+04
            Stop		  3.4526539376245055e+04
            Start		  3.6494185838556994e+04
            Stop		  3.7361069855454552e+04
            Start		  3.9328715972558435e+04
            Stop		  4.0195600793114274e+04
            Start		  4.2163247261159559e+04
            Stop		  4.3030131272200502e+04
            Start		  4.4997777391605647e+04
            Stop		  4.5864662209145914e+04
            Start		  4.7832308684170814e+04
            Stop		  4.8699192687854069e+04
            Start		  5.0666838813283131e+04
            Stop		  5.1533723624338796e+04
            Start		  5.3501370106883020e+04
            Stop		  5.4368254102820050e+04
            Start		  5.6335900235171131e+04
            Stop		  5.7202785039177339e+04
            Start		  5.9170431528640089e+04
            Stop		  6.0037315517734736e+04
            Start		  6.2004961656114116e+04
            Stop		  6.2871846454319886e+04
            Start		  6.4839492948951629e+04
            Stop		  6.5706376933280495e+04
            Start		  6.7674023075550620e+04
            Stop		  6.8540907870409137e+04
            Start		  7.0508554367578196e+04
            Stop		  7.1375438350042285e+04
            Start		  7.3343084493322865e+04
            Stop		  7.4209969287935673e+04
            Start		  7.6177615784572859e+04
            Stop		  7.7044499768397945e+04
            Start		  7.9012145909609055e+04
            Stop		  7.9879030707144528e+04
            Start		  8.1846677200271952e+04
            Stop		  8.2713561188449850e+04
            Start		  8.4681207324860850e+04
            Stop		  8.5548092127989832e+04
            Strand		 26 43
            Strand		 26 44
            Strand		 26 45
            Strand		 26 46
            Strand		 26 47
            Start		  1.1769799501738562e+02
            Stop		  9.8460303673590556e+02
            Start		  2.9522277599161225e+03
            Stop		  3.8191340330023190e+03
            Start		  5.7867594182284429e+03
            Stop		  6.6536643266171122e+03
            Start		  8.6212880324876769e+03
            Stop		  9.4881952713917144e+03
            Start		  1.1455820841003895e+04
            Stop		  1.2322725686542930e+04
            Start		  1.4290351348368566e+04
            Stop		  1.5157256624340749e+04
            Start		  1.7124882262750238e+04
            Stop		  1.7991787081636980e+04
            Start		  1.9959412526345088e+04
            Stop		  2.0826318018810231e+04
            Start		  2.2793943683016823e+04
            Stop		  2.3660848490517172e+04
            Start		  2.5628473865785963e+04
            Stop		  2.6495379428127289e+04
            Start		  2.8463005101590978e+04
            Stop		  2.9329909905150846e+04
            Start		  3.1297535257118474e+04
            Stop		  3.2164440843513006e+04
            Start		  3.4132066518547887e+04
            Stop		  3.4998971322902376e+04
            Start		  3.6966596664658340e+04
            Stop		  3.7833502262112670e+04
            Start		  3.9801127934241798e+04
            Stop		  4.0668032742846983e+04
            Start		  4.2635658077041880e+04
            Stop		  4.3502563682839886e+04
            Start		  4.5470189349245913e+04
            Stop		  4.6337094164439055e+04
            Start		  4.8304719491005395e+04
            Stop		  4.9171625105009975e+04
            Start		  5.1139250764253193e+04
            Stop		  5.2006155587099776e+04
            Start		  5.3973780905964079e+04
            Stop		  5.4840686527942889e+04
            Start		  5.6808312179956156e+04
            Stop		  5.7675217010148524e+04
            Start		  5.9642842322136734e+04
            Stop		  6.0509747950910467e+04
            Start		  6.2477373596926700e+04
            Stop		  6.3344278432865030e+04
            Start		  6.5311903739854155e+04
            Stop		  6.6178809373206415e+04
            Start		  6.8146435015516618e+04
            Stop		  6.9013339854595819e+04
            Start		  7.0980965159285784e+04
            Stop		  7.1847870794250251e+04
            Start		  7.3815496435796609e+04
            Stop		  7.4682401274861666e+04
            Start		  7.6650026580338657e+04
            Stop		  7.7516932213682114e+04
            Start		  7.9484557857543943e+04
            Stop		  8.0351462693438851e+04
            Start		  8.2319088002650140e+04
            Stop		  8.3185993631423087e+04
            Start		  8.5153619280281186e+04
            Stop		  8.6020524110397266e+04
            Strand		 26 48
            Strand		 26 49
            Strand		 26 50
            Strand		 26 51
            Strand		 26 52
            Start		  3.4961924212744350e+02
            Stop		  1.5400504500384382e+03
            Start		  3.1841500999370915e+03
            Stop		  4.3745809485570026e+03
            Start		  6.0186806967722287e+03
            Stop		  7.2091116608026414e+03
            Start		  8.8532114119178277e+03
            Stop		  1.0043642367814413e+04
            Start		  1.1687742125975508e+04
            Stop		  1.2878173074230315e+04
            Start		  1.4522272839723057e+04
            Stop		  1.5712703779953843e+04
            Start		  1.7356803552922596e+04
            Stop		  1.8547234485164590e+04
            Start		  2.0191334265414011e+04
            Stop		  2.1381765190052116e+04
            Start		  2.3025864977065383e+04
            Stop		  2.4216295894820934e+04
            Start		  2.5860395687781900e+04
            Stop		  2.7050826599680702e+04
            Start		  2.8694926397509797e+04
            Stop		  2.9885357304837162e+04
            Start		  3.1529457106238780e+04
            Stop		  3.2719888010483017e+04
            Start		  3.4363987814002387e+04
            Stop		  3.5554418716789514e+04
            Start		  3.7198518520876576e+04
            Stop		  3.8388949423898935e+04
            Start		  4.0033049226976415e+04
            Stop		  4.1223480131918317e+04
            Start		  4.2867579932450928e+04
            Stop		  4.4058010840914743e+04
            Start		  4.5702110637476668e+04
            Stop		  4.6892541550912465e+04
            Start		  4.8536641342249903e+04
            Stop		  4.9727072261891735e+04
            Start		  5.1371172046977990e+04
            Stop		  5.2561602973789770e+04
            Start		  5.4205702751870296e+04
            Stop		  5.5396133686503468e+04
            Start		  5.7040233457129019e+04
            Stop		  5.8230664399893816e+04
            Start		  5.9874764162940235e+04
            Stop		  6.1065195113792339e+04
            Start		  6.2709294869465870e+04
            Stop		  6.3899725828008035e+04
            Start		  6.5543825576836432e+04
            Stop		  6.6734256542336137e+04
            Start		  6.8378356285145303e+04
            Stop		  6.9568787256566895e+04
            Start		  7.1212886994444765e+04
            Stop		  7.2403317970494885e+04
            Start		  7.4047417704743653e+04
            Stop		  7.5237848683927979e+04
            Start		  7.6881948416006795e+04
            Stop		  7.8072379396695876e+04
            Start		  7.9716479128156760e+04
            Stop		  8.0906910108657379e+04
            Start		  8.2551009841077263e+04
            Stop		  8.3741440819706855e+04
            Start		  8.5385540554618128e+04
            Stop		  8.6400000000000000e+04
            Strand		 26 53
            Strand		 26 54
            Strand		 26 55
            Strand		 26 56
            Strand		 26 57
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 26 58
            Strand		 26 59
            Strand		 26 60
            Strand		 26 61
            Strand		 26 63
            Strand		 26 64
            Strand		 26 65
            Strand		 26 66
            Strand		 26 67
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 26 68
            Strand		 26 69
            Strand		 26 70
            Strand		 26 71
            Strand		 27 36
            Strand		 27 37
            Strand		 27 38
            Start		  9.7951602047059725e+02
            Stop		  2.1699452532635837e+03
            Start		  3.8140463767702631e+03
            Stop		  5.0044759486611065e+03
            Start		  6.6485770790662127e+03
            Stop		  7.8390066637379077e+03
            Start		  9.4831077867165659e+03
            Stop		  1.0673537377946403e+04
            Start		  1.2317638495107605e+04
            Stop		  1.3508068092068654e+04
            Start		  1.5152169204503176e+04
            Stop		  1.6342598805850585e+04
            Start		  1.7986699914893175e+04
            Stop		  1.9177129519105933e+04
            Start		  2.0821230626235552e+04
            Stop		  2.2011660231668862e+04
            Start		  2.3655761338445787e+04
            Stop		  2.4846190943403988e+04
            Start		  2.6490292051401208e+04
            Stop		  2.7680721654212339e+04
            Start		  2.9324822764946417e+04
            Stop		  3.0515252364035645e+04
            Start		  3.2159353478900059e+04
            Stop		  3.3349783072858918e+04
            Start		  3.4993884193062782e+04
            Stop		  3.6184313780711054e+04
            Start		  3.7828414907226062e+04
            Stop		  3.9018844487663700e+04
            Start		  4.0662945621181294e+04
            Stop		  4.1853375193827858e+04
            Start		  4.3497476334728934e+04
            Stop		  4.4687905899349345e+04
            Start		  4.6332007047687366e+04
            Stop		  4.7522436604402043e+04
            Start		  4.9166537759900777e+04
            Stop		  5.0356967309180567e+04
            Start		  5.2001068471246028e+04
            Stop		  5.3191498013891534e+04
            Start		  5.4835599181638034e+04
            Stop		  5.6026028718744485e+04
            Start		  5.7670129891033612e+04
            Stop		  5.8860559423942876e+04
            Start		  6.0504660599433228e+04
            Stop		  6.1695090129674834e+04
            Start		  6.3339191306881090e+04
            Stop		  6.4529620836105241e+04
            Start		  6.6173722013463135e+04
            Stop		  6.7364151543368193e+04
            Start		  6.9008252719303258e+04
            Stop		  7.0198682251561360e+04
            Start		  7.1842783424558016e+04
            Stop		  7.3033212960741424e+04
            Start		  7.4677314129409482e+04
            Stop		  7.5867743670921918e+04
            Start		  7.7511844834057469e+04
            Stop		  7.8702274382072355e+04
            Start		  8.0346375538710708e+04
            Stop		  8.1536805094119627e+04
            Start		  8.3180906243577614e+04
            Stop		  8.4371335806951480e+04
            Start		  8.6015436948857212e+04
            Stop		  8.6400000000000000e+04
            Strand		 27 39
            Strand		 27 40
            Strand		 27 41
            Strand		 27 42
            Start		  0.0000000000000000e+00
            Stop		  3.9759453579811371e+01
            Start		  2.0073840337373329e+03
            Stop		  2.8742904409855460e+03
            Start		  4.8419158477302672e+03
            Stop		  5.7088207504061247e+03
            Start		  7.6764444114667604e+03
            Stop		  8.5433516939600686e+03
            Start		  1.0510977270606056e+04
            Stop		  1.1377882114767852e+04
            Start		  1.3345507745229817e+04
            Stop		  1.4212413052397531e+04
            Start		  1.6180038692554905e+04
            Stop		  1.7046943511539441e+04
            Start		  1.9014568945494899e+04
            Stop		  1.9881474448625861e+04
            Start		  2.1849100113088483e+04
            Stop		  2.2716004920865991e+04
            Start		  2.4683630292443275e+04
            Stop		  2.5550535858360938e+04
            Start		  2.7518161531946876e+04
            Stop		  2.8385066335462780e+04
            Start		  3.0352691686431572e+04
            Stop		  3.1219597273685620e+04
            Start		  3.3187222949155577e+04
            Stop		  3.4054127752999913e+04
            Start		  3.6021753094976651e+04
            Stop		  3.6888658692068544e+04
            Start		  3.8856284365024985e+04
            Stop		  3.9723189172691767e+04
            Start		  4.1690814507745141e+04
            Stop		  4.2557720112564821e+04
            Start		  4.4525345780097727e+04
            Stop		  4.5392250594070632e+04
            Start		  4.7359875921804196e+04
            Stop		  4.8226781534564252e+04
            Start		  5.0194407195054824e+04
            Stop		  5.1061312016606069e+04
            Start		  5.3028937336683863e+04
            Stop		  5.3895842957427798e+04
            Start		  5.5863468610597483e+04
            Stop		  5.6730373439642943e+04
            Start		  5.8697998752660089e+04
            Stop		  5.9564904380443128e+04
            Start		  6.1532530027325396e+04
            Stop		  6.2399434862464266e+04
            Start		  6.4367060170112149e+04
            Stop		  6.5233965802896877e+04
            Start		  6.7201591445632483e+04
            Stop		  6.8068496284398832e+04
            Start		  7.0036121589260263e+04
            Stop		  7.0903027224181642e+04
            Start		  7.2870652865638549e+04
            Stop		  7.3737557704932115e+04
            Start		  7.5705183010062363e+04
            Stop		  7.6572088643895739e+04
            Start		  7.8539714287168419e+04
            Stop		  7.9406619123793978e+04
            Start		  8.1374244432199746e+04
            Stop		  8.2241150061911394e+04
            Start		  8.4208775709782378e+04
            Stop		  8.5075680541004884e+04
            Strand		 27 43
            Start		  1.5349737618038389e+03
            Stop		  2.4018579899124566e+03
            Start		  4.3695037935024639e+03
            Stop		  5.2363890055828042e+03
            Start		  7.2040351769840581e+03
            Stop		  8.0709192757042993e+03
            Start		  1.0038563866474702e+04
            Stop		  1.0905450226195477e+04
            Start		  1.2873096592452845e+04
            Stop		  1.3739980635698041e+04
            Start		  1.5707627140642724e+04
            Stop		  1.6574511577325025e+04
            Start		  1.8542158009007115e+04
            Stop		  1.9409042035453906e+04
            Start		  2.1376688274165503e+04
            Stop		  2.2243572975681545e+04
            Start		  2.4211219427095439e+04
            Stop		  2.5078103449579019e+04
            Start		  2.7045749599808922e+04
            Stop		  2.7912634389052477e+04
            Start		  2.9880280846877264e+04
            Stop		  3.0747164867598978e+04
            Start		  3.2714810989617043e+04
            Stop		  3.3581695806246986e+04
            Start		  3.5549342268209941e+04
            Stop		  3.6416226285724973e+04
            Start		  3.8383872401410859e+04
            Stop		  3.9250757223519831e+04
            Start		  4.1218403690678744e+04
            Stop		  4.2085287702770343e+04
            Start		  4.4052933820862134e+04
            Stop		  4.4919818639819954e+04
            Start		  4.6887465113670594e+04
            Stop		  4.7754349118623431e+04
            Start		  4.9721995242739329e+04
            Stop		  5.0588880055163252e+04
            Start		  5.2556526536481091e+04
            Stop		  5.3423410533675349e+04
            Start		  5.5391056664831864e+04
            Stop		  5.6257941470029029e+04
            Start		  5.8225587958437129e+04
            Stop		  5.9092471948554434e+04
            Start		  6.1060118086029375e+04
            Stop		  6.1927002885077876e+04
            Start		  6.3894649379013768e+04
            Stop		  6.4761533363951494e+04
            Start		  6.6729179505752851e+04
            Stop		  6.7596064300971062e+04
            Start		  6.9563710797925552e+04
            Stop		  7.0430594780478132e+04
            Start		  7.2398240923803474e+04
            Stop		  7.3265125718234005e+04
            Start		  7.5232772215175995e+04
            Stop		  7.6099656198553232e+04
            Start		  7.8067302340314083e+04
            Stop		  7.8934187137157758e+04
            Start		  8.0901833631057088e+04
            Stop		  8.1768717618327981e+04
            Start		  8.3736363755698301e+04
            Stop		  8.4603248557746032e+04
            Strand		 27 44
            Strand		 27 45
            Strand		 27 46
            Strand		 27 47
            Strand		 27 48
            Strand		 27 49
            Strand		 27 50
            Strand		 27 51
            Strand		 27 52
            Strand		 27 53
            Start		  0.0000000000000000e+00
            Stop		  5.9520690098017883e+02
            Start		  2.2393065456292466e+03
            Stop		  3.4297373796034090e+03
            Start		  5.0738371254913300e+03
            Stop		  6.2642680914938474e+03
            Start		  7.9083678404975262e+03
            Stop		  9.0987987988383375e+03
            Start		  1.0742898554638004e+04
            Stop		  1.1933329505511694e+04
            Start		  1.3577429268526448e+04
            Stop		  1.4767860211445008e+04
            Start		  1.6411959981927288e+04
            Stop		  1.7602390916806700e+04
            Start		  1.9246490694671083e+04
            Stop		  2.0436921621779758e+04
            Start		  2.2081021406614927e+04
            Stop		  2.3271452326564919e+04
            Start		  2.4915552117651128e+04
            Stop		  2.6105983031371128e+04
            Start		  2.7750082827711896e+04
            Stop		  2.8940513736406447e+04
            Start		  3.0584613536772267e+04
            Stop		  3.1775044441868911e+04
            Start		  3.3419144244851283e+04
            Stop		  3.4609575147937838e+04
            Start		  3.6253674952010995e+04
            Stop		  3.7444105854765854e+04
            Start		  3.9088205658353938e+04
            Stop		  4.0278636562472413e+04
            Start		  4.1922736364018492e+04
            Stop		  4.3113167271138314e+04
            Start		  4.4757267069172820e+04
            Stop		  4.5947697980802288e+04
            Start		  4.7591797774007544e+04
            Stop		  4.8782228691459277e+04
            Start		  5.0426328478727322e+04
            Stop		  5.1616759403060591e+04
            Start		  5.3260859183541885e+04
            Stop		  5.4451290115516145e+04
            Start		  5.6095389888656806e+04
            Stop		  5.7285820828698394e+04
            Start		  5.8929920594264535e+04
            Stop		  6.0120351542447781e+04
            Start		  6.1764451300535860e+04
            Stop		  6.2954882256580015e+04
            Start		  6.4598982007612445e+04
            Stop		  6.5789412970893914e+04
            Start		  6.7433512715600620e+04
            Stop		  6.8623943685180333e+04
            Start		  7.0268043424566786e+04
            Stop		  7.1458474399231447e+04
            Start		  7.3102574134534269e+04
            Stop		  7.4293005112849685e+04
            Start		  7.5937104845482521e+04
            Stop		  7.7127535825856554e+04
            Start		  7.8771635557347981e+04
            Stop		  7.9962066538100480e+04
            Start		  8.1606166270026792e+04
            Stop		  8.2796597249463259e+04
            Start		  8.4440696983379370e+04
            Stop		  8.5631127959865596e+04
            Strand		 27 54
            Strand		 27 55
            Strand		 27 56
            Strand		 27 57
            Strand		 27 58
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 27 59
            Strand		 27 60
            Strand		 27 61
            Strand		 27 62
            Strand		 27 64
            Strand		 27 65
            Strand		 27 66
            Strand		 27 67
            Strand		 27 68
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 27 69
            Strand		 27 70
            Strand		 27 71
            Strand		 28 36
            Strand		 28 37
            Strand		 28 38
            Strand		 28 39
            Start		  3.4676930964084477e+01
            Stop		  1.2251018212145532e+03
            Start		  2.8692028848144846e+03
            Stop		  4.0596323737955013e+03
            Start		  5.7037335093435804e+03
            Stop		  6.8941630925073378e+03
            Start		  8.5382642175039964e+03
            Stop		  9.7286938065237900e+03
            Start		  1.1372794925529417e+04
            Stop		  1.2563224520723514e+04
            Start		  1.4207325634593515e+04
            Stop		  1.5397755234639479e+04
            Start		  1.7041856344654367e+04
            Stop		  1.8232285948090121e+04
            Start		  1.9876387055686671e+04
            Stop		  2.1066816660900538e+04
            Start		  2.2710917767619459e+04
            Stop		  2.3901347372924505e+04
            Start		  2.5545448480342246e+04
            Stop		  2.6735878084050328e+04
            Start		  2.8379979193709885e+04
            Stop		  2.9570408794205818e+04
            Start		  3.1214509907548814e+04
            Stop		  3.2404939503361373e+04
            Start		  3.4049040621664753e+04
            Stop		  3.5239470211531348e+04
            Start		  3.6883571335851215e+04
            Stop		  3.8074000918773345e+04
            Start		  3.9718102049898589e+04
            Stop		  4.0908531625185737e+04
            Start		  4.2552632763603346e+04
            Stop		  4.3743062330903333e+04
            Start		  4.5387163476776914e+04
            Stop		  4.6577593036091559e+04
            Start		  4.8221694189254100e+04
            Stop		  4.9412123740938914e+04
            Start		  5.1056224900900139e+04
            Stop		  5.2246654445649066e+04
            Start		  5.3890755611616842e+04
            Stop		  5.5081185150431615e+04
            Start		  5.6725286321346684e+04
            Stop		  5.7915715855493007e+04
            Start		  5.9559817030075501e+04
            Stop		  6.0750246561027481e+04
            Start		  6.2394347737833072e+04
            Stop		  6.3584777267208512e+04
            Start		  6.5228878444691734e+04
            Stop		  6.6419307974181196e+04
            Start		  6.8063409150763269e+04
            Stop		  6.9253838682055895e+04
            Start		  7.0897939856194018e+04
            Stop		  7.2088369390903346e+04
            Start		  7.3732470561158421e+04
            Stop		  7.4922900100751605e+04
            Start		  7.6567001265851286e+04
            Stop		  7.7757430811584753e+04
            Start		  7.9401531970479424e+04
            Stop		  8.0591961523343736e+04
            Start		  8.2236062675252309e+04
            Stop		  8.3426492235928788e+04
            Start		  8.5070593380373175e+04
            Stop		  8.6261023283963135e+04
            Strand		 28 40
            Strand		 28 41
            Strand		 28 42
            Strand		 28 43
            Start		  1.0625408519517555e+03
            Stop		  1.9294493132962875e+03
            Start		  3.8970722760685212e+03
            Stop		  4.7639809303371476e+03
            Start		  6.7316022457623994e+03
            Stop		  7.5985075128024027e+03
            Start		  9.5661327844269836e+03
            Stop		  1.0433038108525958e+04
            Start		  1.2400660649245328e+04
            Stop		  1.3267569148073408e+04
            Start		  1.5235193536927240e+04
            Stop		  1.6102099757005995e+04
            Start		  1.8069723575100121e+04
            Stop		  1.8936630716245789e+04
            Start		  2.0904256543156556e+04
            Stop		  2.1771161295905535e+04
            Start		  2.3738786112066984e+04
            Stop		  2.4605692235317361e+04
            Start		  2.6573317962271227e+04
            Stop		  2.7440222748099459e+04
            Start		  2.9407847913604386e+04
            Stop		  3.0274753686331365e+04
            Start		  3.2242379379730515e+04
            Stop		  3.3109284177347930e+04
            Start		  3.5076909458291440e+04
            Stop		  3.5943815116266436e+04
            Start		  3.7911440795787370e+04
            Stop		  3.8778345600669418e+04
            Start		  4.0745970916272585e+04
            Stop		  4.1612876540409059e+04
            Start		  4.3580502210946834e+04
            Stop		  4.4447407023102372e+04
            Start		  4.6415032345278989e+04
            Stop		  4.7281937963507007e+04
            Start		  4.9249563625873139e+04
            Stop		  5.0116468445917424e+04
            Start		  5.2084093765004676e+04
            Stop		  5.2950999386706710e+04
            Start		  5.4918625041272258e+04
            Stop		  5.5785529869062149e+04
            Start		  5.7753155182421455e+04
            Stop		  5.8620060809890427e+04
            Start		  6.0587686457768592e+04
            Stop		  6.1454591292015684e+04
            Start		  6.3422216600152162e+04
            Stop		  6.4289122232531416e+04
            Start		  6.6256747875796194e+04
            Stop		  6.7123652714154785e+04
            Start		  6.9091278019193502e+04
            Stop		  6.9958183654061140e+04
            Start		  7.1925809295523402e+04
            Stop		  7.2792714134952941e+04
            Start		  7.4760339439794625e+04
            Stop		  7.5627245074059014e+04
            Start		  7.7594870716823440e+04
            Stop		  7.8461775554101725e+04
            Start		  8.0429400861761969e+04
            Stop		  8.1296306492355696e+04
            Start		  8.3263932139296434e+04
            Stop		  8.4130836971574332e+04
            Start		  8.6098462284608016e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 44
            Start		  5.9013019007224170e+02
            Stop		  1.4570144227801129e+03
            Start		  3.4246609000833823e+03
            Stop		  4.2915451718429085e+03
            Start		  6.2591915605636877e+03
            Stop		  7.1260762313059431e+03
            Start		  9.0937223153300329e+03
            Stop		  9.9606064429787111e+03
            Start		  1.1928251212210385e+04
            Stop		  1.2795137400307747e+04
            Start		  1.4762783731135109e+04
            Stop		  1.5629667787162329e+04
            Start		  1.7597314413848067e+04
            Stop		  1.8464198729554966e+04
            Start		  2.0431845148178527e+04
            Stop		  2.1298729179917711e+04
            Start		  2.3266375457606329e+04
            Stop		  2.4133260120064238e+04
            Start		  2.6100906566833241e+04
            Stop		  2.6967790591206365e+04
            Start		  2.8935436754324171e+04
            Stop		  2.9802321530436737e+04
            Start		  3.1769967987163858e+04
            Stop		  3.2636852007868314e+04
            Start		  3.4604498134927831e+04
            Stop		  3.5471382946232079e+04
            Start		  3.7439029408933515e+04
            Stop		  3.8305913425150051e+04
            Start		  4.0273559543867705e+04
            Stop		  4.1140444362678340e+04
            Start		  4.3108090831651876e+04
            Stop		  4.3974974841597636e+04
            Start		  4.5942620962397268e+04
            Stop		  4.6809505778445979e+04
            Start		  4.8777152254662615e+04
            Stop		  4.9644036257064596e+04
            Start		  5.1611682383824271e+04
            Stop		  5.2478567193503630e+04
            Start		  5.4446213677258042e+04
            Stop		  5.5313097671963049e+04
            Start		  5.7280743805480917e+04
            Stop		  5.8147628608333973e+04
            Start		  6.0115275098802311e+04
            Stop		  6.0982159086932748e+04
            Start		  6.2949805226155448e+04
            Stop		  6.3816690023588475e+04
            Start		  6.5784336518842014e+04
            Stop		  6.6651220502643730e+04
            Start		  6.8618866645301183e+04
            Stop		  6.9485751439887681e+04
            Start		  7.1453397937184884e+04
            Stop		  7.2320281919651330e+04
            Start		  7.4287928062800274e+04
            Stop		  7.5154812857684767e+04
            Start		  7.7122459353933184e+04
            Stop		  7.7989343338290462e+04
            Start		  7.9956989478874850e+04
            Stop		  8.0823874277177441e+04
            Start		  8.2791520769466108e+04
            Stop		  8.3658404758614080e+04
            Start		  8.5626050894012151e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 45
            Strand		 28 46
            Strand		 28 47
            Strand		 28 48
            Start		  1.2944637122386482e+03
            Stop		  2.4848939568872283e+03
            Start		  4.1289936298264365e+03
            Stop		  5.3194245175480328e+03
            Start		  6.9635242680907986e+03
            Stop		  8.1539552300012438e+03
            Start		  9.7980549833190671e+03
            Stop		  1.0988485936699628e+04
            Start		  1.2632585697273100e+04
            Stop		  1.3823016642873017e+04
            Start		  1.5467116410858844e+04
            Stop		  1.6657547348405442e+04
            Start		  1.8301647123838968e+04
            Stop		  1.9492078053486457e+04
            Start		  2.1136177836063303e+04
            Stop		  2.2326608758311242e+04
            Start		  2.3970708547411621e+04
            Stop		  2.5161139463087078e+04
            Start		  2.6805239257802452e+04
            Stop		  2.7995670168023356e+04
            Start		  2.9639769967196360e+04
            Stop		  3.0830200873322417e+04
            Start		  3.2474300675597664e+04
            Stop		  3.3664731579170766e+04
            Start		  3.5308831383054341e+04
            Stop		  3.6499262285730714e+04
            Start		  3.8143362089655850e+04
            Stop		  3.9333792993133444e+04
            Start		  4.0977892795529173e+04
            Stop		  4.2168323701473135e+04
            Start		  4.3812423500833342e+04
            Stop		  4.5002854410802793e+04
            Start		  4.6646954205752379e+04
            Stop		  4.7837385121132065e+04
            Start		  4.9481484910487212e+04
            Stop		  5.0671915832426617e+04
            Start		  5.2316015615246950e+04
            Stop		  5.3506446544609862e+04
            Start		  5.5150546320239526e+04
            Stop		  5.6340977257566177e+04
            Start		  5.7985077025662795e+04
            Stop		  5.9175507971145926e+04
            Start		  6.0819607731695578e+04
            Stop		  6.2010038685172236e+04
            Start		  6.3654138438490103e+04
            Stop		  6.4844569399448585e+04
            Start		  6.6488669146165004e+04
            Stop		  6.7679100113767519e+04
            Start		  6.9323199854800390e+04
            Stop		  7.0513630827919711e+04
            Start		  7.2157730564434198e+04
            Stop		  7.3348161541703186e+04
            Start		  7.4992261275060504e+04
            Stop		  7.6182692254932190e+04
            Start		  7.7826791986629876e+04
            Stop		  7.9017222967445327e+04
            Start		  8.0661322699051409e+04
            Stop		  8.1851753679112662e+04
            Start		  8.3495853412196899e+04
            Stop		  8.4686284389841428e+04
            Start		  8.6330384125906276e+04
            Stop		  8.6400000000000000e+04
            Strand		 28 49
            Strand		 28 50
            Strand		 28 51
            Strand		 28 52
            Strand		 28 53
            Strand		 28 54
            Strand		 28 55
            Strand		 28 56
            Strand		 28 57
            Strand		 28 58
            Strand		 28 59
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 28 60
            Strand		 28 61
            Strand		 28 62
            Strand		 28 63
            Strand		 28 65
            Strand		 28 66
            Strand		 28 67
            Strand		 28 68
            Strand		 28 69
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 28 70
            Strand		 28 71
            Strand		 29 36
            Strand		 29 37
            Strand		 29 38
            Strand		 29 39
            Strand		 29 40
            Start		  0.0000000000000000e+00
            Stop		  2.8025410637502182e+02
            Start		  1.9243630253254169e+03
            Stop		  3.1147889079789948e+03
            Start		  4.7588899712395096e+03
            Stop		  5.9493195171583193e+03
            Start		  7.5934206474876974e+03
            Stop		  8.7838502353053173e+03
            Start		  1.0427951356107707e+04
            Stop		  1.1618380949337421e+04
            Start		  1.3262482064792906e+04
            Stop		  1.4452911663376974e+04
            Start		  1.6097012774523922e+04
            Stop		  1.7287442377002932e+04
            Start		  1.8931543485238155e+04
            Stop		  2.0121973090044557e+04
            Start		  2.1766074196881189e+04
            Stop		  2.2956503802344898e+04
            Start		  2.4600604909355188e+04
            Stop		  2.5791034513780152e+04
            Start		  2.7435135622525908e+04
            Stop		  2.8625565224264541e+04
            Start		  3.0269666336228463e+04
            Stop		  3.1460095933753983e+04
            Start		  3.3104197050274583e+04
            Stop		  3.4294626642248186e+04
            Start		  3.5938727764460855e+04
            Stop		  3.7129157349790505e+04
            Start		  3.8773258478577707e+04
            Stop		  3.9963688056466155e+04
            Start		  4.1607789192418539e+04
            Stop		  4.2798218762398370e+04
            Start		  4.4442319905788856e+04
            Stop		  4.5632749467743051e+04
            Start		  4.7276850618514778e+04
            Stop		  4.8467280172681982e+04
            Start		  5.0111381330450669e+04
            Stop		  5.1301810877414697e+04
            Start		  5.2945912041485615e+04
            Stop		  5.4136341582149806e+04
            Start		  5.5780442751548166e+04
            Stop		  5.6970872287095888e+04
            Start		  5.8614973460609523e+04
            Stop		  5.9805402992452196e+04
            Start		  6.1449504168684864e+04
            Stop		  6.2639933698400062e+04
            Start		  6.4284034875832571e+04
            Stop		  6.5474464405094768e+04
            Start		  6.7118565582151830e+04
            Stop		  6.8308995112658886e+04
            Start		  6.9953096287778055e+04
            Stop		  7.1143525821176823e+04
            Start		  7.2787626992877063e+04
            Stop		  7.3978056530691072e+04
            Start		  7.5622157697637871e+04
            Stop		  7.6812587241200381e+04
            Start		  7.8456688402264248e+04
            Stop		  7.9647117952659930e+04
            Start		  8.1291219106965815e+04
            Stop		  8.2481648664983004e+04
            Start		  8.4125749811948903e+04
            Stop		  8.5316179378045214e+04
            Strand		 29 41
            Strand		 29 42
            Strand		 29 43
            Strand		 29 44
            Start		  1.1769799501738481e+02
            Stop		  9.8460303673590693e+02
            Start		  2.9522277599161198e+03
            Stop		  3.8191340330023190e+03
            Start		  5.7867594182284429e+03
            Stop		  6.6536643266171131e+03
            Start		  8.6212880324876751e+03
            Stop		  9.4881952713917126e+03
            Start		  1.1455820841003895e+04
            Stop		  1.2322725686542932e+04
            Start		  1.4290351348368569e+04
            Stop		  1.5157256624340749e+04
            Start		  1.7124882262750238e+04
            Stop		  1.7991787081636980e+04
            Start		  1.9959412526345084e+04
            Stop		  2.0826318018810231e+04
            Start		  2.2793943683016823e+04
            Stop		  2.3660848490517168e+04
            Start		  2.5628473865785960e+04
            Stop		  2.6495379428127286e+04
            Start		  2.8463005101590974e+04
            Stop		  2.9329909905150842e+04
            Start		  3.1297535257118474e+04
            Stop		  3.2164440843513003e+04
            Start		  3.4132066518547879e+04
            Stop		  3.4998971322902369e+04
            Start		  3.6966596664658333e+04
            Stop		  3.7833502262112670e+04
            Start		  3.9801127934241806e+04
            Stop		  4.0668032742846990e+04
            Start		  4.2635658077041873e+04
            Stop		  4.3502563682839878e+04
            Start		  4.5470189349245913e+04
            Stop		  4.6337094164439048e+04
            Start		  4.8304719491005388e+04
            Stop		  4.9171625105009967e+04
            Start		  5.1139250764253178e+04
            Stop		  5.2006155587099769e+04
            Start		  5.3973780905964086e+04
            Stop		  5.4840686527942897e+04
            Start		  5.6808312179956163e+04
            Stop		  5.7675217010148524e+04
            Start		  5.9642842322136734e+04
            Stop		  6.0509747950910474e+04
            Start		  6.2477373596926700e+04
            Stop		  6.3344278432865023e+04
            Start		  6.5311903739854162e+04
            Stop		  6.6178809373206415e+04
            Start		  6.8146435015516618e+04
            Stop		  6.9013339854595833e+04
            Start		  7.0980965159285784e+04
            Stop		  7.1847870794250266e+04
            Start		  7.3815496435796609e+04
            Stop		  7.4682401274861666e+04
            Start		  7.6650026580338657e+04
            Stop		  7.7516932213682099e+04
            Start		  7.9484557857543943e+04
            Stop		  8.0351462693438836e+04
            Start		  8.2319088002650125e+04
            Stop		  8.3185993631423102e+04
            Start		  8.5153619280281171e+04
            Stop		  8.6020524110397266e+04
            Strand		 29 45
            Start		  0.0000000000000000e+00
            Stop		  5.1217158422709315e+02
            Start		  2.4798173310444649e+03
            Stop		  3.3467015806232125e+03
            Start		  5.3143476499986828e+03
            Stop		  6.1812326155817318e+03
            Start		  8.1488787461494130e+03
            Stop		  9.0157628584196573e+03
            Start		  1.0983407529963999e+04
            Stop		  1.1850293811841948e+04
            Start		  1.3817940161777313e+04
            Stop		  1.4684824210999903e+04
            Start		  1.6652470771195574e+04
            Stop		  1.7519355152950957e+04
            Start		  1.9487001578570522e+04
            Stop		  2.0353885607539280e+04
            Start		  2.2321531863898828e+04
            Stop		  2.3188416547722754e+04
            Start		  2.5156062996940520e+04
            Stop		  2.6022947020358206e+04
            Start		  2.7990593176398161e+04
            Stop		  2.8857477959711494e+04
            Start		  3.0825124416999442e+04
            Stop		  3.1692008437739056e+04
            Start		  3.3659654562041142e+04
            Stop		  3.4526539376245055e+04
            Start		  3.6494185838556987e+04
            Stop		  3.7361069855454545e+04
            Start		  3.9328715972558435e+04
            Stop		  4.0195600793114274e+04
            Start		  4.2163247261159559e+04
            Stop		  4.3030131272200502e+04
            Start		  4.4997777391605647e+04
            Stop		  4.5864662209145907e+04
            Start		  4.7832308684170814e+04
            Stop		  4.8699192687854076e+04
            Start		  5.0666838813283124e+04
            Stop		  5.1533723624338803e+04
            Start		  5.3501370106883020e+04
            Stop		  5.4368254102820050e+04
            Start		  5.6335900235171131e+04
            Stop		  5.7202785039177339e+04
            Start		  5.9170431528640082e+04
            Stop		  6.0037315517734736e+04
            Start		  6.2004961656114108e+04
            Stop		  6.2871846454319872e+04
            Start		  6.4839492948951629e+04
            Stop		  6.5706376933280480e+04
            Start		  6.7674023075550620e+04
            Stop		  6.8540907870409137e+04
            Start		  7.0508554367578196e+04
            Stop		  7.1375438350042255e+04
            Start		  7.3343084493322865e+04
            Stop		  7.4209969287935673e+04
            Start		  7.6177615784572874e+04
            Stop		  7.7044499768397945e+04
            Start		  7.9012145909609055e+04
            Stop		  7.9879030707144528e+04
            Start		  8.1846677200271937e+04
            Stop		  8.2713561188449836e+04
            Start		  8.4681207324860836e+04
            Stop		  8.5548092127989847e+04
            Strand		 29 46
            Strand		 29 47
            Strand		 29 48
            Strand		 29 49
            Start		  3.4961924212744390e+02
            Stop		  1.5400504500384509e+03
            Start		  3.1841500999370869e+03
            Stop		  4.3745809485570026e+03
            Start		  6.0186806967722268e+03
            Stop		  7.2091116608026396e+03
            Start		  8.8532114119178314e+03
            Stop		  1.0043642367814426e+04
            Start		  1.1687742125975503e+04
            Stop		  1.2878173074230312e+04
            Start		  1.4522272839723051e+04
            Stop		  1.5712703779953836e+04
            Start		  1.7356803552922596e+04
            Stop		  1.8547234485164594e+04
            Start		  2.0191334265414007e+04
            Stop		  2.1381765190052120e+04
            Start		  2.3025864977065372e+04
            Stop		  2.4216295894820934e+04
            Start		  2.5860395687781907e+04
            Stop		  2.7050826599680706e+04
            Start		  2.8694926397509797e+04
            Stop		  2.9885357304837155e+04
            Start		  3.1529457106238788e+04
            Stop		  3.2719888010483010e+04
            Start		  3.4363987814002394e+04
            Stop		  3.5554418716789507e+04
            Start		  3.7198518520876569e+04
            Stop		  3.8388949423898943e+04
            Start		  4.0033049226976407e+04
            Stop		  4.1223480131918310e+04
            Start		  4.2867579932450935e+04
            Stop		  4.4058010840914758e+04
            Start		  4.5702110637476668e+04
            Stop		  4.6892541550912450e+04
            Start		  4.8536641342249895e+04
            Stop		  4.9727072261891743e+04
            Start		  5.1371172046977983e+04
            Stop		  5.2561602973789762e+04
            Start		  5.4205702751870303e+04
            Stop		  5.5396133686503439e+04
            Start		  5.7040233457129005e+04
            Stop		  5.8230664399893838e+04
            Start		  5.9874764162940242e+04
            Stop		  6.1065195113792332e+04
            Start		  6.2709294869465870e+04
            Stop		  6.3899725828008042e+04
            Start		  6.5543825576836418e+04
            Stop		  6.6734256542336123e+04
            Start		  6.8378356285145288e+04
            Stop		  6.9568787256566909e+04
            Start		  7.1212886994444780e+04
            Stop		  7.2403317970494914e+04
            Start		  7.4047417704743639e+04
            Stop		  7.5237848683928009e+04
            Start		  7.6881948416006780e+04
            Stop		  7.8072379396695876e+04
            Start		  7.9716479128156760e+04
            Stop		  8.0906910108657408e+04
            Start		  8.2551009841077248e+04
            Stop		  8.3741440819706870e+04
            Start		  8.5385540554618157e+04
            Stop		  8.6400000000000000e+04
            Strand		 29 50
            Strand		 29 51
            Strand		 29 52
            Strand		 29 53
            Strand		 29 54
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 29 55
            Strand		 29 56
            Strand		 29 57
            Strand		 29 58
            Strand		 29 59
            Strand		 29 60
            Strand		 29 61
            Strand		 29 62
            Strand		 29 63
            Strand		 29 64
            Strand		 29 66
            Strand		 29 67
            Strand		 29 68
            Strand		 29 69
            Strand		 29 70
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 29 71
            Strand		 30 36
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 30 37
            Strand		 30 38
            Strand		 30 39
            Strand		 30 40
            Strand		 30 41
            Strand		 30 42
            Strand		 30 43
            Strand		 30 44
            Strand		 30 45
            Strand		 30 46
            Strand		 30 47
            Start		  8.2204588669137377e+02
            Stop		  2.0124714059944504e+03
            Start		  3.6565724999424924e+03
            Stop		  4.8470020014042711e+03
            Start		  6.4911031702852197e+03
            Stop		  7.6815327165059844e+03
            Start		  9.3256338759043410e+03
            Stop		  1.0516063428180496e+04
            Start		  1.2160164580764231e+04
            Stop		  1.3350594140874717e+04
            Start		  1.4994695286064429e+04
            Stop		  1.6185124854212652e+04
            Start		  1.7829225991936677e+04
            Stop		  1.9019655568034199e+04
            Start		  2.0663756698541594e+04
            Stop		  2.1854186282145583e+04
            Start		  2.3498287406005074e+04
            Stop		  2.4688716996340874e+04
            Start		  2.6332818114415339e+04
            Stop		  2.7523247710410411e+04
            Start		  2.9167348823819011e+04
            Stop		  3.0357778424149987e+04
            Start		  3.2001879534219082e+04
            Stop		  3.3192309137369943e+04
            Start		  3.4836410245574756e+04
            Stop		  3.6026839849903306e+04
            Start		  3.7670940957803294e+04
            Stop		  3.8861370561613316e+04
            Start		  4.0505471670783569e+04
            Stop		  4.1695901272399278e+04
            Start		  4.3340002384361454e+04
            Stop		  4.4530431982201080e+04
            Start		  4.6174533098356551e+04
            Stop		  4.7364962691001812e+04
            Start		  4.9009063812570115e+04
            Stop		  5.0199493398828497e+04
            Start		  5.1843594526793793e+04
            Stop		  5.3034024105750868e+04
            Start		  5.4678125240818816e+04
            Stop		  5.5868554811878406e+04
            Start		  5.7512655954445050e+04
            Stop		  5.8703085517355445e+04
            Start		  6.0347186667489856e+04
            Stop		  6.1537616222354882e+04
            Start		  6.3181717379796166e+04
            Stop		  6.4372146927070447e+04
            Start		  6.6016248091239264e+04
            Stop		  6.7206677631708546e+04
            Start		  6.8850778801732333e+04
            Stop		  7.0041208336478769e+04
            Start		  7.1685309511230327e+04
            Stop		  7.2875739041584951e+04
            Start		  7.4519840219731748e+04
            Stop		  7.5710269747216124e+04
            Start		  7.7354370927278884e+04
            Stop		  7.8544800453538308e+04
            Start		  8.0188901633956033e+04
            Stop		  8.1379331160687070e+04
            Start		  8.3023432339885447e+04
            Stop		  8.4213861868761727e+04
            Start		  8.5857963045222306e+04
            Stop		  8.6400000000000000e+04
            Strand		 30 48
            Strand		 30 49
            Strand		 30 50
            Strand		 30 51
            Start		  1.8499065193291797e+03
            Stop		  2.7168163266377551e+03
            Start		  4.6844418886183794e+03
            Stop		  5.5513477424660723e+03
            Start		  7.5189726208863285e+03
            Stop		  8.3858775786833012e+03
            Start		  1.0353501506910605e+04
            Stop		  1.1220408533233209e+04
            Start		  1.3188034043660909e+04
            Stop		  1.4054938919496955e+04
            Start		  1.6022564727575060e+04
            Stop		  1.6889469859052952e+04
            Start		  1.8857095466679308e+04
            Stop		  1.9724000306601814e+04
            Start		  2.1691625789135214e+04
            Stop		  2.2558531243849582e+04
            Start		  2.4526156889467569e+04
            Stop		  2.5393061711777558e+04
            Start		  2.7360687092866836e+04
            Stop		  2.8227592648611735e+04
            Start		  3.0195218311369201e+04
            Stop		  3.1062123123412199e+04
            Start		  3.3029748474968910e+04
            Stop		  3.3896654060391826e+04
            Start		  3.5864279731872259e+04
            Stop		  3.6731184537818997e+04
            Start		  3.8698809881718415e+04
            Stop		  3.9565715475299105e+04
            Start		  4.1533341150704589e+04
            Stop		  4.2400245954119207e+04
            Start		  4.4367871295428762e+04
            Stop		  4.5234776892341433e+04
            Start		  4.7202402567883226e+04
            Stop		  4.8069307372226438e+04
            Start		  5.0036932710466674e+04
            Stop		  5.0903838311298547e+04
            Start		  5.2871463983712056e+04
            Stop		  5.3738368792115070e+04
            Start		  5.5705994125346217e+04
            Stop		  5.6572899731995982e+04
            Start		  5.8540525398729304e+04
            Stop		  5.9407430213574436e+04
            Start		  6.1375055540055779e+04
            Stop		  6.2241961154082273e+04
            Start		  6.4209586813614122e+04
            Stop		  6.5076491636162318e+04
            Start		  6.7044116955091697e+04
            Stop		  6.7911022577006297e+04
            Start		  6.9878648229068538e+04
            Stop		  7.0745553059254278e+04
            Start		  7.2713178371051719e+04
            Stop		  7.3580084000085233e+04
            Start		  7.5547709645695693e+04
            Stop		  7.6414614482142963e+04
            Start		  7.8382239788425330e+04
            Stop		  7.9249145422614136e+04
            Start		  8.1216771063894907e+04
            Stop		  8.2083675904158066e+04
            Start		  8.4051301207473763e+04
            Stop		  8.4918206843985245e+04
            Strand		 30 52
            Start		  1.3774968234368228e+03
            Stop		  2.2443838262508220e+03
            Start		  4.2120266885488372e+03
            Stop		  5.0789144247567974e+03
            Start		  7.0465595615152579e+03
            Stop		  7.9134453725279373e+03
            Start		  9.8810919663782734e+03
            Stop		  1.0747975919424200e+04
            Start		  1.2715621716870328e+04
            Stop		  1.3582506859696039e+04
            Start		  1.5550153381502383e+04
            Stop		  1.6417037363361706e+04
            Start		  1.8384683381722003e+04
            Stop		  1.9251568303451331e+04
            Start		  2.1219214796435575e+04
            Stop		  2.2086098793038171e+04
            Start		  2.4053744879954382e+04
            Stop		  2.4920629733415255e+04
            Start		  2.6888276211874967e+04
            Stop		  2.7755160218373901e+04
            Start		  2.9722806323425350e+04
            Stop		  3.0589691158767153e+04
            Start		  3.2557337628436017e+04
            Stop		  3.3424221641972974e+04
            Start		  3.5391867749830781e+04
            Stop		  3.6258752582038687e+04
            Start		  3.8226399046541526e+04
            Stop		  3.9093283064231000e+04
            Start		  4.1060929171796080e+04
            Stop		  4.1927814003676191e+04
            Start		  4.3895460466346784e+04
            Stop		  4.4762344484963513e+04
            Start		  4.6729990593410563e+04
            Stop		  4.7596875423602680e+04
            Start		  4.9564521887712108e+04
            Stop		  5.0431405903983868e+04
            Start		  5.2399052015743138e+04
            Stop		  5.3265936841771581e+04
            Start		  5.5233583310226924e+04
            Stop		  5.6100467321314667e+04
            Start		  5.8068113438718756e+04
            Stop		  5.8934998258353364e+04
            Start		  6.0902644733281079e+04
            Stop		  6.1769528737242697e+04
            Start		  6.3737174861813568e+04
            Stop		  6.4604059673764874e+04
            Start		  6.6571706156170709e+04
            Stop		  6.7438590152288671e+04
            Start		  6.9406236284371727e+04
            Stop		  7.0273121088616492e+04
            Start		  7.2240767578220722e+04
            Stop		  7.3107651567123146e+04
            Start		  7.5075297705793710e+04
            Stop		  7.5942182503612363e+04
            Start		  7.7909828998901838e+04
            Stop		  7.8776712982452125e+04
            Start		  8.0744359125665345e+04
            Stop		  8.1611243919430402e+04
            Start		  8.3578890417922637e+04
            Stop		  8.4445774398895199e+04
            Strand		 30 53
            Strand		 30 54
            Strand		 30 55
            Strand		 30 56
            Start		  0.0000000000000000e+00
            Stop		  4.3773298654501087e+02
            Start		  2.0818326277221113e+03
            Stop		  3.2722634434774845e+03
            Start		  4.9163631790746376e+03
            Stop		  6.1067941585913168e+03
            Start		  7.7508938912125523e+03
            Stop		  8.9413248708084211e+03
            Start		  1.0585424603709725e+04
            Stop		  1.1775855582267079e+04
            Start		  1.3419955316921294e+04
            Stop		  1.4610386292767016e+04
            Start		  1.6254486030655882e+04
            Stop		  1.7444917002272017e+04
            Start		  1.9089016744725712e+04
            Stop		  2.0279447710783403e+04
            Start		  2.1923547458926932e+04
            Stop		  2.3113978418346363e+04
            Start		  2.4758078173049886e+04
            Stop		  2.5948509125047833e+04
            Start		  2.7592608886888345e+04
            Stop		  2.8783039831012604e+04
            Start		  3.0427139600248567e+04
            Stop		  3.1617570536397867e+04
            Start		  3.3261670312957780e+04
            Stop		  3.4452101241386270e+04
            Start		  3.6096201024871749e+04
            Stop		  3.7286631946177957e+04
            Start		  3.8930731735881207e+04
            Stop		  4.0121162650981722e+04
            Start		  4.1765262445916524e+04
            Stop		  4.2955693356005890e+04
            Start		  4.4599793154950836e+04
            Stop		  4.5790224061449124e+04
            Start		  4.7434323863001249e+04
            Stop		  4.8624754767491722e+04
            Start		  5.0268854570128024e+04
            Stop		  5.1459285474287695e+04
            Start		  5.3103385276431945e+04
            Stop		  5.4293816181958064e+04
            Start		  5.5937915982049963e+04
            Stop		  5.7128346890585402e+04
            Start		  5.8772446687149109e+04
            Stop		  5.9962877600210355e+04
            Start		  6.1606977391919165e+04
            Stop		  6.2797408310829764e+04
            Start		  6.4441508096564408e+04
            Stop		  6.5631939022396895e+04
            Start		  6.7276038801294460e+04
            Stop		  6.8466469734823331e+04
            Start		  7.0110569506315311e+04
            Stop		  7.1301000447983053e+04
            Start		  7.2945100211820158e+04
            Stop		  7.4135531161717881e+04
            Start		  7.5779630917980860e+04
            Stop		  7.6970061875844360e+04
            Start		  7.8614161624940534e+04
            Stop		  7.9804592590161905e+04
            Start		  8.1448692332807157e+04
            Stop		  8.2639123304461551e+04
            Start		  8.4283223041648860e+04
            Stop		  8.5473654018535206e+04
            Strand		 30 57
            Strand		 30 58
            Strand		 30 59
            Strand		 30 60
            Strand		 30 61
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 30 62
            Strand		 30 63
            Strand		 30 64
            Strand		 30 65
            Strand		 30 67
            Strand		 30 68
            Strand		 30 69
            Strand		 30 70
            Strand		 30 71
            Strand		 31 36
            Strand		 31 37
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 31 38
            Strand		 31 39
            Strand		 31 40
            Strand		 31 41
            Strand		 31 42
            Start		  0.0000000000000000e+00
            Stop		  1.0676277869070507e+03
            Start		  2.7117289142723594e+03
            Stop		  3.9021584326000857e+03
            Start		  5.5462596023371780e+03
            Stop		  6.7366891460072648e+03
            Start		  8.3807903076398070e+03
            Stop		  9.5712198574606391e+03
            Start		  1.1215321012428953e+04
            Stop		  1.2405750569899530e+04
            Start		  1.4049851717576556e+04
            Stop		  1.5240281283037164e+04
            Start		  1.6884382423238363e+04
            Stop		  1.8074811996718250e+04
            Start		  1.9718913129583387e+04
            Stop		  2.0909342710755456e+04
            Start		  2.2553443836748917e+04
            Stop		  2.3743873424946090e+04
            Start		  2.5387974544836288e+04
            Stop		  2.6578404139080689e+04
            Start		  2.8222505253906318e+04
            Stop		  2.9412934852952229e+04
            Start		  3.1057035963976636e+04
            Stop		  3.2247465566365223e+04
            Start		  3.3891566675020957e+04
            Stop		  3.5081996279144259e+04
            Start		  3.6726097386970199e+04
            Stop		  3.7916526991141807e+04
            Start		  3.9560628099715512e+04
            Stop		  4.0751057702244543e+04
            Start		  4.2395158813113099e+04
            Stop		  4.3585588412378456e+04
            Start		  4.5229689526990471e+04
            Stop		  4.6420119121512027e+04
            Start		  4.8064220241154064e+04
            Stop		  4.9254649829657719e+04
            Start		  5.0898750955397765e+04
            Stop		  5.2089180536871238e+04
            Start		  5.3733281669511860e+04
            Stop		  5.4923711243249294e+04
            Start		  5.6567812383292323e+04
            Stop		  5.7758241948925213e+04
            Start		  5.9402343096549819e+04
            Stop		  6.0592772654063156e+04
            Start		  6.2236873809117875e+04
            Stop		  6.3427303358850877e+04
            Start		  6.5071404520860327e+04
            Stop		  6.6261834063491493e+04
            Start		  6.7905935231677242e+04
            Stop		  6.9096364768194559e+04
            Start		  7.0740465941509246e+04
            Stop		  7.1930895473166849e+04
            Start		  7.3574996650340297e+04
            Stop		  7.4765426178603244e+04
            Start		  7.6409527358198204e+04
            Stop		  7.7599956884678395e+04
            Start		  7.9244058065153513e+04
            Stop		  8.0434487591538709e+04
            Start		  8.2078588771316397e+04
            Stop		  8.3269018299296135e+04
            Start		  8.4913119476831780e+04
            Stop		  8.6103549008023270e+04
            Strand		 31 43
            Strand		 31 44
            Strand		 31 45
            Strand		 31 46
            Strand		 31 47
            Strand		 31 48
            Strand		 31 49
            Strand		 31 50
            Strand		 31 51
            Strand		 31 52
            Start		  9.0506723982538711e+02
            Stop		  1.7719764927928127e+03
            Start		  3.7395980737482296e+03
            Stop		  4.6065029513352183e+03
            Start		  6.5741285115677783e+03
            Stop		  7.4410335625794169e+03
            Start		  9.4086564666035938e+03
            Stop		  1.0275564569747221e+04
            Start		  1.2243187383796059e+04
            Stop		  1.3110095173611182e+04
            Start		  1.5077719288165772e+04
            Stop		  1.5944626124197075e+04
            Start		  1.7912251896221929e+04
            Stop		  1.8779156681906399e+04
            Start		  2.0746781592876901e+04
            Stop		  2.1613687620098946e+04
            Start		  2.3581313319064113e+04
            Stop		  2.4448218124584044e+04
            Start		  2.6415843314882648e+04
            Stop		  2.7282749061444116e+04
            Start		  2.9250374741143522e+04
            Stop		  3.0117279548298720e+04
            Start		  3.2084904836120517e+04
            Stop		  3.2951810485202179e+04
            Start		  3.4919436161902318e+04
            Stop		  3.5786340966542637e+04
            Start		  3.7753966289148804e+04
            Stop		  3.8620871903908446e+04
            Start		  4.0588497581018797e+04
            Stop		  4.1455402383926979e+04
            Start		  4.3423027718357902e+04
            Stop		  4.4289933322010234e+04
            Start		  4.6257558998458888e+04
            Stop		  4.7124463802189690e+04
            Start		  4.9092089138661962e+04
            Stop		  4.9958994741117647e+04
            Start		  5.1926620414480538e+04
            Stop		  5.2793525221941149e+04
            Start		  5.4761150555351152e+04
            Stop		  5.5628056161695924e+04
            Start		  5.7595681829588284e+04
            Stop		  5.8462586643213464e+04
            Start		  6.0430211970643504e+04
            Stop		  6.1297117583634485e+04
            Start		  6.3264743244445453e+04
            Stop		  6.4131648065669324e+04
            Start		  6.6099273385775436e+04
            Stop		  6.6966179006480612e+04
            Start		  6.8933804659758956e+04
            Stop		  6.9800709488731052e+04
            Start		  7.1768334801606310e+04
            Stop		  7.2635240429589103e+04
            Start		  7.4602866076156351e+04
            Stop		  7.5469770911704501e+04
            Start		  7.7437396218740032e+04
            Stop		  7.8304301852257762e+04
            Start		  8.0271927494076852e+04
            Stop		  8.1138832333907165e+04
            Start		  8.3106457637509942e+04
            Stop		  8.3973363273857161e+04
            Start		  8.5940988913695066e+04
            Stop		  8.6400000000000000e+04
            Strand		 31 53
            Start		  4.3265627191516035e+02
            Stop		  1.2995405894240359e+03
            Start		  3.2671854739910250e+03
            Stop		  4.1340717898034791e+03
            Start		  6.1017176889265293e+03
            Stop		  6.9686018635496621e+03
            Start		  8.9362472014451505e+03
            Stop		  9.8031328472151254e+03
            Start		  1.1770779104722216e+04
            Stop		  1.2637663168042327e+04
            Start		  1.4605307625124919e+04
            Stop		  1.5472194113356376e+04
            Start		  1.7439840519768859e+04
            Stop		  1.8306724541066545e+04
            Start		  2.0274370957499828e+04
            Stop		  2.1141255481914472e+04
            Start		  2.3108901934815640e+04
            Stop		  2.3975785946364562e+04
            Start		  2.5943432162838475e+04
            Stop		  2.6810316886870674e+04
            Start		  2.8777963350574908e+04
            Stop		  2.9644847363467379e+04
            Start		  3.1612493510051536e+04
            Stop		  3.2479378303802565e+04
            Start		  3.4447024767618146e+04
            Stop		  3.5313908784119143e+04
            Start		  3.7281554905058438e+04
            Stop		  3.8148439724009200e+04
            Start		  4.0116086186288223e+04
            Stop		  4.0982970205066791e+04
            Start		  4.2950616317038184e+04
            Stop		  4.3817501144258276e+04
            Start		  4.5785147606643630e+04
            Stop		  4.6652031624966963e+04
            Start		  4.8619677735669466e+04
            Stop		  4.9486562563320214e+04
            Start		  5.1454209028449543e+04
            Stop		  5.2321093043317960e+04
            Start		  5.4288739157203745e+04
            Stop		  5.5155623980837678e+04
            Start		  5.7123270451219010e+04
            Stop		  5.7990154460106496e+04
            Start		  5.9957800579940733e+04
            Stop		  6.0824685396941786e+04
            Start		  6.2792331874297670e+04
            Stop		  6.3659215875663213e+04
            Start		  6.5626862002814931e+04
            Stop		  6.6493746812081925e+04
            Start		  6.8461393296977534e+04
            Stop		  6.9328277290556623e+04
            Start		  7.1295923425015979e+04
            Stop		  7.2162808226898836e+04
            Start		  7.4130454718619818e+04
            Stop		  7.4997338705478222e+04
            Start		  7.6964984845942716e+04
            Stop		  7.7831869642097197e+04
            Start		  7.9799516138766208e+04
            Stop		  8.0666400121116982e+04
            Start		  8.2634046265245895e+04
            Stop		  8.3500931058317758e+04
            Start		  8.5468577557218174e+04
            Stop		  8.6335461059017805e+04
            Strand		 31 54
            Strand		 31 55
            Strand		 31 56
            Strand		 31 57
            Start		  1.1369934904327233e+03
            Stop		  2.3274200121590879e+03
            Start		  3.9715196809463273e+03
            Stop		  5.1619505831917641e+03
            Start		  6.8060503195906367e+03
            Stop		  7.9964813003559893e+03
            Start		  9.6405810328358893e+03
            Stop		  1.0831012011873443e+04
            Start		  1.2475111745781598e+04
            Stop		  1.3665542722710265e+04
            Start		  1.5309642459364166e+04
            Stop		  1.6500073432548379e+04
            Start		  1.8144173173344207e+04
            Stop		  1.9334604141388107e+04
            Start		  2.0978703887524855e+04
            Stop		  2.2169134849259557e+04
            Start		  2.3813234601697164e+04
            Stop		  2.5003665556236087e+04
            Start		  2.6647765315652778e+04
            Stop		  2.7838196262430436e+04
            Start		  2.9482296029192803e+04
            Stop		  3.0672726967989660e+04
            Start		  3.2316826742136596e+04
            Stop		  3.3507257673088803e+04
            Start		  3.5151357454329649e+04
            Stop		  3.6341788377923098e+04
            Start		  3.7985888165650395e+04
            Stop		  3.9176319082699491e+04
            Start		  4.0820418876015559e+04
            Stop		  4.2010849787627456e+04
            Start		  4.3654949585383802e+04
            Stop		  4.4845380492909877e+04
            Start		  4.6489480293757588e+04
            Stop		  4.7679911198734131e+04
            Start		  4.9324011001182953e+04
            Stop		  5.0514441905263790e+04
            Start		  5.2158541707747623e+04
            Stop		  5.3348972612631522e+04
            Start		  5.4993072413577065e+04
            Stop		  5.6183503320933225e+04
            Start		  5.7827603118829058e+04
            Stop		  5.9018034030223796e+04
            Start		  6.0662133823686643e+04
            Stop		  6.1852564740514797e+04
            Start		  6.3496664528350266e+04
            Stop		  6.4687095451773836e+04
            Start		  6.6331195233028760e+04
            Stop		  6.7521626163926077e+04
            Start		  6.9165725937930401e+04
            Stop		  7.0356156876857509e+04
            Start		  7.2000256643253626e+04
            Stop		  7.3190687590419941e+04
            Start		  7.4834787349178237e+04
            Stop		  7.6025218304437469e+04
            Start		  7.7669318055857773e+04
            Stop		  7.8859749018714341e+04
            Start		  8.0503848763412447e+04
            Stop		  8.1694279733043295e+04
            Start		  8.3338379471924156e+04
            Stop		  8.4528810447214972e+04
            Start		  8.6172910181432686e+04
            Stop		  8.6400000000000000e+04
            Strand		 31 58
            Strand		 31 59
            Strand		 31 60
            Strand		 31 61
            Strand		 31 62
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 31 63
            Strand		 31 64
            Strand		 31 65
            Strand		 31 66
            Strand		 31 68
            Strand		 31 69
            Strand		 31 70
            Strand		 31 71
            Strand		 32 36
            Strand		 32 37
            Strand		 32 38
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 32 39
            Strand		 32 40
            Strand		 32 41
            Strand		 32 42
            Strand		 32 43
            Start		  0.0000000000000000e+00
            Stop		  1.2278396490379065e+02
            Start		  1.7668853050999353e+03
            Stop		  2.9573148792436209e+03
            Start		  4.6014160379006144e+03
            Stop		  5.7918455748604265e+03
            Start		  7.4359467392225961e+03
            Stop		  8.6263762868724207e+03
            Start		  1.0270477444138447e+04
            Stop		  1.1460906999001134e+04
            Start		  1.3105008149145755e+04
            Stop		  1.4295437711922312e+04
            Start		  1.5939538854616223e+04
            Stop		  1.7129968425442017e+04
            Start		  1.8774069560716638e+04
            Stop		  1.9964499139382438e+04
            Start		  2.1608600267595513e+04
            Stop		  2.2799029853545060e+04
            Start		  2.4443130975366785e+04
            Stop		  2.5633560567721641e+04
            Start		  2.7277661684105129e+04
            Stop		  2.8468091281703346e+04
            Start		  3.0112192393842775e+04
            Stop		  3.1302621995289832e+04
            Start		  3.2946723104568038e+04
            Stop		  3.4137152708298119e+04
            Start		  3.5781253816225850e+04
            Stop		  3.6971683420570553e+04
            Start		  3.8615784528720178e+04
            Stop		  3.9806214131981804e+04
            Start		  4.1450315241918222e+04
            Stop		  4.2640744842444285e+04
            Start		  4.4284845955656303e+04
            Stop		  4.5475275551912120e+04
            Start		  4.7119376669746976e+04
            Stop		  4.8309806260383019e+04
            Start		  4.9953907383987280e+04
            Stop		  5.1144336967898475e+04
            Start		  5.2788438098167702e+04
            Stop		  5.3978867674541892e+04
            Start		  5.5622968812081323e+04
            Stop		  5.6813398380435014e+04
            Start		  5.8457499525532934e+04
            Stop		  5.9647929085732423e+04
            Start		  6.1292030238347565e+04
            Stop		  6.2482459790614885e+04
            Start		  6.4126560950378203e+04
            Stop		  6.5316990495281396e+04
            Start		  6.6961091661512299e+04
            Stop		  6.8151521199940340e+04
            Start		  6.9795622371676553e+04
            Stop		  7.0986051904800421e+04
            Start		  7.2630153080840333e+04
            Stop		  7.3820582610061596e+04
            Start		  7.5464683789016839e+04
            Stop		  7.6655113315906012e+04
            Start		  7.8299214496262663e+04
            Stop		  7.9489644022490364e+04
            Start		  8.1133745202675200e+04
            Stop		  8.2324174729938633e+04
            Start		  8.3968275908388416e+04
            Stop		  8.5158705438337071e+04
            Strand		 32 44
            Strand		 32 45
            Strand		 32 46
            Strand		 32 47
            Strand		 32 48
            Start		  0.0000000000000000e+00
            Stop		  3.5469709046045790e+02
            Start		  2.3223434113167518e+03
            Stop		  3.1892274503822987e+03
            Start		  5.1568742408756007e+03
            Stop		  6.0237583918384207e+03
            Start		  7.9914048277865377e+03
            Stop		  8.8582888324215892e+03
            Start		  1.0825935183862654e+04
            Stop		  1.1692819771901206e+04
            Start		  1.3660466243163486e+04
            Stop		  1.4527350240193167e+04
            Start		  1.6494996443962420e+04
            Stop		  1.7361881180057921e+04
            Start		  1.9329527658095671e+04
            Stop		  2.0196411657882032e+04
            Start		  2.2164057807868561e+04
            Stop		  2.3030942598176145e+04
            Start		  2.4998589073295741e+04
            Stop		  2.5865473079265048e+04
            Start		  2.7833119206591135e+04
            Stop		  2.8700004019693581e+04
            Start		  3.0667650489425920e+04
            Stop		  3.1534534501720416e+04
            Start		  3.3502180617811704e+04
            Stop		  3.4369065441933017e+04
            Start		  3.6336711906985576e+04
            Stop		  3.7203595923899644e+04
            Start		  3.9171242034353047e+04
            Stop		  4.0038126863578931e+04
            Start		  4.2005773326225353e+04
            Stop		  4.2872657344990912e+04
            Start		  4.4840303453824170e+04
            Stop		  4.5707188283911266e+04
            Start		  4.7674834747103996e+04
            Stop		  4.8541718764533500e+04
            Start		  5.0509364875211832e+04
            Stop		  5.1376249702600879e+04
            Start		  5.3343896169295527e+04
            Stop		  5.4210780182389353e+04
            Start		  5.6178426297793514e+04
            Stop		  5.7045311119657708e+04
            Start		  5.9012957592245926e+04
            Stop		  5.9879841598730949e+04
            Start		  6.1847487720845449e+04
            Stop		  6.2714372535392911e+04
            Start		  6.4682019015269398e+04
            Stop		  6.5548903013999574e+04
            Start		  6.7516549143630516e+04
            Stop		  6.8383433950353050e+04
            Start		  7.0351080437667522e+04
            Stop		  7.1217964428824620e+04
            Start		  7.3185610565480427e+04
            Stop		  7.4052495365220981e+04
            Start		  7.6020141858850518e+04
            Stop		  7.6887025843912998e+04
            Start		  7.8854671985896915e+04
            Stop		  7.9721556780696046e+04
            Start		  8.1689203278439847e+04
            Stop		  8.2556087259925829e+04
            Start		  8.4523733404633240e+04
            Stop		  8.5390618197372096e+04
            Strand		 32 49
            Strand		 32 50
            Strand		 32 51
            Strand		 32 52
            Strand		 32 53
            Start		  0.0000000000000000e+00
            Stop		  8.2712851224968972e+02
            Start		  2.7947528644104677e+03
            Stop		  3.6616638197711854e+03
            Start		  5.6292811179053288e+03
            Stop		  6.4961901731934540e+03
            Start		  8.4638122550587123e+03
            Stop		  9.3307207878762802e+03
            Start		  1.1298344166273617e+04
            Stop		  1.2165251765607731e+04
            Start		  1.4132873023793612e+04
            Stop		  1.4999782359320570e+04
            Start		  1.6967406855755344e+04
            Stop		  1.7834313302217201e+04
            Start		  1.9801939037211796e+04
            Stop		  2.0668843834001585e+04
            Start		  2.2636468879919608e+04
            Stop		  2.3503374771376730e+04
            Start		  2.5471000459873358e+04
            Stop		  2.6337905267204525e+04
            Start		  2.8305530504294991e+04
            Stop		  2.9172436204009307e+04
            Start		  3.1140061881564539e+04
            Stop		  3.2006966688080804e+04
            Start		  3.3974591992467336e+04
            Stop		  3.4841497625102704e+04
            Start		  3.6809123301798121e+04
            Stop		  3.7676028105673387e+04
            Start		  3.9643653434114174e+04
            Stop		  4.0510559043256006e+04
            Start		  4.2478184720344791e+04
            Stop		  4.3345089523213566e+04
            Start		  4.5312714859185631e+04
            Stop		  4.6179620461571227e+04
            Start		  4.8147246137269845e+04
            Stop		  4.9014150941933534e+04
            Start		  5.0981776277851532e+04
            Stop		  5.1848681881146440e+04
            Start		  5.3816307552920829e+04
            Stop		  5.4683212362207654e+04
            Start		  5.6650837693876303e+04
            Stop		  5.7517743302208815e+04
            Start		  5.9485368967866641e+04
            Stop		  6.0352273783925659e+04
            Start		  6.2319899108994388e+04
            Stop		  6.3186804724511880e+04
            Start		  6.5154430382798833e+04
            Stop		  6.6021335206655785e+04
            Start		  6.7988960524274284e+04
            Stop		  6.8855866147522509e+04
            Start		  7.0823491798411196e+04
            Stop		  7.1690396629767216e+04
            Start		  7.3658021940484148e+04
            Stop		  7.4524927570561325e+04
            Start		  7.6492553215279375e+04
            Stop		  7.7359458052555317e+04
            Start		  7.9327083358140357e+04
            Stop		  8.0193988992936414e+04
            Start		  8.2161614633760822e+04
            Stop		  8.3028519474369241e+04
            Start		  8.4996144777478286e+04
            Stop		  8.5863050414068770e+04
            Strand		 32 54
            Strand		 32 55
            Strand		 32 56
            Strand		 32 57
            Strand		 32 58
            Start		  1.9214823493422440e+02
            Stop		  1.3825765884783798e+03
            Start		  3.0266762319555050e+03
            Stop		  4.2171070168723882e+03
            Start		  5.8612067500396888e+03
            Stop		  7.0516377293370224e+03
            Start		  8.6957374619410421e+03
            Stop		  9.8861684414004339e+03
            Start		  1.1530268174712121e+04
            Stop		  1.2720699152542365e+04
            Start		  1.4364798888116798e+04
            Stop		  1.5555229862713435e+04
            Start		  1.7199329601985086e+04
            Stop		  1.8389760571884879e+04
            Start		  2.0033860316121845e+04
            Stop		  2.1224291280072975e+04
            Start		  2.2868391030320290e+04
            Stop		  2.4058821987337145e+04
            Start		  2.5702921744370891e+04
            Stop		  2.6893352693777459e+04
            Start		  2.8537452458070587e+04
            Stop		  2.9727883399530172e+04
            Start		  3.1371983171231728e+04
            Stop		  3.2562414104761821e+04
            Start		  3.4206513883690284e+04
            Stop		  3.5396944809661793e+04
            Start		  3.7041044595313040e+04
            Stop		  3.8231475514434147e+04
            Start		  3.9875575306003440e+04
            Stop		  4.1066006219288531e+04
            Start		  4.2710106015705911e+04
            Stop		  4.3900536924431028e+04
            Start		  4.5544636724408192e+04
            Stop		  4.6735067630055171e+04
            Start		  4.8379167432141963e+04
            Stop		  4.9569598336333300e+04
            Start		  5.1213698138981352e+04
            Stop		  5.2404129043409113e+04
            Start		  5.4048228845039797e+04
            Stop		  5.5238659751391293e+04
            Start		  5.6882759550465038e+04
            Stop		  5.8073190460348778e+04
            Start		  5.9717290255432490e+04
            Stop		  6.0907721170307741e+04
            Start		  6.2551820960137797e+04
            Stop		  6.3742251881250362e+04
            Start		  6.5386351664787981e+04
            Stop		  6.6576782593115684e+04
            Start		  6.8220882369592509e+04
            Stop		  6.9411313305802309e+04
            Start		  7.1055413074754135e+04
            Stop		  7.2245844019172699e+04
            Start		  7.3889943780459769e+04
            Stop		  7.5080374733059507e+04
            Start		  7.6724474486872539e+04
            Stop		  7.7914905447272540e+04
            Start		  7.9559005194124416e+04
            Stop		  8.0749436161607489e+04
            Start		  8.2393535902310570e+04
            Stop		  8.3583966875854632e+04
            Start		  8.5228066611485076e+04
            Stop		  8.6400000000000000e+04
            Strand		 32 59
            Strand		 32 60
            Strand		 32 61
            Strand		 32 62
            Strand		 32 63
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 32 64
            Strand		 32 65
            Strand		 32 66
            Strand		 32 67
            Strand		 32 69
            Strand		 32 70
            Strand		 32 71
            Strand		 33 36
            Strand		 33 37
            Strand		 33 38
            Strand		 33 39
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 33 40
            Strand		 33 41
            Strand		 33 42
            Strand		 33 43
            Strand		 33 44
            Start		  8.2204588669137297e+02
            Stop		  2.0124714059944540e+03
            Start		  3.6565724999424938e+03
            Stop		  4.8470020014042702e+03
            Start		  6.4911031702852124e+03
            Stop		  7.6815327165059807e+03
            Start		  9.3256338759043447e+03
            Stop		  1.0516063428180496e+04
            Start		  1.2160164580764244e+04
            Stop		  1.3350594140874720e+04
            Start		  1.4994695286064434e+04
            Stop		  1.6185124854212649e+04
            Start		  1.7829225991936681e+04
            Stop		  1.9019655568034199e+04
            Start		  2.0663756698541591e+04
            Stop		  2.1854186282145587e+04
            Start		  2.3498287406005071e+04
            Stop		  2.4688716996340874e+04
            Start		  2.6332818114415335e+04
            Stop		  2.7523247710410404e+04
            Start		  2.9167348823819011e+04
            Stop		  3.0357778424149998e+04
            Start		  3.2001879534219068e+04
            Stop		  3.3192309137369943e+04
            Start		  3.4836410245574756e+04
            Stop		  3.6026839849903306e+04
            Start		  3.7670940957803286e+04
            Stop		  3.8861370561613323e+04
            Start		  4.0505471670783561e+04
            Stop		  4.1695901272399286e+04
            Start		  4.3340002384361454e+04
            Stop		  4.4530431982201088e+04
            Start		  4.6174533098356536e+04
            Stop		  4.7364962691001812e+04
            Start		  4.9009063812570108e+04
            Stop		  5.0199493398828497e+04
            Start		  5.1843594526793808e+04
            Stop		  5.3034024105750868e+04
            Start		  5.4678125240818816e+04
            Stop		  5.5868554811878421e+04
            Start		  5.7512655954445036e+04
            Stop		  5.8703085517355430e+04
            Start		  6.0347186667489848e+04
            Stop		  6.1537616222354874e+04
            Start		  6.3181717379796173e+04
            Stop		  6.4372146927070455e+04
            Start		  6.6016248091239249e+04
            Stop		  6.7206677631708531e+04
            Start		  6.8850778801732347e+04
            Stop		  7.0041208336478769e+04
            Start		  7.1685309511230342e+04
            Stop		  7.2875739041584937e+04
            Start		  7.4519840219731748e+04
            Stop		  7.5710269747216109e+04
            Start		  7.7354370927278913e+04
            Stop		  7.8544800453538293e+04
            Start		  8.0188901633956018e+04
            Stop		  8.1379331160687070e+04
            Start		  8.3023432339885432e+04
            Stop		  8.4213861868761742e+04
            Start		  8.5857963045222306e+04
            Stop		  8.6400000000000000e+04
            Strand		 33 45
            Strand		 33 46
            Strand		 33 47
            Strand		 33 48
            Start		  1.8499065193291774e+03
            Stop		  2.7168163266377542e+03
            Start		  4.6844418886183776e+03
            Stop		  5.5513477424660741e+03
            Start		  7.5189726208863303e+03
            Stop		  8.3858775786833012e+03
            Start		  1.0353501506910608e+04
            Stop		  1.1220408533233211e+04
            Start		  1.3188034043660909e+04
            Stop		  1.4054938919496955e+04
            Start		  1.6022564727575060e+04
            Stop		  1.6889469859052952e+04
            Start		  1.8857095466679308e+04
            Stop		  1.9724000306601814e+04
            Start		  2.1691625789135214e+04
            Stop		  2.2558531243849582e+04
            Start		  2.4526156889467569e+04
            Stop		  2.5393061711777555e+04
            Start		  2.7360687092866836e+04
            Stop		  2.8227592648611731e+04
            Start		  3.0195218311369197e+04
            Stop		  3.1062123123412199e+04
            Start		  3.3029748474968903e+04
            Stop		  3.3896654060391833e+04
            Start		  3.5864279731872251e+04
            Stop		  3.6731184537819005e+04
            Start		  3.8698809881718415e+04
            Stop		  3.9565715475299105e+04
            Start		  4.1533341150704589e+04
            Stop		  4.2400245954119215e+04
            Start		  4.4367871295428755e+04
            Stop		  4.5234776892341441e+04
            Start		  4.7202402567883233e+04
            Stop		  4.8069307372226445e+04
            Start		  5.0036932710466681e+04
            Stop		  5.0903838311298554e+04
            Start		  5.2871463983712063e+04
            Stop		  5.3738368792115063e+04
            Start		  5.5705994125346209e+04
            Stop		  5.6572899731995989e+04
            Start		  5.8540525398729304e+04
            Stop		  5.9407430213574436e+04
            Start		  6.1375055540055771e+04
            Stop		  6.2241961154082273e+04
            Start		  6.4209586813614107e+04
            Stop		  6.5076491636162333e+04
            Start		  6.7044116955091667e+04
            Stop		  6.7911022577006283e+04
            Start		  6.9878648229068553e+04
            Stop		  7.0745553059254264e+04
            Start		  7.2713178371051705e+04
            Stop		  7.3580084000085233e+04
            Start		  7.5547709645695693e+04
            Stop		  7.6414614482142963e+04
            Start		  7.8382239788425330e+04
            Stop		  7.9249145422614136e+04
            Start		  8.1216771063894907e+04
            Stop		  8.2083675904158066e+04
            Start		  8.4051301207473734e+04
            Stop		  8.4918206843985245e+04
            Strand		 33 49
            Start		  1.3774968234368209e+03
            Stop		  2.2443838262508211e+03
            Start		  4.2120266885488363e+03
            Stop		  5.0789144247567920e+03
            Start		  7.0465595615152588e+03
            Stop		  7.9134453725279336e+03
            Start		  9.8810919663782752e+03
            Stop		  1.0747975919424194e+04
            Start		  1.2715621716870337e+04
            Stop		  1.3582506859696037e+04
            Start		  1.5550153381502381e+04
            Stop		  1.6417037363361709e+04
            Start		  1.8384683381722010e+04
            Stop		  1.9251568303451320e+04
            Start		  2.1219214796435568e+04
            Stop		  2.2086098793038171e+04
            Start		  2.4053744879954382e+04
            Stop		  2.4920629733415259e+04
            Start		  2.6888276211874971e+04
            Stop		  2.7755160218373894e+04
            Start		  2.9722806323425353e+04
            Stop		  3.0589691158767153e+04
            Start		  3.2557337628436024e+04
            Stop		  3.3424221641972981e+04
            Start		  3.5391867749830788e+04
            Stop		  3.6258752582038687e+04
            Start		  3.8226399046541526e+04
            Stop		  3.9093283064231022e+04
            Start		  4.1060929171796080e+04
            Stop		  4.1927814003676198e+04
            Start		  4.3895460466346784e+04
            Stop		  4.4762344484963513e+04
            Start		  4.6729990593410570e+04
            Stop		  4.7596875423602680e+04
            Start		  4.9564521887712101e+04
            Stop		  5.0431405903983876e+04
            Start		  5.2399052015743138e+04
            Stop		  5.3265936841771581e+04
            Start		  5.5233583310226924e+04
            Stop		  5.6100467321314660e+04
            Start		  5.8068113438718749e+04
            Stop		  5.8934998258353364e+04
            Start		  6.0902644733281057e+04
            Stop		  6.1769528737242697e+04
            Start		  6.3737174861813561e+04
            Stop		  6.4604059673764888e+04
            Start		  6.6571706156170709e+04
            Stop		  6.7438590152288671e+04
            Start		  6.9406236284371727e+04
            Stop		  7.0273121088616492e+04
            Start		  7.2240767578220708e+04
            Stop		  7.3107651567123146e+04
            Start		  7.5075297705793710e+04
            Stop		  7.5942182503612363e+04
            Start		  7.7909828998901823e+04
            Stop		  7.8776712982452125e+04
            Start		  8.0744359125665345e+04
            Stop		  8.1611243919430402e+04
            Start		  8.3578890417922637e+04
            Stop		  8.4445774398895199e+04
            Strand		 33 50
            Strand		 33 51
            Strand		 33 52
            Strand		 33 53
            Strand		 33 54
            Strand		 33 55
            Strand		 33 56
            Strand		 33 57
            Strand		 33 58
            Strand		 33 59
            Start		  0.0000000000000000e+00
            Stop		  4.3773298654501212e+02
            Start		  2.0818326277221113e+03
            Stop		  3.2722634434774859e+03
            Start		  4.9163631790746413e+03
            Stop		  6.1067941585913122e+03
            Start		  7.7508938912125532e+03
            Stop		  8.9413248708084211e+03
            Start		  1.0585424603709725e+04
            Stop		  1.1775855582267079e+04
            Start		  1.3419955316921294e+04
            Stop		  1.4610386292767009e+04
            Start		  1.6254486030655886e+04
            Stop		  1.7444917002272014e+04
            Start		  1.9089016744725715e+04
            Stop		  2.0279447710783406e+04
            Start		  2.1923547458926940e+04
            Stop		  2.3113978418346360e+04
            Start		  2.4758078173049893e+04
            Stop		  2.5948509125047833e+04
            Start		  2.7592608886888345e+04
            Stop		  2.8783039831012615e+04
            Start		  3.0427139600248571e+04
            Stop		  3.1617570536397870e+04
            Start		  3.3261670312957765e+04
            Stop		  3.4452101241386263e+04
            Start		  3.6096201024871756e+04
            Stop		  3.7286631946177957e+04
            Start		  3.8930731735881207e+04
            Stop		  4.0121162650981722e+04
            Start		  4.1765262445916531e+04
            Stop		  4.2955693356005897e+04
            Start		  4.4599793154950843e+04
            Stop		  4.5790224061449131e+04
            Start		  4.7434323863001257e+04
            Stop		  4.8624754767491715e+04
            Start		  5.0268854570128016e+04
            Stop		  5.1459285474287717e+04
            Start		  5.3103385276431945e+04
            Stop		  5.4293816181958064e+04
            Start		  5.5937915982049963e+04
            Stop		  5.7128346890585395e+04
            Start		  5.8772446687149109e+04
            Stop		  5.9962877600210348e+04
            Start		  6.1606977391919172e+04
            Stop		  6.2797408310829727e+04
            Start		  6.4441508096564401e+04
            Stop		  6.5631939022396866e+04
            Start		  6.7276038801294446e+04
            Stop		  6.8466469734823317e+04
            Start		  7.0110569506315311e+04
            Stop		  7.1301000447983082e+04
            Start		  7.2945100211820158e+04
            Stop		  7.4135531161717881e+04
            Start		  7.5779630917980860e+04
            Stop		  7.6970061875844360e+04
            Start		  7.8614161624940549e+04
            Stop		  7.9804592590161905e+04
            Start		  8.1448692332807157e+04
            Stop		  8.2639123304461551e+04
            Start		  8.4283223041648860e+04
            Stop		  8.5473654018535191e+04
            Strand		 33 60
            Strand		 33 61
            Strand		 33 62
            Strand		 33 63
            Strand		 33 64
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 33 65
            Strand		 33 66
            Strand		 33 67
            Strand		 33 68
            Strand		 33 70
            Strand		 33 71
            Strand		 34 36
            Strand		 34 37
            Strand		 34 38
            Strand		 34 39
            Strand		 34 40
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 34 41
            Strand		 34 42
            Strand		 34 43
            Strand		 34 44
            Strand		 34 45
            Start		  0.0000000000000000e+00
            Stop		  1.0676277869070493e+03
            Start		  2.7117289142723589e+03
            Stop		  3.9021584326000852e+03
            Start		  5.5462596023371798e+03
            Stop		  6.7366891460072738e+03
            Start		  8.3807903076398125e+03
            Stop		  9.5712198574606409e+03
            Start		  1.1215321012428949e+04
            Stop		  1.2405750569899534e+04
            Start		  1.4049851717576557e+04
            Stop		  1.5240281283037166e+04
            Start		  1.6884382423238367e+04
            Stop		  1.8074811996718250e+04
            Start		  1.9718913129583383e+04
            Stop		  2.0909342710755460e+04
            Start		  2.2553443836748902e+04
            Stop		  2.3743873424946094e+04
            Start		  2.5387974544836281e+04
            Stop		  2.6578404139080685e+04
            Start		  2.8222505253906311e+04
            Stop		  2.9412934852952236e+04
            Start		  3.1057035963976639e+04
            Stop		  3.2247465566365223e+04
            Start		  3.3891566675020957e+04
            Stop		  3.5081996279144281e+04
            Start		  3.6726097386970192e+04
            Stop		  3.7916526991141815e+04
            Start		  3.9560628099715512e+04
            Stop		  4.0751057702244536e+04
            Start		  4.2395158813113099e+04
            Stop		  4.3585588412378442e+04
            Start		  4.5229689526990471e+04
            Stop		  4.6420119121512063e+04
            Start		  4.8064220241154078e+04
            Stop		  4.9254649829657705e+04
            Start		  5.0898750955397765e+04
            Stop		  5.2089180536871230e+04
            Start		  5.3733281669511853e+04
            Stop		  5.4923711243249301e+04
            Start		  5.6567812383292345e+04
            Stop		  5.7758241948925235e+04
            Start		  5.9402343096549805e+04
            Stop		  6.0592772654063134e+04
            Start		  6.2236873809117875e+04
            Stop		  6.3427303358850870e+04
            Start		  6.5071404520860306e+04
            Stop		  6.6261834063491493e+04
            Start		  6.7905935231677213e+04
            Stop		  6.9096364768194529e+04
            Start		  7.0740465941509232e+04
            Stop		  7.1930895473166820e+04
            Start		  7.3574996650340283e+04
            Stop		  7.4765426178603229e+04
            Start		  7.6409527358198189e+04
            Stop		  7.7599956884678380e+04
            Start		  7.9244058065153513e+04
            Stop		  8.0434487591538680e+04
            Start		  8.2078588771316383e+04
            Stop		  8.3269018299296135e+04
            Start		  8.4913119476831795e+04
            Stop		  8.6103549008023256e+04
            Strand		 34 46
            Strand		 34 47
            Strand		 34 48
            Strand		 34 49
            Start		  9.0506723982538665e+02
            Stop		  1.7719764927928125e+03
            Start		  3.7395980737482314e+03
            Stop		  4.6065029513352183e+03
            Start		  6.5741285115677802e+03
            Stop		  7.4410335625794160e+03
            Start		  9.4086564666035920e+03
            Stop		  1.0275564569747219e+04
            Start		  1.2243187383796059e+04
            Stop		  1.3110095173611182e+04
            Start		  1.5077719288165779e+04
            Stop		  1.5944626124197071e+04
            Start		  1.7912251896221936e+04
            Stop		  1.8779156681906396e+04
            Start		  2.0746781592876909e+04
            Stop		  2.1613687620098943e+04
            Start		  2.3581313319064113e+04
            Stop		  2.4448218124584037e+04
            Start		  2.6415843314882652e+04
            Stop		  2.7282749061444123e+04
            Start		  2.9250374741143525e+04
            Stop		  3.0117279548298724e+04
            Start		  3.2084904836120520e+04
            Stop		  3.2951810485202179e+04
            Start		  3.4919436161902318e+04
            Stop		  3.5786340966542644e+04
            Start		  3.7753966289148811e+04
            Stop		  3.8620871903908446e+04
            Start		  4.0588497581018797e+04
            Stop		  4.1455402383926987e+04
            Start		  4.3423027718357902e+04
            Stop		  4.4289933322010227e+04
            Start		  4.6257558998458895e+04
            Stop		  4.7124463802189697e+04
            Start		  4.9092089138661970e+04
            Stop		  4.9958994741117647e+04
            Start		  5.1926620414480545e+04
            Stop		  5.2793525221941149e+04
            Start		  5.4761150555351160e+04
            Stop		  5.5628056161695924e+04
            Start		  5.7595681829588277e+04
            Stop		  5.8462586643213479e+04
            Start		  6.0430211970643504e+04
            Stop		  6.1297117583634477e+04
            Start		  6.3264743244445468e+04
            Stop		  6.4131648065669331e+04
            Start		  6.6099273385775450e+04
            Stop		  6.6966179006480612e+04
            Start		  6.8933804659758956e+04
            Stop		  6.9800709488731052e+04
            Start		  7.1768334801606310e+04
            Stop		  7.2635240429589088e+04
            Start		  7.4602866076156337e+04
            Stop		  7.5469770911704501e+04
            Start		  7.7437396218740032e+04
            Stop		  7.8304301852257762e+04
            Start		  8.0271927494076852e+04
            Stop		  8.1138832333907165e+04
            Start		  8.3106457637509957e+04
            Stop		  8.3973363273857161e+04
            Start		  8.5940988913695066e+04
            Stop		  8.6400000000000000e+04
            Strand		 34 50
            Start		  4.3265627191516103e+02
            Stop		  1.2995405894240384e+03
            Start		  3.2671854739910250e+03
            Stop		  4.1340717898034791e+03
            Start		  6.1017176889265247e+03
            Stop		  6.9686018635496530e+03
            Start		  8.9362472014451505e+03
            Stop		  9.8031328472151254e+03
            Start		  1.1770779104722213e+04
            Stop		  1.2637663168042329e+04
            Start		  1.4605307625124917e+04
            Stop		  1.5472194113356374e+04
            Start		  1.7439840519768866e+04
            Stop		  1.8306724541066545e+04
            Start		  2.0274370957499836e+04
            Stop		  2.1141255481914468e+04
            Start		  2.3108901934815640e+04
            Stop		  2.3975785946364565e+04
            Start		  2.5943432162838471e+04
            Stop		  2.6810316886870671e+04
            Start		  2.8777963350574912e+04
            Stop		  2.9644847363467368e+04
            Start		  3.1612493510051536e+04
            Stop		  3.2479378303802569e+04
            Start		  3.4447024767618146e+04
            Stop		  3.5313908784119143e+04
            Start		  3.7281554905058445e+04
            Stop		  3.8148439724009208e+04
            Start		  4.0116086186288223e+04
            Stop		  4.0982970205066791e+04
            Start		  4.2950616317038199e+04
            Stop		  4.3817501144258276e+04
            Start		  4.5785147606643623e+04
            Stop		  4.6652031624966970e+04
            Start		  4.8619677735669473e+04
            Stop		  4.9486562563320229e+04
            Start		  5.1454209028449543e+04
            Stop		  5.2321093043317967e+04
            Start		  5.4288739157203745e+04
            Stop		  5.5155623980837678e+04
            Start		  5.7123270451219010e+04
            Stop		  5.7990154460106489e+04
            Start		  5.9957800579940726e+04
            Stop		  6.0824685396941772e+04
            Start		  6.2792331874297670e+04
            Stop		  6.3659215875663198e+04
            Start		  6.5626862002814916e+04
            Stop		  6.6493746812081910e+04
            Start		  6.8461393296977505e+04
            Stop		  6.9328277290556623e+04
            Start		  7.1295923425015979e+04
            Stop		  7.2162808226898822e+04
            Start		  7.4130454718619832e+04
            Stop		  7.4997338705478207e+04
            Start		  7.6964984845942716e+04
            Stop		  7.7831869642097197e+04
            Start		  7.9799516138766208e+04
            Stop		  8.0666400121116953e+04
            Start		  8.2634046265245881e+04
            Stop		  8.3500931058317758e+04
            Start		  8.5468577557218174e+04
            Stop		  8.6335461059017805e+04
            Strand		 34 51
            Strand		 34 52
            Strand		 34 53
            Strand		 34 54
            Start		  1.1369934904327229e+03
            Stop		  2.3274200121590893e+03
            Start		  3.9715196809463282e+03
            Stop		  5.1619505831917613e+03
            Start		  6.8060503195906394e+03
            Stop		  7.9964813003559866e+03
            Start		  9.6405810328358912e+03
            Stop		  1.0831012011873443e+04
            Start		  1.2475111745781598e+04
            Stop		  1.3665542722710263e+04
            Start		  1.5309642459364170e+04
            Stop		  1.6500073432548379e+04
            Start		  1.8144173173344210e+04
            Stop		  1.9334604141388107e+04
            Start		  2.0978703887524855e+04
            Stop		  2.2169134849259557e+04
            Start		  2.3813234601697168e+04
            Stop		  2.5003665556236090e+04
            Start		  2.6647765315652778e+04
            Stop		  2.7838196262430440e+04
            Start		  2.9482296029192810e+04
            Stop		  3.0672726967989664e+04
            Start		  3.2316826742136596e+04
            Stop		  3.3507257673088810e+04
            Start		  3.5151357454329642e+04
            Stop		  3.6341788377923105e+04
            Start		  3.7985888165650380e+04
            Stop		  3.9176319082699491e+04
            Start		  4.0820418876015552e+04
            Stop		  4.2010849787627463e+04
            Start		  4.3654949585383809e+04
            Stop		  4.4845380492909870e+04
            Start		  4.6489480293757581e+04
            Stop		  4.7679911198734131e+04
            Start		  4.9324011001182982e+04
            Stop		  5.0514441905263797e+04
            Start		  5.2158541707747623e+04
            Stop		  5.3348972612631507e+04
            Start		  5.4993072413577065e+04
            Stop		  5.6183503320933225e+04
            Start		  5.7827603118829051e+04
            Stop		  5.9018034030223804e+04
            Start		  6.0662133823686636e+04
            Stop		  6.1852564740514776e+04
            Start		  6.3496664528350244e+04
            Stop		  6.4687095451773828e+04
            Start		  6.6331195233028746e+04
            Stop		  6.7521626163926077e+04
            Start		  6.9165725937930387e+04
            Stop		  7.0356156876857509e+04
            Start		  7.2000256643253597e+04
            Stop		  7.3190687590419911e+04
            Start		  7.4834787349178223e+04
            Stop		  7.6025218304437483e+04
            Start		  7.7669318055857759e+04
            Stop		  7.8859749018714327e+04
            Start		  8.0503848763412447e+04
            Stop		  8.1694279733043280e+04
            Start		  8.3338379471924141e+04
            Stop		  8.4528810447214972e+04
            Start		  8.6172910181432686e+04
            Stop		  8.6400000000000000e+04
            Strand		 34 55
            Strand		 34 56
            Strand		 34 57
            Strand		 34 58
            Strand		 34 59
            Strand		 34 60
            Strand		 34 61
            Strand		 34 62
            Strand		 34 63
            Strand		 34 64
            Strand		 34 65
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 34 66
            Strand		 34 67
            Strand		 34 68
            Strand		 34 69
            Strand		 34 71
            Strand		 35 36
            Strand		 35 37
            Strand		 35 38
            Strand		 35 39
            Strand		 35 40
            Strand		 35 41
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 35 42
            Strand		 35 43
            Strand		 35 44
            Strand		 35 45
            Strand		 35 46
            Start		  0.0000000000000000e+00
            Stop		  1.2278396490379268e+02
            Start		  1.7668853050999346e+03
            Stop		  2.9573148792436268e+03
            Start		  4.6014160379006153e+03
            Stop		  5.7918455748604256e+03
            Start		  7.4359467392225979e+03
            Stop		  8.6263762868724261e+03
            Start		  1.0270477444138442e+04
            Stop		  1.1460906999001138e+04
            Start		  1.3105008149145748e+04
            Stop		  1.4295437711922315e+04
            Start		  1.5939538854616221e+04
            Stop		  1.7129968425442014e+04
            Start		  1.8774069560716642e+04
            Stop		  1.9964499139382438e+04
            Start		  2.1608600267595513e+04
            Stop		  2.2799029853545057e+04
            Start		  2.4443130975366781e+04
            Stop		  2.5633560567721634e+04
            Start		  2.7277661684105125e+04
            Stop		  2.8468091281703342e+04
            Start		  3.0112192393842772e+04
            Stop		  3.1302621995289846e+04
            Start		  3.2946723104568038e+04
            Stop		  3.4137152708298119e+04
            Start		  3.5781253816225850e+04
            Stop		  3.6971683420570560e+04
            Start		  3.8615784528720178e+04
            Stop		  3.9806214131981811e+04
            Start		  4.1450315241918230e+04
            Stop		  4.2640744842444306e+04
            Start		  4.4284845955656310e+04
            Stop		  4.5475275551912135e+04
            Start		  4.7119376669746976e+04
            Stop		  4.8309806260383019e+04
            Start		  4.9953907383987287e+04
            Stop		  5.1144336967898475e+04
            Start		  5.2788438098167702e+04
            Stop		  5.3978867674541907e+04
            Start		  5.5622968812081323e+04
            Stop		  5.6813398380435028e+04
            Start		  5.8457499525532941e+04
            Stop		  5.9647929085732430e+04
            Start		  6.1292030238347572e+04
            Stop		  6.2482459790614907e+04
            Start		  6.4126560950378225e+04
            Stop		  6.5316990495281396e+04
            Start		  6.6961091661512299e+04
            Stop		  6.8151521199940340e+04
            Start		  6.9795622371676567e+04
            Stop		  7.0986051904800435e+04
            Start		  7.2630153080840348e+04
            Stop		  7.3820582610061567e+04
            Start		  7.5464683789016839e+04
            Stop		  7.6655113315906012e+04
            Start		  7.8299214496262677e+04
            Stop		  7.9489644022490349e+04
            Start		  8.1133745202675171e+04
            Stop		  8.2324174729938662e+04
            Start		  8.3968275908388401e+04
            Stop		  8.5158705438337071e+04
            Strand		 35 47
            Strand		 35 48
            Strand		 35 49
            Strand		 35 50
            Start		  0.0000000000000000e+00
            Stop		  8.2712851224968881e+02
            Start		  2.7947528644104673e+03
            Stop		  3.6616638197711864e+03
            Start		  5.6292811179053288e+03
            Stop		  6.4961901731934540e+03
            Start		  8.4638122550587123e+03
            Stop		  9.3307207878762783e+03
            Start		  1.1298344166273611e+04
            Stop		  1.2165251765607738e+04
            Start		  1.4132873023793612e+04
            Stop		  1.4999782359320559e+04
            Start		  1.6967406855755340e+04
            Stop		  1.7834313302217201e+04
            Start		  1.9801939037211792e+04
            Stop		  2.0668843834001585e+04
            Start		  2.2636468879919608e+04
            Stop		  2.3503374771376733e+04
            Start		  2.5471000459873350e+04
            Stop		  2.6337905267204515e+04
            Start		  2.8305530504294995e+04
            Stop		  2.9172436204009307e+04
            Start		  3.1140061881564539e+04
            Stop		  3.2006966688080811e+04
            Start		  3.3974591992467344e+04
            Stop		  3.4841497625102704e+04
            Start		  3.6809123301798129e+04
            Stop		  3.7676028105673402e+04
            Start		  3.9643653434114174e+04
            Stop		  4.0510559043256006e+04
            Start		  4.2478184720344791e+04
            Stop		  4.3345089523213574e+04
            Start		  4.5312714859185638e+04
            Stop		  4.6179620461571227e+04
            Start		  4.8147246137269845e+04
            Stop		  4.9014150941933534e+04
            Start		  5.0981776277851532e+04
            Stop		  5.1848681881146440e+04
            Start		  5.3816307552920814e+04
            Stop		  5.4683212362207647e+04
            Start		  5.6650837693876296e+04
            Stop		  5.7517743302208823e+04
            Start		  5.9485368967866641e+04
            Stop		  6.0352273783925652e+04
            Start		  6.2319899108994374e+04
            Stop		  6.3186804724511887e+04
            Start		  6.5154430382798811e+04
            Stop		  6.6021335206655800e+04
            Start		  6.7988960524274298e+04
            Stop		  6.8855866147522524e+04
            Start		  7.0823491798411182e+04
            Stop		  7.1690396629767230e+04
            Start		  7.3658021940484134e+04
            Stop		  7.4524927570561340e+04
            Start		  7.6492553215279375e+04
            Stop		  7.7359458052555317e+04
            Start		  7.9327083358140357e+04
            Stop		  8.0193988992936400e+04
            Start		  8.2161614633760808e+04
            Stop		  8.3028519474369241e+04
            Start		  8.4996144777478286e+04
            Stop		  8.5863050414068770e+04
            Strand		 35 51
            Start		  0.0000000000000000e+00
            Stop		  3.5469709046045813e+02
            Start		  2.3223434113167536e+03
            Stop		  3.1892274503822996e+03
            Start		  5.1568742408756016e+03
            Stop		  6.0237583918384234e+03
            Start		  7.9914048277865368e+03
            Stop		  8.8582888324215928e+03
            Start		  1.0825935183862661e+04
            Stop		  1.1692819771901206e+04
            Start		  1.3660466243163492e+04
            Stop		  1.4527350240193167e+04
            Start		  1.6494996443962424e+04
            Stop		  1.7361881180057917e+04
            Start		  1.9329527658095678e+04
            Stop		  2.0196411657882036e+04
            Start		  2.2164057807868561e+04
            Stop		  2.3030942598176145e+04
            Start		  2.4998589073295745e+04
            Stop		  2.5865473079265055e+04
            Start		  2.7833119206591131e+04
            Stop		  2.8700004019693588e+04
            Start		  3.0667650489425927e+04
            Stop		  3.1534534501720416e+04
            Start		  3.3502180617811711e+04
            Stop		  3.4369065441933024e+04
            Start		  3.6336711906985576e+04
            Stop		  3.7203595923899651e+04
            Start		  3.9171242034353047e+04
            Stop		  4.0038126863578931e+04
            Start		  4.2005773326225353e+04
            Stop		  4.2872657344990912e+04
            Start		  4.4840303453824185e+04
            Stop		  4.5707188283911266e+04
            Start		  4.7674834747103996e+04
            Stop		  4.8541718764533507e+04
            Start		  5.0509364875211832e+04
            Stop		  5.1376249702600879e+04
            Start		  5.3343896169295534e+04
            Stop		  5.4210780182389353e+04
            Start		  5.6178426297793507e+04
            Stop		  5.7045311119657694e+04
            Start		  5.9012957592245933e+04
            Stop		  5.9879841598730956e+04
            Start		  6.1847487720845456e+04
            Stop		  6.2714372535392933e+04
            Start		  6.4682019015269405e+04
            Stop		  6.5548903013999574e+04
            Start		  6.7516549143630516e+04
            Stop		  6.8383433950353050e+04
            Start		  7.0351080437667522e+04
            Stop		  7.1217964428824635e+04
            Start		  7.3185610565480427e+04
            Stop		  7.4052495365220981e+04
            Start		  7.6020141858850518e+04
            Stop		  7.6887025843912998e+04
            Start		  7.8854671985896915e+04
            Stop		  7.9721556780696061e+04
            Start		  8.1689203278439862e+04
            Stop		  8.2556087259925858e+04
            Start		  8.4523733404633254e+04
            Stop		  8.5390618197372110e+04
            Strand		 35 52
            Strand		 35 53
            Strand		 35 54
            Strand		 35 55
            Start		  1.9214823493422307e+02
            Stop		  1.3825765884783743e+03
            Start		  3.0266762319555050e+03
            Stop		  4.2171070168723900e+03
            Start		  5.8612067500396897e+03
            Stop		  7.0516377293370269e+03
            Start		  8.6957374619410439e+03
            Stop		  9.8861684414004267e+03
            Start		  1.1530268174712122e+04
            Stop		  1.2720699152542365e+04
            Start		  1.4364798888116798e+04
            Stop		  1.5555229862713435e+04
            Start		  1.7199329601985082e+04
            Stop		  1.8389760571884879e+04
            Start		  2.0033860316121845e+04
            Stop		  2.1224291280072975e+04
            Start		  2.2868391030320294e+04
            Stop		  2.4058821987337145e+04
            Start		  2.5702921744370895e+04
            Stop		  2.6893352693777451e+04
            Start		  2.8537452458070595e+04
            Stop		  2.9727883399530183e+04
            Start		  3.1371983171231750e+04
            Stop		  3.2562414104761821e+04
            Start		  3.4206513883690292e+04
            Stop		  3.5396944809661807e+04
            Start		  3.7041044595313033e+04
            Stop		  3.8231475514434147e+04
            Start		  3.9875575306003448e+04
            Stop		  4.1066006219288516e+04
            Start		  4.2710106015705918e+04
            Stop		  4.3900536924431050e+04
            Start		  4.5544636724408185e+04
            Stop		  4.6735067630055164e+04
            Start		  4.8379167432141949e+04
            Stop		  4.9569598336333293e+04
            Start		  5.1213698138981359e+04
            Stop		  5.2404129043409106e+04
            Start		  5.4048228845039797e+04
            Stop		  5.5238659751391286e+04
            Start		  5.6882759550465038e+04
            Stop		  5.8073190460348786e+04
            Start		  5.9717290255432490e+04
            Stop		  6.0907721170307734e+04
            Start		  6.2551820960137782e+04
            Stop		  6.3742251881250362e+04
            Start		  6.5386351664787973e+04
            Stop		  6.6576782593115684e+04
            Start		  6.8220882369592524e+04
            Stop		  6.9411313305802323e+04
            Start		  7.1055413074754120e+04
            Stop		  7.2245844019172699e+04
            Start		  7.3889943780459769e+04
            Stop		  7.5080374733059507e+04
            Start		  7.6724474486872539e+04
            Stop		  7.7914905447272569e+04
            Start		  7.9559005194124416e+04
            Stop		  8.0749436161607460e+04
            Start		  8.2393535902310570e+04
            Stop		  8.3583966875854618e+04
            Start		  8.5228066611485076e+04
            Stop		  8.6400000000000000e+04
            Strand		 35 56
            Strand		 35 57
            Strand		 35 58
            Strand		 35 59
            Strand		 35 60
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 35 61
            Strand		 35 62
            Strand		 35 63
            Strand		 35 64
            Strand		 35 65
            Strand		 35 66
            Strand		 35 67
            Strand		 35 68
            Strand		 35 69
            Strand		 35 70
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #ff00ff
                AnimationColor		 #00c4c4
                AnimationLineWidth		 1
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

