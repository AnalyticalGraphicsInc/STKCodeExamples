stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Chain

    Name		 FirstToSecond
    BEGIN Definition

        Object		 Constellation/SatRec
        Object		 Constellation/SatTrans
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 No
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 86400
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 15 Jun 2020 19:00:00.000000000
                Stop		 16 Jun 2020 19:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        SaveIntervalFile		 C:\Users\aclaybrook\Documents\STK 12\ConstellationAnalysisScenarios\TransRecTest\strand.int
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        BEGIN StrandObjIndexes
            StrandObj		 Satellite/LEO11/Receiver/Receiver3
            StrandObj		 Satellite/LEO12/Receiver/Receiver4
            StrandObj		 Satellite/LEO13/Receiver/Receiver5
            StrandObj		 Satellite/LEO14/Receiver/Receiver6
            StrandObj		 Satellite/LEO15/Receiver/Receiver9
            StrandObj		 Satellite/LEO16/Receiver/Receiver10
            StrandObj		 Satellite/LEO21/Receiver/Receiver11
            StrandObj		 Satellite/LEO22/Receiver/Receiver12
            StrandObj		 Satellite/LEO23/Receiver/Receiver13
            StrandObj		 Satellite/LEO24/Receiver/Receiver14
            StrandObj		 Satellite/LEO25/Receiver/Receiver15
            StrandObj		 Satellite/LEO26/Receiver/Receiver16
            StrandObj		 Satellite/LEO31/Receiver/Receiver17
            StrandObj		 Satellite/LEO32/Receiver/Receiver18
            StrandObj		 Satellite/LEO33/Receiver/Receiver19
            StrandObj		 Satellite/LEO34/Receiver/Receiver20
            StrandObj		 Satellite/LEO35/Receiver/Receiver21
            StrandObj		 Satellite/LEO36/Receiver/Receiver22
            StrandObj		 Satellite/LEO41/Receiver/Receiver23
            StrandObj		 Satellite/LEO42/Receiver/Receiver24
            StrandObj		 Satellite/LEO43/Receiver/Receiver25
            StrandObj		 Satellite/LEO44/Receiver/Receiver26
            StrandObj		 Satellite/LEO45/Receiver/Receiver27
            StrandObj		 Satellite/LEO46/Receiver/Receiver28
            StrandObj		 Satellite/LEO51/Receiver/Receiver29
            StrandObj		 Satellite/LEO52/Receiver/Receiver30
            StrandObj		 Satellite/LEO53/Receiver/Receiver31
            StrandObj		 Satellite/LEO54/Receiver/Receiver32
            StrandObj		 Satellite/LEO55/Receiver/Receiver33
            StrandObj		 Satellite/LEO56/Receiver/Receiver34
            StrandObj		 Satellite/LEO61/Receiver/Receiver35
            StrandObj		 Satellite/LEO62/Receiver/Receiver36
            StrandObj		 Satellite/LEO63/Receiver/Receiver37
            StrandObj		 Satellite/LEO64/Receiver/Receiver38
            StrandObj		 Satellite/LEO65/Receiver/Receiver39
            StrandObj		 Satellite/LEO66/Receiver/Receiver40
            StrandObj		 Satellite/LEO11/Transmitter/Transmitter3
            StrandObj		 Satellite/LEO12/Transmitter/Transmitter4
            StrandObj		 Satellite/LEO13/Transmitter/Transmitter5
            StrandObj		 Satellite/LEO14/Transmitter/Transmitter6
            StrandObj		 Satellite/LEO15/Transmitter/Transmitter7
            StrandObj		 Satellite/LEO16/Transmitter/Transmitter8
            StrandObj		 Satellite/LEO21/Transmitter/Transmitter9
            StrandObj		 Satellite/LEO22/Transmitter/Transmitter12
            StrandObj		 Satellite/LEO23/Transmitter/Transmitter13
            StrandObj		 Satellite/LEO24/Transmitter/Transmitter14
            StrandObj		 Satellite/LEO25/Transmitter/Transmitter15
            StrandObj		 Satellite/LEO26/Transmitter/Transmitter16
            StrandObj		 Satellite/LEO31/Transmitter/Transmitter17
            StrandObj		 Satellite/LEO32/Transmitter/Transmitter18
            StrandObj		 Satellite/LEO33/Transmitter/Transmitter19
            StrandObj		 Satellite/LEO34/Transmitter/Transmitter20
            StrandObj		 Satellite/LEO35/Transmitter/Transmitter21
            StrandObj		 Satellite/LEO36/Transmitter/Transmitter22
            StrandObj		 Satellite/LEO41/Transmitter/Transmitter23
            StrandObj		 Satellite/LEO42/Transmitter/Transmitter24
            StrandObj		 Satellite/LEO43/Transmitter/Transmitter25
            StrandObj		 Satellite/LEO44/Transmitter/Transmitter26
            StrandObj		 Satellite/LEO45/Transmitter/Transmitter27
            StrandObj		 Satellite/LEO46/Transmitter/Transmitter28
            StrandObj		 Satellite/LEO51/Transmitter/Transmitter29
            StrandObj		 Satellite/LEO52/Transmitter/Transmitter30
            StrandObj		 Satellite/LEO53/Transmitter/Transmitter31
            StrandObj		 Satellite/LEO54/Transmitter/Transmitter32
            StrandObj		 Satellite/LEO55/Transmitter/Transmitter33
            StrandObj		 Satellite/LEO56/Transmitter/Transmitter34
            StrandObj		 Satellite/LEO61/Transmitter/Transmitter35
            StrandObj		 Satellite/LEO62/Transmitter/Transmitter36
            StrandObj		 Satellite/LEO63/Transmitter/Transmitter37
            StrandObj		 Satellite/LEO64/Transmitter/Transmitter38
            StrandObj		 Satellite/LEO65/Transmitter/Transmitter39
            StrandObj		 Satellite/LEO66/Transmitter/Transmitter40
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 36
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 1 37
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 2 38
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 3 39
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 4 40
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 5 41
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 6 42
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 7 43
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 8 44
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 9 45
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 10 46
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 11 47
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 12 48
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 13 49
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 14 50
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 15 51
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 16 52
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 17 53
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 18 54
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 19 55
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 20 56
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 21 57
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 22 58
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 23 59
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 24 60
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 25 61
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 26 62
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 27 63
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 28 64
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 29 65
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 30 66
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 31 67
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 32 68
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 33 69
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 34 70
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
            Strand		 35 71
            Start		  0.0000000000000000e+00
            Stop		  8.6400000000000000e+04
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #00ff00
                AnimationColor		 #00c4c4
                AnimationLineWidth		 1
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

