stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Chain

    Name		 Chain1
    BEGIN Definition

        Object		 Place/Place1
        Object		 Constellation/Sats
        Object		 Constellation/Sats
        Object		 Place/Place2
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 Yes
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 14400
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 22 May 2020 16:00:00.000000000
                Stop		 22 May 2020 20:00:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        SaveIntervalFile		 C:\Users\aclaybrook\Documents\STK 12\ChainPath\strand.int
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        BEGIN StrandObjIndexes
            StrandObj		 Place/Place1
            StrandObj		 Satellite/GEO
            StrandObj		 Satellite/Satellite111
            StrandObj		 Satellite/Satellite112
            StrandObj		 Satellite/Satellite113
            StrandObj		 Satellite/Satellite114
            StrandObj		 Satellite/Satellite115
            StrandObj		 Satellite/Satellite116
            StrandObj		 Satellite/Satellite121
            StrandObj		 Satellite/Satellite122
            StrandObj		 Satellite/Satellite123
            StrandObj		 Satellite/Satellite124
            StrandObj		 Satellite/Satellite125
            StrandObj		 Satellite/Satellite126
            StrandObj		 Satellite/Satellite131
            StrandObj		 Satellite/Satellite132
            StrandObj		 Satellite/Satellite133
            StrandObj		 Satellite/Satellite134
            StrandObj		 Satellite/Satellite135
            StrandObj		 Satellite/Satellite136
            StrandObj		 Satellite/Satellite141
            StrandObj		 Satellite/Satellite142
            StrandObj		 Satellite/Satellite143
            StrandObj		 Satellite/Satellite144
            StrandObj		 Satellite/Satellite145
            StrandObj		 Satellite/Satellite146
            StrandObj		 Satellite/Satellite151
            StrandObj		 Satellite/Satellite152
            StrandObj		 Satellite/Satellite153
            StrandObj		 Satellite/Satellite154
            StrandObj		 Satellite/Satellite155
            StrandObj		 Satellite/Satellite156
            StrandObj		 Satellite/Satellite161
            StrandObj		 Satellite/Satellite162
            StrandObj		 Satellite/Satellite163
            StrandObj		 Satellite/Satellite164
            StrandObj		 Satellite/Satellite165
            StrandObj		 Satellite/Satellite166
            StrandObj		 Place/Place2
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 1 1 38
            Start		  0.0000000000000000e+00
            Stop		  1.4400000000000000e+04
            Strand		 0 1 2 38
            Start		  2.1149632195889831e+03
            Stop		  2.9019829226343904e+03
            Start		  9.3973319735515688e+03
            Stop		  1.0862310922398225e+04
            Strand		 0 1 3 38
            Start		  9.4174925597403512e+02
            Stop		  1.4747720591339571e+03
            Start		  8.1715316984640694e+03
            Stop		  9.5801990395805078e+03
            Strand		 0 1 4 38
            Start		  6.9494861761869633e+03
            Stop		  8.2839867853354444e+03
            Start		  1.4342090931196422e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 1 5 38
            Start		  5.7314499545613435e+03
            Stop		  6.9715338193774678e+03
            Start		  1.3098732694737739e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 1 6 38
            Start		  4.5181635853688858e+03
            Stop		  5.6400221246945530e+03
            Start		  1.1860574866344492e+04
            Stop		  1.3390358615486637e+04
            Strand		 0 1 7 38
            Start		  3.3113224481488905e+03
            Stop		  4.2855809953814642e+03
            Start		  1.0626930780401957e+04
            Stop		  1.2131950604689744e+04
            Strand		 0 1 8 38
            Start		  1.9937662505776322e+02
            Stop		  1.2303921025076613e+03
            Strand		 0 1 9 38
            Start		  0.0000000000000000e+00
            Stop		  2.0948168724378579e+01
            Strand		 0 1 10 38
            Strand		 0 1 11 38
            Start		  4.4674510747356926e+03
            Stop		  4.7424042064040304e+03
            Strand		 0 1 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.6155442936893587e+03
            Strand		 0 1 13 38
            Start		  1.5715472223761499e+03
            Stop		  2.4312549985318733e+03
            Strand		 0 1 14 38
            Start		  0.0000000000000000e+00
            Stop		  4.2458514658473865e+02
            Start		  6.4155613241792025e+03
            Stop		  7.9358847630052642e+03
            Start		  1.4208013931068119e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 1 15 38
            Start		  5.1628713132146759e+03
            Stop		  6.6998599859260812e+03
            Start		  1.2866592998418269e+04
            Stop		  1.4055829240497009e+04
            Strand		 0 1 16 38
            Start		  3.9202250979255800e+03
            Stop		  5.4589789181041133e+03
            Start		  1.1545819764440092e+04
            Stop		  1.2839834763058099e+04
            Strand		 0 1 17 38
            Start		  2.6873265302893583e+03
            Stop		  4.2124208437663774e+03
            Start		  1.0242478496301919e+04
            Stop		  1.1619568004013641e+04
            Strand		 0 1 18 38
            Start		  1.4642517209886255e+03
            Stop		  2.9590350715293180e+03
            Start		  8.9541496902931121e+03
            Stop		  1.0395472758638833e+04
            Strand		 0 1 19 38
            Start		  2.5160588436072240e+02
            Stop		  1.6972070271340531e+03
            Start		  7.6789801932244818e+03
            Stop		  9.1676325534052175e+03
            Strand		 0 1 20 38
            Start		  1.3089338568703177e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 1 21 38
            Start		  1.1905939714950015e+04
            Stop		  1.3156788514549589e+04
            Strand		 0 1 22 38
            Start		  1.0743370348210261e+04
            Stop		  1.1844308993035040e+04
            Strand		 0 1 23 38
            Start		  9.6149870886865210e+03
            Stop		  1.0494963373447537e+04
            Strand		 0 1 24 38
            Start		  8.5708983258619282e+03
            Stop		  9.0570962921406972e+03
            Strand		 0 1 25 38
            Start		  1.4287797392503802e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 1 26 38
            Strand		 0 1 27 38
            Strand		 0 1 28 38
            Strand		 0 1 29 38
            Strand		 0 1 30 38
            Strand		 0 1 31 38
            Strand		 0 1 32 38
            Start		  1.5642151592087109e+03
            Stop		  3.0718833329730119e+03
            Start		  9.3759467997114352e+03
            Stop		  1.0112033488972374e+04
            Strand		 0 1 33 38
            Start		  3.1342835997522292e+02
            Stop		  1.8452481520569190e+03
            Start		  7.9984858956004409e+03
            Stop		  9.0100451414278923e+03
            Strand		 0 1 34 38
            Start		  0.0000000000000000e+00
            Stop		  6.0887222809569755e+02
            Start		  6.6718401863873032e+03
            Stop		  7.8605897165860306e+03
            Strand		 0 1 35 38
            Start		  5.3725548938167321e+03
            Stop		  6.6857287417851185e+03
            Strand		 0 1 36 38
            Start		  4.0912143238830004e+03
            Stop		  5.4936786264992807e+03
            Strand		 0 1 37 38
            Start		  2.8227895322559370e+03
            Stop		  4.2883771574587045e+03
            Strand		 0 2 1 38
            Start		  4.2312448076820260e+02
            Stop		  1.9595764963542460e+03
            Start		  8.0391187866889431e+03
            Stop		  9.5056108741549651e+03
            Strand		 0 2 2 38
            Start		  9.3973319735515688e+03
            Stop		  9.5056108741549651e+03
            Strand		 0 2 3 38
            Start		  9.4174925597403512e+02
            Stop		  1.4747720591339571e+03
            Start		  8.1715316984640694e+03
            Stop		  9.5056108741549651e+03
            Strand		 0 2 4 38
            Strand		 0 2 5 38
            Strand		 0 2 6 38
            Strand		 0 2 7 38
            Strand		 0 2 8 38
            Start		  4.2312448076820260e+02
            Stop		  1.2303921025076613e+03
            Strand		 0 2 9 38
            Strand		 0 2 10 38
            Strand		 0 2 11 38
            Strand		 0 2 12 38
            Strand		 0 2 13 38
            Start		  1.5715472223761499e+03
            Stop		  1.9595764963542460e+03
            Strand		 0 2 14 38
            Strand		 0 2 15 38
            Strand		 0 2 16 38
            Strand		 0 2 17 38
            Strand		 0 2 18 38
            Start		  1.6242484459892605e+03
            Stop		  1.9595764963542460e+03
            Start		  8.9541496902931121e+03
            Stop		  9.5056108741549651e+03
            Strand		 0 2 19 38
            Start		  1.2243392670615649e+03
            Stop		  1.6972070271340531e+03
            Start		  8.3431052631756829e+03
            Stop		  9.1676325534052175e+03
            Strand		 0 2 20 38
            Strand		 0 2 21 38
            Strand		 0 2 22 38
            Strand		 0 2 23 38
            Strand		 0 2 24 38
            Strand		 0 2 25 38
            Strand		 0 2 26 38
            Strand		 0 2 27 38
            Strand		 0 2 28 38
            Strand		 0 2 29 38
            Strand		 0 2 30 38
            Strand		 0 2 31 38
            Strand		 0 2 32 38
            Start		  1.5642151592087109e+03
            Stop		  1.9595764963542460e+03
            Start		  9.3759467997114352e+03
            Stop		  9.5056108741549651e+03
            Strand		 0 2 33 38
            Start		  4.2312448076820260e+02
            Stop		  1.4761455091068185e+03
            Start		  8.0391187866889431e+03
            Stop		  8.5949072614437482e+03
            Strand		 0 2 34 38
            Strand		 0 2 35 38
            Strand		 0 2 36 38
            Strand		 0 2 37 38
            Strand		 0 3 1 38
            Start		  0.0000000000000000e+00
            Stop		  7.1132373212555592e+02
            Start		  6.7650152041667998e+03
            Stop		  8.2397008209733012e+03
            Start		  1.4381178268911723e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 3 2 38
            Strand		 0 3 3 38
            Start		  8.1715316984640694e+03
            Stop		  8.2397008209733012e+03
            Strand		 0 3 4 38
            Start		  6.9494861761869633e+03
            Stop		  8.2397008209733012e+03
            Start		  1.4381178268911723e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 3 5 38
            Strand		 0 3 6 38
            Strand		 0 3 7 38
            Strand		 0 3 8 38
            Start		  1.9937662505776322e+02
            Stop		  7.1132373212555592e+02
            Strand		 0 3 9 38
            Start		  0.0000000000000000e+00
            Stop		  2.0948168724378579e+01
            Strand		 0 3 10 38
            Strand		 0 3 11 38
            Strand		 0 3 12 38
            Strand		 0 3 13 38
            Strand		 0 3 14 38
            Start		  3.7879285972181137e+01
            Stop		  4.2458514658473865e+02
            Start		  7.1566433776212689e+03
            Stop		  7.9358847630052642e+03
            Start		  1.4381178268911723e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 3 15 38
            Strand		 0 3 16 38
            Strand		 0 3 17 38
            Strand		 0 3 18 38
            Strand		 0 3 19 38
            Start		  4.3778515037470646e+02
            Stop		  7.1132373212555592e+02
            Start		  7.6789801932244818e+03
            Stop		  8.2397008209733012e+03
            Strand		 0 3 20 38
            Strand		 0 3 21 38
            Strand		 0 3 22 38
            Strand		 0 3 23 38
            Strand		 0 3 24 38
            Strand		 0 3 25 38
            Strand		 0 3 26 38
            Strand		 0 3 27 38
            Strand		 0 3 28 38
            Strand		 0 3 29 38
            Strand		 0 3 30 38
            Strand		 0 3 31 38
            Strand		 0 3 32 38
            Strand		 0 3 33 38
            Start		  3.1342835997522292e+02
            Stop		  7.1132373212555592e+02
            Start		  7.9984858956004409e+03
            Stop		  8.2397008209733012e+03
            Strand		 0 3 34 38
            Start		  0.0000000000000000e+00
            Stop		  2.8968150596257192e+02
            Start		  6.7650152041667998e+03
            Stop		  7.4084473399337367e+03
            Strand		 0 3 35 38
            Strand		 0 3 36 38
            Strand		 0 3 37 38
            Strand		 0 4 1 38
            Start		  5.4913022864436052e+03
            Stop		  6.9772332891374917e+03
            Start		  1.3118811627936493e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 2 38
            Strand		 0 4 3 38
            Strand		 0 4 4 38
            Start		  6.9494861761869633e+03
            Stop		  6.9772332891374917e+03
            Start		  1.4342090931196422e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 5 38
            Start		  5.7314499545613435e+03
            Stop		  6.9715338193774678e+03
            Start		  1.3118811627936493e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 6 38
            Strand		 0 4 7 38
            Strand		 0 4 8 38
            Strand		 0 4 9 38
            Strand		 0 4 10 38
            Strand		 0 4 11 38
            Strand		 0 4 12 38
            Strand		 0 4 13 38
            Strand		 0 4 14 38
            Start		  6.4155613241792025e+03
            Stop		  6.9772332891374917e+03
            Start		  1.4208013931068119e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 15 38
            Start		  5.9701789577588770e+03
            Stop		  6.6998599859260812e+03
            Start		  1.3118811627936493e+04
            Stop		  1.4055829240497009e+04
            Strand		 0 4 16 38
            Strand		 0 4 17 38
            Strand		 0 4 18 38
            Strand		 0 4 19 38
            Strand		 0 4 20 38
            Start		  1.3877144127768803e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 21 38
            Strand		 0 4 22 38
            Strand		 0 4 23 38
            Strand		 0 4 24 38
            Strand		 0 4 25 38
            Start		  1.4287797392503802e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 4 26 38
            Strand		 0 4 27 38
            Strand		 0 4 28 38
            Strand		 0 4 29 38
            Strand		 0 4 30 38
            Strand		 0 4 31 38
            Strand		 0 4 32 38
            Strand		 0 4 33 38
            Strand		 0 4 34 38
            Start		  6.6718401863873032e+03
            Stop		  6.9772332891374917e+03
            Strand		 0 4 35 38
            Start		  5.4913022864436052e+03
            Stop		  6.2219890193757601e+03
            Strand		 0 4 36 38
            Strand		 0 4 37 38
            Strand		 0 5 1 38
            Start		  4.2191686236141850e+03
            Stop		  5.7182429579469199e+03
            Start		  1.1853003238770531e+04
            Stop		  1.3319681527287970e+04
            Strand		 0 5 2 38
            Strand		 0 5 3 38
            Strand		 0 5 4 38
            Strand		 0 5 5 38
            Start		  1.3098732694737739e+04
            Stop		  1.3319681527287970e+04
            Strand		 0 5 6 38
            Start		  4.5181635853688858e+03
            Stop		  5.6400221246945530e+03
            Start		  1.1860574866344492e+04
            Stop		  1.3319681527287970e+04
            Strand		 0 5 7 38
            Strand		 0 5 8 38
            Strand		 0 5 9 38
            Strand		 0 5 10 38
            Strand		 0 5 11 38
            Start		  4.4674510747356926e+03
            Stop		  4.7424042064040304e+03
            Strand		 0 5 12 38
            Strand		 0 5 13 38
            Strand		 0 5 14 38
            Strand		 0 5 15 38
            Start		  5.1836263622330771e+03
            Stop		  5.7182429579469199e+03
            Start		  1.2866592998418269e+04
            Stop		  1.3319681527287970e+04
            Strand		 0 5 16 38
            Start		  4.7837181590262653e+03
            Stop		  5.4589789181041133e+03
            Start		  1.1902483791879384e+04
            Stop		  1.2839834763058099e+04
            Strand		 0 5 17 38
            Strand		 0 5 18 38
            Strand		 0 5 19 38
            Strand		 0 5 20 38
            Start		  1.3089338568703177e+04
            Stop		  1.3319681527287970e+04
            Strand		 0 5 21 38
            Start		  1.2690683254788122e+04
            Stop		  1.3156788514549589e+04
            Strand		 0 5 22 38
            Strand		 0 5 23 38
            Strand		 0 5 24 38
            Strand		 0 5 25 38
            Strand		 0 5 26 38
            Strand		 0 5 27 38
            Strand		 0 5 28 38
            Strand		 0 5 29 38
            Strand		 0 5 30 38
            Strand		 0 5 31 38
            Strand		 0 5 32 38
            Strand		 0 5 33 38
            Strand		 0 5 34 38
            Strand		 0 5 35 38
            Start		  5.3725548938167321e+03
            Stop		  5.7182429579469199e+03
            Strand		 0 5 36 38
            Start		  4.2191686236141850e+03
            Stop		  5.0355264458138727e+03
            Strand		 0 5 37 38
            Strand		 0 6 1 38
            Start		  2.9497683553857059e+03
            Stop		  4.4625461191266722e+03
            Start		  1.0584041136354728e+04
            Stop		  1.2046293762040472e+04
            Strand		 0 6 2 38
            Strand		 0 6 3 38
            Strand		 0 6 4 38
            Strand		 0 6 5 38
            Strand		 0 6 6 38
            Start		  1.1860574866344492e+04
            Stop		  1.2046293762040472e+04
            Strand		 0 6 7 38
            Start		  3.3113224481488905e+03
            Stop		  4.2855809953814642e+03
            Start		  1.0626930780401957e+04
            Stop		  1.2046293762040472e+04
            Strand		 0 6 8 38
            Strand		 0 6 9 38
            Strand		 0 6 10 38
            Strand		 0 6 11 38
            Strand		 0 6 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.6155442936893587e+03
            Strand		 0 6 13 38
            Strand		 0 6 14 38
            Strand		 0 6 15 38
            Strand		 0 6 16 38
            Start		  3.9971696665433878e+03
            Stop		  4.4625461191266722e+03
            Start		  1.1545819764440092e+04
            Stop		  1.2046293762040472e+04
            Strand		 0 6 17 38
            Start		  3.5972578035932656e+03
            Stop		  4.2124208437663774e+03
            Start		  1.0716023141062489e+04
            Stop		  1.1619568004013641e+04
            Strand		 0 6 18 38
            Strand		 0 6 19 38
            Strand		 0 6 20 38
            Strand		 0 6 21 38
            Start		  1.1905939714950015e+04
            Stop		  1.2046293762040472e+04
            Strand		 0 6 22 38
            Start		  1.1504222367326172e+04
            Stop		  1.1844308993035040e+04
            Strand		 0 6 23 38
            Strand		 0 6 24 38
            Strand		 0 6 25 38
            Strand		 0 6 26 38
            Strand		 0 6 27 38
            Strand		 0 6 28 38
            Strand		 0 6 29 38
            Strand		 0 6 30 38
            Strand		 0 6 31 38
            Strand		 0 6 32 38
            Strand		 0 6 33 38
            Strand		 0 6 34 38
            Strand		 0 6 35 38
            Strand		 0 6 36 38
            Start		  4.0912143238830004e+03
            Stop		  4.4625461191266722e+03
            Strand		 0 6 37 38
            Start		  2.9497683553857059e+03
            Stop		  3.8490650990554495e+03
            Strand		 0 7 1 38
            Start		  1.6841167217815605e+03
            Stop		  3.2098074138443840e+03
            Start		  9.3124692568358550e+03
            Stop		  1.0774662161727210e+04
            Strand		 0 7 2 38
            Start		  2.1149632195889831e+03
            Stop		  2.9019829226343904e+03
            Start		  9.3973319735515688e+03
            Stop		  1.0774662161727210e+04
            Strand		 0 7 3 38
            Strand		 0 7 4 38
            Strand		 0 7 5 38
            Strand		 0 7 6 38
            Strand		 0 7 7 38
            Start		  1.0626930780401957e+04
            Stop		  1.0774662161727210e+04
            Strand		 0 7 8 38
            Strand		 0 7 9 38
            Strand		 0 7 10 38
            Strand		 0 7 11 38
            Strand		 0 7 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.2098074138443840e+03
            Strand		 0 7 13 38
            Start		  1.6841167217815605e+03
            Stop		  2.4312549985318733e+03
            Strand		 0 7 14 38
            Strand		 0 7 15 38
            Strand		 0 7 16 38
            Strand		 0 7 17 38
            Start		  2.8107080288706979e+03
            Stop		  3.2098074138443840e+03
            Start		  1.0242478496301919e+04
            Stop		  1.0774662161727210e+04
            Strand		 0 7 18 38
            Start		  2.4107997768673713e+03
            Stop		  2.9590350715293180e+03
            Start		  9.5295660054213131e+03
            Stop		  1.0395472758638833e+04
            Strand		 0 7 19 38
            Strand		 0 7 20 38
            Strand		 0 7 21 38
            Strand		 0 7 22 38
            Start		  1.0743370348210261e+04
            Stop		  1.0774662161727210e+04
            Strand		 0 7 23 38
            Start		  1.0317761492492891e+04
            Stop		  1.0494963373447537e+04
            Strand		 0 7 24 38
            Strand		 0 7 25 38
            Strand		 0 7 26 38
            Strand		 0 7 27 38
            Strand		 0 7 28 38
            Strand		 0 7 29 38
            Strand		 0 7 30 38
            Strand		 0 7 31 38
            Strand		 0 7 32 38
            Start		  1.6841167217815605e+03
            Stop		  2.6626032256131757e+03
            Start		  9.3759467997114352e+03
            Stop		  9.7813717452310320e+03
            Strand		 0 7 33 38
            Strand		 0 7 34 38
            Strand		 0 7 35 38
            Strand		 0 7 36 38
            Strand		 0 7 37 38
            Start		  2.8227895322559370e+03
            Stop		  3.2098074138443840e+03
            Strand		 0 8 1 38
            Start		  0.0000000000000000e+00
            Stop		  8.7936267493209516e+02
            Start		  7.0254616436788892e+03
            Stop		  8.5057673856740621e+03
            Strand		 0 8 2 38
            Strand		 0 8 3 38
            Start		  8.1715316984640694e+03
            Stop		  8.5057673856740621e+03
            Strand		 0 8 4 38
            Start		  7.0254616436788892e+03
            Stop		  8.2839867853354444e+03
            Strand		 0 8 5 38
            Strand		 0 8 6 38
            Strand		 0 8 7 38
            Strand		 0 8 8 38
            Start		  1.9937662505776322e+02
            Stop		  8.7936267493209516e+02
            Strand		 0 8 9 38
            Start		  0.0000000000000000e+00
            Stop		  2.0948168724378579e+01
            Strand		 0 8 10 38
            Strand		 0 8 11 38
            Strand		 0 8 12 38
            Strand		 0 8 13 38
            Strand		 0 8 14 38
            Start		  0.0000000000000000e+00
            Stop		  4.2458514658473865e+02
            Start		  7.0254616436788892e+03
            Stop		  7.9358847630052642e+03
            Strand		 0 8 15 38
            Strand		 0 8 16 38
            Strand		 0 8 17 38
            Strand		 0 8 18 38
            Strand		 0 8 19 38
            Start		  2.5160588436072240e+02
            Stop		  8.7936267493209516e+02
            Start		  7.6789801932244818e+03
            Stop		  8.5057673856740621e+03
            Strand		 0 8 20 38
            Strand		 0 8 21 38
            Strand		 0 8 22 38
            Strand		 0 8 23 38
            Strand		 0 8 24 38
            Strand		 0 8 25 38
            Strand		 0 8 26 38
            Strand		 0 8 27 38
            Strand		 0 8 28 38
            Strand		 0 8 29 38
            Strand		 0 8 30 38
            Strand		 0 8 31 38
            Strand		 0 8 32 38
            Strand		 0 8 33 38
            Start		  3.1342835997522292e+02
            Stop		  8.7936267493209516e+02
            Start		  7.9984858956004409e+03
            Stop		  8.5057673856740621e+03
            Strand		 0 8 34 38
            Start		  0.0000000000000000e+00
            Stop		  6.0887222809569755e+02
            Start		  7.0254616436788892e+03
            Stop		  7.8605897165860306e+03
            Strand		 0 8 35 38
            Strand		 0 8 36 38
            Strand		 0 8 37 38
            Strand		 0 9 1 38
            Start		  5.8163003466907685e+03
            Stop		  7.2545007899825750e+03
            Start		  1.3195214625355176e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 9 2 38
            Strand		 0 9 3 38
            Strand		 0 9 4 38
            Start		  6.9494861761869633e+03
            Stop		  7.2545007899825750e+03
            Start		  1.4342090931196422e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 9 5 38
            Start		  5.8163003466907685e+03
            Stop		  6.9715338193774678e+03
            Start		  1.3195214625355176e+04
            Stop		  1.4329467816840986e+04
            Strand		 0 9 6 38
            Strand		 0 9 7 38
            Strand		 0 9 8 38
            Strand		 0 9 9 38
            Strand		 0 9 10 38
            Strand		 0 9 11 38
            Strand		 0 9 12 38
            Strand		 0 9 13 38
            Strand		 0 9 14 38
            Start		  6.4155613241792025e+03
            Stop		  7.2545007899825750e+03
            Start		  1.4208013931068119e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 9 15 38
            Start		  5.8163003466907685e+03
            Stop		  6.6998599859260812e+03
            Start		  1.3195214625355176e+04
            Stop		  1.4055829240497009e+04
            Strand		 0 9 16 38
            Strand		 0 9 17 38
            Strand		 0 9 18 38
            Strand		 0 9 19 38
            Strand		 0 9 20 38
            Start		  1.4077666307414933e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 9 21 38
            Strand		 0 9 22 38
            Strand		 0 9 23 38
            Strand		 0 9 24 38
            Strand		 0 9 25 38
            Strand		 0 9 26 38
            Strand		 0 9 27 38
            Strand		 0 9 28 38
            Strand		 0 9 29 38
            Strand		 0 9 30 38
            Strand		 0 9 31 38
            Strand		 0 9 32 38
            Strand		 0 9 33 38
            Strand		 0 9 34 38
            Start		  6.6718401863873032e+03
            Stop		  7.2545007899825750e+03
            Strand		 0 9 35 38
            Start		  5.8163003466907685e+03
            Stop		  6.6857287417851185e+03
            Strand		 0 9 36 38
            Strand		 0 9 37 38
            Strand		 0 10 1 38
            Start		  4.6175419835582597e+03
            Stop		  5.9991522583146361e+03
            Start		  1.1946835877398889e+04
            Stop		  1.3493232751408581e+04
            Strand		 0 10 2 38
            Strand		 0 10 3 38
            Strand		 0 10 4 38
            Strand		 0 10 5 38
            Start		  5.7314499545613435e+03
            Stop		  5.9991522583146361e+03
            Start		  1.3098732694737739e+04
            Stop		  1.3493232751408581e+04
            Strand		 0 10 6 38
            Start		  4.6175419835582597e+03
            Stop		  5.6400221246945530e+03
            Start		  1.1946835877398889e+04
            Stop		  1.3143008310961255e+04
            Strand		 0 10 7 38
            Strand		 0 10 8 38
            Strand		 0 10 9 38
            Strand		 0 10 10 38
            Strand		 0 10 11 38
            Start		  4.6175419835582597e+03
            Stop		  4.7424042064040304e+03
            Strand		 0 10 12 38
            Strand		 0 10 13 38
            Strand		 0 10 14 38
            Strand		 0 10 15 38
            Start		  5.1628713132146759e+03
            Stop		  5.9991522583146361e+03
            Start		  1.2866592998418269e+04
            Stop		  1.3493232751408581e+04
            Strand		 0 10 16 38
            Start		  4.6175419835582597e+03
            Stop		  5.4589789181041133e+03
            Start		  1.1946835877398889e+04
            Stop		  1.2839834763058099e+04
            Strand		 0 10 17 38
            Strand		 0 10 18 38
            Strand		 0 10 19 38
            Strand		 0 10 20 38
            Start		  1.3291112182883156e+04
            Stop		  1.3493232751408581e+04
            Strand		 0 10 21 38
            Start		  1.2891201155331368e+04
            Stop		  1.3156788514549589e+04
            Strand		 0 10 22 38
            Strand		 0 10 23 38
            Strand		 0 10 24 38
            Strand		 0 10 25 38
            Strand		 0 10 26 38
            Strand		 0 10 27 38
            Strand		 0 10 28 38
            Strand		 0 10 29 38
            Strand		 0 10 30 38
            Strand		 0 10 31 38
            Strand		 0 10 32 38
            Strand		 0 10 33 38
            Strand		 0 10 34 38
            Strand		 0 10 35 38
            Start		  5.3725548938167321e+03
            Stop		  5.9991522583146361e+03
            Strand		 0 10 36 38
            Start		  4.6175419835582597e+03
            Stop		  5.4936786264992807e+03
            Strand		 0 10 37 38
            Strand		 0 11 1 38
            Start		  3.4309256128034185e+03
            Stop		  4.7378757994342877e+03
            Start		  1.0705129896228675e+04
            Stop		  1.2247212109943375e+04
            Strand		 0 11 2 38
            Strand		 0 11 3 38
            Strand		 0 11 4 38
            Strand		 0 11 5 38
            Strand		 0 11 6 38
            Start		  4.5181635853688858e+03
            Stop		  4.7378757994342877e+03
            Start		  1.1860574866344492e+04
            Stop		  1.2247212109943375e+04
            Strand		 0 11 7 38
            Start		  3.4309256128034185e+03
            Stop		  4.2855809953814642e+03
            Start		  1.0705129896228675e+04
            Stop		  1.1956550011283123e+04
            Strand		 0 11 8 38
            Strand		 0 11 9 38
            Strand		 0 11 10 38
            Strand		 0 11 11 38
            Start		  4.4674510747356926e+03
            Stop		  4.7378757994342877e+03
            Strand		 0 11 12 38
            Start		  3.4309256128034185e+03
            Stop		  3.6155442936893587e+03
            Strand		 0 11 13 38
            Strand		 0 11 14 38
            Strand		 0 11 15 38
            Strand		 0 11 16 38
            Start		  3.9202250979255800e+03
            Stop		  4.7378757994342877e+03
            Start		  1.1545819764440092e+04
            Stop		  1.2247212109943375e+04
            Strand		 0 11 17 38
            Start		  3.4309256128034185e+03
            Stop		  4.2124208437663774e+03
            Start		  1.0705129896228675e+04
            Stop		  1.1619568004013641e+04
            Strand		 0 11 18 38
            Strand		 0 11 19 38
            Strand		 0 11 20 38
            Strand		 0 11 21 38
            Start		  1.2104650667424896e+04
            Stop		  1.2247212109943375e+04
            Strand		 0 11 22 38
            Start		  1.1704744571110872e+04
            Stop		  1.1844308993035040e+04
            Strand		 0 11 23 38
            Strand		 0 11 24 38
            Strand		 0 11 25 38
            Strand		 0 11 26 38
            Strand		 0 11 27 38
            Strand		 0 11 28 38
            Strand		 0 11 29 38
            Strand		 0 11 30 38
            Strand		 0 11 31 38
            Strand		 0 11 32 38
            Strand		 0 11 33 38
            Strand		 0 11 34 38
            Strand		 0 11 35 38
            Strand		 0 11 36 38
            Start		  4.0912143238830004e+03
            Stop		  4.7378757994342877e+03
            Strand		 0 11 37 38
            Start		  3.4309256128034185e+03
            Stop		  4.2883771574587045e+03
            Strand		 0 12 1 38
            Start		  2.2591635074177866e+03
            Stop		  3.4679277642550774e+03
            Start		  9.4706201376317913e+03
            Stop		  1.1001155927188873e+04
            Strand		 0 12 2 38
            Start		  2.2591635074177866e+03
            Stop		  2.9019829226343904e+03
            Start		  9.4706201376317913e+03
            Stop		  1.0770088080470883e+04
            Strand		 0 12 3 38
            Strand		 0 12 4 38
            Strand		 0 12 5 38
            Strand		 0 12 6 38
            Strand		 0 12 7 38
            Start		  3.3113224481488905e+03
            Stop		  3.4679277642550774e+03
            Start		  1.0626930780401957e+04
            Stop		  1.1001155927188873e+04
            Strand		 0 12 8 38
            Strand		 0 12 9 38
            Strand		 0 12 10 38
            Strand		 0 12 11 38
            Strand		 0 12 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.4679277642550774e+03
            Strand		 0 12 13 38
            Start		  2.2591635074177866e+03
            Stop		  2.4312549985318733e+03
            Strand		 0 12 14 38
            Strand		 0 12 15 38
            Strand		 0 12 16 38
            Strand		 0 12 17 38
            Start		  2.6873265302893583e+03
            Stop		  3.4679277642550774e+03
            Start		  1.0242478496301919e+04
            Stop		  1.1001155927188873e+04
            Strand		 0 12 18 38
            Start		  2.2591635074177866e+03
            Stop		  2.9590350715293180e+03
            Start		  9.4706201376317913e+03
            Stop		  1.0395472758638833e+04
            Strand		 0 12 19 38
            Strand		 0 12 20 38
            Strand		 0 12 21 38
            Strand		 0 12 22 38
            Start		  1.0918191158066194e+04
            Stop		  1.1001155927188873e+04
            Strand		 0 12 23 38
            Strand		 0 12 24 38
            Strand		 0 12 25 38
            Strand		 0 12 26 38
            Strand		 0 12 27 38
            Strand		 0 12 28 38
            Strand		 0 12 29 38
            Strand		 0 12 30 38
            Strand		 0 12 31 38
            Strand		 0 12 32 38
            Start		  2.2591635074177866e+03
            Stop		  3.0718833329730119e+03
            Start		  9.4706201376317913e+03
            Stop		  1.0112033488972374e+04
            Strand		 0 12 33 38
            Strand		 0 12 34 38
            Strand		 0 12 35 38
            Strand		 0 12 36 38
            Strand		 0 12 37 38
            Start		  2.8227895322559370e+03
            Stop		  3.4679277642550774e+03
            Strand		 0 13 1 38
            Start		  1.1068795058812871e+03
            Stop		  2.1847497687874638e+03
            Start		  8.2438467862825855e+03
            Stop		  9.7543013378113592e+03
            Strand		 0 13 2 38
            Start		  2.1149632195889831e+03
            Stop		  2.1847497687874638e+03
            Start		  9.3973319735515688e+03
            Stop		  9.7543013378113592e+03
            Strand		 0 13 3 38
            Start		  1.1068795058812871e+03
            Stop		  1.4747720591339571e+03
            Start		  8.2438467862825855e+03
            Stop		  9.5801990395805078e+03
            Strand		 0 13 4 38
            Strand		 0 13 5 38
            Strand		 0 13 6 38
            Strand		 0 13 7 38
            Strand		 0 13 8 38
            Start		  1.1068795058812871e+03
            Stop		  1.2303921025076613e+03
            Strand		 0 13 9 38
            Strand		 0 13 10 38
            Strand		 0 13 11 38
            Strand		 0 13 12 38
            Strand		 0 13 13 38
            Start		  1.5715472223761499e+03
            Stop		  2.1847497687874638e+03
            Strand		 0 13 14 38
            Strand		 0 13 15 38
            Strand		 0 13 16 38
            Strand		 0 13 17 38
            Strand		 0 13 18 38
            Start		  1.4642517209886255e+03
            Stop		  2.1847497687874638e+03
            Start		  8.9541496902931121e+03
            Stop		  9.7543013378113592e+03
            Strand		 0 13 19 38
            Start		  1.1068795058812871e+03
            Stop		  1.6972070271340531e+03
            Start		  8.2438467862825855e+03
            Stop		  9.1676325534052175e+03
            Strand		 0 13 20 38
            Strand		 0 13 21 38
            Strand		 0 13 22 38
            Strand		 0 13 23 38
            Start		  9.7317263654219078e+03
            Stop		  9.7543013378113592e+03
            Strand		 0 13 24 38
            Strand		 0 13 25 38
            Strand		 0 13 26 38
            Strand		 0 13 27 38
            Strand		 0 13 28 38
            Strand		 0 13 29 38
            Strand		 0 13 30 38
            Strand		 0 13 31 38
            Strand		 0 13 32 38
            Start		  1.5642151592087109e+03
            Stop		  2.1847497687874638e+03
            Start		  9.3759467997114352e+03
            Stop		  9.7543013378113592e+03
            Strand		 0 13 33 38
            Start		  1.1068795058812871e+03
            Stop		  1.8452481520569190e+03
            Start		  8.2438467862825855e+03
            Stop		  9.0100451414278923e+03
            Strand		 0 13 34 38
            Strand		 0 13 35 38
            Strand		 0 13 36 38
            Strand		 0 13 37 38
            Strand		 0 14 1 38
            Start		  1.4039192938633783e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 2 38
            Strand		 0 14 3 38
            Strand		 0 14 4 38
            Start		  1.4342090931196422e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 5 38
            Start		  1.4039192938633783e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 6 38
            Strand		 0 14 7 38
            Strand		 0 14 8 38
            Strand		 0 14 9 38
            Strand		 0 14 10 38
            Strand		 0 14 11 38
            Strand		 0 14 12 38
            Strand		 0 14 13 38
            Strand		 0 14 14 38
            Start		  1.4208013931068119e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 15 38
            Start		  1.4039192938633783e+04
            Stop		  1.4055829240497009e+04
            Strand		 0 14 16 38
            Strand		 0 14 17 38
            Strand		 0 14 18 38
            Strand		 0 14 19 38
            Strand		 0 14 20 38
            Start		  1.4039192938633783e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 21 38
            Strand		 0 14 22 38
            Strand		 0 14 23 38
            Strand		 0 14 24 38
            Strand		 0 14 25 38
            Start		  1.4287797392503802e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 14 26 38
            Strand		 0 14 27 38
            Strand		 0 14 28 38
            Strand		 0 14 29 38
            Strand		 0 14 30 38
            Strand		 0 14 31 38
            Strand		 0 14 32 38
            Strand		 0 14 33 38
            Strand		 0 14 34 38
            Strand		 0 14 35 38
            Strand		 0 14 36 38
            Strand		 0 14 37 38
            Strand		 0 15 1 38
            Start		  1.2987103309810953e+04
            Stop		  1.3524675923627279e+04
            Strand		 0 15 2 38
            Strand		 0 15 3 38
            Strand		 0 15 4 38
            Strand		 0 15 5 38
            Start		  1.3098732694737739e+04
            Stop		  1.3524675923627279e+04
            Strand		 0 15 6 38
            Start		  1.2987103309810953e+04
            Stop		  1.3390358615486637e+04
            Strand		 0 15 7 38
            Strand		 0 15 8 38
            Strand		 0 15 9 38
            Strand		 0 15 10 38
            Strand		 0 15 11 38
            Strand		 0 15 12 38
            Strand		 0 15 13 38
            Strand		 0 15 14 38
            Strand		 0 15 15 38
            Start		  1.2987103309810953e+04
            Stop		  1.3524675923627279e+04
            Strand		 0 15 16 38
            Strand		 0 15 17 38
            Strand		 0 15 18 38
            Strand		 0 15 19 38
            Strand		 0 15 20 38
            Start		  1.3089338568703177e+04
            Stop		  1.3524675923627279e+04
            Strand		 0 15 21 38
            Start		  1.2987103309810953e+04
            Stop		  1.3156788514549589e+04
            Strand		 0 15 22 38
            Strand		 0 15 23 38
            Strand		 0 15 24 38
            Strand		 0 15 25 38
            Strand		 0 15 26 38
            Strand		 0 15 27 38
            Strand		 0 15 28 38
            Strand		 0 15 29 38
            Strand		 0 15 30 38
            Strand		 0 15 31 38
            Strand		 0 15 32 38
            Strand		 0 15 33 38
            Strand		 0 15 34 38
            Strand		 0 15 35 38
            Strand		 0 15 36 38
            Strand		 0 15 37 38
            Strand		 0 16 1 38
            Strand		 0 16 2 38
            Strand		 0 16 3 38
            Strand		 0 16 4 38
            Strand		 0 16 5 38
            Strand		 0 16 6 38
            Strand		 0 16 7 38
            Strand		 0 16 8 38
            Strand		 0 16 9 38
            Strand		 0 16 10 38
            Strand		 0 16 11 38
            Strand		 0 16 12 38
            Strand		 0 16 13 38
            Strand		 0 16 14 38
            Strand		 0 16 15 38
            Strand		 0 16 16 38
            Strand		 0 16 17 38
            Strand		 0 16 18 38
            Strand		 0 16 19 38
            Strand		 0 16 20 38
            Strand		 0 16 21 38
            Strand		 0 16 22 38
            Strand		 0 16 23 38
            Strand		 0 16 24 38
            Strand		 0 16 25 38
            Strand		 0 16 26 38
            Strand		 0 16 27 38
            Strand		 0 16 28 38
            Strand		 0 16 29 38
            Strand		 0 16 30 38
            Strand		 0 16 31 38
            Strand		 0 16 32 38
            Strand		 0 16 33 38
            Strand		 0 16 34 38
            Strand		 0 16 35 38
            Strand		 0 16 36 38
            Strand		 0 16 37 38
            Strand		 0 17 1 38
            Strand		 0 17 2 38
            Strand		 0 17 3 38
            Strand		 0 17 4 38
            Strand		 0 17 5 38
            Strand		 0 17 6 38
            Strand		 0 17 7 38
            Strand		 0 17 8 38
            Strand		 0 17 9 38
            Strand		 0 17 10 38
            Strand		 0 17 11 38
            Strand		 0 17 12 38
            Strand		 0 17 13 38
            Strand		 0 17 14 38
            Strand		 0 17 15 38
            Strand		 0 17 16 38
            Strand		 0 17 17 38
            Strand		 0 17 18 38
            Strand		 0 17 19 38
            Strand		 0 17 20 38
            Strand		 0 17 21 38
            Strand		 0 17 22 38
            Strand		 0 17 23 38
            Strand		 0 17 24 38
            Strand		 0 17 25 38
            Strand		 0 17 26 38
            Strand		 0 17 27 38
            Strand		 0 17 28 38
            Strand		 0 17 29 38
            Strand		 0 17 30 38
            Strand		 0 17 31 38
            Strand		 0 17 32 38
            Strand		 0 17 33 38
            Strand		 0 17 34 38
            Strand		 0 17 35 38
            Strand		 0 17 36 38
            Strand		 0 17 37 38
            Strand		 0 18 1 38
            Strand		 0 18 2 38
            Strand		 0 18 3 38
            Strand		 0 18 4 38
            Strand		 0 18 5 38
            Strand		 0 18 6 38
            Strand		 0 18 7 38
            Strand		 0 18 8 38
            Strand		 0 18 9 38
            Strand		 0 18 10 38
            Strand		 0 18 11 38
            Strand		 0 18 12 38
            Strand		 0 18 13 38
            Strand		 0 18 14 38
            Strand		 0 18 15 38
            Strand		 0 18 16 38
            Strand		 0 18 17 38
            Strand		 0 18 18 38
            Strand		 0 18 19 38
            Strand		 0 18 20 38
            Strand		 0 18 21 38
            Strand		 0 18 22 38
            Strand		 0 18 23 38
            Strand		 0 18 24 38
            Strand		 0 18 25 38
            Strand		 0 18 26 38
            Strand		 0 18 27 38
            Strand		 0 18 28 38
            Strand		 0 18 29 38
            Strand		 0 18 30 38
            Strand		 0 18 31 38
            Strand		 0 18 32 38
            Strand		 0 18 33 38
            Strand		 0 18 34 38
            Strand		 0 18 35 38
            Strand		 0 18 36 38
            Strand		 0 18 37 38
            Strand		 0 19 1 38
            Strand		 0 19 2 38
            Strand		 0 19 3 38
            Strand		 0 19 4 38
            Strand		 0 19 5 38
            Strand		 0 19 6 38
            Strand		 0 19 7 38
            Strand		 0 19 8 38
            Strand		 0 19 9 38
            Strand		 0 19 10 38
            Strand		 0 19 11 38
            Strand		 0 19 12 38
            Strand		 0 19 13 38
            Strand		 0 19 14 38
            Strand		 0 19 15 38
            Strand		 0 19 16 38
            Strand		 0 19 17 38
            Strand		 0 19 18 38
            Strand		 0 19 19 38
            Strand		 0 19 20 38
            Strand		 0 19 21 38
            Strand		 0 19 22 38
            Strand		 0 19 23 38
            Strand		 0 19 24 38
            Strand		 0 19 25 38
            Strand		 0 19 26 38
            Strand		 0 19 27 38
            Strand		 0 19 28 38
            Strand		 0 19 29 38
            Strand		 0 19 30 38
            Strand		 0 19 31 38
            Strand		 0 19 32 38
            Strand		 0 19 33 38
            Strand		 0 19 34 38
            Strand		 0 19 35 38
            Strand		 0 19 36 38
            Strand		 0 19 37 38
            Strand		 0 20 1 38
            Strand		 0 20 2 38
            Strand		 0 20 3 38
            Strand		 0 20 4 38
            Strand		 0 20 5 38
            Strand		 0 20 6 38
            Strand		 0 20 7 38
            Strand		 0 20 8 38
            Strand		 0 20 9 38
            Strand		 0 20 10 38
            Strand		 0 20 11 38
            Strand		 0 20 12 38
            Strand		 0 20 13 38
            Strand		 0 20 14 38
            Strand		 0 20 15 38
            Strand		 0 20 16 38
            Strand		 0 20 17 38
            Strand		 0 20 18 38
            Strand		 0 20 19 38
            Strand		 0 20 20 38
            Strand		 0 20 21 38
            Strand		 0 20 22 38
            Strand		 0 20 23 38
            Strand		 0 20 24 38
            Strand		 0 20 25 38
            Strand		 0 20 26 38
            Strand		 0 20 27 38
            Strand		 0 20 28 38
            Strand		 0 20 29 38
            Strand		 0 20 30 38
            Strand		 0 20 31 38
            Strand		 0 20 32 38
            Strand		 0 20 33 38
            Strand		 0 20 34 38
            Strand		 0 20 35 38
            Strand		 0 20 36 38
            Strand		 0 20 37 38
            Strand		 0 21 1 38
            Strand		 0 21 2 38
            Strand		 0 21 3 38
            Strand		 0 21 4 38
            Strand		 0 21 5 38
            Strand		 0 21 6 38
            Strand		 0 21 7 38
            Strand		 0 21 8 38
            Strand		 0 21 9 38
            Strand		 0 21 10 38
            Strand		 0 21 11 38
            Strand		 0 21 12 38
            Strand		 0 21 13 38
            Strand		 0 21 14 38
            Strand		 0 21 15 38
            Strand		 0 21 16 38
            Strand		 0 21 17 38
            Strand		 0 21 18 38
            Strand		 0 21 19 38
            Strand		 0 21 20 38
            Strand		 0 21 21 38
            Strand		 0 21 22 38
            Strand		 0 21 23 38
            Strand		 0 21 24 38
            Strand		 0 21 25 38
            Strand		 0 21 26 38
            Strand		 0 21 27 38
            Strand		 0 21 28 38
            Strand		 0 21 29 38
            Strand		 0 21 30 38
            Strand		 0 21 31 38
            Strand		 0 21 32 38
            Strand		 0 21 33 38
            Strand		 0 21 34 38
            Strand		 0 21 35 38
            Strand		 0 21 36 38
            Strand		 0 21 37 38
            Strand		 0 22 1 38
            Strand		 0 22 2 38
            Strand		 0 22 3 38
            Strand		 0 22 4 38
            Strand		 0 22 5 38
            Strand		 0 22 6 38
            Strand		 0 22 7 38
            Strand		 0 22 8 38
            Strand		 0 22 9 38
            Strand		 0 22 10 38
            Strand		 0 22 11 38
            Strand		 0 22 12 38
            Strand		 0 22 13 38
            Strand		 0 22 14 38
            Strand		 0 22 15 38
            Strand		 0 22 16 38
            Strand		 0 22 17 38
            Strand		 0 22 18 38
            Strand		 0 22 19 38
            Strand		 0 22 20 38
            Strand		 0 22 21 38
            Strand		 0 22 22 38
            Strand		 0 22 23 38
            Strand		 0 22 24 38
            Strand		 0 22 25 38
            Strand		 0 22 26 38
            Strand		 0 22 27 38
            Strand		 0 22 28 38
            Strand		 0 22 29 38
            Strand		 0 22 30 38
            Strand		 0 22 31 38
            Strand		 0 22 32 38
            Strand		 0 22 33 38
            Strand		 0 22 34 38
            Strand		 0 22 35 38
            Strand		 0 22 36 38
            Strand		 0 22 37 38
            Strand		 0 23 1 38
            Strand		 0 23 2 38
            Strand		 0 23 3 38
            Strand		 0 23 4 38
            Strand		 0 23 5 38
            Strand		 0 23 6 38
            Strand		 0 23 7 38
            Strand		 0 23 8 38
            Strand		 0 23 9 38
            Strand		 0 23 10 38
            Strand		 0 23 11 38
            Strand		 0 23 12 38
            Strand		 0 23 13 38
            Strand		 0 23 14 38
            Strand		 0 23 15 38
            Strand		 0 23 16 38
            Strand		 0 23 17 38
            Strand		 0 23 18 38
            Strand		 0 23 19 38
            Strand		 0 23 20 38
            Strand		 0 23 21 38
            Strand		 0 23 22 38
            Strand		 0 23 23 38
            Strand		 0 23 24 38
            Strand		 0 23 25 38
            Strand		 0 23 26 38
            Strand		 0 23 27 38
            Strand		 0 23 28 38
            Strand		 0 23 29 38
            Strand		 0 23 30 38
            Strand		 0 23 31 38
            Strand		 0 23 32 38
            Strand		 0 23 33 38
            Strand		 0 23 34 38
            Strand		 0 23 35 38
            Strand		 0 23 36 38
            Strand		 0 23 37 38
            Strand		 0 24 1 38
            Strand		 0 24 2 38
            Strand		 0 24 3 38
            Strand		 0 24 4 38
            Strand		 0 24 5 38
            Strand		 0 24 6 38
            Strand		 0 24 7 38
            Strand		 0 24 8 38
            Strand		 0 24 9 38
            Strand		 0 24 10 38
            Strand		 0 24 11 38
            Strand		 0 24 12 38
            Strand		 0 24 13 38
            Strand		 0 24 14 38
            Strand		 0 24 15 38
            Strand		 0 24 16 38
            Strand		 0 24 17 38
            Strand		 0 24 18 38
            Strand		 0 24 19 38
            Strand		 0 24 20 38
            Strand		 0 24 21 38
            Strand		 0 24 22 38
            Strand		 0 24 23 38
            Strand		 0 24 24 38
            Strand		 0 24 25 38
            Strand		 0 24 26 38
            Strand		 0 24 27 38
            Strand		 0 24 28 38
            Strand		 0 24 29 38
            Strand		 0 24 30 38
            Strand		 0 24 31 38
            Strand		 0 24 32 38
            Strand		 0 24 33 38
            Strand		 0 24 34 38
            Strand		 0 24 35 38
            Strand		 0 24 36 38
            Strand		 0 24 37 38
            Strand		 0 25 1 38
            Strand		 0 25 2 38
            Strand		 0 25 3 38
            Strand		 0 25 4 38
            Strand		 0 25 5 38
            Strand		 0 25 6 38
            Strand		 0 25 7 38
            Strand		 0 25 8 38
            Strand		 0 25 9 38
            Strand		 0 25 10 38
            Strand		 0 25 11 38
            Strand		 0 25 12 38
            Strand		 0 25 13 38
            Strand		 0 25 14 38
            Strand		 0 25 15 38
            Strand		 0 25 16 38
            Strand		 0 25 17 38
            Strand		 0 25 18 38
            Strand		 0 25 19 38
            Strand		 0 25 20 38
            Strand		 0 25 21 38
            Strand		 0 25 22 38
            Strand		 0 25 23 38
            Strand		 0 25 24 38
            Strand		 0 25 25 38
            Strand		 0 25 26 38
            Strand		 0 25 27 38
            Strand		 0 25 28 38
            Strand		 0 25 29 38
            Strand		 0 25 30 38
            Strand		 0 25 31 38
            Strand		 0 25 32 38
            Strand		 0 25 33 38
            Strand		 0 25 34 38
            Strand		 0 25 35 38
            Strand		 0 25 36 38
            Strand		 0 25 37 38
            Strand		 0 26 1 38
            Start		  1.3327097304195877e+03
            Stop		  2.7000585722922528e+03
            Strand		 0 26 2 38
            Start		  2.1149632195889831e+03
            Stop		  2.3350148878263462e+03
            Strand		 0 26 3 38
            Strand		 0 26 4 38
            Strand		 0 26 5 38
            Strand		 0 26 6 38
            Strand		 0 26 7 38
            Strand		 0 26 8 38
            Strand		 0 26 9 38
            Strand		 0 26 10 38
            Strand		 0 26 11 38
            Strand		 0 26 12 38
            Strand		 0 26 13 38
            Start		  1.5715472223761499e+03
            Stop		  2.4312549985318733e+03
            Strand		 0 26 14 38
            Strand		 0 26 15 38
            Strand		 0 26 16 38
            Strand		 0 26 17 38
            Start		  2.6873265302893583e+03
            Stop		  2.7000585722922528e+03
            Strand		 0 26 18 38
            Strand		 0 26 19 38
            Strand		 0 26 20 38
            Strand		 0 26 21 38
            Strand		 0 26 22 38
            Strand		 0 26 23 38
            Strand		 0 26 24 38
            Strand		 0 26 25 38
            Strand		 0 26 26 38
            Strand		 0 26 27 38
            Strand		 0 26 28 38
            Strand		 0 26 29 38
            Strand		 0 26 30 38
            Strand		 0 26 31 38
            Strand		 0 26 32 38
            Start		  1.5642151592087109e+03
            Stop		  2.7000585722922528e+03
            Strand		 0 26 33 38
            Strand		 0 26 34 38
            Strand		 0 26 35 38
            Strand		 0 26 36 38
            Strand		 0 26 37 38
            Strand		 0 27 1 38
            Start		  7.6278666491454089e+01
            Stop		  1.5037233627480089e+03
            Start		  7.8387876892633976e+03
            Stop		  8.3632390478511479e+03
            Strand		 0 27 2 38
            Strand		 0 27 3 38
            Start		  9.4174925597403512e+02
            Stop		  1.1485537278510219e+03
            Start		  8.1715316984640694e+03
            Stop		  8.2673192677462630e+03
            Strand		 0 27 4 38
            Strand		 0 27 5 38
            Strand		 0 27 6 38
            Strand		 0 27 7 38
            Strand		 0 27 8 38
            Start		  1.9937662505776322e+02
            Stop		  1.2303921025076613e+03
            Strand		 0 27 9 38
            Strand		 0 27 10 38
            Strand		 0 27 11 38
            Strand		 0 27 12 38
            Strand		 0 27 13 38
            Strand		 0 27 14 38
            Strand		 0 27 15 38
            Strand		 0 27 16 38
            Strand		 0 27 17 38
            Strand		 0 27 18 38
            Start		  1.4642517209886255e+03
            Stop		  1.5037233627480089e+03
            Strand		 0 27 19 38
            Strand		 0 27 20 38
            Strand		 0 27 21 38
            Strand		 0 27 22 38
            Strand		 0 27 23 38
            Strand		 0 27 24 38
            Strand		 0 27 25 38
            Strand		 0 27 26 38
            Strand		 0 27 27 38
            Strand		 0 27 28 38
            Strand		 0 27 29 38
            Strand		 0 27 30 38
            Strand		 0 27 31 38
            Strand		 0 27 32 38
            Strand		 0 27 33 38
            Start		  3.1342835997522292e+02
            Stop		  1.5037233627480089e+03
            Start		  7.9984858956004409e+03
            Stop		  8.3632390478511479e+03
            Strand		 0 27 34 38
            Strand		 0 27 35 38
            Strand		 0 27 36 38
            Strand		 0 27 37 38
            Strand		 0 28 1 38
            Start		  0.0000000000000000e+00
            Stop		  2.9666892066516317e+02
            Start		  6.4670457879412934e+03
            Stop		  7.3143636154904880e+03
            Strand		 0 28 2 38
            Strand		 0 28 3 38
            Strand		 0 28 4 38
            Start		  6.9494861761869633e+03
            Stop		  7.0808543253119988e+03
            Strand		 0 28 5 38
            Strand		 0 28 6 38
            Strand		 0 28 7 38
            Strand		 0 28 8 38
            Start		  1.9937662505776322e+02
            Stop		  2.9666892066516317e+02
            Strand		 0 28 9 38
            Start		  0.0000000000000000e+00
            Stop		  2.0948168724378579e+01
            Strand		 0 28 10 38
            Strand		 0 28 11 38
            Strand		 0 28 12 38
            Strand		 0 28 13 38
            Strand		 0 28 14 38
            Strand		 0 28 15 38
            Strand		 0 28 16 38
            Strand		 0 28 17 38
            Strand		 0 28 18 38
            Strand		 0 28 19 38
            Start		  2.5160588436072240e+02
            Stop		  2.9666892066516317e+02
            Strand		 0 28 20 38
            Strand		 0 28 21 38
            Strand		 0 28 22 38
            Strand		 0 28 23 38
            Strand		 0 28 24 38
            Strand		 0 28 25 38
            Strand		 0 28 26 38
            Strand		 0 28 27 38
            Strand		 0 28 28 38
            Strand		 0 28 29 38
            Strand		 0 28 30 38
            Strand		 0 28 31 38
            Strand		 0 28 32 38
            Strand		 0 28 33 38
            Strand		 0 28 34 38
            Start		  0.0000000000000000e+00
            Stop		  2.9666892066516317e+02
            Start		  6.6718401863873032e+03
            Stop		  7.3143636154904880e+03
            Strand		 0 28 35 38
            Strand		 0 28 36 38
            Strand		 0 28 37 38
            Strand		 0 29 1 38
            Start		  5.1547785566994662e+03
            Stop		  6.1990637566055138e+03
            Strand		 0 29 2 38
            Strand		 0 29 3 38
            Strand		 0 29 4 38
            Strand		 0 29 5 38
            Start		  5.7314499545613435e+03
            Stop		  5.8943940866317816e+03
            Strand		 0 29 6 38
            Strand		 0 29 7 38
            Strand		 0 29 8 38
            Strand		 0 29 9 38
            Strand		 0 29 10 38
            Strand		 0 29 11 38
            Strand		 0 29 12 38
            Strand		 0 29 13 38
            Strand		 0 29 14 38
            Strand		 0 29 15 38
            Strand		 0 29 16 38
            Strand		 0 29 17 38
            Strand		 0 29 18 38
            Strand		 0 29 19 38
            Strand		 0 29 20 38
            Strand		 0 29 21 38
            Strand		 0 29 22 38
            Strand		 0 29 23 38
            Strand		 0 29 24 38
            Strand		 0 29 25 38
            Strand		 0 29 26 38
            Strand		 0 29 27 38
            Strand		 0 29 28 38
            Strand		 0 29 29 38
            Strand		 0 29 30 38
            Strand		 0 29 31 38
            Strand		 0 29 32 38
            Strand		 0 29 33 38
            Strand		 0 29 34 38
            Strand		 0 29 35 38
            Start		  5.3725548938167321e+03
            Stop		  6.1990637566055138e+03
            Strand		 0 29 36 38
            Strand		 0 29 37 38
            Strand		 0 30 1 38
            Start		  3.8678624539798138e+03
            Stop		  5.0518726865566578e+03
            Strand		 0 30 2 38
            Strand		 0 30 3 38
            Strand		 0 30 4 38
            Strand		 0 30 5 38
            Strand		 0 30 6 38
            Start		  4.5181635853688858e+03
            Stop		  4.7079326203335795e+03
            Strand		 0 30 7 38
            Strand		 0 30 8 38
            Strand		 0 30 9 38
            Strand		 0 30 10 38
            Strand		 0 30 11 38
            Start		  4.4674510747356926e+03
            Stop		  4.7424042064040304e+03
            Strand		 0 30 12 38
            Strand		 0 30 13 38
            Strand		 0 30 14 38
            Strand		 0 30 15 38
            Strand		 0 30 16 38
            Strand		 0 30 17 38
            Strand		 0 30 18 38
            Strand		 0 30 19 38
            Strand		 0 30 20 38
            Strand		 0 30 21 38
            Strand		 0 30 22 38
            Strand		 0 30 23 38
            Strand		 0 30 24 38
            Strand		 0 30 25 38
            Strand		 0 30 26 38
            Strand		 0 30 27 38
            Strand		 0 30 28 38
            Strand		 0 30 29 38
            Strand		 0 30 30 38
            Strand		 0 30 31 38
            Strand		 0 30 32 38
            Strand		 0 30 33 38
            Strand		 0 30 34 38
            Strand		 0 30 35 38
            Strand		 0 30 36 38
            Start		  4.0912143238830004e+03
            Stop		  5.0518726865566578e+03
            Strand		 0 30 37 38
            Strand		 0 31 1 38
            Start		  2.5955660917811806e+03
            Stop		  3.8837808232651973e+03
            Strand		 0 31 2 38
            Strand		 0 31 3 38
            Strand		 0 31 4 38
            Strand		 0 31 5 38
            Strand		 0 31 6 38
            Strand		 0 31 7 38
            Start		  3.3113224481488905e+03
            Stop		  3.5214753011139278e+03
            Strand		 0 31 8 38
            Strand		 0 31 9 38
            Strand		 0 31 10 38
            Strand		 0 31 11 38
            Strand		 0 31 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.6155442936893587e+03
            Strand		 0 31 13 38
            Strand		 0 31 14 38
            Strand		 0 31 15 38
            Strand		 0 31 16 38
            Strand		 0 31 17 38
            Strand		 0 31 18 38
            Strand		 0 31 19 38
            Strand		 0 31 20 38
            Strand		 0 31 21 38
            Strand		 0 31 22 38
            Strand		 0 31 23 38
            Strand		 0 31 24 38
            Strand		 0 31 25 38
            Strand		 0 31 26 38
            Strand		 0 31 27 38
            Strand		 0 31 28 38
            Strand		 0 31 29 38
            Strand		 0 31 30 38
            Strand		 0 31 31 38
            Strand		 0 31 32 38
            Strand		 0 31 33 38
            Strand		 0 31 34 38
            Strand		 0 31 35 38
            Strand		 0 31 36 38
            Strand		 0 31 37 38
            Start		  2.8227895322559370e+03
            Stop		  3.8837808232651973e+03
            Strand		 0 32 1 38
            Start		  3.5500230427009524e+02
            Stop		  1.8436205957280954e+03
            Start		  7.8647684225200028e+03
            Stop		  9.4111302981512708e+03
            Strand		 0 32 2 38
            Start		  9.3973319735515688e+03
            Stop		  9.4111302981512708e+03
            Strand		 0 32 3 38
            Start		  9.4174925597403512e+02
            Stop		  1.4747720591339571e+03
            Start		  8.1715316984640694e+03
            Stop		  9.4111302981512708e+03
            Strand		 0 32 4 38
            Strand		 0 32 5 38
            Strand		 0 32 6 38
            Strand		 0 32 7 38
            Strand		 0 32 8 38
            Start		  3.5500230427009524e+02
            Stop		  1.2303921025076613e+03
            Strand		 0 32 9 38
            Strand		 0 32 10 38
            Strand		 0 32 11 38
            Strand		 0 32 12 38
            Strand		 0 32 13 38
            Start		  1.5715472223761499e+03
            Stop		  1.8436205957280954e+03
            Strand		 0 32 14 38
            Start		  7.8647684225200028e+03
            Stop		  7.9358847630052642e+03
            Strand		 0 32 15 38
            Strand		 0 32 16 38
            Strand		 0 32 17 38
            Strand		 0 32 18 38
            Start		  1.4642517209886255e+03
            Stop		  1.8436205957280954e+03
            Start		  8.9541496902931121e+03
            Stop		  9.4111302981512708e+03
            Strand		 0 32 19 38
            Start		  1.0238222115772224e+03
            Stop		  1.6972070271340531e+03
            Start		  8.1425851766983296e+03
            Stop		  9.1676325534052175e+03
            Strand		 0 32 20 38
            Strand		 0 32 21 38
            Strand		 0 32 22 38
            Strand		 0 32 23 38
            Strand		 0 32 24 38
            Strand		 0 32 25 38
            Strand		 0 32 26 38
            Strand		 0 32 27 38
            Strand		 0 32 28 38
            Strand		 0 32 29 38
            Strand		 0 32 30 38
            Strand		 0 32 31 38
            Strand		 0 32 32 38
            Start		  1.5642151592087109e+03
            Stop		  1.8436205957280954e+03
            Start		  9.3759467997114352e+03
            Stop		  9.4111302981512708e+03
            Strand		 0 32 33 38
            Start		  3.5500230427009524e+02
            Stop		  1.8436205957280954e+03
            Start		  7.9984858956004409e+03
            Stop		  9.0100451414278923e+03
            Strand		 0 32 34 38
            Strand		 0 32 35 38
            Strand		 0 32 36 38
            Strand		 0 32 37 38
            Strand		 0 33 1 38
            Start		  0.0000000000000000e+00
            Stop		  5.7015088366838427e+02
            Start		  6.6181271272224758e+03
            Stop		  8.1629296924839809e+03
            Start		  1.4103700216068946e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 33 2 38
            Strand		 0 33 3 38
            Strand		 0 33 4 38
            Start		  6.9494861761869633e+03
            Stop		  8.1629296924839809e+03
            Start		  1.4342090931196422e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 33 5 38
            Strand		 0 33 6 38
            Strand		 0 33 7 38
            Strand		 0 33 8 38
            Start		  1.9937662505776322e+02
            Stop		  5.7015088366838427e+02
            Strand		 0 33 9 38
            Start		  0.0000000000000000e+00
            Stop		  2.0948168724378579e+01
            Strand		 0 33 10 38
            Strand		 0 33 11 38
            Strand		 0 33 12 38
            Strand		 0 33 13 38
            Strand		 0 33 14 38
            Start		  0.0000000000000000e+00
            Stop		  4.2458514658473865e+02
            Start		  6.9561223458996155e+03
            Stop		  7.9358847630052642e+03
            Start		  1.4208013931068119e+04
            Stop		  1.4400000000000000e+04
            Strand		 0 33 15 38
            Start		  6.6721531489400231e+03
            Stop		  6.6998599859260812e+03
            Strand		 0 33 16 38
            Strand		 0 33 17 38
            Strand		 0 33 18 38
            Strand		 0 33 19 38
            Start		  2.5160588436072240e+02
            Stop		  5.7015088366838427e+02
            Start		  7.6789801932244818e+03
            Stop		  8.1629296924839809e+03
            Strand		 0 33 20 38
            Strand		 0 33 21 38
            Strand		 0 33 22 38
            Strand		 0 33 23 38
            Strand		 0 33 24 38
            Strand		 0 33 25 38
            Strand		 0 33 26 38
            Strand		 0 33 27 38
            Strand		 0 33 28 38
            Strand		 0 33 29 38
            Strand		 0 33 30 38
            Strand		 0 33 31 38
            Strand		 0 33 32 38
            Strand		 0 33 33 38
            Start		  3.1342835997522292e+02
            Stop		  5.7015088366838427e+02
            Start		  7.9984858956004409e+03
            Stop		  8.1629296924839809e+03
            Strand		 0 33 34 38
            Start		  0.0000000000000000e+00
            Stop		  5.7015088366838427e+02
            Start		  6.6718401863873032e+03
            Stop		  7.8605897165860306e+03
            Strand		 0 33 35 38
            Strand		 0 33 36 38
            Strand		 0 33 37 38
            Strand		 0 34 1 38
            Start		  5.3702243646325296e+03
            Stop		  6.9085746925344592e+03
            Start		  1.2852336113489375e+04
            Stop		  1.4331598984558850e+04
            Strand		 0 34 2 38
            Strand		 0 34 3 38
            Strand		 0 34 4 38
            Strand		 0 34 5 38
            Start		  5.7314499545613435e+03
            Stop		  6.9085746925344592e+03
            Start		  1.3098732694737739e+04
            Stop		  1.4331598984558850e+04
            Strand		 0 34 6 38
            Strand		 0 34 7 38
            Strand		 0 34 8 38
            Strand		 0 34 9 38
            Strand		 0 34 10 38
            Strand		 0 34 11 38
            Strand		 0 34 12 38
            Strand		 0 34 13 38
            Strand		 0 34 14 38
            Start		  6.4155613241792025e+03
            Stop		  6.9085746925344592e+03
            Start		  1.4208013931068119e+04
            Stop		  1.4331598984558850e+04
            Strand		 0 34 15 38
            Start		  5.7696624691825000e+03
            Stop		  6.6998599859260812e+03
            Start		  1.2888426734367127e+04
            Stop		  1.4055829240497009e+04
            Strand		 0 34 16 38
            Strand		 0 34 17 38
            Strand		 0 34 18 38
            Strand		 0 34 19 38
            Strand		 0 34 20 38
            Strand		 0 34 21 38
            Strand		 0 34 22 38
            Strand		 0 34 23 38
            Strand		 0 34 24 38
            Strand		 0 34 25 38
            Start		  1.4287797392503802e+04
            Stop		  1.4331598984558850e+04
            Strand		 0 34 26 38
            Strand		 0 34 27 38
            Strand		 0 34 28 38
            Strand		 0 34 29 38
            Strand		 0 34 30 38
            Strand		 0 34 31 38
            Strand		 0 34 32 38
            Strand		 0 34 33 38
            Strand		 0 34 34 38
            Start		  6.6718401863873032e+03
            Stop		  6.9085746925344592e+03
            Strand		 0 34 35 38
            Start		  5.3725548938167321e+03
            Stop		  6.6857287417851185e+03
            Strand		 0 34 36 38
            Strand		 0 34 37 38
            Strand		 0 35 1 38
            Start		  4.1204676610681945e+03
            Stop		  5.6486717057880487e+03
            Start		  1.1603738397981300e+04
            Stop		  1.3113459795705870e+04
            Strand		 0 35 2 38
            Strand		 0 35 3 38
            Strand		 0 35 4 38
            Strand		 0 35 5 38
            Start		  1.3098732694737739e+04
            Stop		  1.3113459795705870e+04
            Strand		 0 35 6 38
            Start		  4.5181635853688858e+03
            Stop		  5.6400221246945530e+03
            Start		  1.1860574866344492e+04
            Stop		  1.3113459795705870e+04
            Strand		 0 35 7 38
            Strand		 0 35 8 38
            Strand		 0 35 9 38
            Strand		 0 35 10 38
            Strand		 0 35 11 38
            Start		  4.4674510747356926e+03
            Stop		  4.7424042064040304e+03
            Strand		 0 35 12 38
            Strand		 0 35 13 38
            Strand		 0 35 14 38
            Strand		 0 35 15 38
            Start		  5.1628713132146759e+03
            Stop		  5.6486717057880487e+03
            Start		  1.2866592998418269e+04
            Stop		  1.3113459795705870e+04
            Strand		 0 35 16 38
            Start		  4.5832037106623648e+03
            Stop		  5.4589789181041133e+03
            Start		  1.1701966788488988e+04
            Stop		  1.2839834763058099e+04
            Strand		 0 35 17 38
            Start		  1.1603738397981300e+04
            Stop		  1.1619568004013641e+04
            Strand		 0 35 18 38
            Strand		 0 35 19 38
            Strand		 0 35 20 38
            Start		  1.3089338568703177e+04
            Stop		  1.3113459795705870e+04
            Strand		 0 35 21 38
            Strand		 0 35 22 38
            Strand		 0 35 23 38
            Strand		 0 35 24 38
            Strand		 0 35 25 38
            Strand		 0 35 26 38
            Strand		 0 35 27 38
            Strand		 0 35 28 38
            Strand		 0 35 29 38
            Strand		 0 35 30 38
            Strand		 0 35 31 38
            Strand		 0 35 32 38
            Strand		 0 35 33 38
            Strand		 0 35 34 38
            Strand		 0 35 35 38
            Start		  5.3725548938167321e+03
            Stop		  5.6486717057880487e+03
            Strand		 0 35 36 38
            Start		  4.1204676610681945e+03
            Stop		  5.4936786264992807e+03
            Strand		 0 35 37 38
            Strand		 0 36 1 38
            Start		  2.8683017701636932e+03
            Stop		  4.3839511601559752e+03
            Start		  1.0356840672274904e+04
            Stop		  1.1886919943271045e+04
            Strand		 0 36 2 38
            Strand		 0 36 3 38
            Strand		 0 36 4 38
            Strand		 0 36 5 38
            Strand		 0 36 6 38
            Start		  1.1860574866344492e+04
            Stop		  1.1886919943271045e+04
            Strand		 0 36 7 38
            Start		  3.3113224481488905e+03
            Stop		  4.2855809953814642e+03
            Start		  1.0626930780401957e+04
            Stop		  1.1886919943271045e+04
            Strand		 0 36 8 38
            Strand		 0 36 9 38
            Strand		 0 36 10 38
            Strand		 0 36 11 38
            Strand		 0 36 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.6155442936893587e+03
            Strand		 0 36 13 38
            Strand		 0 36 14 38
            Strand		 0 36 15 38
            Strand		 0 36 16 38
            Start		  3.9202250979255800e+03
            Stop		  4.3839511601559752e+03
            Start		  1.1545819764440092e+04
            Stop		  1.1886919943271045e+04
            Strand		 0 36 17 38
            Start		  3.3967397115430322e+03
            Stop		  4.2124208437663774e+03
            Start		  1.0515504979195053e+04
            Stop		  1.1619568004013641e+04
            Strand		 0 36 18 38
            Start		  1.0356840672274904e+04
            Stop		  1.0395472758638833e+04
            Strand		 0 36 19 38
            Strand		 0 36 20 38
            Strand		 0 36 21 38
            Strand		 0 36 22 38
            Strand		 0 36 23 38
            Strand		 0 36 24 38
            Strand		 0 36 25 38
            Strand		 0 36 26 38
            Strand		 0 36 27 38
            Strand		 0 36 28 38
            Strand		 0 36 29 38
            Strand		 0 36 30 38
            Strand		 0 36 31 38
            Strand		 0 36 32 38
            Strand		 0 36 33 38
            Strand		 0 36 34 38
            Strand		 0 36 35 38
            Strand		 0 36 36 38
            Start		  4.0912143238830004e+03
            Stop		  4.3839511601559752e+03
            Strand		 0 36 37 38
            Start		  2.8683017701636932e+03
            Stop		  4.2883771574587045e+03
            Strand		 0 37 1 38
            Start		  1.6132692767456565e+03
            Stop		  3.1152658456884574e+03
            Start		  9.1107747116018581e+03
            Stop		  1.0652631105083230e+04
            Strand		 0 37 2 38
            Start		  2.1149632195889831e+03
            Stop		  2.9019829226343904e+03
            Start		  9.3973319735515688e+03
            Stop		  1.0652631105083230e+04
            Strand		 0 37 3 38
            Strand		 0 37 4 38
            Strand		 0 37 5 38
            Strand		 0 37 6 38
            Strand		 0 37 7 38
            Start		  1.0626930780401957e+04
            Stop		  1.0652631105083230e+04
            Strand		 0 37 8 38
            Strand		 0 37 9 38
            Strand		 0 37 10 38
            Strand		 0 37 11 38
            Strand		 0 37 12 38
            Start		  2.9801742755726200e+03
            Stop		  3.1152658456884574e+03
            Strand		 0 37 13 38
            Start		  1.6132692767456565e+03
            Stop		  2.4312549985318733e+03
            Strand		 0 37 14 38
            Strand		 0 37 15 38
            Strand		 0 37 16 38
            Strand		 0 37 17 38
            Start		  2.6873265302893583e+03
            Stop		  3.1152658456884574e+03
            Start		  1.0242478496301919e+04
            Stop		  1.0652631105083230e+04
            Strand		 0 37 18 38
            Start		  2.2102819227931491e+03
            Stop		  2.9590350715293180e+03
            Start		  9.3290443910175709e+03
            Stop		  1.0395472758638833e+04
            Strand		 0 37 19 38
            Start		  9.1107747116018581e+03
            Stop		  9.1676325534052175e+03
            Strand		 0 37 20 38
            Strand		 0 37 21 38
            Strand		 0 37 22 38
            Strand		 0 37 23 38
            Strand		 0 37 24 38
            Strand		 0 37 25 38
            Strand		 0 37 26 38
            Strand		 0 37 27 38
            Strand		 0 37 28 38
            Strand		 0 37 29 38
            Strand		 0 37 30 38
            Strand		 0 37 31 38
            Strand		 0 37 32 38
            Start		  1.6132692767456565e+03
            Stop		  3.0718833329730119e+03
            Start		  9.3759467997114352e+03
            Stop		  1.0112033488972374e+04
            Strand		 0 37 33 38
            Strand		 0 37 34 38
            Strand		 0 37 35 38
            Strand		 0 37 36 38
            Strand		 0 37 37 38
            Start		  2.8227895322559370e+03
            Stop		  3.1152658456884574e+03
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
            BEGIN ShortText

            END ShortText
            BEGIN LongText

            END LongText
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #00ff00
                AnimationColor		 #00ffff
                AnimationLineWidth		 2
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 On
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

