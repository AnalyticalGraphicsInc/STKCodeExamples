stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN Chain

    Name		 Chain1Hop
    BEGIN Definition

        Object		 Constellation/Network1Places
        Object		 Constellation/Sats
        Object		 Constellation/Network2Places
        Type		 Chain
        FromOperator		 Or
        FromOrder		 1
        ToOperator		 Or
        ToOrder		 1
        Recompute		 Yes
        IntervalType		 0
        ComputeIntervalStart		 0
        ComputeIntervalStop		 86760
        ComputeIntervalPtr		
        BEGIN EVENTINTERVAL
            BEGIN Interval
                Start		 3 Dec 2019 04:00:00.000000000
                Stop		 4 Dec 2019 04:06:00.000000000
            END Interval
            IntervalState		 Explicit
        END EVENTINTERVAL

        ConstConstraintsByStrands		 Yes
        UseSaveIntervalFile		 No
        SaveIntervalFile		 C:\Users\aclaybrook\Documents\STK 12\ConstellationAnalysisScenarios\ChainPath\strand.int
        UseMinAngle		 No
        UseMaxAngle		 No
        UseMinLinkTime		 No
        LTDelayCriterion		 2
        TimeConvergence		 0.005
        AbsValueConvergence		 1e-14
        RelValueConvergence		 1e-08
        MaxTimeStep		 360
        MinTimeStep		 0.01
        UseLightTimeDelay		 Yes
        DetectEventsUsingSamplesOnly		 No
        UseLoadIntervalFile		 No
        BEGIN StrandObjIndexes
            StrandObj		 Place/Network1Place1
            StrandObj		 Place/Network1Place2
            StrandObj		 Place/Network1Place3
            StrandObj		 Place/Network1Place4
            StrandObj		 Place/Network1Place5
            StrandObj		 Satellite/LEO11
            StrandObj		 Satellite/LEO12
            StrandObj		 Satellite/LEO13
            StrandObj		 Satellite/LEO14
            StrandObj		 Satellite/LEO15
            StrandObj		 Satellite/LEO16
            StrandObj		 Satellite/LEO21
            StrandObj		 Satellite/LEO22
            StrandObj		 Satellite/LEO23
            StrandObj		 Satellite/LEO24
            StrandObj		 Satellite/LEO25
            StrandObj		 Satellite/LEO26
            StrandObj		 Satellite/LEO31
            StrandObj		 Satellite/LEO32
            StrandObj		 Satellite/LEO33
            StrandObj		 Satellite/LEO34
            StrandObj		 Satellite/LEO35
            StrandObj		 Satellite/LEO36
            StrandObj		 Satellite/LEO41
            StrandObj		 Satellite/LEO42
            StrandObj		 Satellite/LEO43
            StrandObj		 Satellite/LEO44
            StrandObj		 Satellite/LEO45
            StrandObj		 Satellite/LEO46
            StrandObj		 Satellite/LEO51
            StrandObj		 Satellite/LEO52
            StrandObj		 Satellite/LEO53
            StrandObj		 Satellite/LEO54
            StrandObj		 Satellite/LEO55
            StrandObj		 Satellite/LEO56
            StrandObj		 Satellite/LEO61
            StrandObj		 Satellite/LEO62
            StrandObj		 Satellite/LEO63
            StrandObj		 Satellite/LEO64
            StrandObj		 Satellite/LEO65
            StrandObj		 Satellite/LEO66
            StrandObj		 Place/Network2Place1
            StrandObj		 Place/Network2Place2
            StrandObj		 Place/Network2Place3
            StrandObj		 Place/Network2Place4
            StrandObj		 Place/Network2Place5
        END StrandObjIndexes

        SaveMode		 1
        BEGIN StrandAccessesByIndex
            Strand		 0 5 41
            Strand		 0 5 42
            Strand		 0 5 43
            Strand		 0 5 44
            Strand		 0 5 45
            Strand		 0 6 41
            Strand		 0 6 42
            Strand		 0 6 43
            Strand		 0 6 44
            Strand		 0 6 45
            Strand		 0 7 41
            Strand		 0 7 42
            Strand		 0 7 43
            Strand		 0 7 44
            Strand		 0 7 45
            Strand		 0 8 41
            Strand		 0 8 42
            Strand		 0 8 43
            Strand		 0 8 44
            Strand		 0 8 45
            Strand		 0 9 41
            Strand		 0 9 42
            Strand		 0 9 43
            Strand		 0 9 44
            Strand		 0 9 45
            Strand		 0 10 41
            Strand		 0 10 42
            Strand		 0 10 43
            Strand		 0 10 44
            Strand		 0 10 45
            Strand		 0 11 41
            Strand		 0 11 42
            Strand		 0 11 43
            Strand		 0 11 44
            Strand		 0 11 45
            Strand		 0 12 41
            Strand		 0 12 42
            Strand		 0 12 43
            Strand		 0 12 44
            Strand		 0 12 45
            Strand		 0 13 41
            Strand		 0 13 42
            Strand		 0 13 43
            Strand		 0 13 44
            Strand		 0 13 45
            Strand		 0 14 41
            Strand		 0 14 42
            Strand		 0 14 43
            Strand		 0 14 44
            Strand		 0 14 45
            Strand		 0 15 41
            Strand		 0 15 42
            Strand		 0 15 43
            Strand		 0 15 44
            Strand		 0 15 45
            Strand		 0 16 41
            Strand		 0 16 42
            Strand		 0 16 43
            Strand		 0 16 44
            Strand		 0 16 45
            Strand		 0 17 41
            Strand		 0 17 42
            Strand		 0 17 43
            Strand		 0 17 44
            Strand		 0 17 45
            Strand		 0 18 41
            Strand		 0 18 42
            Strand		 0 18 43
            Strand		 0 18 44
            Strand		 0 18 45
            Strand		 0 19 41
            Strand		 0 19 42
            Strand		 0 19 43
            Strand		 0 19 44
            Strand		 0 19 45
            Strand		 0 20 41
            Strand		 0 20 42
            Strand		 0 20 43
            Strand		 0 20 44
            Strand		 0 20 45
            Strand		 0 21 41
            Strand		 0 21 42
            Strand		 0 21 43
            Strand		 0 21 44
            Strand		 0 21 45
            Strand		 0 22 41
            Strand		 0 22 42
            Strand		 0 22 43
            Strand		 0 22 44
            Strand		 0 22 45
            Strand		 0 23 41
            Strand		 0 23 42
            Strand		 0 23 43
            Strand		 0 23 44
            Strand		 0 23 45
            Strand		 0 24 41
            Strand		 0 24 42
            Strand		 0 24 43
            Strand		 0 24 44
            Strand		 0 24 45
            Strand		 0 25 41
            Strand		 0 25 42
            Strand		 0 25 43
            Strand		 0 25 44
            Strand		 0 25 45
            Strand		 0 26 41
            Strand		 0 26 42
            Strand		 0 26 43
            Strand		 0 26 44
            Strand		 0 26 45
            Strand		 0 27 41
            Strand		 0 27 42
            Strand		 0 27 43
            Strand		 0 27 44
            Strand		 0 27 45
            Strand		 0 28 41
            Strand		 0 28 42
            Strand		 0 28 43
            Strand		 0 28 44
            Strand		 0 28 45
            Strand		 0 29 41
            Strand		 0 29 42
            Strand		 0 29 43
            Strand		 0 29 44
            Strand		 0 29 45
            Strand		 0 30 41
            Strand		 0 30 42
            Strand		 0 30 43
            Strand		 0 30 44
            Strand		 0 30 45
            Strand		 0 31 41
            Strand		 0 31 42
            Strand		 0 31 43
            Strand		 0 31 44
            Strand		 0 31 45
            Strand		 0 32 41
            Strand		 0 32 42
            Strand		 0 32 43
            Strand		 0 32 44
            Strand		 0 32 45
            Strand		 0 33 41
            Strand		 0 33 42
            Strand		 0 33 43
            Strand		 0 33 44
            Strand		 0 33 45
            Strand		 0 34 41
            Strand		 0 34 42
            Strand		 0 34 43
            Strand		 0 34 44
            Strand		 0 34 45
            Strand		 0 35 41
            Strand		 0 35 42
            Strand		 0 35 43
            Strand		 0 35 44
            Strand		 0 35 45
            Strand		 0 36 41
            Strand		 0 36 42
            Strand		 0 36 43
            Strand		 0 36 44
            Strand		 0 36 45
            Strand		 0 37 41
            Strand		 0 37 42
            Strand		 0 37 43
            Strand		 0 37 44
            Strand		 0 37 45
            Strand		 0 38 41
            Strand		 0 38 42
            Strand		 0 38 43
            Strand		 0 38 44
            Strand		 0 38 45
            Strand		 0 39 41
            Strand		 0 39 42
            Strand		 0 39 43
            Strand		 0 39 44
            Strand		 0 39 45
            Strand		 0 40 41
            Strand		 0 40 42
            Strand		 0 40 43
            Strand		 0 40 44
            Strand		 0 40 45
            Strand		 1 5 41
            Strand		 1 5 42
            Strand		 1 5 43
            Strand		 1 5 44
            Strand		 1 5 45
            Strand		 1 6 41
            Strand		 1 6 42
            Strand		 1 6 43
            Strand		 1 6 44
            Strand		 1 6 45
            Strand		 1 7 41
            Strand		 1 7 42
            Strand		 1 7 43
            Strand		 1 7 44
            Strand		 1 7 45
            Strand		 1 8 41
            Strand		 1 8 42
            Strand		 1 8 43
            Strand		 1 8 44
            Strand		 1 8 45
            Strand		 1 9 41
            Strand		 1 9 42
            Strand		 1 9 43
            Strand		 1 9 44
            Strand		 1 9 45
            Strand		 1 10 41
            Strand		 1 10 42
            Strand		 1 10 43
            Strand		 1 10 44
            Strand		 1 10 45
            Strand		 1 11 41
            Strand		 1 11 42
            Strand		 1 11 43
            Strand		 1 11 44
            Strand		 1 11 45
            Strand		 1 12 41
            Strand		 1 12 42
            Strand		 1 12 43
            Strand		 1 12 44
            Strand		 1 12 45
            Strand		 1 13 41
            Strand		 1 13 42
            Strand		 1 13 43
            Strand		 1 13 44
            Strand		 1 13 45
            Strand		 1 14 41
            Strand		 1 14 42
            Strand		 1 14 43
            Strand		 1 14 44
            Strand		 1 14 45
            Strand		 1 15 41
            Strand		 1 15 42
            Strand		 1 15 43
            Strand		 1 15 44
            Strand		 1 15 45
            Strand		 1 16 41
            Strand		 1 16 42
            Strand		 1 16 43
            Strand		 1 16 44
            Strand		 1 16 45
            Strand		 1 17 41
            Strand		 1 17 42
            Strand		 1 17 43
            Strand		 1 17 44
            Strand		 1 17 45
            Strand		 1 18 41
            Strand		 1 18 42
            Strand		 1 18 43
            Strand		 1 18 44
            Strand		 1 18 45
            Strand		 1 19 41
            Strand		 1 19 42
            Strand		 1 19 43
            Strand		 1 19 44
            Strand		 1 19 45
            Strand		 1 20 41
            Strand		 1 20 42
            Strand		 1 20 43
            Strand		 1 20 44
            Strand		 1 20 45
            Strand		 1 21 41
            Strand		 1 21 42
            Strand		 1 21 43
            Strand		 1 21 44
            Strand		 1 21 45
            Strand		 1 22 41
            Strand		 1 22 42
            Strand		 1 22 43
            Strand		 1 22 44
            Strand		 1 22 45
            Strand		 1 23 41
            Strand		 1 23 42
            Strand		 1 23 43
            Strand		 1 23 44
            Strand		 1 23 45
            Strand		 1 24 41
            Strand		 1 24 42
            Strand		 1 24 43
            Strand		 1 24 44
            Strand		 1 24 45
            Strand		 1 25 41
            Strand		 1 25 42
            Strand		 1 25 43
            Strand		 1 25 44
            Strand		 1 25 45
            Strand		 1 26 41
            Strand		 1 26 42
            Strand		 1 26 43
            Strand		 1 26 44
            Strand		 1 26 45
            Strand		 1 27 41
            Strand		 1 27 42
            Strand		 1 27 43
            Strand		 1 27 44
            Strand		 1 27 45
            Strand		 1 28 41
            Strand		 1 28 42
            Strand		 1 28 43
            Strand		 1 28 44
            Strand		 1 28 45
            Strand		 1 29 41
            Strand		 1 29 42
            Strand		 1 29 43
            Strand		 1 29 44
            Strand		 1 29 45
            Strand		 1 30 41
            Strand		 1 30 42
            Strand		 1 30 43
            Strand		 1 30 44
            Strand		 1 30 45
            Strand		 1 31 41
            Strand		 1 31 42
            Strand		 1 31 43
            Strand		 1 31 44
            Strand		 1 31 45
            Strand		 1 32 41
            Strand		 1 32 42
            Strand		 1 32 43
            Strand		 1 32 44
            Strand		 1 32 45
            Strand		 1 33 41
            Strand		 1 33 42
            Strand		 1 33 43
            Strand		 1 33 44
            Strand		 1 33 45
            Strand		 1 34 41
            Strand		 1 34 42
            Strand		 1 34 43
            Strand		 1 34 44
            Strand		 1 34 45
            Strand		 1 35 41
            Strand		 1 35 42
            Strand		 1 35 43
            Strand		 1 35 44
            Strand		 1 35 45
            Strand		 1 36 41
            Strand		 1 36 42
            Strand		 1 36 43
            Strand		 1 36 44
            Strand		 1 36 45
            Strand		 1 37 41
            Strand		 1 37 42
            Strand		 1 37 43
            Strand		 1 37 44
            Strand		 1 37 45
            Strand		 1 38 41
            Strand		 1 38 42
            Strand		 1 38 43
            Strand		 1 38 44
            Strand		 1 38 45
            Strand		 1 39 41
            Strand		 1 39 42
            Strand		 1 39 43
            Strand		 1 39 44
            Strand		 1 39 45
            Strand		 1 40 41
            Strand		 1 40 42
            Strand		 1 40 43
            Strand		 1 40 44
            Strand		 1 40 45
            Strand		 2 5 41
            Strand		 2 5 42
            Strand		 2 5 43
            Strand		 2 5 44
            Strand		 2 5 45
            Start		  2.8249507117562454e+04
            Stop		  2.8277976796009407e+04
            Strand		 2 6 41
            Strand		 2 6 42
            Strand		 2 6 43
            Strand		 2 6 44
            Strand		 2 6 45
            Start		  2.7183494522059089e+04
            Stop		  2.7199555094368327e+04
            Strand		 2 7 41
            Strand		 2 7 42
            Strand		 2 7 43
            Strand		 2 7 44
            Strand		 2 7 45
            Start		  7.3622307259381967e+04
            Stop		  7.3645186370670563e+04
            Strand		 2 8 41
            Strand		 2 8 42
            Strand		 2 8 43
            Strand		 2 8 44
            Strand		 2 8 45
            Start		  7.2591517940184087e+04
            Stop		  7.2630528321017351e+04
            Strand		 2 9 41
            Strand		 2 9 42
            Strand		 2 9 43
            Strand		 2 9 44
            Strand		 2 9 45
            Start		  7.1584185626471808e+04
            Stop		  7.1593503567849431e+04
            Strand		 2 10 41
            Strand		 2 10 42
            Strand		 2 10 43
            Strand		 2 10 44
            Strand		 2 10 45
            Start		  2.9325033123943540e+04
            Stop		  2.9348160966619726e+04
            Strand		 2 11 41
            Strand		 2 11 42
            Strand		 2 11 43
            Strand		 2 11 44
            Strand		 2 11 45
            Strand		 2 12 41
            Strand		 2 12 42
            Strand		 2 12 43
            Strand		 2 12 44
            Strand		 2 12 45
            Strand		 2 13 41
            Strand		 2 13 42
            Strand		 2 13 43
            Strand		 2 13 44
            Strand		 2 13 45
            Start		  8.6103938472484006e+04
            Stop		  8.6127083256230806e+04
            Strand		 2 14 41
            Strand		 2 14 42
            Strand		 2 14 43
            Strand		 2 14 44
            Strand		 2 14 45
            Start		  4.3869879572916296e+04
            Stop		  4.3888021211811836e+04
            Strand		 2 15 41
            Strand		 2 15 42
            Strand		 2 15 43
            Strand		 2 15 44
            Strand		 2 15 45
            Start		  2.0010893197142545e+03
            Stop		  2.0375063074924124e+03
            Start		  4.2791736864327278e+04
            Stop		  4.2820465304551188e+04
            Strand		 2 16 41
            Strand		 2 16 42
            Strand		 2 16 43
            Strand		 2 16 44
            Strand		 2 16 45
            Start		  9.8006276525622377e+02
            Stop		  1.0108138724904518e+03
            Start		  4.1722780647167310e+04
            Stop		  4.1744383883370676e+04
            Strand		 2 17 41
            Strand		 2 17 42
            Strand		 2 17 43
            Strand		 2 17 44
            Strand		 2 17 45
            Strand		 2 18 41
            Strand		 2 18 42
            Strand		 2 18 43
            Strand		 2 18 44
            Strand		 2 18 45
            Start		  5.8415455063140369e+04
            Stop		  5.8427027159242061e+04
            Strand		 2 19 41
            Strand		 2 19 42
            Strand		 2 19 43
            Strand		 2 19 44
            Strand		 2 19 45
            Start		  1.6532001115736439e+04
            Stop		  1.6561388305563305e+04
            Start		  5.7334761649222179e+04
            Stop		  5.7362212689235996e+04
            Strand		 2 20 41
            Strand		 2 20 42
            Strand		 2 20 43
            Strand		 2 20 44
            Strand		 2 20 45
            Start		  1.5504697600461193e+04
            Stop		  1.5541771018595180e+04
            Start		  5.6262983380251062e+04
            Stop		  5.6288546768572487e+04
            Strand		 2 21 41
            Strand		 2 21 42
            Strand		 2 21 43
            Strand		 2 21 44
            Strand		 2 21 45
            Start		  5.5201284233967221e+04
            Stop		  5.5206987831965380e+04
            Strand		 2 22 41
            Strand		 2 22 42
            Strand		 2 22 43
            Strand		 2 22 44
            Strand		 2 22 45
            Strand		 2 23 41
            Strand		 2 23 42
            Strand		 2 23 43
            Strand		 2 23 44
            Strand		 2 23 45
            Start		  3.1064335065812949e+04
            Stop		  3.1082257470672761e+04
            Start		  7.1878568735560999e+04
            Stop		  7.1903191047479311e+04
            Strand		 2 24 41
            Strand		 2 24 42
            Strand		 2 24 43
            Strand		 2 24 44
            Strand		 2 24 45
            Start		  3.0031500430406737e+04
            Stop		  3.0070980939761637e+04
            Start		  7.0804060647091479e+04
            Stop		  7.0832021743997524e+04
            Strand		 2 25 41
            Strand		 2 25 42
            Strand		 2 25 43
            Strand		 2 25 44
            Strand		 2 25 45
            Start		  2.9020840567194235e+04
            Stop		  2.9036010125418892e+04
            Start		  6.9739215854575188e+04
            Stop		  6.9752719664903445e+04
            Strand		 2 26 41
            Strand		 2 26 42
            Strand		 2 26 43
            Strand		 2 26 44
            Strand		 2 26 45
            Strand		 2 27 41
            Strand		 2 27 42
            Strand		 2 27 43
            Strand		 2 27 44
            Strand		 2 27 45
            Strand		 2 28 41
            Strand		 2 28 42
            Strand		 2 28 43
            Strand		 2 28 44
            Strand		 2 28 45
            Start		  7.2961758278622045e+04
            Stop		  7.2965139519583128e+04
            Strand		 2 29 41
            Strand		 2 29 42
            Strand		 2 29 43
            Strand		 2 29 44
            Strand		 2 29 45
            Start		  4.3541800663470443e+04
            Stop		  4.3569057270543301e+04
            Start		  8.4278138114285757e+04
            Stop		  8.4297805359309845e+04
            Strand		 2 30 41
            Strand		 2 30 42
            Strand		 2 30 43
            Strand		 2 30 44
            Strand		 2 30 45
            Start		  1.3167340793106252e+03
            Stop		  1.3325481516303325e+03
            Strand		 2 31 41
            Strand		 2 31 42
            Strand		 2 31 43
            Strand		 2 31 44
            Strand		 2 31 45
            Start		  2.3760636258017252e+02
            Stop		  2.6602560197432103e+02
            Strand		 2 32 41
            Strand		 2 32 42
            Strand		 2 32 43
            Strand		 2 32 44
            Strand		 2 32 45
            Strand		 2 33 41
            Strand		 2 33 42
            Strand		 2 33 43
            Strand		 2 33 44
            Strand		 2 33 45
            Start		  4.5597958117055416e+04
            Stop		  4.5599330811708984e+04
            Start		  8.6423129260502930e+04
            Stop		  8.6443368488620399e+04
            Strand		 2 34 41
            Strand		 2 34 42
            Strand		 2 34 43
            Strand		 2 34 44
            Strand		 2 34 45
            Start		  4.4560181364274271e+04
            Stop		  4.4598198913762004e+04
            Start		  8.5345977021142200e+04
            Stop		  8.5374792176305782e+04
            Strand		 2 35 41
            Strand		 2 35 42
            Strand		 2 35 43
            Strand		 2 35 44
            Strand		 2 35 45
            Start		  1.4780938924270427e+04
            Stop		  1.4807485923412178e+04
            Strand		 2 36 41
            Strand		 2 36 42
            Strand		 2 36 43
            Strand		 2 36 44
            Strand		 2 36 45
            Start		  1.3708100719079201e+04
            Stop		  1.3734771440134256e+04
            Strand		 2 37 41
            Strand		 2 37 42
            Strand		 2 37 43
            Strand		 2 37 44
            Strand		 2 37 45
            Start		  1.2645177402041281e+04
            Stop		  1.2654063744894280e+04
            Strand		 2 38 41
            Strand		 2 38 42
            Strand		 2 38 43
            Strand		 2 38 44
            Strand		 2 38 45
            Start		  5.9090503626194099e+04
            Stop		  5.9123084033025676e+04
            Strand		 2 39 41
            Strand		 2 39 42
            Strand		 2 39 43
            Strand		 2 39 44
            Strand		 2 39 45
            Start		  5.8065509860476224e+04
            Stop		  5.8100627964322732e+04
            Strand		 2 40 41
            Strand		 2 40 42
            Strand		 2 40 43
            Strand		 2 40 44
            Strand		 2 40 45
            Start		  1.5862593604078087e+04
            Stop		  1.5871221256512137e+04
            Strand		 3 5 41
            Strand		 3 5 42
            Strand		 3 5 43
            Strand		 3 5 44
            Strand		 3 5 45
            Strand		 3 6 41
            Strand		 3 6 42
            Strand		 3 6 43
            Strand		 3 6 44
            Strand		 3 6 45
            Strand		 3 7 41
            Strand		 3 7 42
            Strand		 3 7 43
            Strand		 3 7 44
            Strand		 3 7 45
            Strand		 3 8 41
            Strand		 3 8 42
            Strand		 3 8 43
            Strand		 3 8 44
            Strand		 3 8 45
            Strand		 3 9 41
            Strand		 3 9 42
            Strand		 3 9 43
            Strand		 3 9 44
            Strand		 3 9 45
            Strand		 3 10 41
            Strand		 3 10 42
            Strand		 3 10 43
            Strand		 3 10 44
            Strand		 3 10 45
            Strand		 3 11 41
            Strand		 3 11 42
            Strand		 3 11 43
            Strand		 3 11 44
            Strand		 3 11 45
            Strand		 3 12 41
            Strand		 3 12 42
            Strand		 3 12 43
            Strand		 3 12 44
            Strand		 3 12 45
            Strand		 3 13 41
            Strand		 3 13 42
            Strand		 3 13 43
            Strand		 3 13 44
            Strand		 3 13 45
            Strand		 3 14 41
            Strand		 3 14 42
            Strand		 3 14 43
            Strand		 3 14 44
            Strand		 3 14 45
            Strand		 3 15 41
            Strand		 3 15 42
            Strand		 3 15 43
            Strand		 3 15 44
            Strand		 3 15 45
            Strand		 3 16 41
            Strand		 3 16 42
            Strand		 3 16 43
            Strand		 3 16 44
            Strand		 3 16 45
            Strand		 3 17 41
            Strand		 3 17 42
            Strand		 3 17 43
            Strand		 3 17 44
            Strand		 3 17 45
            Strand		 3 18 41
            Strand		 3 18 42
            Strand		 3 18 43
            Strand		 3 18 44
            Strand		 3 18 45
            Strand		 3 19 41
            Strand		 3 19 42
            Strand		 3 19 43
            Strand		 3 19 44
            Strand		 3 19 45
            Strand		 3 20 41
            Strand		 3 20 42
            Strand		 3 20 43
            Strand		 3 20 44
            Strand		 3 20 45
            Strand		 3 21 41
            Strand		 3 21 42
            Strand		 3 21 43
            Strand		 3 21 44
            Strand		 3 21 45
            Strand		 3 22 41
            Strand		 3 22 42
            Strand		 3 22 43
            Strand		 3 22 44
            Strand		 3 22 45
            Strand		 3 23 41
            Strand		 3 23 42
            Strand		 3 23 43
            Strand		 3 23 44
            Strand		 3 23 45
            Strand		 3 24 41
            Strand		 3 24 42
            Strand		 3 24 43
            Strand		 3 24 44
            Strand		 3 24 45
            Strand		 3 25 41
            Strand		 3 25 42
            Strand		 3 25 43
            Strand		 3 25 44
            Strand		 3 25 45
            Strand		 3 26 41
            Strand		 3 26 42
            Strand		 3 26 43
            Strand		 3 26 44
            Strand		 3 26 45
            Strand		 3 27 41
            Strand		 3 27 42
            Strand		 3 27 43
            Strand		 3 27 44
            Strand		 3 27 45
            Strand		 3 28 41
            Strand		 3 28 42
            Strand		 3 28 43
            Strand		 3 28 44
            Strand		 3 28 45
            Strand		 3 29 41
            Strand		 3 29 42
            Strand		 3 29 43
            Strand		 3 29 44
            Strand		 3 29 45
            Strand		 3 30 41
            Strand		 3 30 42
            Strand		 3 30 43
            Strand		 3 30 44
            Strand		 3 30 45
            Strand		 3 31 41
            Strand		 3 31 42
            Strand		 3 31 43
            Strand		 3 31 44
            Strand		 3 31 45
            Strand		 3 32 41
            Strand		 3 32 42
            Strand		 3 32 43
            Strand		 3 32 44
            Strand		 3 32 45
            Strand		 3 33 41
            Strand		 3 33 42
            Strand		 3 33 43
            Strand		 3 33 44
            Strand		 3 33 45
            Strand		 3 34 41
            Strand		 3 34 42
            Strand		 3 34 43
            Strand		 3 34 44
            Strand		 3 34 45
            Strand		 3 35 41
            Strand		 3 35 42
            Strand		 3 35 43
            Strand		 3 35 44
            Strand		 3 35 45
            Strand		 3 36 41
            Strand		 3 36 42
            Strand		 3 36 43
            Strand		 3 36 44
            Strand		 3 36 45
            Strand		 3 37 41
            Strand		 3 37 42
            Strand		 3 37 43
            Strand		 3 37 44
            Strand		 3 37 45
            Strand		 3 38 41
            Strand		 3 38 42
            Strand		 3 38 43
            Strand		 3 38 44
            Strand		 3 38 45
            Strand		 3 39 41
            Strand		 3 39 42
            Strand		 3 39 43
            Strand		 3 39 44
            Strand		 3 39 45
            Strand		 3 40 41
            Strand		 3 40 42
            Strand		 3 40 43
            Strand		 3 40 44
            Strand		 3 40 45
            Strand		 4 5 41
            Strand		 4 5 42
            Strand		 4 5 43
            Strand		 4 5 44
            Strand		 4 5 45
            Strand		 4 6 41
            Strand		 4 6 42
            Strand		 4 6 43
            Strand		 4 6 44
            Strand		 4 6 45
            Strand		 4 7 41
            Strand		 4 7 42
            Strand		 4 7 43
            Strand		 4 7 44
            Strand		 4 7 45
            Strand		 4 8 41
            Strand		 4 8 42
            Strand		 4 8 43
            Strand		 4 8 44
            Strand		 4 8 45
            Strand		 4 9 41
            Strand		 4 9 42
            Strand		 4 9 43
            Strand		 4 9 44
            Strand		 4 9 45
            Strand		 4 10 41
            Strand		 4 10 42
            Strand		 4 10 43
            Strand		 4 10 44
            Strand		 4 10 45
            Strand		 4 11 41
            Strand		 4 11 42
            Strand		 4 11 43
            Strand		 4 11 44
            Strand		 4 11 45
            Strand		 4 12 41
            Strand		 4 12 42
            Strand		 4 12 43
            Strand		 4 12 44
            Strand		 4 12 45
            Strand		 4 13 41
            Strand		 4 13 42
            Strand		 4 13 43
            Strand		 4 13 44
            Strand		 4 13 45
            Strand		 4 14 41
            Strand		 4 14 42
            Strand		 4 14 43
            Strand		 4 14 44
            Strand		 4 14 45
            Strand		 4 15 41
            Strand		 4 15 42
            Strand		 4 15 43
            Strand		 4 15 44
            Strand		 4 15 45
            Strand		 4 16 41
            Strand		 4 16 42
            Strand		 4 16 43
            Strand		 4 16 44
            Strand		 4 16 45
            Strand		 4 17 41
            Strand		 4 17 42
            Strand		 4 17 43
            Strand		 4 17 44
            Strand		 4 17 45
            Strand		 4 18 41
            Strand		 4 18 42
            Strand		 4 18 43
            Strand		 4 18 44
            Strand		 4 18 45
            Strand		 4 19 41
            Strand		 4 19 42
            Strand		 4 19 43
            Strand		 4 19 44
            Strand		 4 19 45
            Strand		 4 20 41
            Strand		 4 20 42
            Strand		 4 20 43
            Strand		 4 20 44
            Strand		 4 20 45
            Strand		 4 21 41
            Strand		 4 21 42
            Strand		 4 21 43
            Strand		 4 21 44
            Strand		 4 21 45
            Strand		 4 22 41
            Strand		 4 22 42
            Strand		 4 22 43
            Strand		 4 22 44
            Strand		 4 22 45
            Strand		 4 23 41
            Strand		 4 23 42
            Strand		 4 23 43
            Strand		 4 23 44
            Strand		 4 23 45
            Strand		 4 24 41
            Strand		 4 24 42
            Strand		 4 24 43
            Strand		 4 24 44
            Strand		 4 24 45
            Strand		 4 25 41
            Strand		 4 25 42
            Strand		 4 25 43
            Strand		 4 25 44
            Strand		 4 25 45
            Strand		 4 26 41
            Strand		 4 26 42
            Strand		 4 26 43
            Strand		 4 26 44
            Strand		 4 26 45
            Strand		 4 27 41
            Strand		 4 27 42
            Strand		 4 27 43
            Strand		 4 27 44
            Strand		 4 27 45
            Strand		 4 28 41
            Strand		 4 28 42
            Strand		 4 28 43
            Strand		 4 28 44
            Strand		 4 28 45
            Strand		 4 29 41
            Strand		 4 29 42
            Strand		 4 29 43
            Strand		 4 29 44
            Strand		 4 29 45
            Strand		 4 30 41
            Strand		 4 30 42
            Strand		 4 30 43
            Strand		 4 30 44
            Strand		 4 30 45
            Strand		 4 31 41
            Strand		 4 31 42
            Strand		 4 31 43
            Strand		 4 31 44
            Strand		 4 31 45
            Strand		 4 32 41
            Strand		 4 32 42
            Strand		 4 32 43
            Strand		 4 32 44
            Strand		 4 32 45
            Strand		 4 33 41
            Strand		 4 33 42
            Strand		 4 33 43
            Strand		 4 33 44
            Strand		 4 33 45
            Strand		 4 34 41
            Strand		 4 34 42
            Strand		 4 34 43
            Strand		 4 34 44
            Strand		 4 34 45
            Strand		 4 35 41
            Strand		 4 35 42
            Strand		 4 35 43
            Strand		 4 35 44
            Strand		 4 35 45
            Strand		 4 36 41
            Strand		 4 36 42
            Strand		 4 36 43
            Strand		 4 36 44
            Strand		 4 36 45
            Strand		 4 37 41
            Strand		 4 37 42
            Strand		 4 37 43
            Strand		 4 37 44
            Strand		 4 37 45
            Strand		 4 38 41
            Strand		 4 38 42
            Strand		 4 38 43
            Strand		 4 38 44
            Strand		 4 38 45
            Strand		 4 39 41
            Strand		 4 39 42
            Strand		 4 39 43
            Strand		 4 39 44
            Strand		 4 39 45
            Strand		 4 40 41
            Strand		 4 40 42
            Strand		 4 40 43
            Strand		 4 40 44
            Strand		 4 40 45
        END StrandAccessesByIndex


    END Definition

    BEGIN Extensions

        BEGIN ExternData
            BEGIN DataGroup

                GroupName		 NetworkData

                NumberOfPoints		 361
                BlockFactor		 50

                ThinningInterval		 0

                ReferenceEpoch		 3 Dec 2019 04:00:00.000000000

                BEGIN DataElement
                    Name		 numcenters
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 minnumhops
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 numnodesw/maxdegree
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 maxnumedges
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 minnodestoloseaccesstoall
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 numofsetstoloseaccesstoall
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 minnodestoloseaccesstoany
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 numofsetstoloseaccesstoany
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 totnumnodes
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 totnumedges
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN DataElement
                    Name		 totnumstrands
                    InterpOrder		 1
                    DataType		 REAL
                END DataElement

                BEGIN Data
                     0.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     4.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     6.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     7.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     8.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     9.0000000000000000e+01  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.0000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.1000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.2000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.3000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.5000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.6000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.7000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.8000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.9000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0000000000000000e+02  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1000000000000000e+02  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.2000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.3000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.1000000000000000e+01  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  4.0000000000000000e+00  2.0000000000000000e+01  4.0000000000000000e+01  4.0000000000000000e+01
                     2.5000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.1000000000000000e+01  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  4.0000000000000000e+00  2.0000000000000000e+01  4.0000000000000000e+01  4.0000000000000000e+01
                     2.6000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.1000000000000000e+01  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+01  3.9000000000000000e+01  3.9000000000000000e+01
                     2.7000000000000000e+02  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     2.8000000000000000e+02  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     2.9000000000000000e+02  4.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     3.0000000000000000e+02  4.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     3.1000000000000000e+02  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     3.2000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     3.3000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.7000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     3.4000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.7000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     3.5000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.7000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     3.6000000000000000e+02  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.7000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     3.7000000000000000e+02  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     3.8000000000000000e+02  1.1000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     3.9000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     4.0000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     4.1000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     4.2000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     4.3000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     4.4000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     4.5000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     4.6000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     4.7000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     4.8000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     4.9000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     5.0000000000000000e+02  1.2000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     5.1000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     5.2000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     5.3000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     5.4000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.5000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.6000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.7000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.8000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     5.9000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     6.0000000000000000e+02  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     6.1000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     6.2000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     6.3000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     6.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     6.5000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     6.6000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     6.7000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     6.8000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     6.9000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     7.0000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     7.1000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     7.2000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.3000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.5000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.6000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.7000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     7.8000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     7.9000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     8.0000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     8.1000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     8.2000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     8.3000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.5000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.6000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.7000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.8000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     8.9000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.0000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.1000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.2000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.3000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.4000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.5000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.6000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.7000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.8000000000000000e+02  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     9.9000000000000000e+02  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     1.0000000000000000e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     1.0100000000000000e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     1.0200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.0300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.0400000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.0500000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.0600000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.0700000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.0800000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.0900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.1000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1100000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1400000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1500000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1600000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.1700000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.1800000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.1900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.2000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.2100000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.2200000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.2300000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.2400000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.2500000000000000e+03  1.0000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.2600000000000000e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     1.2700000000000000e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     1.2800000000000000e+03  1.0000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.2900000000000000e+03  1.0000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.3000000000000000e+03  1.0000000000000000e+01  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     1.3100000000000000e+03  7.0000000000000000e+00  2.0000000000000000e+00  4.0000000000000000e+00  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     1.3200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.2000000000000000e+01  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  4.0000000000000000e+00  2.1000000000000000e+01  4.1000000000000000e+01  4.1000000000000000e+01
                     1.3300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.2000000000000000e+01  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  4.0000000000000000e+00  2.1000000000000000e+01  4.1000000000000000e+01  4.1000000000000000e+01
                     1.3400000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.9000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     1.3500000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.9000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     1.3600000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.9000000000000000e+01  3.1000000000000000e+01  3.1000000000000000e+01
                     1.3700000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     1.3800000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     1.3900000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.1000000000000000e+01  3.1000000000000000e+01
                     1.4000000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.1000000000000000e+01  3.1000000000000000e+01
                     1.4100000000000000e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.8000000000000000e+01  3.0000000000000000e+01  3.0000000000000000e+01
                     1.4200000000000000e+03  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.4300000000000000e+03  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.4400000000000000e+03  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     1.4500000000000000e+03  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     1.4600000000000000e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.4700000000000000e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     1.4800000000000000e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     1.4900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.5000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.5100000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.5200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.5300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.5400000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.5500000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.5600000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.5700000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.5800000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.5900000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.6000000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.6100000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.6200000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.6300000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.6400000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     1.6500000000000000e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.6600000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.6700000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.6800000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.6900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.7000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     1.7100000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.7200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.7300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     1.7400000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.7500000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.7600000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.7700000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.7800000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.7900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.8000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.8100000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.8200000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.8300000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     1.8400000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     1.8500000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.8600000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.8700000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.8800000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.8900000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.9000000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.9100000000000000e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.9200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.9300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     1.9400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.9500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.9600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.9700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.9800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     1.9900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     2.0000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     2.0100000000000018e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     2.0200000000000018e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     2.0300000000000018e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.6000000000000000e+01  3.3000000000000000e+01  3.3000000000000000e+01
                     2.0400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.0900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.1400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.1500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.1600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.1700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.1800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.1900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.2000000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2100000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2200000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2300000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2400000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2500000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.2600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.2700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.2800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     2.2900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     2.3000000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.6000000000000000e+01  1.6000000000000000e+01
                     2.3100000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.6000000000000000e+01  1.6000000000000000e+01
                     2.3200000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.6000000000000000e+01  1.6000000000000000e+01
                     2.3300000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.6000000000000000e+01  1.6000000000000000e+01
                     2.3400000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.6000000000000000e+01  1.6000000000000000e+01
                     2.3500000000000018e+03  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.2000000000000000e+01  1.5000000000000000e+01  1.5000000000000000e+01
                     2.3600000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     2.3700000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.3800000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.3900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  9.0000000000000000e+00  9.0000000000000000e+00
                     2.4000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  9.0000000000000000e+00  9.0000000000000000e+00
                     2.4100000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.4200000000000018e+03  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.4300000000000018e+03  1.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  1.9000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.4400000000000018e+03  1.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  1.0000000000000000e+00  5.0000000000000000e+00  1.9000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     2.4500000000000018e+03  1.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  1.0000000000000000e+00  4.0000000000000000e+00  1.9000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     2.4600000000000018e+03  1.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  4.0000000000000000e+00  4.0000000000000000e+00  1.0000000000000000e+00  4.0000000000000000e+00  1.9000000000000000e+01  2.9000000000000000e+01  2.9000000000000000e+01
                     2.4700000000000018e+03  2.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     2.4800000000000018e+03  3.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.4900000000000018e+03  3.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.5000000000000018e+03  3.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.5100000000000018e+03  3.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     2.5200000000000018e+03  3.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     2.5300000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.6000000000000000e+01  2.8000000000000000e+01  2.8000000000000000e+01
                     2.5400000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.5500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.5600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.5700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.5800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.5900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.6000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.6100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.6200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.6300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.6400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.6500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.6600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.6700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.6800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.6900000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7000000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.7200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     2.7600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  8.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.6000000000000000e+01  2.6000000000000000e+01
                     2.7700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.7900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.8000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     2.8100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     2.8200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.8300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.8400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     2.8500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.8600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.8700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.8800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     2.8900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     2.9000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     2.9900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     3.0000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     3.0100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     3.0200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     3.0300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.6000000000000000e+01  2.7000000000000000e+01  2.7000000000000000e+01
                     3.0400000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.2000000000000000e+01  1.1000000000000000e+01  1.1000000000000000e+01
                     3.0500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     3.0600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     3.0700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.0800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.0900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1600000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.1700000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     3.1800000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     3.1900000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2000000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2100000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2200000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2300000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2400000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.2500000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.2600000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.2700000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     3.2800000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     3.2900000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.2000000000000000e+01  2.2000000000000000e+01
                     3.3000000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.3100000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.3200000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.3300000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.3400000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.1000000000000000e+01  2.1000000000000000e+01
                     3.3500000000000018e+03  1.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  7.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  1.4000000000000000e+01  2.0000000000000000e+01  2.0000000000000000e+01
                     3.3600000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.3700000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  1.4000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     3.3800000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.7000000000000000e+01  1.7000000000000000e+01
                     3.3900000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.7000000000000000e+01  1.7000000000000000e+01
                     3.4000000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.7000000000000000e+01  1.7000000000000000e+01
                     3.4100000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.7000000000000000e+01  1.7000000000000000e+01
                     3.4200000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.4300000000000018e+03  7.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  1.9000000000000000e+01  1.9000000000000000e+01
                     3.4400000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  9.0000000000000000e+00  9.0000000000000000e+00
                     3.4500000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  9.0000000000000000e+00  9.0000000000000000e+00
                     3.4600000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  9.0000000000000000e+00  9.0000000000000000e+00
                     3.4700000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  9.0000000000000000e+00  8.0000000000000000e+00  8.0000000000000000e+00
                     3.4800000000000018e+03  2.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  2.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  9.0000000000000000e+00  8.0000000000000000e+00  8.0000000000000000e+00
                     3.4900000000000018e+03  3.0000000000000000e+00  1.0000000000000000e+00  3.0000000000000000e+00  5.0000000000000000e+00  1.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.0000000000000000e+01  1.3000000000000000e+01  1.3000000000000000e+01
                     3.5000000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  3.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.5000000000000000e+01  2.5000000000000000e+01
                     3.5100000000000018e+03  8.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     3.5200000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.5300000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.5400000000000018e+03  5.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.5500000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     3.5600000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.5000000000000000e+01  2.4000000000000000e+01  2.4000000000000000e+01
                     3.5700000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.5800000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  2.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.4000000000000000e+01  2.3000000000000000e+01  2.3000000000000000e+01
                     3.5900000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                     3.6000000000000018e+03  4.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  6.0000000000000000e+00  2.0000000000000000e+00  1.0000000000000000e+00  0.0000000000000000e+00  0.0000000000000000e+00  1.3000000000000000e+01  1.8000000000000000e+01  1.8000000000000000e+01
                END Data

            END DataGroup

        END ExternData

        BEGIN ADFFileData
        END ADFFileData

        BEGIN Desc
        END Desc

        BEGIN Crdn
        END Crdn

        BEGIN Graphics

            BEGIN Attributes

                StaticColor		 #ffff00
                AnimationColor		 #00c4c4
                AnimationLineWidth		 2
                StaticLineWidth		 3

            END Attributes

            BEGIN Graphics
                ShowGfx		 Off
                ShowStatic		 Off
                ShowAnimationHighlight		 On
                ShowAnimationLine		 On
                ShowLinkDirection		 Off
            END Graphics
        END Graphics

        BEGIN VO
        END VO

    END Extensions

END Chain

