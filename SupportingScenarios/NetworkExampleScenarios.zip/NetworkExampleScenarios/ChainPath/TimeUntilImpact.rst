stk.v.12.0
WrittenBy    STK_v12.0.0

BEGIN ReportStyle

    BEGIN ClassId
        Class		 Missile
    END ClassId

    BEGIN Header
        StyleType		 0
        Date		 No
        Name		 Yes
        IsHidden		 No
        DescShort		 No
        DescLong		 No
        YLog10		 No
        Y2Log10		 No
        YUseWholeNumbers		 No
        Y2UseWholeNumbers		 No
        VerticalGridLines		 No
        HorizontalGridLines		 No
        AnnotationType		 Spaced
        NumAnnotations		 3
        NumAngularAnnotations		 5
        ShowYAnnotations		 Yes
        AnnotationRotation		 1
        BackgroundColor		 #ffffff
        ForegroundColor		 #000000
        ViewableDuration		 3600
        RealTimeMode		 No
        DayLinesStatus		 1
        LegendStatus		 1
        LegendLocation		 1

        BEGIN PostProcessor
            Destination		 0
            Use		 0
            Destination		 1
            Use		 0
            Destination		 2
            Use		 0
            Destination		 3
            Use		 0
        END PostProcessor
        NumSections		 1
    END Header

    BEGIN Section
        Name		 Section 1
        ClassName		 Missile
        NameInTitle		 No
        ExpandMethod		 0
        PropMask		 2
        ShowIntervals		 No
        NumIntervals		 0
        NumLines		 1

        BEGIN Line
            Name		 Line 1
            NumElements		 2

            BEGIN Element
                Name		 Time
                IsIndepVar		 Yes
                IndepVarName		 Time
                Title		 Time
                NameInTitle		 No
                Service		 CalculateScalar
                Type		 ElapsedTimeFromStop
                Element		 Time
                SumAllowedMask		 0
                SummaryOnly		 No
                DataType		 0
                UnitType		 2
                LineStyle		 0
                LineWidth		 0
                PointStyle		 0
                PointSize		 0
                FillPattern		 0
                LineColor		 #000000
                FillColor		 #000000
                PropMask		 0
                UseScenUnits		 Yes
            END Element

            BEGIN Element
                Name		 Scalar Calculations-ElapsedTimeFromStop-Scalar
                IsIndepVar		 No
                IndepVarName		 Time
                Title		 T-Minus Until Impact
                NameInTitle		 Yes
                Service		 CalculateScalar
                Type		 ElapsedTimeFromStop
                Element		 Scalar
                Format		 %.3f
                SumAllowedMask		 1543
                SummaryOnly		 No
                DataType		 0
                UnitType		 1
                LineStyle		 0
                LineWidth		 0
                PointStyle		 0
                PointSize		 0
                FillPattern		 0
                LineColor		 #000000
                FillColor		 #000000
                PropMask		 0
                BEGIN Event
                    UseEvent		 No
                    EventValue		 0
                    Convergence		 0.002
                    Direction		 Both
                    CreateFile		 No
                END Event
                UseScenUnits		 Yes
            END Element
        END Line
    END Section

    BEGIN LineAnnotations
        BEGIN Line
            ShowAnnotation		 No
            LineType		 2
            LineColor		 #000000
            LineStyle		 0
            LineWidth		 0
            LineValue		 0
            LineUseCurrent		 Yes
            LineShowLabel		 No
            UnitType		 0
        END Line
    END LineAnnotations
END ReportStyle

